# 	$Id$	
# -*- coding: latin-1 -*-
## ********************************************************************************
## dimpossize 
## Copyright (C) 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import unohelper, uno
    import math, traceback
    from com.sun.star.task import XJob
    from com.sun.star.drawing.CircleKind import ARC, FULL
except ImportError:
    print "probleme d'import"
# =====================================
# dessin de cotes
# drawing of measure
# =====================================
class DimPosSize(unohelper.Base, XJob):
    """dessin de cote
    drawing of measure"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
    # ==================================
    # wrapper for the compute functions
    # ==================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # =============================
    # needed from dict env
    # UNOTYPE
    # MODE
    # COORDS
    # ORIGINCOORD
    # SHAPE
    # STEP
    # DIMTYPE
    # DIMSHAPE
    # DIMCOORDS
    # CONTROLLER
    # MODEL
    # ==============================
    def execute(self, aNamedValues):
        aEnv = dict(list(aNamedValues[0].Value))
        aULCCoord = uno.createUnoStruct("com.sun.star.awt.Point")
        aSize = uno.createUnoStruct("com.sun.star.awt.Size")
        aGroupShape = aEnv['%sDIMSHAPE' % aEnv['DIMTYPE']]
        # ++++++++++++++++++++++++
        if not aEnv['DIMVISIBLE']:
            # ---------------------
            if aGroupShape is None:
                # print "%sdimshape will be created" % aEnv['DIMTYPE']
                aGroupShape = aEnv['MODEL'].createInstance("com.sun.star.drawing.GroupShape")
            aEnv['CONTROLLER'].CurrentPage.add(aGroupShape)
            aEnv['DIMVISIBLE'] = True
            # print "%sdimshape added" % aEnv['DIMTYPE']
        # +++++++++++++++++++++++++++++++
        if aEnv['DIMTYPE'] == 'LINEAR': # drawing a linear measure
            # ------------------------ help line 1
            if aGroupShape.Count == 0:
                aShape = aEnv['MODEL'].createInstance("com.sun.star.drawing.LineShape")
                aGroupShape.add(aShape)
                aShape.setName("helpline1")
            else:
                aShape = aGroupShape.getByIndex(0)
            aShape.PolyPolygon = ((aEnv['DIMCOORDS'][0], aEnv['DIMCOORDS'][1]),)
            # ------------------------ base line
            if aGroupShape.Count == 1:
                aShape = aEnv['MODEL'].createInstance("com.sun.star.drawing.LineShape")
                aShape.setName("baseline")
                aGroupShape.add(aShape)
            else:
                aShape = aGroupShape.getByIndex(1)
            aShape.PolyPolygon = ((aEnv['DIMCOORDS'][2], aEnv['DIMCOORDS'][3]),)
            aShape.LineStartName = aShape.LineEndName = "Arrow"
            aShape.LineStartWidth = aShape.LineEndWidth = 200
            # ------------------------ help line 2
            if aGroupShape.Count == 2:
                aShape = aEnv['MODEL'].createInstance("com.sun.star.drawing.LineShape")
                aShape.setName("helpline2")
                aGroupShape.add(aShape)
            else:
                aShape = aGroupShape.getByIndex(2)
            aShape.PolyPolygon = ((aEnv['DIMCOORDS'][4], aEnv['DIMCOORDS'][5]),)
            # ------------------------ text
            if aGroupShape.Count == 3:
                aShape = aEnv['MODEL'].createInstance("com.sun.star.drawing.TextShape")
                aShape.setName("value")
                aGroupShape.add(aShape)
            else:
                aShape = aGroupShape.getByIndex(3)
            fAngle1 = self.compute("toPolarCoord", aEnv['DIMCOORDS'][2], aEnv['DIMCOORDS'][3])[1]
            aSize.Width = 150 * len(aEnv['DIMVALUE'])
            aSize.Height = 250
            aShape.setSize(aSize)
            nDist2 = self.compute("Dist2Line", aEnv['DIMCOORDS'][2], aEnv['DIMCOORDS'][3], aEnv['DIMCOORDS'][6])
            aULCCoord = self.compute("CoordFromAbsOrd",  aEnv['DIMCOORDS'][2],  aEnv['DIMCOORDS'][3], nDist2[0] - aSize.Width / 2, -500)
            aShape.setPosition(aULCCoord)
            # aShape.TextFitToSize = uno.Enum("com.sun.star.drawing.TextFitToSizeType", "NONE ")
            aShape.TextAutoGrowHeight = True
            aShape.TextAutoGrowWidth = True
            aShape.CharHeight = 8
            aShape.RotateAngle = long(fAngle1 * 18000 / math.pi)
            aTextCursor = aShape.createTextCursor()
            aTextCursor.gotoEnd(False)
            aTextCursor.gotoStart(True)
            aShape.insertString(aTextCursor, aEnv['DIMVALUE'], True)
        # ++++++++++++++++++++++++++++++++
        elif aEnv['DIMTYPE'] == 'ANGULAR': # drawing an angular measure 
            # ------------------------ arc baseline
            if aGroupShape.Count == 0:
                aShape = aEnv['MODEL'].createInstance("com.sun.star.drawing.EllipseShape")
                aGroupShape.add(aShape)
                aShape.setName("baseline")
            else:
                aShape = aGroupShape.getByIndex(0)
            fAngle1 = self.compute("toPolarCoord", aEnv['DIMCOORDS'][0], aEnv['DIMCOORDS'][2])[1]
            fAngle2 = self.compute("toPolarCoord", aEnv['DIMCOORDS'][0], aEnv['DIMCOORDS'][3])[1]
            nRadius, fAngle3 = self.compute("toPolarCoord", aEnv['DIMCOORDS'][0], aEnv['DIMCOORDS'][1])
            aULCCoord.X = aEnv['DIMCOORDS'][0].X - nRadius
            aULCCoord.Y = aEnv['DIMCOORDS'][0].Y - nRadius
            aSize.Width = aSize.Height = 2 * nRadius
            aShape.CircleKind = ARC
            aShape.CircleStartAngle = long(math.degrees(fAngle1) * 100)
            aShape.CircleEndAngle = long(math.degrees(fAngle2) * 100)
            aShape.LineStartName = aShape.LineEndName = "Arrow"
            aShape.LineStartWidth = aShape.LineEndWidth = 200
            aShape.setPosition(aULCCoord)
            aShape.setSize(aSize)
            # ------------------------ value
            if aGroupShape.Count == 1:
                aShape = aEnv['MODEL'].createInstance("com.sun.star.drawing.TextShape")
                aGroupShape.add(aShape)
                aShape.setName("Value")
            else:
                aShape = aGroupShape.getByIndex(1)
            # ------------
            aSize.Width = 150 * len(aEnv['DIMVALUE'])
            aSize.Height = 250
            aShape.setSize(aSize)
            if fAngle3 <= math.pi:
                nSign = 1
            else:
                nSign = -1
            aULCCoord = self.compute("CoordFromAbsOrd",  aEnv['DIMCOORDS'][0],  aEnv['DIMCOORDS'][1], nRadius + nSign * 500, -nSign * aSize.Width / 2)
            aShape.setPosition(aULCCoord)
            # aShape.TextFitToSize = uno.Enum("com.sun.star.drawing.TextFitToSizeType", "NONE")
            aShape.TextAutoGrowHeight = True
            aShape.TextAutoGrowWidth = True
            aShape.CharHeight = 8
            aShape.RotateAngle = long(math.degrees(fAngle3 - nSign * math.pi / 2) * 100) % 36000
            aTextCursor = aShape.createTextCursor()
            aTextCursor.gotoEnd(False)
            aTextCursor.gotoStart(True)
            aShape.insertString(aTextCursor, aEnv['DIMVALUE'], True)
        # +++++++++++++++++++++++++++++++++++++++++++++++
        elif aEnv['DIMTYPE'] in ("RADIAL",  "DIAMETRAL"):
            nRadius = self.compute("toPolarCoord", aEnv['DIMCOORDS'][0], aEnv['DIMCOORDS'][1])[0]
            # ------------------------ 1st helpline
            if aGroupShape.Count == 0:
                aShape = aEnv['MODEL'].createInstance("com.sun.star.drawing.LineShape")
                aGroupShape.add(aShape)
                aShape.setName("helpline1")
            else:
                aShape = aGroupShape.getByIndex(0)
            aShape.PolyPolygon = ((aEnv['DIMCOORDS'][1], aEnv['DIMCOORDS'][2]),)
            aShape.LineStartName = "Arrow"
            aShape.LineStartWidth = 200
            # ------------------------ baseline
            if aGroupShape.Count == 1:
                aShape = aEnv['MODEL'].createInstance("com.sun.star.drawing.LineShape")
                aGroupShape.add(aShape)
                aShape.setName("baseline")
            else:
                aShape = aGroupShape.getByIndex(1)
            # -------------------------------------------------
            if aEnv['DIMCOORDS'][3].X > aEnv['DIMCOORDS'][2].X:
                aEnv['DIMCOORDS'][3].X = aEnv['DIMCOORDS'][2].X + len(aEnv['DIMVALUE']) * 125
            else:
                aEnv['DIMCOORDS'][3].X = aEnv['DIMCOORDS'][2].X - len(aEnv['DIMVALUE']) * 125
            aShape.PolyPolygon = ((aEnv['DIMCOORDS'][2], aEnv['DIMCOORDS'][3]),)
            # ------------------------ value
            if aGroupShape.Count == 2:
                aShape = aEnv['MODEL'].createInstance("com.sun.star.drawing.TextShape")
                aGroupShape.add(aShape)
                aShape.setName("value")
            else:
                aShape = aGroupShape.getByIndex(2)
            # -------------------------------------------------
            if aEnv['DIMCOORDS'][3].X > aEnv['DIMCOORDS'][2].X:
                aULCCoord.X = aEnv['DIMCOORDS'][2].X
                aULCCoord.Y = aEnv['DIMCOORDS'][2].Y - 500
            else:
                aULCCoord.X = aEnv['DIMCOORDS'][3].X
                aULCCoord.Y = aEnv['DIMCOORDS'][3].Y - 500
            aSize.Width = 150 * len(aEnv['DIMVALUE'])
            aSize.Height = 250
            aShape.setPosition(aULCCoord)
            aShape.setSize(aSize)
            # aShape.TextFitToSize = uno.Enum("com.sun.star.drawing.TextFitToSizeType", "NONE")
            aShape.TextAutoGrowHeight = True
            aShape.TextAutoGrowWidth = True
            aShape.CharHeight = 8
            aTextCursor = aShape.createTextCursor()
            aTextCursor.gotoEnd(False)
            aTextCursor.gotoStart(True)
            aShape.insertString(aTextCursor, aEnv['DIMVALUE'], True)
            aShape.setName("Value")
        aGroupShape.setPropertyValue("SizeProtect", True)
        aGroupShape.setPropertyValue("MoveProtect", True)
        aGroupShape.setName("dimension")
        aEnv['%sDIMSHAPE' % aEnv['DIMTYPE']] = aGroupShape
        aNamedValues[0].Value = tuple(aEnv.items())
        return aNamedValues
    # **********************************
    # inspection wrapper
    # **********************************
    def inspectObject(self, aObject):
        aDiveIn = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DiveIn", self.ctx)
        aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aParms[0].Name = "inspect"
        aParms[0].Value = aObject
        aParms = aDiveIn.execute(aParms)
        return
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(DimPosSize,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.DimPosSize", # implemenation name
                                         ("org.openoffice.comp.pyuno.DimPosSize",),)    # list of implemented services
