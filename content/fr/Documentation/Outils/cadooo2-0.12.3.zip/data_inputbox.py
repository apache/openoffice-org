# 	$Id: data_inputbox.py,v 1.1 2006-07-16 10:02:12 gerard Exp $	
# -*- coding: latin-1 -*-
## ********************************************************************************
## data_inputbox.py sam jan  1 17:25:41 CET 2005
## Copyright (C) 2004 - 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import traceback, math
    import uno, unohelper
    from com.sun.star.task import XJob
    from com.sun.star.awt import XActionListener
except ImportError, e:
    print e
#=============================================================
# a class to iput dimensional or positional datas
# une classe pour des donnees de dimensions ou positions
#=============================================================
class DataInputBox(unohelper.Base, XJob, XActionListener):
    def __init__(self, aContext):
        self.ctx = aContext
        self.bOK = False
        smgr = self.ctx.ServiceManager
        desktop = smgr.createInstanceWithContext( "com.sun.star.frame.Desktop",self.ctx)
        # access the current draw document
        if desktop.ActiveFrame.ActiveFrame:
            self.aController = desktop.ActiveFrame.ActiveFrame.Controller
        else:
            self.aController = desktop.ActiveFrame.Controller
        self.aComponetWindow = self.aController.Frame.ComponentWindow
    # ******************************
    def execute(self, aNamedValues):
        aEnv = dict(list(aNamedValues[0].Value))
        aMsgL10n = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
        aArgs = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aArgs[0].Name = "Translation"
        aArgs[0].Value = tuple(["d%d" % i for i in range(13)])
        aArgs = aMsgL10n.execute(aArgs)
        aBox = uno.createUnoStruct("com.sun.star.awt.Rectangle")
        aBox.Width, aBox.Height = 130, 150
        aBox.X = (self.aComponetWindow.PosSize.X + (self.aComponetWindow.PosSize.Width - aBox.Width) / 2) / 25e-1
        aBox.Y = (self.aComponetWindow.PosSize.Y + (self.aComponetWindow.PosSize.Height - aBox.Height) / 2) / 25e-1
        # create the dialog model and set the properties
        DataDialogModel = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.awt.UnoControlDialogModel", self.ctx)
        DataDialogModel.setPropertyValue("PositionX", aBox.X)
        DataDialogModel.setPropertyValue("PositionY", aBox.Y)
        DataDialogModel.setPropertyValue("Width", aBox.Width)
        DataDialogModel.setPropertyValue("Height", aBox.Height)
        DataDialogModel.setPropertyValue("Title", aEnv['TITLE'])
        # create the label model and set the properties
        CommentDialogLabelModel = DataDialogModel.createInstance( "com.sun.star.awt.UnoControlFixedTextModel" )
        CommentDialogLabelModel.setPropertyValue("PositionX", 10)
        CommentDialogLabelModel.setPropertyValue("PositionY", 10)
        CommentDialogLabelModel.setPropertyValue("Width", 110)
        CommentDialogLabelModel.setPropertyValue("Height", 20)
        CommentDialogLabelModel.setPropertyValue("Name", "LabelComment")
        CommentDialogLabelModel.setPropertyValue("TabIndex", 8)
        CommentDialogLabelModel.setPropertyValue("MultiLine", True)
        CommentDialogLabelModel.setPropertyValue("Label", aEnv['COMMENT'])
        # create the button model and set the properties
        DataDialogButtonModel1 = DataDialogModel.createInstance( "com.sun.star.awt.UnoControlButtonModel" )
        DataDialogButtonModel1.setPropertyValue("PositionX", 25)
        DataDialogButtonModel1.setPropertyValue("PositionY", 125)
        DataDialogButtonModel1.setPropertyValue("Width", 30)
        DataDialogButtonModel1.setPropertyValue("Height", 15)
        DataDialogButtonModel1.setPropertyValue("Name", "Button1")
        DataDialogButtonModel1.setPropertyValue("TabIndex", 6)
        DataDialogButtonModel1.setPropertyValue("Label", aArgs[0].Value[0])
        DataDialogButtonModel1.setPropertyValue("DefaultButton", True)
        # create the button model and set the properties
        DataDialogButtonModel2 = DataDialogModel.createInstance( "com.sun.star.awt.UnoControlButtonModel" )
        DataDialogButtonModel2.setPropertyValue("PositionX", 75)
        DataDialogButtonModel2.setPropertyValue("PositionY", 125)
        DataDialogButtonModel2.setPropertyValue("Width", 30)
        DataDialogButtonModel2.setPropertyValue("Height", 15)
        DataDialogButtonModel2.setPropertyValue("Name", "Button2")
        DataDialogButtonModel2.setPropertyValue("TabIndex", 7)
        DataDialogButtonModel2.setPropertyValue("Label", aArgs[0].Value[1])
        DataDialogModel.insertByName("Comment", CommentDialogLabelModel)
        DataDialogModel.insertByName("Button1", DataDialogButtonModel1)
        DataDialogModel.insertByName("Button2", DataDialogButtonModel2)
        # flag values of 2 and 6 have no meaning, 4 is for angle input
        if aEnv['FLAG'] not in (2, 4, 6):
            # create the label model and set the properties
            DXDialogLabelModel = DataDialogModel.createInstance( "com.sun.star.awt.UnoControlFixedTextModel" )
            DXDialogLabelModel.setPropertyValue("PositionX", 10)
            DXDialogLabelModel.setPropertyValue("PositionY", 40)
            DXDialogLabelModel.setPropertyValue("Width", 25)
            DXDialogLabelModel.setPropertyValue("Height", 15)
            DXDialogLabelModel.setPropertyValue("Name", "LabelDX")
            DXDialogLabelModel.setPropertyValue("TabIndex", 9)
            DXDialogLabelModel.setPropertyValue("MultiLine", False)
            # flag 0 <=> distance input
            # flag 5 <=> global polar coordinates input
            # flag 7 <=> relative polar coordinates input
            if aEnv['FLAG'] in (0, 5, 7):
                DXDialogLabelModel.setPropertyValue("Label", aArgs[0].Value[2])
            # flag 1 <=> global rectangular coordinates input
            # flag 3 <=> relative rectangular coordinates input
            elif aEnv['FLAG'] in (1, 3):
                DXDialogLabelModel.setPropertyValue("Label", "X")
            # create the edit model and set the properties
            DXDialogEditModel = DataDialogModel.createInstance( "com.sun.star.awt.UnoControlNumericFieldModel" )
            DXDialogEditModel.setPropertyValue("PositionX", 40)
            DXDialogEditModel.setPropertyValue("PositionY", 40)
            DXDialogEditModel.setPropertyValue("Width", 45)
            DXDialogEditModel.setPropertyValue("Height", 15)
            DXDialogEditModel.setPropertyValue("Name", "NumfDX")
            DXDialogEditModel.setPropertyValue("TabIndex", 0)
            DXDialogEditModel.setPropertyValue("Value", aEnv['X'])
            DXDialogEditModel.setPropertyValue("Spin", True)
            DXDialogEditModel.setPropertyValue("HelpText", aArgs[0].Value[3])
            # create the listbox model and set the properties
            DXDialogListBoxModel = DataDialogModel.createInstance( "com.sun.star.awt.UnoControlListBoxModel" )
            DXDialogListBoxModel.setPropertyValue("PositionX", 90)
            DXDialogListBoxModel.setPropertyValue("PositionY", 40)
            DXDialogListBoxModel.setPropertyValue("Width", 30)
            DXDialogListBoxModel.setPropertyValue("Height", 15)
            DXDialogListBoxModel.setPropertyValue("Name", "ListDUnit")
            DXDialogListBoxModel.setPropertyValue("TabIndex", 1)
            DXDialogListBoxModel.setPropertyValue("Dropdown", True)
            DXDialogListBoxModel.setPropertyValue("HelpText", aArgs[0].Value[4])
            # insert the control models into the dialog model
            DataDialogModel.insertByName("LabelDX", DXDialogLabelModel)
            DataDialogModel.insertByName("NumfDX", DXDialogEditModel)
            DataDialogModel.insertByName("ListDUnit", DXDialogListBoxModel)
        if aEnv['FLAG'] != 0:
            # create the label model and set the properties
            AYDialogLabelModel = DataDialogModel.createInstance( "com.sun.star.awt.UnoControlFixedTextModel" )
            AYDialogLabelModel.setPropertyValue("PositionX", 10)
            AYDialogLabelModel.setPropertyValue("PositionY", 65)
            AYDialogLabelModel.setPropertyValue("Width", 25)
            AYDialogLabelModel.setPropertyValue("Height", 15)
            AYDialogLabelModel.setPropertyValue("Name", "LabelAY")
            AYDialogLabelModel.setPropertyValue("TabIndex", 10)
            AYDialogLabelModel.setPropertyValue("MultiLine", False)
            # flag 4 <=> angle input
            if aEnv['FLAG'] in (4, 5, 7):
                AYDialogLabelModel.setPropertyValue("Label", aArgs[0].Value[5])
            elif aEnv['FLAG'] in (1, 3):
                AYDialogLabelModel.setPropertyValue("Label", "Y")
            # create the edit model and set the properties
            AYDialogEditModel = DataDialogModel.createInstance( "com.sun.star.awt.UnoControlNumericFieldModel" )
            AYDialogEditModel.setPropertyValue("PositionX", 40)
            AYDialogEditModel.setPropertyValue("PositionY", 65)
            AYDialogEditModel.setPropertyValue("Width", 45)
            AYDialogEditModel.setPropertyValue("Height", 15)
            AYDialogEditModel.setPropertyValue("Name", "NumfAY")
            AYDialogEditModel.setPropertyValue("TabIndex", 2)
            AYDialogEditModel.setPropertyValue("Value", aEnv['Y'])
            AYDialogEditModel.setPropertyValue("Spin", True)
            AYDialogEditModel.setPropertyValue("HelpText", aArgs[0].Value[6])
            # create the listbox model and set the properties
            AYDialogListBoxModel = DataDialogModel.createInstance( "com.sun.star.awt.UnoControlListBoxModel" )
            AYDialogListBoxModel.setPropertyValue("PositionX", 90)
            AYDialogListBoxModel.setPropertyValue("PositionY", 65)
            AYDialogListBoxModel.setPropertyValue("Width", 30)
            AYDialogListBoxModel.setPropertyValue("Height", 15)
            AYDialogListBoxModel.setPropertyValue("Name", "ListAUnit")
            AYDialogListBoxModel.setPropertyValue("TabIndex", 3)
            AYDialogListBoxModel.setPropertyValue("Dropdown", True)
            AYDialogListBoxModel.setPropertyValue("HelpText", aArgs[0].Value[4])
            # insert the control models into the dialog model
            DataDialogModel.insertByName("LabelAY", AYDialogLabelModel)
            DataDialogModel.insertByName("NumfAY", AYDialogEditModel)
            DataDialogModel.insertByName("ListAUnit", AYDialogListBoxModel)
        if aEnv['FLAG'] in (1, 3, 5, 7):
            # create the groupbox model and set the properties
            DAXYDialogGroupBoxModel = DataDialogModel.createInstance( "com.sun.star.awt.UnoControlGroupBoxModel" )
            DAXYDialogGroupBoxModel.setPropertyValue("PositionX", 10)
            DAXYDialogGroupBoxModel.setPropertyValue("PositionY", 85)
            DAXYDialogGroupBoxModel.setPropertyValue("Width", 110)
            DAXYDialogGroupBoxModel.setPropertyValue("Height", 25)
            DAXYDialogGroupBoxModel.setPropertyValue("Name", "Group")
            DAXYDialogGroupBoxModel.setPropertyValue("TabIndex", 11)
            DAXYDialogGroupBoxModel.setPropertyValue("Label", aArgs[0].Value[7])
            # create the radio button model and set the properties
            AbsDialogRadioButtonModel = DataDialogModel.createInstance("com.sun.star.awt.UnoControlRadioButtonModel")
            AbsDialogRadioButtonModel.PositionX = 25
            AbsDialogRadioButtonModel.PositionY = 95
            AbsDialogRadioButtonModel.Width = 30
            AbsDialogRadioButtonModel.Height = 15
            AbsDialogRadioButtonModel.Name = "RadioA"
            AbsDialogRadioButtonModel.TabIndex = 4
            AbsDialogRadioButtonModel.State = False
            AbsDialogRadioButtonModel.Label = aArgs[0].Value[8]
            # create the radio button model and set the properties
            RelDialogRadioButtonModel = DataDialogModel.createInstance("com.sun.star.awt.UnoControlRadioButtonModel")
            RelDialogRadioButtonModel.PositionX = 75
            RelDialogRadioButtonModel.PositionY = 95
            RelDialogRadioButtonModel.Width = 30
            RelDialogRadioButtonModel.Height = 15
            RelDialogRadioButtonModel.Name = "RadioR"
            RelDialogRadioButtonModel.TabIndex = 5
            RelDialogRadioButtonModel.State = True
            RelDialogRadioButtonModel.Label = aArgs[0].Value[9]
            DataDialogModel.insertByName("Group", DAXYDialogGroupBoxModel)
            DataDialogModel.insertByName("RadioA", AbsDialogRadioButtonModel)
            DataDialogModel.insertByName("RadioR", RelDialogRadioButtonModel)
        # create the dialog control and set the model 
        self.DataDialogControl = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.awt.UnoControlDialog", self.ctx)
        self.DataDialogControl.setModel(DataDialogModel)
        if aEnv['FLAG'] not in (2, 4, 6):
            DXDialogListBoxControl = self.DataDialogControl.getControl("ListDUnit")
            DXDialogListBoxControl.addItem("mm", 0)
            DXDialogListBoxControl.addItem("cm", 1)
            DXDialogListBoxControl.addItem("m", 2)
            DXDialogListBoxControl.selectItem("m", True)
            DXDialogListBoxControl.makeVisible(1)
        if aEnv['FLAG'] in (1, 3):
            AYDialogListBoxControl = self.DataDialogControl.getControl("ListAUnit")
            AYDialogListBoxControl.addItem("mm", 0)
            AYDialogListBoxControl.addItem("cm", 1)
            AYDialogListBoxControl.addItem("m", 2)
            AYDialogListBoxControl.selectItem("m", True)
            AYDialogListBoxControl.makeVisible(1)
        elif aEnv['FLAG'] in (4, 5, 7):
            AYDialogListBoxControl = self.DataDialogControl.getControl("ListAUnit")
            AYDialogListBoxControl.addItem(aArgs[0].Value[10], 0)
            AYDialogListBoxControl.addItem(aArgs[0].Value[11], 1)
            AYDialogListBoxControl.addItem(aArgs[0].Value[12], 2)
            AYDialogListBoxControl.selectItem(aArgs[0].Value[10], True)
            AYDialogListBoxControl.makeVisible(1)
        # add an action listener to the button1 control 
        aDataDialogButton1 = self.DataDialogControl.getControl("Button1")
        aDataDialogButton1.setActionCommand("ok")
        aDataDialogButton1.addActionListener(self)
        # add an action listener to the button2 control 
        aDataDialogButton2 = self.DataDialogControl.getControl("Button2")
        aDataDialogButton2.setActionCommand("cancel")
        aDataDialogButton2.addActionListener(self)
        #create a peer 
        aToolkit = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.awt.Toolkit", self.ctx)
        self.DataDialogControl.setVisible(0)
        self.DataDialogControl.createPeer(aToolkit, aToolkit.getDesktopWindow())
        #execute the dialog 
        self.DataDialogControl.execute()
        if self.bOK:
            if aEnv['FLAG'] not in (2, 4, 6):
                aEnv['RETURN'] = True
                aEnv['XUNIT'] = DXDialogListBoxControl.getSelectedItem()
                if aEnv['XUNIT'] == "mm":
                    aEnv['X'] = int( self.DataDialogControl.getControl("NumfDX").getValue() * 100)
                elif aEnv['XUNIT'] == "cm":
                    aEnv['X'] = int( self.DataDialogControl.getControl("NumfDX").getValue() * 1000)
                else:
                    aEnv['X'] = int( self.DataDialogControl.getControl("NumfDX").getValue() * 100000)
            if aEnv['FLAG'] in (1, 3):
                aEnv['RETURN'] = True
                aEnv['YUNIT'] = AYDialogListBoxControl.getSelectedItem()
                if aEnv['YUNIT'] == "mm":
                    aEnv['Y'] = int( self.DataDialogControl.getControl("NumfAY").getValue() * 100)
                elif aEnv['YUNIT'] == "cm":
                    aEnv['Y'] = int( self.DataDialogControl.getControl("NumfAY").getValue() * 1000)
                else:
                    aEnv['Y'] = int( self.DataDialogControl.getControl("NumfAY").getValue() * 100000)
            elif aEnv['FLAG'] in (4, 5, 7):
                aEnv['RETURN'] = True
                aEnv['YUNIT'] = AYDialogListBoxControl.getSelectedItem()
                if aEnv['YUNIT'] == aArgs[0].Value[10]:
                    aEnv['Y'] = self.DataDialogControl.getControl("NumfAY").getValue()
                elif aEnv['YUNIT'] == aArgs[0].Value[11]:
                    aEnv['Y'] = self.DataDialogControl.getControl("NumfAY").getValue() * math.pi / 180
                else:
                    aEnv['Y'] = self.DataDialogControl.getControl("NumfAY").getValue() * math.pi / 200
            if aEnv['FLAG'] in (1, 3, 5, 7):
                DAXYDialogRadionButtonControl = self.DataDialogControl.getControl("RadioA")
                if DAXYDialogRadionButtonControl.getState():
                    aEnv['FLAG'] = aEnv['FLAG'] & 0x5
                else:
                    aEnv['FLAG'] = aEnv['FLAG'] | 0x2
        # remove an action listener to the button1 control 
        aDataDialogButton1.removeActionListener(self)
        # remove an action listener to the button2 control 
        aDataDialogButton2.removeActionListener(self)
        aNamedValues[0].Value = tuple(aEnv.items())
        return aNamedValues
	## XEventListener 
    def disposing(self, eventObject):
        self.DataDialogControl = None
	## XActionListener 
    def actionPerformed(self, actionEvent):
        if actionEvent.ActionCommand == "ok":
            self.bOK = True
        else:
            self.bOK = False
        self.DataDialogControl.endExecute()

# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(DataInputBox,                                        # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.DataInputBox", # implemenation name
                                         ("org.openoffice.comp.pyuno.DataInputBox",),)    # list of implemented services

