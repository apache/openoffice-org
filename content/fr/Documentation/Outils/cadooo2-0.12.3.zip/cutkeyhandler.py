#	$Id: cutkeyhandler.py,v 1.1 2006-07-16 10:02:12 gerard Exp $
# -*- coding: latin-1 -*-
## ********************************************************************************
## 
## Copyright (C) 2006 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import unohelper, uno
    import math, traceback, operator
    from com.sun.star.task import XJob
    from com.sun.star.awt.KeyModifier import SHIFT
except ImportError:
    print "probleme d'import"
#===============================
# gestion des evenements clavier
# handling keyboard events
#===============================
class CutKeyHandler(unohelper.Base, XJob):
    """gestion des evenements clavier
    handling keyboard events"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
        # Datum needed by coordinates input form
        self.aCoordData = {}
        self.aCoordData["TITLE"]  = "No Title"
        self.aCoordData["FLAG"] = 0
        self.aCoordData["COMMENT"] = "No comment"
        self.aCoordData["X"] = 0
        self.aCoordData["XUNIT"] = "m"
        self.aCoordData["Y"] = 0
        self.aCoordData["YUNIT"] = "m"
        self.aCoordData["RETURN"] = False
        # Struct needed to pass arguments throught UNO
        self.aNamedValues = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        self.aNamedValues[0].Name = "CONTEXT"
        self.aEntityPosSize = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.EntityPosSize", self.ctx)
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # ==================================
    # actions clavier - keyboard actions
    # aArgs as tuple of NamedValue
    #   Name         Value
    # KEYCODE     integer
    # DRAWSCALE
    # COORDS
    # STEP
    # DRAWSCALE
    # CANCELJOB
    # ORTHOMODE
    # SHAPE
    # ==================================
    def execute(self, aArgs):
        aEnv = dict(list(aArgs[0].Value))
        # ----------------------------------------------------------------------------------------------------
        if [516, 520, 524, 527, 531].count(aEnv['KEYEVENT'].KeyCode) and not aEnv['KEYEVENT'].Modifiers:
            # e,   i,   m,   p,   t => link 2 entities
            i = [516, 520, 524, 527, 531].index(aEnv['KEYEVENT'].KeyCode)
            bKHState = list(aEnv['L2OSTATE'])
            bKHState[i] = not bKHState[i]
            aEnv['L2OSTATE'] = tuple(bKHState)
            aStatusBarCheckBox = aEnv['STATUSBARCONTROL'][i]
            if aStatusBarCheckBox.getState() != aEnv['L2OSTATE'][i]:
                aStatusBarCheckBox.setState(aEnv['L2OSTATE'][i])
        # ----------------------------------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (523,) and not aEnv['KEYEVENT'].Modifiers and aEnv['SPOTTEDSHAPE']:
            # .................................l
            aMsgL10n = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
            aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
            aParms[0].Name = "Translation"
            i = aEnv['SPOTTEDSHAPE'][0][-1]
            aShape = aEnv['GROUPSHAPE'].getByIndex(i)
            aType = aShape.getShapeType().split('.')[-1]
            aStyle = aShape.Style
            aEnv['GROUPSHAPE'].remove(aEnv['SHAPE'])
            aEnv['SHAPE'] = None
            # ---------------------------------------------
            if aEnv['SPOTTEDSHAPE'][1] in ("LineShape",):
                aParms[0].Value = ("k0", "k1")
                aParms = aMsgL10n.execute(aParms)
                aCoords = uno.createUnoStruct("com.sun.star.awt.Point")
                while True:
                    aCoordInput = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DataInputBox", self.ctx)
                    self.aCoordData["TITLE"]  = aParms[0].Value[0]
                    self.aCoordData["FLAG"] = 0
                    self.aCoordData["COMMENT"] = aParms[0].Value[1]
                    self.aCoordData["RETURN"] = False
                    self.aCoordData["X"] = float(aEnv['MOUSERELPOS'][0]) / (100000 * aEnv['DRAWSCALE'])
                    self.aNamedValues[0].Value = tuple(self.aCoordData.items())
                    self.aCoordData = dict(list(aCoordInput.execute(self.aNamedValues)[0].Value))
                    # ---------------------------
                    if self.aCoordData["RETURN"]:
                        nDist = long(self.aCoordData['X']*aEnv['DRAWSCALE'])
                        # ------
                        if nDist:
                            fK = float(nDist) / aEnv['MOUSERELPOS'][2]
                            aCoords.X = aEnv['SPOTTEDSHAPE'][2].X + long(fK * (aEnv['SPOTTEDSHAPE'][3].X - aEnv['SPOTTEDSHAPE'][2].X))
                            aCoords.Y = aEnv['SPOTTEDSHAPE'][2].Y + long(fK * (aEnv['SPOTTEDSHAPE'][3].Y - aEnv['SPOTTEDSHAPE'][2].Y))
                            # ------------------------------------------
                            if aType in ("LineShape", "RectangleShape"):
                                aEnv['COORDS'][0][0].X = aCoords.X
                                aEnv['COORDS'][0][0].Y = aCoords.Y
                                aArgs[0].Value = tuple(aEnv.items())
                                aEnv = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                                aEnv['SHAPE'].Style = aStyle
                                aEnv['SHAPE'].setName("")
                                aEnv['SHAPE'] = None
                                # ---------------------------
                                if aType == "RectangleShape": # Rectangle
                                    i = 1
                                    # -------------------------------------------------
                                    for aSplit in aEnv['SPLITTEDSHAPE']:
                                        # -----------------------------------------
                                        if i != aEnv['SPOTTEDSHAPE'][-1]: # to do ?
                                            # ----------------------------------------------------
                                            if aSplit[1] == "LineShape":
                                                aEnv['UNOTYPE'] = "LineShape"
                                                aEnv['ENTITYPE'] = "LINE"
                                                aEnv['STEP'] = 1
                                                aEnv['MODE'] = (aEnv['MODE'][0],) + ("VERTEX",)
                                                aShapeCoords = [[aSplit[2], aSplit[3]]]
                                            else:
                                                aEnv['UNOTYPE'] = "EllipseShape"
                                                aEnv['ENTITYPE'] = "ARC"
                                                aEnv['STEP'] = 3
                                                aEnv['MODE'] = (aEnv['MODE'][0],) + ("RADIUS", "STARTANGLE", "ENDANGLE")
                                                aShapeCoords = [[uno.createUnoStruct("com.sun.star.awt.Point") for j in range(4)]]
                                                aShapeCoords[0][0].X, aShapeCoords[0][0].Y = aSplit[2].X, aSplit[2].Y
                                                nRadius = aSplit[3].Width
                                                aShapeCoords[0][1].X, aShapeCoords[0][1].Y = aSplit[2].X + nRadius, aSplit[2].Y
                                                aShapeCoords[0][2].X = aSplit[2].X + nRadius * math.cos(aSplit[5])
                                                aShapeCoords[0][2].Y = aSplit[2].Y - nRadius * math.sin(aSplit[5])
                                                aShapeCoords[0][3].X = aSplit[2].X + nRadius * math.cos(aSplit[6])
                                                aShapeCoords[0][3].Y = aSplit[2].Y - nRadius * math.sin(aSplit[6])
                                            aEnv['COORDS'] = tuple([tuple(c) for c in aShapeCoords])
                                            aArgs[0].Value = tuple(aEnv.items())
                                            aEnv = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                                            aEnv['SHAPE'].Style = aStyle
                                            aEnv['SHAPE'].setName("")
                                            aEnv['SHAPE'] = None
                                        i = i + 1
                            # --------------------------------------------------
                            elif aType in ("PolyLineShape", "PolyPolygonShape"):
                                idx = 0
                                aShapeCoords = []
                                # ---------------------------------
                                for aPolygon in aShape.PolyPolygon[:]:
                                    aShapeCoords.append([])
                                    # --------------------------
                                    for i in range(len(aPolygon)):
                                        aShapeCoords[-1].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                                        idx = idx + 1
                                        # -----------------------------------------
                                        if aEnv['SPOTTEDSHAPE'][-1] == idx:
                                            if i > 0:
                                                aShapeCoords[-1][-1].X = aPolygon[i].X
                                                aShapeCoords[-1][-1].Y = aPolygon[i].Y
                                                aShapeCoords[-1].append([uno.createUnoStruct("com.sun.star.awt.Point")])
                                            aShapeCoords[-1][-1].X = aCoords.X
                                            aShapeCoords[-1][-1].Y = aCoords.Y
                                        else:
                                            aShapeCoords[-1][-1].X = aPolygon[i].X
                                            aShapeCoords[-1][-1].Y = aPolygon[i].Y
                                    idx = idx - 1
                                aEnv['COORDS'] = tuple([tuple(i) for i in aShapeCoords])
                                aEnv['UNOTYPE'] = aType
                                aEnv['ENTITYPE'] = "POLYGON"
                                aEnv['STEP'] = -1
                                aEnv['MODE'] = (aEnv['MODE'][0],) + ("VERTEX",)
                                aArgs[0].Value = tuple(aEnv.items())
                                aEnv = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                                aEnv['SHAPE'].Style = aStyle
                                aEnv['SHAPE'].setName("")
                                aEnv['SHAPE'] = None
                            break
            # ---------------------------------------------
            if aEnv['SPOTTEDSHAPE'][1] in ("ArcEllipseShape", "ArcCircleShape"):
                aParms[0].Value = ("k0", "k5")
                aParms = aMsgL10n.execute(aParms)
                aCoords = uno.createUnoStruct("com.sun.star.awt.Point")
                while True:
                    aCoordInput = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DataInputBox", self.ctx)
                    self.aCoordData["TITLE"]  = aParms[0].Value[0]
                    self.aCoordData["FLAG"] = 4
                    self.aCoordData["COMMENT"] = aParms[0].Value[1]
                    self.aCoordData["RETURN"] = False
                    self.aCoordData["Y"] = aEnv['SPOTTEDSHAPE'][5] * 180 / math.pi
                    self.aNamedValues[0].Value = tuple(self.aCoordData.items())
                    self.aCoordData = dict(list(aCoordInput.execute(self.aNamedValues)[0].Value))
                    # ---------------------------
                    if self.aCoordData["RETURN"]:
                        fAngle = self.aCoordData["Y"]
                        if fAngle == float(0):
                            fAngle = 2 * math.pi
                        aEnv['CIRCLEKIND'] = aShape.CircleKind
                        aEnv['UNOTYPE'] = "EllipseShape"
                        aShapeCoords = [uno.createUnoStruct("com.sun.star.awt.Point") for i in range(4)]
                        aShapeCoords[0].X = aEnv['SPOTTEDSHAPE'][2].X
                        aShapeCoords[0].Y = aEnv['SPOTTEDSHAPE'][2].Y
                        if aEnv['SPOTTEDSHAPE'][1] in ("ArcCircleShape",):
                            aEnv['ENTITYPE'] = "ARC"
                            aEnv['STEP'] = 3
                            aEnv['MODE'] = (aEnv['MODE'][0],) + ("RADIUS", "STARTANGLE", "ENDANGLE")
                        else:
                            aEnv['ENTITYPE'] = "ELLARC"
                            aEnv['STEP'] = 4
                            aEnv['MODE'] = (aEnv['MODE'][0],) + ("RADIUS", "RADIUS2", "STARTANGLE", "ENDANGLE")
                            aShapeCoords[0].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                            aCoords = self.compute("PointOnEllipse", None, math.pi/2, *aEnv['SPOTTEDSHAPE'][2:5])[0]
                            aShapeCoords[2].X = aCoords.X
                            aShapeCoords[2].Y = aCoords.Y
                        aCoords = self.compute("PointOnEllipse", None, float(0), *aEnv['SPOTTEDSHAPE'][2:5])[0]
                        aShapeCoords[1].X = aCoords.X
                        aShapeCoords[1].Y = aCoords.Y
                        aCoords = self.compute("PointOnEllipse", None, aEnv['SPOTTEDSHAPE'][6], *aEnv['SPOTTEDSHAPE'][2:5])[0]
                        aShapeCoords[-1].X = aCoords.X
                        aShapeCoords[-1].Y = aCoords.Y
                        aCoords = self.compute("PointOnEllipse", None, fAngle, *aEnv['SPOTTEDSHAPE'][2:5])[0]
                        aShapeCoords[-2].X = aCoords.X
                        aShapeCoords[-2].Y = aCoords.Y
                        aArgs[0].Value = tuple(aEnv.items())
                        aEnv = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                        aEnv['SHAPE'].Style = aStyle
                        aEnv['SHAPE'].setName("")
                        aEnv['SHAPE'] = None
                        break
            aEnv['GROUPSHAPE'].remove(aShape)
            # ----------------------------
            if aEnv['REPEATMODE']: # repeat mode on ?
                aEnv['VALIDLIST'] = False
                aEnv['SHAPE'] = None
                aEnv['GROUPSHAPE'] = self.aController.getCurrentPage()
            else:
                aEnv['STOPJOB'] = True
        # --------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (1281,) and not aEnv['KEYEVENT'].Modifiers:
            #                                 Esc => kill job
            aEnv['CANCELJOB'] = True
        # -------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (512,) and not aEnv['KEYEVENT'].Modifiers:
            #                                  a => axonometric mode
            aEnv['ORTHOMODE'] = not aEnv['ORTHOMODE']
            aStatusBarCheckBox = aEnv['STATUSBARCONTROL'][5]
            if aStatusBarCheckBox.getState() != aEnv['ORTHOMODE']:
                aStatusBarCheckBox.setState(aEnv['ORTHOMODE'])
        # --------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (1289,) and not aEnv['KEYEVENT'].Modifiers:
            #                                  * => repeat mode
            aEnv['REPEATMODE'] = not aEnv['REPEATMODE']
            aStatusBarCheckBox = aEnv['STATUSBARCONTROL'][6]
            if aStatusBarCheckBox.getState() != aEnv['REPEATMODE']:
                aStatusBarCheckBox.setState(aEnv['REPEATMODE'])
        aArgs[0].Value = tuple(aEnv.items())
        return aArgs
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()
g_ImplementationHelper.addImplementation(CutKeyHandler,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.CutKeyHandler", # implemenation name
                                         ("org.openoffice.comp.pyuno.CutKeyHandler",),)    # list of implemented services
