# 	$Id: compute.py,v 1.1 2006-07-16 10:02:12 gerard Exp $	
# -*- coding: latin-1 -*-
## ********************************************************************************
## compute.py dim jan 23 20:39:02 CET 2005
## Copyright (C) 2004, 2005, 2006, 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import math
    import uno, unohelper
    from com.sun.star.lang import IllegalArgumentException
    from com.sun.star.task import XJob
except ImportError, e:
    print e
#=========================================
# a class usefull for various computations
#=========================================
class Compute(unohelper.Base, XJob):
    """Utile pour divers calculs
    Usefull for various computations"""
    def __init__(self, ctx):
        self.ctx = ctx
    ##
    ## execution of the right method
    ##
    def execute(self, aNamedValues):
        if aNamedValues[0].Value == "toPolarCoord":
            aNamedValues[3].Value = self.toPolarCoord(aNamedValues[1].Value,\
                                                      aNamedValues[2].Value)
        elif aNamedValues[0].Value == "transformMouseCoord":
            aNamedValues[2].Value = self.transformMouseCoord(aNamedValues[1].Value)
        elif aNamedValues[0].Value == "CollarX":
            aNamedValues[4].Value = self.getCollarX(aNamedValues[1].Value,\
                                                    aNamedValues[2].Value,\
                                                    aNamedValues[3].Value)
        elif aNamedValues[0].Value == "InterLines":
            aNamedValues[5].Value = self.getInterLines(aNamedValues[1].Value,\
                                                       aNamedValues[2].Value,\
                                                       aNamedValues[3].Value,\
                                                       aNamedValues[4].Value)
        elif aNamedValues[0].Value == "InterLines2":
            aNamedValues[7].Value = self.getInterLines2(aNamedValues[1].Value,\
                                                        aNamedValues[2].Value,\
                                                        aNamedValues[3].Value,\
                                                        aNamedValues[4].Value,\
                                                        aNamedValues[5].Value,\
                                                        aNamedValues[6].Value)
        elif aNamedValues[0].Value == "InterLineEllipse":
            aNamedValues[6].Value = self.getInterLineEllipse(aNamedValues[1].Value,\
                                                             aNamedValues[2].Value,\
                                                             aNamedValues[3].Value,\
                                                             aNamedValues[4].Value,\
                                                             aNamedValues[5].Value)
        elif aNamedValues[0].Value == "InterEllipses":
            aNamedValues[7].Value = self.getInterEllipses(aNamedValues[1].Value,\
                                                          aNamedValues[2].Value,\
                                                          aNamedValues[3].Value,\
                                                          aNamedValues[4].Value,\
                                                          aNamedValues[5].Value,\
                                                          aNamedValues[6].Value)
        elif aNamedValues[0].Value == "TangentEllipseCircle":
            aNamedValues[5].Value = self.getTangentEllipseCircle(aNamedValues[1].Value,\
                                                                 aNamedValues[2].Value,\
                                                                 aNamedValues[3].Value,\
                                                                 aNamedValues[4].Value)
        elif aNamedValues[0].Value == "TangentEllipseLine":
            aNamedValues[5].Value = self.getTangentEllipseLine(aNamedValues[1].Value,\
                                                               aNamedValues[2].Value,\
                                                               aNamedValues[3].Value,\
                                                               aNamedValues[4].Value)
        elif aNamedValues[0].Value == "TangentLineCircle":
            aNamedValues[4].Value = self.getTangentLineCircle(aNamedValues[1].Value,\
                                                              aNamedValues[2].Value,\
                                                              aNamedValues[3].Value)
        elif aNamedValues[0].Value == "Circle3P":
            aNamedValues[4].Value = self.getCircle3P(aNamedValues[1].Value,\
                                                     aNamedValues[2].Value,\
                                                     aNamedValues[3].Value)
        elif aNamedValues[0].Value == "Dist2Line":
            aNamedValues[4].Value = self.getDist2Line(aNamedValues[1].Value,\
                                                      aNamedValues[2].Value,\
                                                      aNamedValues[3].Value)
        elif aNamedValues[0].Value == "Dist2Arc":
            aNamedValues[7].Value = self.getDist2Arc(aNamedValues[1].Value,\
                                                     aNamedValues[2].Value,\
                                                     aNamedValues[3].Value,\
                                                     aNamedValues[4].Value,\
                                                     aNamedValues[5].Value,\
                                                     aNamedValues[6].Value)
        elif aNamedValues[0].Value == "PointOnEllipse":
            aNamedValues[6].Value = self.getPointOnEllipse(aNamedValues[1].Value,\
                                                           aNamedValues[2].Value,\
                                                           aNamedValues[3].Value,\
                                                           aNamedValues[4].Value,\
                                                           aNamedValues[5].Value)
        elif aNamedValues[0].Value == "CoordFromAbsOrd":
            aNamedValues[5].Value = self.getCoordFromAbsOrd(aNamedValues[1].Value,\
                                                            aNamedValues[2].Value,\
                                                            aNamedValues[3].Value,\
                                                            aNamedValues[4].Value)
        else:
            raise IllegalArgumentException, 'unknown function'
        return aNamedValues
    # ***************************************************
    # transform screen coordinates to drawing coordinates
    # ***************************************************
    def transformMouseCoord(self, aParams):
        aEnv = dict(list(aParams))
        aMouseCoord = uno.createUnoStruct("com.sun.star.awt.Point")
        aMouseCoord.X = long(float(aEnv['MOUSEEVENT'].X) * aEnv['DEVICEXSCALE'] + aEnv['VISIBLEAREA'].X)
        aMouseCoord.Y = long(float(aEnv['MOUSEEVENT'].Y) * aEnv['DEVICEYSCALE'] + aEnv['VISIBLEAREA'].Y)
        if aEnv['ORTHOMODE'] and aEnv['VALIDORIGIN']:
            if aMouseCoord.X < aEnv['ORIGINCOORD'].X:
                nSignX = -1
            else:
                nSignX = 1
            if aMouseCoord.Y < aEnv['ORIGINCOORD'].Y:
                nSignY = -1
            else:
                nSignY = 1
            if abs(aMouseCoord.Y - aEnv['ORIGINCOORD'].Y) < (math.sqrt(2)-1)*abs(aMouseCoord.X - aEnv['ORIGINCOORD'].X):
                aMouseCoord.Y = aEnv['ORIGINCOORD'].Y
            elif abs(aMouseCoord.Y - aEnv['ORIGINCOORD'].Y) < abs(aMouseCoord.X - aEnv['ORIGINCOORD'].X):
                aMouseCoord.Y = aEnv['ORIGINCOORD'].Y + nSignY * abs(aMouseCoord.X - aEnv['ORIGINCOORD'].X)
            elif abs(aMouseCoord.Y - aEnv['ORIGINCOORD'].Y) < (math.sqrt(2)+1)*abs(aMouseCoord.X - aEnv['ORIGINCOORD'].X):
                aMouseCoord.X = aEnv['ORIGINCOORD'].X + nSignX * abs(aMouseCoord.Y - aEnv['ORIGINCOORD'].Y)
            else:
                aMouseCoord.X = aEnv['ORIGINCOORD'].X + 1
        return (aMouseCoord.X, aMouseCoord.Y)
    ##
    ## Convert rectangular coordinates to polar - conversion coordonnes rectangulaires en polaires
    ##
    def toPolarCoord(self, aCoord0, aCoord1):
        """Conversion de coordonnees rectangulaires en polaires
        Polar to rectangular coordinates conversion
        @param aCoord0 as com.sun.star.awt.Point
        @param aCoord1 as com.sun.star.awt.Point
        return (distance, angle) as tuple(int, float)"""
        aPolarCoord = []
        aPolarCoord.append(long(math.sqrt((aCoord1.X - aCoord0.X) ** 2 + (aCoord1.Y - aCoord0.Y) ** 2)))
        if aPolarCoord[0] == 0:
            aPolarCoord.append(0)
            return tuple(aPolarCoord)
        aPolarCoord.append(math.asin(float(abs(aCoord1.Y - aCoord0.Y)) / aPolarCoord[0]))
        if (aCoord1.X - aCoord0.X) >= 0:
            if (aCoord1.Y - aCoord0.Y) < 0:
                aPolarCoord[1] = 2 * math.pi - aPolarCoord[1]
        else:
            if (aCoord1.Y - aCoord0.Y) > 0:
                aPolarCoord[1] = math.pi - aPolarCoord[1]
            else:
                aPolarCoord[1] = math.pi + aPolarCoord[1]
        if aPolarCoord[1] > 0:
            aPolarCoord[1] = 2* math.pi - aPolarCoord[1]
        return tuple(aPolarCoord)
    ##
    ## Compute balanced steps - calcul du balancement
    ##
    def getCollarX(self, nCollarLength, nStrideLength, nStrideX):
        """Calcul du balancement sur la ligne de collet
        balance computing on collar line
        @param nCollarLength as int
        @param nStrideLength as int
        @param nStrideX as int
        return nCollarX as int"""
        fKg = float(nStrideX) / nStrideLength
        fK = float(nCollarLength) / nStrideLength
        if nStrideX > long((nStrideLength - nCollarLength) / float(nStrideLength + nCollarLength) * nCollarLength):
            return long(nStrideX * ((fK * (1 + fK ** 2)) / (2 * fK ** 2 + (1 - fK ** 2) * fKg)))
        else:
            return nStrideX
    ##
    ## Compute the coordinates of two lines intersection point and the distances from each parameter point coordinates
    ## Calcule les distances entre les points donnes en parametre et le point d'intersection des droites
    ##
    def getInterLines2(self, aCoordA, aCoordB, aCoordC, aCoordD, nOffset1, nOffset2):
        """Calcul des coordonnees du point d'intersection de deux droites et des distances par rapport aux points donnes en parametre
        Compute the coordinates of two lines intersection point and the distances from each parameter point coordinates
        @param aCoordA, aCoordB, aCoordC, aCoordD as com.sun.star.awt.Point
        @param nOffset1, nOffset2 as Long
        return nDistance1, nDistance2, nX, nY as tuple(int, int, int, int)"""
        aCoord1 = self.getCoordFromAbsOrd(aCoordA, aCoordB, 0, nOffset1)
        aCoord2 = self.getCoordFromAbsOrd(aCoordC, aCoordD, 0, nOffset2)
        fAngle1 = self.toPolarCoord(aCoordA, aCoordB)[1]
        fAngle2 = self.toPolarCoord(aCoordC, aCoordD)[1]
        return self.getInterLines(aCoord1, fAngle1, aCoord2, fAngle2)
    ##
    ## Compute the distances from each parameter point coordinates to the intersection point of the two lines
    ## Calcule les distances entre les points donnes en parametre et le point d'intersection des droites
    ##
    def getInterLines(self, aCoord1, fAngle1, aCoord2, fAngle2):
        """Calcul des coordonnees du point d'intersection de deux droites et des distances par rapport aux points donnes en parametre
        Compute the coordinates of two lines intersection point and the distances from each parameter point coordinates
        @param aCoord1 as com.sun.star.awt.Point
        @param fAngle1 as float
        @param aCoord2 as com.sun.star.awt.Point
        @param fAngle2 as float
        return nDistance1, nDistance2, nX, nY as tuple(int, int, int, int)"""
        nInter = [0 for i in range(4)]
        if abs(math.cos(fAngle1)) < 1e-3:
            nInter[2] = aCoord1.X
            if abs(math.cos(fAngle2)) >= 1e-3:
                nInter[3] = aCoord2.Y - long(math.tan(fAngle2)*(aCoord1.X - aCoord2.X))
                nInter[0] = long((nInter[3] - aCoord1.Y) / math.sin(-fAngle1))
                nInter[1] = long((nInter[2] - aCoord2.X) / math.cos(fAngle2))
                return tuple(nInter)
            else:
                return None
        elif abs(math.cos(fAngle2)) < 1e-3:
            nInter[2] = aCoord2.X
            nInter[3] = aCoord1.Y - long(math.tan(fAngle1)*(aCoord2.X - aCoord1.X))
            nInter[1] = long((nInter[3] - aCoord2.Y) / math.sin(-fAngle2))
            nInter[0] = long((nInter[2] - aCoord1.X) / math.cos(fAngle1))
            return tuple(nInter)
        else:
            fM1 = -math.tan(fAngle1)
            fM2 = -math.tan(fAngle2)
            if abs(fM1 - fM2) < 1e-3:
                return None
            nP1 = aCoord1.Y - long(fM1 * aCoord1.X)
            nP2 = aCoord2.Y - long(fM2 * aCoord2.X)
            nInter[2] = long(-(nP1 - nP2) / (fM1 - fM2))
            nInter[3] = long(fM1 * nInter[2]) + nP1
            nInter[0] = long((nInter[2] - aCoord1.X) / math.cos(fAngle1))
            nInter[1] = long((nInter[2] - aCoord2.X) / math.cos(fAngle2))
        return tuple(nInter)
    ##
    ## Compute the distances from first parameter point coordinates to each intersection point with the ellipse
    ## Calcule les distances entre le point de la droite donne en parametre et les points d'intersection avec l'ellipse
    ##
    def getInterLineEllipse(self, aCoord1, fAngle1, aCoord2, aSize, fAngle2):
        """Compute distances and coordinates for each intersection point between a line and an ellipse
        Calcule distances et coordonnes des points d'intersection d'une droite avec une ellipse
        @param aCoord1 as com.sun.star.awt.Point
        @param fAngle1 as float
        @param aCoord2 as com.sun.star.awt.Point
        @param aSize as com.sun.star.awt.Size
        @param fAngle2 as float
        return nDistance1, nDistance2, nX1, nY1, nX2, nY2 as tuple(int, int, int, int, int, int)"""
        nInter = []
        fAlfa1 = 2 * math.pi - fAngle1
        fAlfa2 = 2 * math.pi - fAngle2
        fRotation = fAlfa1 - fAlfa2
        aCoord = uno.createUnoStruct('com.sun.star.awt.Point')
        aCoord.X = long((aCoord1.X-aCoord2.X)*math.cos(fAlfa2)+(aCoord1.Y-aCoord2.Y)*math.sin(fAlfa2))
        aCoord.Y = long(-(aCoord1.X-aCoord2.X)*math.sin(fAlfa2)+(aCoord1.Y-aCoord2.Y)*math.cos(fAlfa2))
        if abs(math.pi/2 - abs(fRotation)) < 1e-6 or abs(3*math.pi/2 - abs(fRotation)) < 1e-6:
            if abs(aCoord.X) > aSize.Width:
                return ()
            else:
                nInter.append(long((-aSize.Height*math.sqrt(1-(float(aCoord.X)/aSize.Width)**2)-aCoord.Y)/math.sin(fRotation)))
                nInter.append(long((aSize.Height*math.sqrt(1-(float(aCoord.X)/aSize.Width)**2)-aCoord.Y)/math.sin(fRotation)))
        elif abs(fRotation) < 1e-6 or abs(math.pi - abs(fRotation)) < 1e-6:
            if abs(aCoord.Y) > aSize.Height:
                return ()
            else:
                nInter.append(-long((aSize.Width*math.sqrt(1-(float(aCoord.Y)/aSize.Height)**2)-aCoord.X)/math.cos(fRotation)))
                nInter.append(long((aSize.Width*math.sqrt(1-(float(aCoord.Y)/aSize.Height)**2)-aCoord.X)/math.cos(fRotation)))
        else:
            fM = math.tan(fRotation)
            fP = aCoord.Y - fM * aCoord.X
            fA = (aSize.Width * fM)**2 + aSize.Height**2
            fDelta = fA - fP**2
            if fDelta < 0:
                return ()
            else:
                nInter.append(long(((aSize.Width*(aSize.Height*math.sqrt(fDelta)-aSize.Width*fM*fP)/fA)-aCoord.X)/math.cos(fRotation)))
                nInter.append(long(((-aSize.Width*(aSize.Height*math.sqrt(fDelta)+aSize.Width*fM*fP)/fA)-aCoord.X)/math.cos(fRotation)))
        nInter.append(aCoord1.X + long(nInter[0] * math.cos(fAlfa1)))
        nInter.append(aCoord1.Y + long(nInter[0] * math.sin(fAlfa1)))
        nInter.append(aCoord1.X + long(nInter[1] * math.cos(fAlfa1)))
        nInter.append(aCoord1.Y + long(nInter[1] * math.sin(fAlfa1)))
        return tuple(nInter)
    ##
    ## Compute coordinates for each intersection point between 2 ellipses
    ## Calcule les coordonnes des points d'intersection de deux ellipses
    ##
    def getInterEllipses(self, aCoord1, aSize1, fAngle1, aCoord2, aSize2, fAngle2):
        """Compute coordinates for each intersection point between 2 ellipses
        Calcule coordonnes des points d'intersection de deux ellipses
        @param aCoord1 as com.sun.star.awt.Point : coordinates of first ellipse center
        @param aSize1 as com.sun.star.awt.Size : half short and great axis dimension
        @param fAngle1 as float : rotation angle
        @param aCoord2 as com.sun.star.awt.Point : coordinates of second ellipse center
        @param aSize1 as com.sun.star.awt.Size : half short and great axis dimension
        @param fAngle2 as float : rotation angle
        return nX1, nY1, nX2, nY2, nX3, nY3, nX4, nY4 as tuple(int, int, int, int, int, int, int, int)"""
        if abs(aCoord1.X-aCoord2.X)<5 and abs(aCoord1.Y-aCoord2.Y)<5 and abs(aSize1.Width-aSize2.Width)<5 and abs(aSize1.Height-aSize2.Height)<5 and abs(fAngle1-fAngle2)<1e-6:
            return ()
        nInterCoord = []
        if abs(aSize1.Width-aSize1.Height)<10 and abs(aSize2.Width-aSize2.Height)<10:
            nDist, fTheta1 = self.toPolarCoord(aCoord1, aCoord2)
            if nDist == 0:
                return ()
            if aSize1.Width+aSize2.Width<nDist:
                return ()
            nU = (aSize1.Width**2+nDist**2-aSize2.Width**2)/(2*nDist)
            if abs(nU) > aSize1.Width:
                return ()
            nV = long(math.sqrt(aSize1.Width**2-nU**2))
            nInterCoord.append(long(aCoord1.X + nU * math.cos(fTheta1) - nV * math.sin(-fTheta1)))
            nInterCoord.append(long(aCoord1.Y + nU * math.sin(-fTheta1) + nV * math.cos(fTheta1)))
            nInterCoord.append(long(aCoord1.X + nU * math.cos(fTheta1) + nV * math.sin(-fTheta1)))
            nInterCoord.append(long(aCoord1.Y + nU * math.sin(-fTheta1) - nV * math.cos(fTheta1)))
            return tuple(nInterCoord)
        aCoordE2Center = uno.createUnoStruct("com.sun.star.awt.Point")
        aCoord = uno.createUnoStruct("com.sun.star.awt.Point")
        aSize = uno.createUnoStruct('com.sun.star.awt.Size')
        fTheta1 = 0
        fAlfa1 = 2 * math.pi - fAngle1
        fAlfa2 = 2 * math.pi - fAngle2
         ## working in ellipse 1 coordinates system
        fRotation = fAlfa2 - fAlfa1
        aCoordE2Center.X = long((aCoord2.X - aCoord1.X) * math.cos(fAlfa1) + (aCoord2.Y - aCoord1.Y) * math.sin(fAlfa1))
        aCoordE2Center.Y = long(-(aCoord2.X - aCoord1.X) * math.sin(fAlfa1) + (aCoord2.Y - aCoord1.Y) * math.cos(fAlfa1))
        fTestValue = []
        fCosW = aSize2.Width * math.cos(fRotation)
        fSinW = aSize2.Width * math.sin(fRotation)
        fCosH = aSize2.Height * math.cos(fRotation)
        fSinH = aSize2.Height * math.sin(fRotation)
        if fCosW < 1e-3:
            aSize.Width, aSize.Height = aSize2.Height, aSize2.Width
        elif fSinW < 1e-3:
            aSize.Width, aSize.Height =  aSize2.Width, aSize2.Height
        else:
            fThetaXMin = math.atan(- fSinH / fCosW)
            fThetaYMin = math.atan(fCosH / fSinW)
            aSize.Width = abs(long(fCosW * math.cos(fThetaXMin) - fSinH * math.sin(fThetaXMin)))
            aSize.Height = abs(long(fSinW * math.cos(fThetaYMin) + fCosH * math.sin(fThetaYMin)))
        if abs(aCoordE2Center.X) > aSize.Width + aSize1.Width or abs(aCoordE2Center.Y) > aSize.Height + aSize1.Height:
            return ()
        while fTheta1 < 2*math.pi:
            aCoord.X = long(fCosW * math.cos(fTheta1) - fSinH * math.sin(fTheta1) + aCoordE2Center.X)
            aCoord.Y = long(fSinW * math.cos(fTheta1) + fCosH * math.sin(fTheta1) + aCoordE2Center.Y)
            fTestValue.append([fTheta1,\
                               float(aCoord.X)**2/aSize1.Width**2 + float(aCoord.Y)**2/aSize1.Height**2 - 1,\
                               2 * (- fCosW * math.sin(fTheta1) - fSinH * math.cos(fTheta1)) * float(aCoord.X) / aSize1.Width**2 +\
                               2 * (-fSinW * math.sin(fTheta1) + fCosH * math.cos(fTheta1)) * float(aCoord.Y) / aSize1.Height**2])
            fTheta1 = fTheta1 + 2e-1
        bInEllipse = fTestValue[0][1] < 0
        bDecValue = fTestValue[0][2] < 0
        for i in range(len(fTestValue)):
            if abs(fTestValue[i][1]) < 1e-6:
                nInterCoord.append(long(aCoord2.X + aSize2.Width * math.cos(fTestValue[i][0]) * math.cos(fAlfa2)\
                                       - aSize2.Height * math.sin(fTestValue[i][0]) * math.sin(fAlfa2)))
                nInterCoord.append(long(aCoord2.Y + aSize2.Width * math.cos(fTestValue[i][0]) * math.sin(fAlfa2)\
                                       + aSize2.Height * math.sin(fTestValue[i][0]) * math.cos(fAlfa2)))
            elif (fTestValue[i][1] > 0 and bInEllipse) or (fTestValue[i][1] < 0 and not bInEllipse):
                fInc = 2e-1
                while abs(fTestValue[i][1]) > 1e-6 and fInc > 1e-6:
                    fTheta1 = fTestValue[i][0]
                    aCoord.X = long(fCosW * math.cos(fTheta1) - fSinH * math.sin(fTheta1) + aCoordE2Center.X)
                    aCoord.Y = long(fSinW * math.cos(fTheta1) + fCosH * math.sin(fTheta1) + aCoordE2Center.Y)
                    fTestValue[i][1] = float(aCoord.X)**2/aSize1.Width**2 + float(aCoord.Y)**2/aSize1.Height**2 - 1
                    fInc = fInc / 2
                    if (fTestValue[i][1] > 0 and not bInEllipse) or (fTestValue[i][1] < 0 and bInEllipse):
                        fTestValue[i][0] += fInc
                    else:
                        fTestValue[i][0] -= fInc
                nInterCoord.append(long(aCoord2.X + aSize2.Width * math.cos(fTestValue[i][0]) * math.cos(fAlfa2)\
                                       - aSize2.Height * math.sin(fTestValue[i][0]) * math.sin(fAlfa2)))
                nInterCoord.append(long(aCoord2.Y + aSize2.Width * math.cos(fTestValue[i][0]) * math.sin(fAlfa2)\
                                       + aSize2.Height * math.sin(fTestValue[i][0]) * math.cos(fAlfa2)))
                bInEllipse = not bInEllipse
            elif (bDecValue and fTestValue[i][2] >= 0) or (not bDecValue and fTestValue[i][2] < 0):
                fInc = 2e-1
                while abs(fTestValue[i][2]) > 1e-6 and abs(fInc) > 1e-6:
                    fTheta1 = fTestValue[i][0]
                    aCoord.X = long(fCosW * math.cos(fTheta1) - fSinH * math.sin(fTheta1) + aCoordE2Center.X)
                    aCoord.Y = long(fSinW * math.cos(fTheta1) + fCosH * math.sin(fTheta1) + aCoordE2Center.Y)
                    fTestValue[i][1] = float(aCoord.X)**2/aSize1.Width**2 + float(aCoord.Y)**2/aSize1.Height**2 - 1.0
                    fTestValue[i][2] = 2*(-fCosW * math.sin(fTheta1) - fSinH * math.cos(fTheta1)) * float(aCoord.X)/aSize1.Width**2 +\
                                       2*(-fSinW * math.sin(fTheta1) + fCosH * math.cos(fTheta1)) * float(aCoord.Y)/aSize1.Height**2
                    fInc = fInc / 2
                    if (not bDecValue and fTestValue[i][2] >= 0.0) or (bDecValue and fTestValue[i][2] < 0):
                        fTestValue[i][0] += fInc
                    else:
                        fTestValue[i][0] -= fInc
                if abs(fTestValue[i][1]) < 1e-3:
                    nInterCoord.append(long(aCoord2.X + aSize2.Width * math.cos(fTestValue[i][0]) * math.cos(fAlfa2)\
                                           - aSize2.Height * math.sin(fTestValue[i][0]) * math.sin(fAlfa2)))
                    nInterCoord.append(long(aCoord2.Y + aSize2.Width * math.cos(fTestValue[i][0]) * math.sin(fAlfa2)\
                                           + aSize2.Height * math.sin(fTestValue[i][0]) * math.cos(fAlfa2)))
                bDecValue = not bDecValue
        return tuple(nInterCoord)
    ##
    ## Compute coordinates of the tangent point between a line  and circle
    ## Calcule les coordonnes du point de tangence entre une droite et un cercle
    ##
    def getTangentLineCircle(self, aCoord1, fAngle1, aCoord2):
        """Compute coordinates of the tangent point between a line  and circle
        Calcule les coordonnes du point de tangence entre une droite et un cercle
        @param aCoord1 as com.sun.star.awt.Point : coordinates of a point of the line
        @param fAngle1 as float : slope angle of the line
        @param aCoord2 as com.sun.star.awt.Point : coordinates of circle center
        return nX1, nY1 as tuple(int, int)"""
        nTanCoord = []
        fAlfa1 = math.fmod(2 * math.pi - fAngle1, 2*math.pi)
        if fAlfa1 < 1e-3 or abs(math.pi-fAlfa1) < 1e-3:
            nTanCoord.append(aCoord2.X)
            nTanCoord.append(aCoord1.Y)
        elif abs(math.pi/2-fAlfa1) < 1e-3 or abs(3*math.pi/2-fAlfa1) < 1e-3:
            nTanCoord.append(aCoord1.X)
            nTanCoord.append(aCoord2.Y)
        else:
            fP = aCoord1.Y - aCoord2.Y - math.tan(fAlfa1) * (aCoord1.X - aCoord2.X)
            if abs(fP) < 1e-3:
                nTanCoord.append(aCoord2.X)
                nTanCoord.append(aCoord2.Y)
            else:
                nTanCoord.append(long(aCoord2.X - math.tan(fAlfa1) * fP / (1 + math.tan(fAlfa1)**2)))
                nTanCoord.append(long(aCoord2.Y + math.tan(fAlfa1) * (nTanCoord[0] - aCoord2.X) + fP))
        return tuple(nTanCoord)
    ##
    ## Compute coordinates for each tangent point between an ellipse and circle
    ## Calcule les coordonnes des points de tangence entre une ellipse et un cercle
    ##
    def getTangentEllipseCircle(self, aCoord1, aSize1, fAngle1, aCoord2):
        """Compute coordinates for each tangent point between an ellipse and circle
        Calcule les coordonnes des points de tangence entre une ellipse et un cercle
        @param aCoord1 as com.sun.star.awt.Point : coordinates of ellipse center
        @param aSize1 as com.sun.star.awt.Size : half short and great axis dimension
        @param fAngle1 as float : rotation angle
        @param aCoord2 as com.sun.star.awt.Point : coordinates of circle center
        return nX1, nY1, nX2, nY2, nX3, nY3, nX4, nY4 as tuple(int, int, int, int, int, int, int, int)"""
        nTanCoord = []
        aCoord = uno.createUnoStruct('com.sun.star.awt.Point')
        aCoordCircleCenter = uno.createUnoStruct("com.sun.star.awt.Point")
        aCoordCircleCenter.X = long((aCoord2.X - aCoord1.X) * math.cos(fAngle1) - (aCoord2.Y - aCoord1.Y) * math.sin(fAngle1))
        aCoordCircleCenter.Y = long((aCoord2.X - aCoord1.X) * math.sin(fAngle1) + (aCoord2.Y - aCoord1.Y) * math.cos(fAngle1))
        if aSize1.Width == aSize1.Height:
            if not aCoordCircleCenter.X and not aCoordCircleCenter.Y:
                return ()
            fK = aSize1.Width / math.sqrt(aCoordCircleCenter.X**2 + aCoordCircleCenter.Y**2)
            nTanCoord.append(long(aCoord1.X + fK * aCoordCircleCenter.X))
            nTanCoord.append(long(aCoord1.Y + fK * aCoordCircleCenter.Y))
            nTanCoord.append(long(aCoord1.X - fK * aCoordCircleCenter.X))
            nTanCoord.append(long(aCoord1.Y - fK * aCoordCircleCenter.Y))
            return tuple(nTanCoord)
        fTestValue = []
        fTheta = 0
        fK = float(aSize1.Height) / aSize1.Width
        while True:
            aCoord.X = aSize1.Width * math.cos(fTheta)
            aCoord.Y = aSize1.Height * math.sin(fTheta)
            fTestValue.append([fTheta, aCoord.Y*(aCoord.X-aCoordCircleCenter.X)-fK**2*aCoord.X*(aCoord.Y-aCoordCircleCenter.Y)])
            if fTheta > 13*math.pi/6:
                break
            fTheta = fTheta + math.pi/4
        bDecValue = fTestValue[0][1] < 0
        for i in range(len(fTestValue)):
            if (bDecValue and fTestValue[i][1] >= 0) or (not bDecValue and fTestValue[i][1] < 0):
                fInc = math.pi/4
                while abs(fInc) > 1e-6:
                    aCoord.X, aCoord.Y = aSize1.Width * math.cos(fTestValue[i][0]), aSize1.Height * math.sin(fTestValue[i][0])
                    fTestValue[i][1] = aCoord.Y*(aCoord.X-aCoordCircleCenter.X)-fK**2*aCoord.X*(aCoord.Y-aCoordCircleCenter.Y)
                    fInc = fInc / 2
                    if (not bDecValue and fTestValue[i][1] >= 0) or (bDecValue and fTestValue[i][1] < 0):
                        fTestValue[i][0] += fInc
                    else:
                        fTestValue[i][0] -= fInc
                    if (aCoord.X-aSize1.Width*math.cos(fTestValue[i][0]))<2 and (aCoord.Y-aSize1.Height*math.sin(fTestValue[i][0]))<2:
                        nTanCoord.append(long(aCoord1.X + aSize1.Width * math.cos(fTestValue[i][0]) * math.cos(fAngle1)\
                                             + aSize1.Height * math.sin(fTestValue[i][0]) * math.sin(fAngle1)))
                        nTanCoord.append(long(aCoord1.Y - aSize1.Width * math.cos(fTestValue[i][0]) * math.sin(fAngle1)\
                                             + aSize1.Height * math.sin(fTestValue[i][0]) * math.cos(fAngle1)))
                        break
                bDecValue = not bDecValue
        return tuple(nTanCoord)
    ##
    ## Compute coordinates for each tangent point between an ellipse and a line
    ## Calcule les coordonnes des points de tangence entre une ellipse et une droite
    ##
    def getTangentEllipseLine(self, aCoord1, aSize1, fAngle1, aCoord2):
        """Compute coordinates for each tangent point between an ellipse and line
        Calcule les coordonnes des points de tangence entre une ellipse et une droite
        @param aCoord1 as com.sun.star.awt.Point : coordinates of ellipse center
        @param aSize1 as com.sun.star.awt.Size : half short and great axis dimension
        @param fAngle1 as float : rotation angle
        @param aCoord2 as com.sun.star.awt.Point : coordinates of a point belonging to the line
        return nX1, nY1, nX2, nY2, nX3, nY3, nX4, nY4 as tuple(int, int, int, int, int, int, int, int)"""
        nTanCoord = []
        aCoord = uno.createUnoStruct('com.sun.star.awt.Point')
        aCoordLine = uno.createUnoStruct("com.sun.star.awt.Point")
        aCoordLine.X = long((aCoord2.X - aCoord1.X) * math.cos(fAngle1) - (aCoord2.Y - aCoord1.Y) * math.sin(fAngle1))
        aCoordLine.Y = long((aCoord2.X - aCoord1.X) * math.sin(fAngle1) + (aCoord2.Y - aCoord1.Y) * math.cos(fAngle1))
        nDelta = aSize1.Width**2 * aCoordLine.Y**2 + aSize1.Height**2 * aCoordLine.X**2 - aSize1.Width**2 * aSize1.Height**2
        if nDelta < 0:
            return ()
        elif nDelta == 0:
            return (aCoord2.X, aCoord2.Y)
        fM1 = (-aCoordLine.X * aCoordLine.Y + math.sqrt(nDelta)) / (aSize1.Width**2 - aCoordLine.X**2)
        fP1 = aCoordLine.Y - fM1 * aCoordLine.X
        fM2 = (-aCoordLine.X * aCoordLine.Y - math.sqrt(nDelta)) / (aSize1.Width**2 - aCoordLine.X**2)
        fP2 = aCoordLine.Y - fM2 * aCoordLine.X
        aCoord.X = long(-aSize1.Width**2 * fM1 * fP1 / (aSize1.Height**2 + aSize1.Width**2 * fM1**2))
        aCoord.Y = long(fM1 * aCoord.X + fP1)
        nTanCoord.append(long(aCoord1.X + aCoord.X * math.cos(fAngle1) + aCoord.Y * math.sin(fAngle1)))
        nTanCoord.append(long(aCoord1.Y - aCoord.X * math.sin(fAngle1) + aCoord.Y * math.cos(fAngle1)))
        aCoord.X = long(-aSize1.Width**2 * fM2 * fP2 / (aSize1.Height**2 + aSize1.Width**2 * fM2**2))
        aCoord.Y = long(fM2 * aCoord.X + fP2)
        nTanCoord.append(long(aCoord1.X + aCoord.X * math.cos(fAngle1) + aCoord.Y * math.sin(fAngle1)))
        nTanCoord.append(long(aCoord1.Y - aCoord.X * math.sin(fAngle1) + aCoord.Y * math.cos(fAngle1)))
        return tuple(nTanCoord)
    ##
    ## Compute coordinates of circle center and its radius given 3 points
    ## Calcule les coordonnees du centre et son rayon d'un cercle passant par 3 points
    ##
    def getCircle3P(self, aCoordA, aCoordB, aCoordM):
        """Compute coordinates of circle center and its radius given 3 points
        Calcule les coordonnees du centre et son rayon d'un cercle passant par 3 points
        @param aCoord1 as com.sun.star.awt.Point : coordinates of a point belonging to the circle
        @param aCoord2 as com.sun.star.awt.Point : coordinates of a point belonging to the circle
        @param aCoord3 as com.sun.star.awt.Point : coordinates of a point belonging to the circle
        return nXCenter, nYCenter, nRadius as tuple(int, int, int)"""
        nCoeff = [[aCoordB.X - aCoordA.X, aCoordB.Y - aCoordA.Y, (aCoordB.X**2 - aCoordA.X**2 + aCoordB.Y**2 - aCoordA.Y**2)/2],]
        nCoeff.append([aCoordM.X - aCoordA.X, aCoordM.Y - aCoordA.Y, (aCoordM.X**2 - aCoordA.X**2 + aCoordM.Y**2 - aCoordA.Y**2)/2])
        nDet = nCoeff[0][0] * nCoeff[1][1] - nCoeff[1][0] * nCoeff[0][1]
        nCircleData = []
        if nDet == 0:
            nCircleData.append((aCoordA.X + aCoordB.X) / 2)
            nCircleData.append((aCoordA.Y + aCoordB.Y) / 2)
        else:
            nCircleData.append((nCoeff[0][2] * nCoeff[1][1] - nCoeff[1][2] * nCoeff[0][1]) / nDet)
            nCircleData.append((nCoeff[0][0] * nCoeff[1][2] - nCoeff[1][0] * nCoeff[0][2]) / nDet)
        nCircleData.append(long(math.sqrt((nCircleData[0] - aCoordA.X)**2 + (nCircleData[1] - aCoordA.Y)**2)))
        return tuple(nCircleData)
    ##
    ## Compute X, Y from absissa, ordinate of a point related to a line
    ## Calcule X,Y � partir de absisse, ordonnee par rapport � un droite d'un point
    ##
    def getCoordFromAbsOrd(self, aCoordA, aCoordB, aAbsissa, aOrdinate):
        """Compute X, Y from absissa, ordinate of a point related to a line
        Calcule X,Y �partir de absisse, ordonnee par rapport �un droite d'un point
        @param aCoordA as com.sun.star.awt.Point : origin coordinates of the line
        @param aCoordB as com.sun.star.awt.Point : end coordinates of the line
        @param aAbsissa as Long
        @param aOrdinate as long
        return coordinates as com.sun.star.awt.Point"""
        nDist, fAngle = self.toPolarCoord(aCoordA, aCoordB)
        aCoord = uno.createUnoStruct("com.sun.star.awt.Point")
        aCoord.X = aCoordA.X + aAbsissa * math.cos(fAngle) + aOrdinate * math.sin(fAngle)
        aCoord.Y = aCoordA.Y - aAbsissa * math.sin(fAngle) + aOrdinate * math.cos(fAngle)
        return aCoord
    ##
    ## Compute absissa, odinate from a point to a line and the length of the line
    ## Calcule absisse et ordonnee d'un point a un segment et la longueur
    ##
    def getDist2Line(self, aCoordA, aCoordB, aCoordM):
        """Compute a distance from a point to a line
        Calcule la distance d'un point a une droite
        @param aCoordA as com.sun.star.awt.Point : coordinates of a point belonging to the line
        @param aCoordB as com.sun.star.awt.Point : coordinates of a point belonging to the line
        @param aCoordC as com.sun.star.awt.Point : coordinates of a point off line
        return absissa, ordinate, length as tuple(long, long, long)"""
        nArea = (aCoordB.Y - aCoordM.Y) * aCoordA.X + (aCoordM.Y - aCoordA.Y) * aCoordB.X + (aCoordA.Y - aCoordB.Y) * aCoordM.X
        nDist = long(math.sqrt((aCoordA.X - aCoordB.X)**2 + (aCoordA.Y - aCoordB.Y)**2))
        if nDist:
            nProd = (aCoordB.X - aCoordA.X) * (aCoordM.X - aCoordA.X) + (aCoordB.Y - aCoordA.Y) * (aCoordM.Y - aCoordA.Y)
            return long(nProd / nDist), long(nArea / nDist), nDist
        else:
            nDist = self.toPolarCoord(aCoordA, aCoordM)[0]
            return 0, nDist, 0
    ##
    ## Compute absissa, odinate from a point to an arc and the length of arc
    ## Calcule absisse et ordonnee d'un point a un arc et la longueur de l arc
    ##
    def getDist2Arc(self, aCoordA, aSize, fAngle, fStartAngle, fEndAngle, aCoordB):
        """Compute absissa, odinate from a point to an arc and the length of arc
        Calcule absisse et ordonnee d'un point a un arc et la longueur de l arc
        @param aCoordA as com.sun.star.awt.Point : coordinates of arc center
        @param aSize as com.sun.star.awt.Size : radius of arc
        @param fAngle as float : rotate angle
        @param fStartAngle as float : start angle of arc
        @param fEndAngle as float : end angle of arc
        @param aCoordB as com.sun.star.awt.Point : coordinates of a point off arc
        return absissa, ordinate, length as tuple(long, long, long)"""
        nRadius = long(math.sqrt(aSize.Width * aSize.Height))
        nDist1, fAngle1 = self.toPolarCoord(aCoordA, aCoordB)
        # fAngle1 = self.getPointOnEllipse(fAngle1, None, aCoordA, aSize, fAngle)[1]
        fAngle1 = fAngle1 - fAngle
        if fAngle1 < 0:
            fAngle1 = fAngle1 + 2 * math.pi
        fPolarEndAngle = math.atan2(aSize.Height * math.sin(fEndAngle), aSize.Width * math.cos(fEndAngle))
        if fPolarEndAngle < 0:
            fPolarEndAngle = fPolarEndAngle + 2 * math.pi
        fPolarStartAngle = math.atan2(aSize.Height * math.sin(fStartAngle), aSize.Width * math.cos(fStartAngle))
        if fPolarStartAngle < 0:
            fPolarStartAngle = fPolarStartAngle + 2 * math.pi
        fAngle2 = fPolarEndAngle - fPolarStartAngle
        if fAngle2 <= 0:
            fAngle2 = fAngle2 + 2 * math.pi
        fAngle3 = fAngle1 - fPolarStartAngle
        if fPolarStartAngle > fPolarEndAngle and fAngle3 <= 0:
            fAngle3 = fAngle3 + 2 * math.pi
        nDist2 = long((aSize.Width * aSize.Height) / math.sqrt((aSize.Height * math.cos(-fAngle1))**2 + (aSize.Width * math.sin(-fAngle1))**2))
        return long(fAngle3*nRadius), (nDist1 - nDist2), long(fAngle2*nRadius)
    ##
    ## Compute absissa, ordinate of a point of an ellipse or circle
    ## Calcule absisse et ordonnee d'un point d'une ellipse ou cercle
    ##
    def getPointOnEllipse(self, fPolarAngle, fEllAngle, aCenter, aSize, fRotation):
        """Compute absissa, ordinate of a point of an ellipse or circle
        Calcule absisse et ordonnee d'un point d'une ellipse ou cercle
        @param fPolarAngle as float : polar global angle
        @param fEllAngle as float : elliptic local angle
        @param aCenter as com.sun.star.awt.Point : center coordinates
        @param aSize as com.sun.star.awt.Size : axis sizes of ellipse
        @param fRotation as float : rotation angle
        @return tuple (aGlobalPoint as com.sun.star.awt.Point, fTheta as float)"""
        if aSize.Width == 0:
            return aCenter, float(0 + fRotation)
        if aSize.Height == 0:
            return aCenter, math.pi/2 + fRotation
        aLocalPoint = [uno.createUnoStruct("com.sun.star.awt.Point"), uno.createUnoStruct("com.sun.star.awt.Point")]
        aGlobalPoint = uno.createUnoStruct("com.sun.star.awt.Point")
        aLocalPoint[1].X = aLocalPoint[1].Y = 0L
        if not fPolarAngle is None:
            fAlfa = fPolarAngle - fRotation
            aLocalPoint[0].X = long(aSize.Width * aSize.Height * math.cos(fAlfa) / math.sqrt((aSize.Width * math.sin(-fAlfa))**2+(aSize.Height * math.cos(fAlfa))**2))
            aLocalPoint[0].Y = long(aLocalPoint[0].X * math.tan(-fAlfa))
            fTheta = -math.atan2(float(aLocalPoint[0].Y)/aSize.Height, float(aLocalPoint[0].X)/aSize.Width)
            if fTheta < 0:
                fTheta = fTheta + math.pi * 2E0
        else:
            aLocalPoint[0].X = long(aSize.Width * math.cos(fEllAngle))
            aLocalPoint[0].Y = long(aSize.Height * math.sin(-fEllAngle))
            fTheta = self.toPolarCoord(aLocalPoint[1], aLocalPoint[0])[1] + fRotation
        aGlobalPoint.X = long(aCenter.X + aLocalPoint[0].X * math.cos(fRotation) + aLocalPoint[0].Y * math.sin(fRotation))
        aGlobalPoint.Y = long(aCenter.Y - aLocalPoint[0].X * math.sin(fRotation) + aLocalPoint[0].Y * math.cos(fRotation))
        return aGlobalPoint, fTheta

# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()
g_ImplementationHelper.addImplementation(Compute,                                          # UNO object class
					 "org.openoffice.comp.pyuno.deneux.Compute",       # implemenation name
					 ("org.openoffice.comp.pyuno.Compute",),)          # list of implemented services
