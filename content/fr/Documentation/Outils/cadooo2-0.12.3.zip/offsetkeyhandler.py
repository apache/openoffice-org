#	$Id: offsetkeyhandler.py,v 1.1 2006-07-16 10:02:13 gerard Exp $
## ********************************************************************************
## 
## Copyright (C) 2005 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import unohelper, uno
    import math, traceback, operator
    from com.sun.star.task import XJob
    from com.sun.star.awt.KeyModifier import SHIFT
except ImportError:
    print "probleme d'import"
#===============================
# gestion des evenements clavier
# handling keyboard events
#===============================
class OffsetKeyHandler(unohelper.Base, XJob):
    """gestion des evenements clavier
    handling keyboard events"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
        # Datum needed by coordinates input form
        self.aCoordData = {}
        self.aCoordData["TITLE"]  = "No Title"
        self.aCoordData["FLAG"] = 0
        self.aCoordData["COMMENT"] = "No comment"
        self.aCoordData["X"] = 0
        self.aCoordData["XUNIT"] = "m"
        self.aCoordData["Y"] = 0
        self.aCoordData["YUNIT"] = "m"
        self.aCoordData["RETURN"] = False
        # Struct needed to pass arguments throught UNO
        self.aNamedValues = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        self.aNamedValues[0].Name = "CONTEXT"
        self.aEntityPosSize = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.EntityPosSize", self.ctx)
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # ==================================
    # actions clavier - keyboard actions
    # aNamedValues as tuple of NamedValue
    #   Name         Value
    # KEYCODE     integer
    # L2OSTATE    tuple of 5 integers (0 or 1)
    # DRAWSCALE
    # DRAWSCALE
    # CANCELJOB
    # ORTHOMODE
    # SHAPE
    # ==================================
    def execute(self, aArgs):
        aValues = dict(list(aArgs[0].Value))
        # ----------------------------------------------------------------------------------------------------
        if [516, 520, 524, 527, 531].count(aValues['KEYEVENT'].KeyCode) and not aValues['KEYEVENT'].Modifiers:
            # e,   i,   m,   p,   t => link 2 entities
            i = [516, 520, 524, 527, 531].index(aValues['KEYEVENT'].KeyCode)
            bKHState = list(aValues['L2OSTATE'])
            bKHState[i] = not bKHState[i]
            aValues['L2OSTATE'] = tuple(bKHState)
            aStatusBarCheckBox = aValues['STATUSBARCONTROL'][i]
            if aStatusBarCheckBox.getState() != aValues['L2OSTATE'][i]:
                aStatusBarCheckBox.setState(aValues['L2OSTATE'][i])
        # --------------------------------------------------------------------------------------------------
        elif aValues['KEYEVENT'].KeyCode in (523, 529) and not aValues['KEYEVENT'].Modifiers:
            # .................................l, ..r
            aMsgL10n = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
            aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
            aParms[0].Name = "Translation"
            # ---------------------------------------------------------------------------
            aParms[0].Value = ("k0", "k1")
            aParms = aMsgL10n.execute(aParms)
            aCoordInput = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DataInputBox", self.ctx)
            self.aCoordData["TITLE"]  = aParms[0].Value[0]
            self.aCoordData["FLAG"] = 0
            self.aCoordData["COMMENT"] = aParms[0].Value[1]
            self.aCoordData["RETURN"] = False
            self.aCoordData["X"] = float(aValues['OFFSET']) / (100000 * aValues['DRAWSCALE'])
            self.aNamedValues[0].Value = tuple(self.aCoordData.items())
            self.aCoordData = dict(list(aCoordInput.execute(self.aNamedValues)[0].Value))
            # ---------------------------
            if self.aCoordData["RETURN"]:
                aValues['OFFSET'] = long(self.aCoordData['X']*aValues['DRAWSCALE'])
        # --------------------------------------------------------------------------------
        elif aValues['KEYEVENT'].KeyCode in (1281,) and not aValues['KEYEVENT'].Modifiers:
            #                                 Esc => kill job
            aValues['CANCELJOB'] = True
        # -------------------------------------------------------------------------------
        elif aValues['KEYEVENT'].KeyCode in (512,) and not aValues['KEYEVENT'].Modifiers:
            #                                  a => axonometric mode
            aValues['ORTHOMODE'] = not aValues['ORTHOMODE']
            aStatusBarCheckBox = aValues['STATUSBARCONTROL'][5]
            if aStatusBarCheckBox.getState() != aValues['ORTHOMODE']:
                aStatusBarCheckBox.setState(aValues['ORTHOMODE'])
        # --------------------------------------------------------------------------------
        elif aValues['KEYEVENT'].KeyCode in (1289,) and not aValues['KEYEVENT'].Modifiers:
            #                                  * => repeat mode
            aValues['REPEATMODE'] = not aValues['REPEATMODE']
            aStatusBarCheckBox = aValues['STATUSBARCONTROL'][6]
            if aStatusBarCheckBox.getState() != aValues['REPEATMODE']:
                aStatusBarCheckBox.setState(aValues['REPEATMODE'])
        self.aNamedValues[0].Value = tuple(aValues.items())
        return self.aNamedValues
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()
g_ImplementationHelper.addImplementation(OffsetKeyHandler,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.OffsetKeyHandler", # implemenation name
                                         ("org.openoffice.comp.pyuno.OffsetKeyHandler",),)    # list of implemented services
