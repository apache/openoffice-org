# 	$Id: ellarcjob.py,v 1.1 2006-07-16 10:02:13 gerard Exp $	
# -*- coding: latin-1 -*-
## ********************************************************************************
## Copyright (C) 2005, 2006, 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    from com.sun.star.task import XJobExecutor
    from com.sun.star.drawing.CircleKind import ARC
    import traceback
except ImportError:
    print "probleme d'import"
#======================================================
# a class to draw an arc of circle from center and radius
# une classe pour tracer arc de cercle depuis le centre
#======================================================
class EllArcJob(unohelper.Base, XJobExecutor):
    """Trace un arc d'ellipse depuis le centre
    Draws an arc of ellipse from center"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
    ## *********************
    ## Called from GUI
    ## *********************
    def trigger(self, args):
        aEnv = {}
        aEnv['UNOTYPE'] = "EllipseShape"
        aEnv['ENTITYPE'] = "ELLARC"
        aEnv['STEPS'] = 5
        aEnv['MODE'] = ('CREATE', 'RADIUS', 'RADIUS2', 'STARTANGLE', 'ENDANGLE')
        aEnv['CIRCLEKIND'] = ARC
        aNamedValues = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aNamedValues[0].Name = "CONTEXT"
        aMsgL10n = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
        aNamedValues[0].Value = ("ea0", "ea1", "ea2", "ea3", "ea4", "ea5")
        aNamedValues = aMsgL10n.execute(aNamedValues)
        aEnv['COMMENT'] = (aNamedValues[0].Value)
        aCadoooJob = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.CadoooJob", self.ctx)
        aNamedValues[0].Value = tuple(aEnv.items())
        aEnv = dict(list(aCadoooJob.execute(aNamedValues)[0].Value))
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(EllArcJob,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.EllArc", # implemenation name
                                         ("org.openoffice.comp.pyuno.EllArc",),)    # list of implemented services
