# 	$Id: magneticpoleshape.py,v 1.1 2006-07-16 10:02:13 gerard Exp $	
## ********************************************************************************
## magneticpoleshape jeu jan 26 20:18:45 CET 2005
## Copyright (C) 2005 G�ard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    import math, traceback
    from com.sun.star.drawing.FillStyle import NONE
    from com.sun.star.task import XJob
except ImportError:
    print "probleme d'import"
# =========================
# Gerer la marque d'ancrage
# Handle the anchor
# =========================
class MagneticPoleShape(unohelper.Base, XJob):
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = ctx.ServiceManager
        # translation component
        aMsgL10n = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", ctx)
        self.aArgs = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        self.aArgs[0].Name = "Translation"
        self.aArgs[0].Value = tuple(["st%d" % i for i in range(5)])
        self.aArgs = aMsgL10n.execute(self.aArgs)
    # ========================================
    # sets the shape of the magnetic pole
    # and draws it at L2OCOORD
    # the dictionary args must contain
    # MAGNETKIND a character in (e, i, m, p, t)
    # MAGNETVISIBLE a flag as boolean
    # MAGNETSIZE a size as long integer
    # L2OCOORD a struct com.sun.star.awt.Point
    # ========================================
    def execute(self, aNamedValues):
        aEnv = dict(list(aNamedValues[0].Value))
        aSize = uno.createUnoStruct("com.sun.star.awt.Size")
        aSize.Width = aEnv['MAGNETSIZE']
        aSize.Height = aEnv['MAGNETSIZE']
        aCoord = uno.createUnoStruct("com.sun.star.awt.Point")
        aCoord.X = (aEnv['L2OCOORD'].X - aEnv['VISIBLEAREA'].X) / aEnv['DEVICEXSCALE'] - aSize.Width/2
        aCoord.Y = (aEnv['L2OCOORD'].Y - aEnv['VISIBLEAREA'].Y) / aEnv['DEVICEYSCALE'] - aSize.Height/2
        if aEnv['MAGNETVISIBLE']:
            if aEnv['MAGNETKIND'] == "0":
                aEnv['MAGNETVISIBLE'] = False
                aPeer = aEnv['MAGNETSHAPE'].getPeer()
                aPeer.dispose()
                aEnv['MAGNETSHAPE'].setModel(None)
                aEnv['MAGNETSHAPE'] = None
                aNamedValues[0].Value = tuple(aEnv.items())
                return aNamedValues
        elif aEnv['MAGNETKIND'] == "0":
            aNamedValues[0].Value = tuple(aEnv.items())
            return aNamedValues
        else:
            aButtonModel = self.smgr.createInstance("com.sun.star.awt.UnoControlButtonModel")
            aButtonModel.BackgroundColor = 0xff0000
            aButtonModel.Label = ""
            aButtonModel.HelpText = self.aArgs[0].Value[['e', 'i', 'm', 'p', 't'].index(aEnv['MAGNETKIND'])]
            aEnv['MAGNETSHAPE'] = self.smgr.createInstance("com.sun.star.awt.UnoControlButton")
            aEnv['MAGNETSHAPE'].setModel(aButtonModel)
            aEnv['MAGNETSHAPE'].createPeer(aEnv['COMPONENTWINDOW'].Toolkit, aEnv['COMPONENTWINDOW'])
            aEnv['MAGNETSHAPE'].setDesignMode(False)
            aEnv['MAGNETSHAPE'].setEnable(True)
        aPeer = aEnv['MAGNETSHAPE'].getPeer()
        aPeer.setPosSize(aCoord.X, aCoord.Y, aSize.Width, aSize.Height, 15)
        aPeer.setBackground(0xff0000)
        aPeer.setVisible(True)
        aEnv['MAGNETVISIBLE'] = True
        aEnv['MAGNETSHAPE'].Model.HelpText = self.aArgs[0].Value[['e', 'i', 'm', 'p', 't'].index(aEnv['MAGNETKIND'])]
        aEnv['MAGNETSHAPE'].setLabel(aEnv['MAGNETSHAPE'].Model.HelpText[0])
        aEnv['MAGNETSHAPE'].setVisible(True)
        aNamedValues[0].Value = tuple(aEnv.items())
        return aNamedValues
    # **********************************
    # inspection wrapper
    # **********************************
    def inspectObject(self, aObject):
        aDiveIn = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DiveIn", self.ctx)
        aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aParms[0].Name = "inspect"
        aParms[0].Value = aObject
        aEnv = aDiveIn.execute(aParms)
        return
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(MagneticPoleShape,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.MagneticPoleShape", # implemenation name
                                         ("org.openoffice.comp.pyuno.MagneticPoleShape",),)    # list of implemented services
