#	$Id: shapemousehandler.py,v 1.1 2006-07-16 10:02:14 gerard Exp $
# -*- coding: latin-1 -*-
## ********************************************************************************
## 
## Copyright (C) 2005 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    import math, traceback
    from com.sun.star.task import XJob
except ImportError:
    print "probleme d'import"
# ===================================================
# Gerer les saisies de points et validation d'entites
# Handle points inputs and entities validation
# ===================================================
class ShapeMouseHandler(unohelper.Base, XJob):
    """Gere les saisies de points et validation d'entite
    Handles points inputs and entities validation"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.aEntityPosSize = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.EntityPosSize", self.ctx)
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # **********************************
    # Handles mouse clicks
    # MOUSEEVENT  struct MouseEvent
    # VALIDL2O    integer (0 or 1)
    # L2OCOORD    tuple of 2 integers
    # CANCELJOB   integer (0 or 1)
    # STEP
    # COORDS%s
    # REPEATMODE
    # SHAPE
    # **********************************
    def execute(self, aArgs):
        self.aEnv = dict(list(aArgs[0].Value))
        # ----------------------------------------
        if self.aEnv['MOUSEEVENT'].Buttons > 1: # don't handle mouse buttons but left
            return aArgs
        aShapeCoords = [list(c) for c in self.aEnv['COORDS']]
        aMouseCoord = uno.createUnoStruct("com.sun.star.awt.Point")
        # --------------------------------------------
        if self.aEnv['MOUSEEVENT'].ClickCount == 1: # one click ?
            # --------------------------------------------------------------------------------------------------------------
            if not self.aEnv.has_key('EDITMODE'):
                aMouseCoord.X, aMouseCoord.Y = self.compute("transformMouseCoord", tuple(self.aEnv.items()))
                # --------------------------
                if self.aEnv['VALIDL2O']: # valid link to entity ?
                    aMouseCoord.X, aMouseCoord.Y = self.aEnv['L2OCOORD'].X, self.aEnv['L2OCOORD'].Y
                aShapeCoords[-1][-1].X, aShapeCoords[-1][-1].Y = (aMouseCoord.X, aMouseCoord.Y)
                self.aEnv['COORDS'] = tuple([tuple(c) for c in aShapeCoords])
                self.aEnv['ORIGINCOORD'].X, self.aEnv['ORIGINCOORD'].Y = aMouseCoord.X, aMouseCoord.Y
                self.aEnv['VALIDORIGIN'] = True
                # --------------------------
                if self.aEnv['STEP'] != 0: # is it 1st point ?
                    aArgs[0].Value = tuple(self.aEnv.items())
                    self.aEnv = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                self.aEnv['STEP'] = self.aEnv['STEP'] % self.aEnv['STEPS'] + 1
                # -----------------------------------------------
                if self.aEnv['STEP'] == self.aEnv['STEPS']: # is it the last point ?
                    self.aEnv['SHAPE'].setName("")
                    self.aEnv['SHAPE'].LineColor = self.aEnv['SHAPE'].Style.LineColor
                    self.aEnv['SHAPE'].LineWidth = self.aEnv['SHAPE'].Style.LineWidth
                    # ----------------------------
                    if self.aEnv['REPEATMODE']: # repeat mode on ?
                        self.aEnv['STEP'] = 0
                        self.aEnv['VALIDORIGIN'] = False
                        self.aEnv['VALIDLIST'] = False
                        self.aEnv['SHAPE'] = None
                        self.aEnv['GROUPSHAPE'] = self.aEnv['CONTROLLER'].getCurrentPage()
                        aShapeCoords = [[uno.createUnoStruct("com.sun.star.awt.Point")]]
                    else:
                        self.aEnv['STOPJOB'] = True
                else:
                    aShapeCoords[-1].append(uno.createUnoStruct("com.sun.star.awt.Point"))
        # --------------------------------------------
        elif self.aEnv['MOUSEEVENT'].ClickCount == 2:
            self.aEnv['STEP'] = self.aEnv['STEP'] % self.aEnv['STEPS'] - 1
            del aShapeCoords[-1][-2:]
            if not (len(aShapeCoords) > 0 and len(aShapeCoords[0]) > 1):
                self.aEnv['CANCELJOB'] = True
            else:
                self.aEnv['COORDS'] = tuple([tuple(c) for c in aShapeCoords])
                aArgs[0].Value = tuple(self.aEnv.items())
                self.aEnv = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                self.aEnv['SHAPE'].setName("")
                self.aEnv['SHAPE'].LineColor = self.aEnv['SHAPE'].Style.LineColor
                self.aEnv['SHAPE'].LineWidth = self.aEnv['SHAPE'].Style.LineWidth
                # ----------------------------
                if self.aEnv['REPEATMODE']: # repeat mode on ?
                    self.aEnv['STEP'] = 0
                    self.aEnv['VALIDORIGIN'] = False
                    self.aEnv['VALIDLIST'] = False
                    self.aEnv['SHAPE'] = None
                    self.aEnv['GROUPSHAPE'] = self.aEnv['CONTROLLER'].getCurrentPage()
                    self.aEnv['COORD'] = ((uno.createUnoStruct("com.sun.star.awt.Point"),),)
                    aShapeCoords = [[uno.createUnoStruct("com.sun.star.awt.Point")]]
                else:
                    self.aEnv['STOPJOB'] = True
        self.aEnv['COORDS'] = tuple([tuple(c) for c in aShapeCoords])
        aArgs[0].Value = tuple(self.aEnv.items())
        return aArgs
    # **********************************
    # inspection wrapper
    # **********************************
    def inspectObject(self, aObject):
        aDiveIn = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.DiveIn", self.ctx)
        aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aParms[0].Name = "inspect"
        aParms[0].Value = aObject
        aValues = dict(list(aDiveIn.execute(aParms)[0].Value))
        return
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(ShapeMouseHandler,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.ShapeMouseHandler", # implemenation name
                                         ("org.openoffice.comp.pyuno.ShapeMouseHandler",),)    # list of implemented services
