#	$Id: shapedraw.py,v 1.1 2006-07-16 10:02:14 gerard Exp $
## ********************************************************************************
## 
## Copyright (C) 2005, 2006, 2007 Gerard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    from com.sun.star.task import XJob
    import math, traceback
except ImportError:
    print "probleme d'import"
#======================================================
# a class to draw an entity
# une classe pour tracer une entite
#======================================================
class ShapeDraw(unohelper.Base, XJob):
    """Trace une entite graphique
    Draws a graphical entity"""
    def __init__(self, ctx):
        self.ctx = ctx
        desktop = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.frame.Desktop",self.ctx)
        self.aLink2Obj = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.Link2Obj", self.ctx)
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # ==============================
    def execute(self, aNamedValues):
        self.aEnv = dict(list(aNamedValues[0].Value))
        sText = self.aEnv['COMMENT'][0] + self.aEnv['COMMENT'][self.aEnv['STEP']+1]
        self.aEnv['STATUSBARCONTROL'][-1].setText(sText)
        # a single mouse move => check link to object
        aMouseCoord = self.compute('transformMouseCoord', tuple(self.aEnv.items()))
        self.aEnv['COORDS'][-1][-1].X = aMouseCoord[0]
        self.aEnv['COORDS'][-1][-1].Y = aMouseCoord[1]
        if list(self.aEnv['L2OSTATE']).count(0) != 5:
            aNamedValues[0].Value = tuple(self.aEnv.items())
            aNamedValues[1].Value = "spot"
            self.aEnv = dict(list(self.aLink2Obj.execute(aNamedValues)[0].Value))
        # first step => create a graphical entity
        if self.aEnv['VALIDL2O']:
            self.aEnv['COORDS'][-1][-1].X = self.aEnv['L2OCOORD'].X
            self.aEnv['COORDS'][-1][-1].Y = self.aEnv['L2OCOORD'].Y
        self.aEnv['GROUPSHAPE'] = self.aEnv['CONTROLLER'].getCurrentPage()
        aNamedValues[0].Value = tuple(self.aEnv.items())
        return aNamedValues
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(ShapeDraw,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.ShapeDraw", # implemenation name
                                         ("org.openoffice.comp.pyuno.ShapeDraw",),)    # list of implemented services
