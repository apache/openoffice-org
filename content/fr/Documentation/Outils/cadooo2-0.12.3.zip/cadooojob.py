#	$Id: cadooojob.py,v 1.2 2007/03/05 15:33:37 gerard Exp $
# -*- coding: latin-1 -*-
## ********************************************************************************
## 
## Copyright (C) 2006, 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    from com.sun.star.task import XJob
    from time import sleep
    import traceback
    from com.sun.star.awt import XMouseMotionListener, XKeyHandler, XMouseClickHandler
    from com.sun.star.awt import XWindowListener, XItemListener, XAdjustmentListener
    from com.sun.star.registry import InvalidRegistryException
    from com.sun.star.registry.RegistryValueType import NOT_DEFINED
    from com.sun.star.accessibility.AccessibleRole import SCROLL_BAR, SCROLL_PANE, DOCUMENT, PANEL
except ImportError:
    print "probleme d'import"
#======================================================
# a class to draw or edit a graphical entity
# une classe pour tracer ou edite une entite graphique
#======================================================
class CadoooJob(unohelper.Base, XJob, XAdjustmentListener, XMouseMotionListener, XKeyHandler, XMouseClickHandler, XItemListener, XWindowListener):
    """Trace ou edit une entite graphique
    Draws a graphical entity"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
        # get the central desktop object
        self.desktop = self.smgr.createInstanceWithContext( "com.sun.star.frame.Desktop",self.ctx)
    ## *********************
    ## Other init stuffs
    ## *********************
    def execute(self, aArgs):
        self.aEnv = dict(list(aArgs[0].Value))
        # access the current draw document
        if self.desktop.ActiveFrame.ActiveFrame:
            self.aEnv['CONTROLLER'] = self.desktop.ActiveFrame.ActiveFrame.Controller
        else:
            self.aEnv['CONTROLLER'] = self.desktop.ActiveFrame.Controller
        self.aEnv['MODEL'] = self.aEnv['CONTROLLER'].Model
        self.aEnv['CONTROLLER'].select(None)
        self.aEnv['DESKTOPWINDOW'] = self.desktop.ActiveFrame.ContainerWindow.Toolkit.getDesktopWindow()
        # self.inspectObject(self.aEnv['CONTROLLER'])
        # find the window document and scroll bars
        self.scrollbars = []
        for i in range(self.aEnv['CONTROLLER'].Frame.ComponentWindow.AccessibleContext.AccessibleChildCount):
            aChild = self.aEnv['CONTROLLER'].Frame.ComponentWindow.AccessibleContext.getAccessibleChild(i)
            if aChild.AccessibleContext.AccessibleRole == SCROLL_PANE:
                for j in range(aChild.AccessibleContext.AccessibleChildCount):
                    aSubChild = aChild.AccessibleContext.getAccessibleChild(j)
                    if aSubChild.AccessibleContext.AccessibleRole == DOCUMENT:
                        aLocation = aSubChild.Location
                        aSize = aSubChild.Size
                    if aSubChild.AccessibleContext.AccessibleRole == SCROLL_BAR:
                        self.scrollbars.append(aSubChild)
                for w in aChild.Windows:
                    nWidth, nHeight = (aLocation.X-w.PosSize.X) / 2 + aSize.Width, (aLocation.Y-w.PosSize.Y) / 2 + aSize.Height
                    if w.AccessibleContext.AccessibleRole == PANEL and nWidth == w.PosSize.Width and nHeight == w.PosSize.Height:
                        self.aEnv['COMPONENTWINDOW'] = w
        aDocumentSettings = self.aEnv['MODEL'].createInstance("com.sun.star.drawing.DocumentSettings")
        # Common datas
        self.aEnv['KEYEVENT'] = None
        self.aEnv['MOUSEEVENT'] = None
        self.aEnv['L2OSTATE'] = (0, 0, 0, 0, 0) # e, i, m, p, t
        self.aEnv['VALIDLIST'] = 0
        self.aEnv['VALIDL2O'] = 0
        self.aEnv['L2OCOORD'] = uno.createUnoStruct("com.sun.star.awt.Point")
        self.aEnv['VALIDORIGIN'] = 0
        self.aEnv['ORIGINCOORD'] = uno.createUnoStruct("com.sun.star.awt.Point")
        self.aEnv['CANCELJOB'] = False
        self.aEnv['STOPJOB'] = False
        self.aEnv['REPEATMODE'] = False
        self.aEnv['ORTHOMODE'] = False
        self.aEnv['DRAWSCALE'] = float(aDocumentSettings.getPropertyValue("ScaleNumerator")) / aDocumentSettings.getPropertyValue("ScaleDenominator")
        self.aEnv['GROUPSHAPE'] = self.aEnv['CONTROLLER'].getCurrentPage()
        self.aEnv['ZOOMVALUE'] = self.aEnv['CONTROLLER'].ZoomValue
        self.aEnv['STEP'] = 0
        self.aEnv['SHAPE'] = None
        self.aEnv['COORDS'] = ((uno.createUnoStruct("com.sun.star.awt.Point"),),)
        self.aEnv['SPOTTEDID'] = None
        self.aEnv['MAGNETSIZE'] = 16
        self.aEnv['MAGNETSHAPE'] = None
        self.aEnv['VISIBLEAREA'] = uno.createUnoStruct("com.sun.star.awt.Point")
        self.setCoordTransformParams()
        # Struct needed to pass arguments throught UNO
        self.aNamedValues = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),uno.createUnoStruct("com.sun.star.beans.NamedValue"))
        self.aNamedValues[0].Name = "CONTEXT"
        self.aNamedValues[1].Name = "ACTION"
        # =========================================
        # access the registry - acces aux registres
        # =========================================
        self.aRegistry = self.smgr.createInstanceWithContext("com.sun.star.registry.SimpleRegistry", self.ctx)
        sFile = "./cadooo.rdb"
        aURL = unohelper.systemPathToFileUrl(sFile)
        try:
            self.aRegistry.open(aURL, False, False)
        except InvalidRegistryException, e:
            self.aRegistry.open(aURL, False, True)
        aRootKey = self.aRegistry.getRootKey()
        # if Cadooo already running => exit
        # else => locking new command
        self.aLockKey = aRootKey.openKey("LOCKED")
        if self.aLockKey is None:
            self.aLockKey = aRootKey.createKey("LOCKED")
        elif self.aLockKey.getLongValue():
            self.aRegistry.close()
            return aArgs
        self.aLockKey.setLongValue(1)
        # setting link to object state
        self.aL2OStateKey = aRootKey.openKey("L2OSTATE")
        if self.aL2OStateKey is None:
            self.aL2OStateKey = aRootKey.createKey("L2OSTATE")
            self.aL2OStateKey.setLongListValue(self.aEnv['L2OSTATE'])
        self.aEnv['L2OSTATE'] = self.aL2OStateKey.getLongListValue()
        # setting orthometric mode
        self.aOrthomodeKey = aRootKey.openKey("ORTHOMODE")
        if self.aOrthomodeKey is None:
            self.aOrthomodeKey = aRootKey.createKey("ORTHOMODE")
            self.aOrthomodeKey.setLongValue(self.aEnv['ORTHOMODE'])
        self.aEnv['ORTHOMODE'] = self.aOrthomodeKey.getLongValue()
        # =============================
        # create the CADOOo status bar
        # =============================
        aStatusBar = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.CadoooStatusBar", self.ctx)
        self.aNamedValues[0].Value = tuple(self.aEnv.items())
        self.aNamedValues[1].Value = "none"
        self.aEnv = dict(list(aStatusBar.execute(self.aNamedValues)[0].Value))
        # add item listener at the check boxes
        for i in range(7):
            self.aEnv['STATUSBARCONTROL'][i].addItemListener(self)
        nEntities = self.aEnv['GROUPSHAPE'].getCount()
        # not sure this serves anymore
        for i in range(nEntities):
            aShape = self.aEnv['GROUPSHAPE'].getByIndex(i)
            aShape.setPropertyValue("SizeProtect", True)
            aShape.setPropertyValue("MoveProtect", True)
        # stupid initialization
        self.aEnv['MAGNETVISIBLE'] = False
        self.aEntityPosSize = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.EntityPosSize", self.ctx)
        if self.aEnv.has_key('EDITMODE'):
            if self.aEnv['MODE'][0] == "OFFSET":
                self.aDrawJob = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.OffsetDraw", self.ctx)
                self.aKeyHandler = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.OffsetKeyHandler", self.ctx)
                self.aMouseHandler = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.OffsetMouseHandler", self.ctx)
            elif self.aEnv['MODE'][0] == "TRIM":
                self.aDrawJob = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.TrimDraw", self.ctx)
                self.aKeyHandler = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.TrimKeyHandler", self.ctx)
                self.aMouseHandler = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.TrimMouseHandler", self.ctx)
            elif self.aEnv['MODE'][0] == "CUT":
                self.aDrawJob = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.CutDraw", self.ctx)
                self.aKeyHandler = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.CutKeyHandler", self.ctx)
                self.aMouseHandler = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.CutMouseHandler", self.ctx)
        elif self.aEnv.has_key('DIMMODE'):
                self.aDrawJob = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DimDraw", self.ctx)
                self.aKeyHandler = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DimKeyHandler", self.ctx)
                self.aMouseHandler = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DimMouseHandler", self.ctx)
                self.aDimPosSize = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DimPosSize", self.ctx)
        else:
            self.aDrawJob = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.ShapeDraw", self.ctx)
            self.aKeyHandler = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.ShapeKeyHandler", self.ctx)
            self.aMouseHandler = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.ShapeMouseHandler", self.ctx)
        # add listeners
        for s in self.scrollbars:
            s.addAdjustmentListener(self)
        self.aEnv['CONTROLLER'].addKeyHandler(self)
        self.aEnv['COMPONENTWINDOW'].addMouseMotionListener(self)
        self.aEnv['CONTROLLER'].addMouseClickHandler(self)
        self.aEnv['CONTROLLER'].Frame.ComponentWindow.addWindowListener(self)
        self.aEnv['DESKTOPWINDOW'].addWindowListener(self)
        self.bCoordTransformParams = False
        return aArgs
    #********************************
    # working on the graphical entity
    #********************************
    def mouseMoved(self, aMouseEvent):
        # esc => kill job
        if self.aEnv['CANCELJOB'] or self.aEnv['STOPJOB']:
            return
        if self.aEnv['ZOOMVALUE'] != self.aEnv['CONTROLLER'].ZoomValue or not self.bCoordTransformParams:
            self.setCoordTransformParams()
            self.aEnv['ZOOMVALUE'] = self.aEnv['CONTROLLER'].ZoomValue
        self.aEnv['MOUSEEVENT'] = aMouseEvent
        try:
            self.aNamedValues[0].Value = tuple(self.aEnv.items())
            self.aEnv = dict(list(self.aDrawJob.execute(self.aNamedValues)[0].Value))
            if self.aEnv['STEP']:
                self.aNamedValues[0].Value = tuple(self.aEnv.items())
                self.aEnv = dict(list(self.aEntityPosSize.execute(self.aNamedValues)[0].Value))
                # sleep(1)
                self.aEnv['SHAPE'].LineColor = 0xFF00FF
                self.aEnv['SHAPE'].LineWidth = long(50 * 100 / self.aEnv['ZOOMVALUE'])
                # print "entity redraw"
            if self.aEnv.has_key('DIMMODE') and self.aEnv['DIMTYPE'] in ('LINEAR', 'ANGULAR', 'RADIAL', 'DIAMETRAL'):
                self.aNamedValues[0].Value = tuple(self.aEnv.items())
                self.aEnv = dict(list(self.aDimPosSize.execute(self.aNamedValues)[0].Value))
                # print "dimension redraw"
        except:
            traceback.print_exc()
        return
    # **********************************
    def mouseDragged(self, aMouseEvent):
        return
    # **********************************
    def mousePressed(self, aMouseEvent):
        return True
    # **********************************
    def mouseReleased(self, aMouseEvent):
        self.aEnv['MOUSEEVENT'] = aMouseEvent
        self.aNamedValues[0].Value = tuple(self.aEnv.items())
        self.aEnv = dict(list(self.aMouseHandler.execute(self.aNamedValues)[0].Value))
        # ---------------------------------------------------------
        if not self.aEnv['CANCELJOB'] and not self.aEnv['STOPJOB']:
            return True
        if self.aEnv['CANCELJOB']:
            if self.aEnv['SHAPE']:
                self.aEnv['GROUPSHAPE'].remove(self.aEnv['SHAPE'])
        elif self.aEnv['STOPJOB']:
            if not self.aEnv['SHAPE'] is None:
                self.aEnv['SHAPE'].setName("")
        self.stopDrawJob()
        self.aEnv['CONTROLLER'].removeKeyHandler(self)
        self.aEnv['COMPONENTWINDOW'].removeMouseMotionListener(self)
        self.aEnv['CONTROLLER'].removeMouseClickHandler(self)
        self.aEnv['CONTROLLER'].Frame.ComponentWindow.removeWindowListener(self)
        self.aEnv['DESKTOPWINDOW'].removeWindowListener(self)
        for aScrollbar in self.scrollbars:
            aScrollbar.removeAdjustmentListener(self)
        return True
    # **********************************
    def keyPressed(self, aKeyEvent):
        return True
    # **********************************
    def keyReleased(self, aKeyEvent):
        self.aEnv['KEYEVENT'] = aKeyEvent
        self.aNamedValues[0].Value = tuple(self.aEnv.items())
        self.aEnv = dict(list(self.aKeyHandler.execute(self.aNamedValues)[0].Value))
        if not self.aEnv['CANCELJOB'] and not self.aEnv['STOPJOB']:
            return True
        if self.aEnv['CANCELJOB']:
            if self.aEnv['SHAPE']:
                self.aEnv['GROUPSHAPE'].remove(self.aEnv['SHAPE'])
        elif self.aEnv['STOPJOB']:
            if not self.aEnv['SHAPE'] is None:
                self.aEnv['SHAPE'].setName("")
        self.stopDrawJob()
        self.aEnv['CONTROLLER'].removeKeyHandler(self)
        self.aEnv['COMPONENTWINDOW'].removeMouseMotionListener(self)
        self.aEnv['CONTROLLER'].removeMouseClickHandler(self)
        self.aEnv['CONTROLLER'].Frame.ComponentWindow.removeWindowListener(self)
        self.aEnv['DESKTOPWINDOW'].removeWindowListener(self)
        for aScrollbar in self.scrollbars:
            aScrollbar.removeAdjustmentListener(self)
        return True
    # ************************
    # Item listener
    # ************************
    def itemStateChanged(self, ObjEvent):
        aKeyEvent = uno.createUnoStruct("com.sun.star.awt.KeyEvent")
        if self.aEnv['STATUSBARCONTROL'][0].getState() != self.aEnv['L2OSTATE'][0]:
            aKeyEvent.KeyCode = 516
        elif self.aEnv['STATUSBARCONTROL'][1].getState() != self.aEnv['L2OSTATE'][1]:
            aKeyEvent.KeyCode = 520
        elif self.aEnv['STATUSBARCONTROL'][2].getState() != self.aEnv['L2OSTATE'][2]:
            aKeyEvent.KeyCode = 524
        elif self.aEnv['STATUSBARCONTROL'][3].getState() != self.aEnv['L2OSTATE'][3]:
            aKeyEvent.KeyCode = 527
        elif self.aEnv['STATUSBARCONTROL'][4].getState() != self.aEnv['L2OSTATE'][4]:
            aKeyEvent.KeyCode = 531
        elif self.aEnv['STATUSBARCONTROL'][5].getState() != self.aEnv['ORTHOMODE']:
            aKeyEvent.KeyCode = 512
        elif self.aEnv['STATUSBARCONTROL'][6].getState() != self.aEnv['REPEATMODE']:
            aKeyEvent.KeyCode = 1289
        self.keyReleased(aKeyEvent)
        self.aEnv['CONTROLLER'].setFocus()
        return
    # ************************
    # scrollbars listener
    # ************************
    def adjustmentValueChanged(self, AdjustmentEvent):
        self.bCoordTransformParams = False
        return
    # ************************************
    # coordinates tranformation parameters
    # ************************************
    def setCoordTransformParams(self):
        ## self.inspectObject(self.aEnv['CONTROLLER'])
        self.aEnv['DEVICEXSCALE'] = float(self.aEnv['CONTROLLER'].VisibleArea.Width) / self.aEnv['COMPONENTWINDOW'].PosSize.Width
        self.aEnv['DEVICEYSCALE'] = float(self.aEnv['CONTROLLER'].VisibleArea.Height) / self.aEnv['COMPONENTWINDOW'].PosSize.Height
        # self.inspectObject(self.aEnv['CONTROLLER'])
        self.aEnv['BORDERCOORD'] = (self.aEnv['CONTROLLER'].CurrentPage.BorderLeft, self.aEnv['CONTROLLER'].CurrentPage.BorderTop)
        self.aEnv['VISIBLEAREA'].X = self.aEnv['CONTROLLER'].VisibleArea.X
        self.aEnv['VISIBLEAREA'].Y = self.aEnv['CONTROLLER'].VisibleArea.Y
        self.bCoordTransformParams = True
        return
    # ************************
    # Window listener
    # ************************
    def windowResized(self, WindowEvent):
        # print "window event thrown"
        nBarHeight = self.aEnv['STATUSBARWINDOW'].PosSize.Height
        # self.aEnv['VALIDLIST'] = False
        if WindowEvent is None or self.aEnv['STATUSBARCONTROL'] is None:
            return
        aNewPosSize = self.aEnv['CONTROLLER'].Frame.ComponentWindow.PosSize
        aPosSize = self.aEnv['WINPOSSIZE']
        if aNewPosSize.Width != aPosSize.Width or aNewPosSize.Height != aPosSize.Height:
            aRect = uno.createUnoStruct("com.sun.star.awt.Rectangle")
            aRect.X, aRect.Y, aRect.Width, aRect.Height = aNewPosSize.X, aNewPosSize.Y+aNewPosSize.Height-nBarHeight, aNewPosSize.Width, nBarHeight
            self.aEnv['STATUSBARWINDOW'].setPosSize(aRect.X, aRect.Y, aRect.Width, aRect.Height, 15)
            aPeer = self.aEnv['STATUSBARCONTROL'][-1].getPeer()
            aPeer.setPosSize(0, 0, aRect.Width, self.aEnv['STATUSBARCONTROL'][-1].MinimumSize.Height, 15)
            aWidth = []
            for i in range(7):
                aPeer = self.aEnv['STATUSBARCONTROL'][i].getPeer()
                aPeer.setPosSize(reduce(__add_, aWidth, 0) + 5, 30, self.aEnv['STATUSBARCONTROL'][i].MinimumSize.Width, self.aEnv['STATUSBARCONTROL'][i].MinimumSize.Height, 15)
                aWidth.append(self.aEnv['STATUSBARCONTROL'][i].MinimumSize.Width)
            self.aEnv['WINPOSSIZE'].X, self.aEnv['WINPOSSIZE'].Y = aNewPosSize.X, aNewPosSize.Y
            self.aEnv['WINPOSSIZE'].Width, self.aEnv['WINPOSSIZE'].Height = aNewPosSize.Width, aNewPosSize.Height-nBarHeight
            self.aEnv['CONTROLLER'].Frame.ComponentWindow.setPosSize(aNewPosSize.X, aNewPosSize.Y, aNewPosSize.Width, aNewPosSize.Height-nBarHeight, 15)
        self.setCoordTransformParams()
        return
    def windowMoved(self, WindowEvent):
        self.bCoordTransformParams = False
        return
    def windowShown(self, WindowEvent):
        self.bCoordTransformParams = False
        return
    def windowHidden(self, WindowEvent):
        self.bCoordTransformParams = False
        return
    # ************************
    # Job cleaning
    # ************************
    def stopDrawJob(self):
        self.aL2OStateKey.setLongListValue(self.aEnv['L2OSTATE'])
        self.aOrthomodeKey.setLongValue(self.aEnv['ORTHOMODE'])
        self.aLockKey.setLongValue(0)
        self.aRegistry.close()
        nBarHeight = self.aEnv['STATUSBARWINDOW'].PosSize.Height
        self.aEnv['L2OSTATE'] = (0, 0, 0, 0, 0)
        self.aEnv['ENTITYPE'] = 'NONE'
        self.aEnv['VALIDORIGIN'] = 0
        self.aEnv['VALIDLIST'] = 0
        self.aEnv['GROUPSHAPE'] = self.aEnv['CONTROLLER'].getCurrentPage()
        self.aEnv['STEP'] = 0
        if not self.aEnv['MAGNETSHAPE'] is None:
            aPeer = self.aEnv['MAGNETSHAPE'].getPeer()
            aPeer.dispose()
            self.aEnv['MAGNETSHAPE'].setModel(None)
            self.aEnv['MAGNETSHAPE'] = None
        self.aEnv['MODEL'].setModified(True)
        nEntities = self.aEnv['GROUPSHAPE'].getCount()
        for i in range(nEntities):
            aShape = self.aEnv['GROUPSHAPE'].getByIndex(i)
            aShape.setPropertyValue("SizeProtect", False)
            aShape.setPropertyValue("MoveProtect", False)
        aPeer = self.aEnv['STATUSBARCONTROL'][-1].getPeer()
        self.aEnv['STATUSBARCONTROL'][-1].setModel(None) 
        aPeer.dispose()
        for i in range(7):
            aPeer = self.aEnv['STATUSBARCONTROL'][i].getPeer()
            self.aEnv['STATUSBARCONTROL'][i].removeItemListener(self)
            self.aEnv['STATUSBARCONTROL'][i].setModel(None)
            aPeer.dispose()
        self.aEnv['STATUSBARCONTROL'] = None
        self.aEnv['STATUSBARWINDOW'].setVisible(False)
        self.aEnv['STATUSBARWINDOW'].dispose()
        # self.desktop.CurrentFrame.ComponentWindow.setFocus()
        aPosSize = self.aEnv['CONTROLLER'].Frame.ComponentWindow.PosSize
        # self.inspectObject(self.desktop.CurrentFrame.ComponentWindow)
        self.aEnv['CONTROLLER'].Frame.ComponentWindow.setPosSize(aPosSize.X, aPosSize.Y, aPosSize.Width, aPosSize.Height+nBarHeight, 15)
        return
    # XEventListener 
    def disposing(self, eventObject):
        return
    # **********************************
    # inspection wrapper
    # **********************************
    def inspectObject(self, aObject):
        aDiveIn = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DiveIn", self.ctx)
        aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aParms[0].Name = "inspect"
        aParms[0].Value = aObject
        aParms = aDiveIn.execute(aParms)
        return
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(CadoooJob,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.CadoooJob", # implemenation name
                                         ("org.openoffice.comp.pyuno.CadoooJob",),)    # list of implemented services
