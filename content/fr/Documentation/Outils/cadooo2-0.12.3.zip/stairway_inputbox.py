# 	$Id: stairway_inputbox.py,v 1.1 2006-07-16 10:02:14 gerard Exp $	
# -*- coding: latin-1 -*-
## ********************************************************************************
## stairway_inputbox jeu f�v 10 20:19:31 CET 2005
## Copyright (C) 2004 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************

try:
    import uno, unohelper
    from com.sun.star.task import XJob
    from com.sun.star.awt import XActionListener
except ImportError:
    print "import impossible"

class StairwayInputBox(unohelper.Base, XJob, XActionListener):
    """Saisie des param�tres de l'escalier balanc�
    input of balanced stairway parameters"""
    def __init__(self, aContext):
        self.ctx = aContext
        self.bOK = False
        desktop = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.frame.Desktop",self.ctx)
        aModel = desktop.getCurrentComponent()
        self.aController = aModel.getCurrentController()
    # ******************************
    def execute(self, aNamedValues):
        aMsgL10n = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
        aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aParms[0].Name = "Translation"
        aParms[0].Value = tuple(["sw%d" % i for i in range(12)])
        aParms = aMsgL10n.execute(aParms)
        aBox = uno.createUnoStruct("com.sun.star.awt.Rectangle")
        aBox.Width, aBox.Height = 190, 150
        aBox.X = (self.aController.Frame.ComponentWindow.PosSize.X + (self.aController.Frame.ComponentWindow.PosSize.Width - aBox.Width) / 2) / 25e-1
        aBox.Y = (self.aController.Frame.ComponentWindow.PosSize.Y + (self.aController.Frame.ComponentWindow.PosSize.Height - aBox.Height) / 2) / 25e-1
	aStairwayDialogModel = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.awt.UnoControlDialogModel", self.ctx)
	# -----------------------------------------------------
	aStairwayDialogModel.setPropertyValue("PositionX", aBox.X)
	aStairwayDialogModel.setPropertyValue("PositionY", aBox.Y)
	aStairwayDialogModel.setPropertyValue("Width", aBox.Width)
	aStairwayDialogModel.setPropertyValue("Height", aBox.Height)
	aStairwayDialogModel.setPropertyValue("Title", aParms[0].Value[0])
	# create the button model and set the properties - cree le modele de bouton et fixe les proprietes
	aStairwayDialogButtonModel1 = aStairwayDialogModel.createInstance( "com.sun.star.awt.UnoControlButtonModel" )
	aStairwayDialogButtonModel1.setPropertyValue("PositionX", 25)
	aStairwayDialogButtonModel1.setPropertyValue("PositionY", 130)
	aStairwayDialogButtonModel1.setPropertyValue("Width", 30)
	aStairwayDialogButtonModel1.setPropertyValue("Height", 15)
	aStairwayDialogButtonModel1.setPropertyValue("Name", "Button1")
	aStairwayDialogButtonModel1.setPropertyValue("TabIndex", 5)
	aStairwayDialogButtonModel1.setPropertyValue("Label", aParms[0].Value[1])
	aStairwayDialogButtonModel1.setPropertyValue("DefaultButton", True)
	# create the button model and set the properties - cree le modele de bouton et fixe les proprietes
	aStairwayDialogButtonModel2 = aStairwayDialogModel.createInstance( "com.sun.star.awt.UnoControlButtonModel" )
	aStairwayDialogButtonModel2.setPropertyValue("PositionX", 135)
	aStairwayDialogButtonModel2.setPropertyValue("PositionY", 130)
	aStairwayDialogButtonModel2.setPropertyValue("Width", 30)
	aStairwayDialogButtonModel2.setPropertyValue("Height", 15)
	aStairwayDialogButtonModel2.setPropertyValue("Name", "Button2")
	aStairwayDialogButtonModel2.setPropertyValue("TabIndex", 6)
	aStairwayDialogButtonModel2.setPropertyValue("Label", aParms[0].Value[2])
	# create the edit model and set the properties - cree le modele d'edition et fixe les proprietes
	aStairwayDialogEditModel1 = aStairwayDialogModel.createInstance( "com.sun.star.awt.UnoControlNumericFieldModel" )
	aStairwayDialogEditModel1.setPropertyValue("PositionX", 130)
	aStairwayDialogEditModel1.setPropertyValue("PositionY", 10)
	aStairwayDialogEditModel1.setPropertyValue("Width", 50)
	aStairwayDialogEditModel1.setPropertyValue("Height", 15)
	aStairwayDialogEditModel1.setPropertyValue("Name", "Numf1")
	aStairwayDialogEditModel1.setPropertyValue("TabIndex", 0)
	aStairwayDialogEditModel1.setPropertyValue("Value", 17)
	aStairwayDialogEditModel1.setPropertyValue("Spin", True)
	aStairwayDialogEditModel1.setPropertyValue("HelpText", aParms[0].Value[3])
        # ...................................
        # input field of stride line distance
        # ...................................
        # create the label model set the properties
        DXDialogLabelModel = aStairwayDialogModel.createInstance( "com.sun.star.awt.UnoControlFixedTextModel" )
        DXDialogLabelModel.setPropertyValue("PositionX", 10)
        DXDialogLabelModel.setPropertyValue("PositionY", 40)
        DXDialogLabelModel.setPropertyValue("Width", 85)
        DXDialogLabelModel.setPropertyValue("Height", 15)
        DXDialogLabelModel.setPropertyValue("Name", "LabelDX")
        DXDialogLabelModel.setPropertyValue("TabIndex", 8)
        DXDialogLabelModel.setPropertyValue("MultiLine", False)
        DXDialogLabelModel.setPropertyValue("Label", aParms[0].Value[4])
        # create the edit model and set the properties
        DXDialogEditModel = aStairwayDialogModel.createInstance( "com.sun.star.awt.UnoControlNumericFieldModel" )
        DXDialogEditModel.setPropertyValue("PositionX", 100)
        DXDialogEditModel.setPropertyValue("PositionY", 40)
        DXDialogEditModel.setPropertyValue("Width", 45)
        DXDialogEditModel.setPropertyValue("Height", 15)
        DXDialogEditModel.setPropertyValue("Name", "NumfDX")
        DXDialogEditModel.setPropertyValue("TabIndex", 1)
        DXDialogEditModel.setPropertyValue("Value", 5e-1)
        DXDialogEditModel.setPropertyValue("Spin", True)
        DXDialogEditModel.setPropertyValue("HelpText", aParms[0].Value[5])
        # create the listbox model and set the properties
        DXDialogListBoxModel = aStairwayDialogModel.createInstance( "com.sun.star.awt.UnoControlListBoxModel" )
        DXDialogListBoxModel.setPropertyValue("PositionX", 150)
        DXDialogListBoxModel.setPropertyValue("PositionY", 40)
        DXDialogListBoxModel.setPropertyValue("Width", 30)
        DXDialogListBoxModel.setPropertyValue("Height", 15)
        DXDialogListBoxModel.setPropertyValue("Name", "ListDUnit")
        DXDialogListBoxModel.setPropertyValue("TabIndex", 2)
        DXDialogListBoxModel.setPropertyValue("Dropdown", True)
        DXDialogListBoxModel.setPropertyValue("HelpText", aParms[0].Value[6])
	# create the listbox model and set the properties - cree le modele de liste et fixe les proprietes
	aStairwayDialogLabelModel1 = aStairwayDialogModel.createInstance( "com.sun.star.awt.UnoControlFixedTextModel" )
	aStairwayDialogLabelModel1.setPropertyValue("PositionX", 10)
	aStairwayDialogLabelModel1.setPropertyValue("PositionY", 10)
	aStairwayDialogLabelModel1.setPropertyValue("Width", 110)
	aStairwayDialogLabelModel1.setPropertyValue("Height", 20)
	aStairwayDialogLabelModel1.setPropertyValue("Name", "Label1")
	aStairwayDialogLabelModel1.setPropertyValue("TabIndex", 7)
	aStairwayDialogLabelModel1.setPropertyValue("MultiLine", True)
	aStairwayDialogLabelModel1.setPropertyValue("Label", aParms[0].Value[7])
	# create the edit model and set the properties - cree le modele d'edition et fixe les proprietes
	aStairwayDialogEditModel2 = aStairwayDialogModel.createInstance( "com.sun.star.awt.UnoControlNumericFieldModel" )
	aStairwayDialogEditModel2.setPropertyValue("PositionX", 130)
	aStairwayDialogEditModel2.setPropertyValue("PositionY", 65)
	aStairwayDialogEditModel2.setPropertyValue("Width", 50)
	aStairwayDialogEditModel2.setPropertyValue("Height", 15)
	aStairwayDialogEditModel2.setPropertyValue("Name", "Numf2")
	aStairwayDialogEditModel2.setPropertyValue("TabIndex", 3)
	aStairwayDialogEditModel2.setPropertyValue("Value", 2)
	aStairwayDialogEditModel2.setPropertyValue("Spin", True)
	aStairwayDialogEditModel2.setPropertyValue("HelpText", aParms[0].Value[8])
	# create the listbox model and set the properties - cree le modele de liste et fixe les proprietes
	aStairwayDialogLabelModel2 = aStairwayDialogModel.createInstance( "com.sun.star.awt.UnoControlFixedTextModel" )
	aStairwayDialogLabelModel2.setPropertyValue("PositionX", 10)
	aStairwayDialogLabelModel2.setPropertyValue("PositionY", 65)
	aStairwayDialogLabelModel2.setPropertyValue("Width", 110)
	aStairwayDialogLabelModel2.setPropertyValue("Height", 20)
	aStairwayDialogLabelModel2.setPropertyValue("Name", "Label2")
	aStairwayDialogLabelModel2.setPropertyValue("TabIndex", 9)
	aStairwayDialogLabelModel2.setPropertyValue("MultiLine", True)
	aStairwayDialogLabelModel2.setPropertyValue("Label", aParms[0].Value[9])
	# create the edit model and set the properties - cree le modele d'edition et fixe les proprietes
	aStairwayDialogEditModel3 = aStairwayDialogModel.createInstance( "com.sun.star.awt.UnoControlNumericFieldModel" )
	aStairwayDialogEditModel3.setPropertyValue("PositionX", 130)
	aStairwayDialogEditModel3.setPropertyValue("PositionY", 100)
	aStairwayDialogEditModel3.setPropertyValue("Width", 50)
	aStairwayDialogEditModel3.setPropertyValue("Height", 15)
	aStairwayDialogEditModel3.setPropertyValue("Name", "Numf3")
	aStairwayDialogEditModel3.setPropertyValue("TabIndex", 4)
	aStairwayDialogEditModel3.setPropertyValue("Value", 16)
	aStairwayDialogEditModel3.setPropertyValue("Spin", True)
	aStairwayDialogEditModel3.setPropertyValue("HelpText", aParms[0].Value[10])
	# create the listbox model and set the properties - cree le modele de liste et fixe les proprietes
	aStairwayDialogLabelModel3 = aStairwayDialogModel.createInstance( "com.sun.star.awt.UnoControlFixedTextModel" )
	aStairwayDialogLabelModel3.setPropertyValue("PositionX", 10)
	aStairwayDialogLabelModel3.setPropertyValue("PositionY", 100)
	aStairwayDialogLabelModel3.setPropertyValue("Width", 110)
	aStairwayDialogLabelModel3.setPropertyValue("Height", 20)
	aStairwayDialogLabelModel3.setPropertyValue("Name", "Label3")
	aStairwayDialogLabelModel3.setPropertyValue("TabIndex", 10)
	aStairwayDialogLabelModel3.setPropertyValue("MultiLine", True)
	aStairwayDialogLabelModel3.setPropertyValue("Label", aParms[0].Value[11])
	# insert the control models into the dialog model - insere les modeles de controle dans le modele de dialogue
	aStairwayDialogModel.insertByName("Button1", aStairwayDialogButtonModel1)
	aStairwayDialogModel.insertByName("Button2", aStairwayDialogButtonModel2)
	aStairwayDialogModel.insertByName("Numf1", aStairwayDialogEditModel1)
	aStairwayDialogModel.insertByName("Label1", aStairwayDialogLabelModel1)
	aStairwayDialogModel.insertByName("Numf2", aStairwayDialogEditModel2)
	aStairwayDialogModel.insertByName("Label2", aStairwayDialogLabelModel2)
	aStairwayDialogModel.insertByName("Numf3", aStairwayDialogEditModel3)
	aStairwayDialogModel.insertByName("Label3", aStairwayDialogLabelModel3)
        aStairwayDialogModel.insertByName("LabelDX", DXDialogLabelModel)
        aStairwayDialogModel.insertByName("NumfDX", DXDialogEditModel)
        aStairwayDialogModel.insertByName("ListDUnit", DXDialogListBoxModel)
	# create the dialog control and set the model - cree le control de dialogue et fixe le modele
	self.aStairwayDialogControl = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.awt.UnoControlDialog", self.ctx)
	self.aStairwayDialogControl.setModel(aStairwayDialogModel)
        DXDialogListBoxControl = self.aStairwayDialogControl.getControl("ListDUnit")
        DXDialogListBoxControl.addItem("mm", 0)
        DXDialogListBoxControl.addItem("cm", 1)
        DXDialogListBoxControl.addItem("m", 2)
        DXDialogListBoxControl.makeVisible(2)
        DXDialogListBoxControl.selectItemPos(2, True)
	aStairwayDialogButton1 = self.aStairwayDialogControl.getControl("Button1")
        aStairwayDialogButton1.setActionCommand("ok")
	aStairwayDialogButton1.addActionListener(self)
	# add an action listener to the button2 control - ajoute un audit d'action au controle button2
	aStairwayDialogButton2 = self.aStairwayDialogControl.getControl("Button2")
        aStairwayDialogButton2.setActionCommand("cancel")
	aStairwayDialogButton2.addActionListener(self)
	#create a peer - cree un port
	aToolkit = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.awt.Toolkit", self.ctx)
	self.aStairwayDialogControl.setVisible(0)
	self.aStairwayDialogControl.createPeer(aToolkit, aToolkit.getDesktopWindow())
	#execute the dialog - lance le dialogue
	self.aStairwayDialogControl.execute()
	if self.bOK:
            #print self.__doc__
	    aNamedValues[0].Value = True
	    aNamedValues[1].Value = int(self.aStairwayDialogControl.getControl("Numf1").getValue())
	    aNamedValues[2].Value = int(self.aStairwayDialogControl.getControl("Numf2").getValue())
	    if aNamedValues[2].Value <= 1:
		aNamedValues[2].Value = 0
	    aNamedValues[3].Value = int(self.aStairwayDialogControl.getControl("Numf3").getValue())
	    if aNamedValues[3].Value >= aNamedValues[1].Value:
		aNamedValues[3].Value = 0
            sUnit = DXDialogListBoxControl.getSelectedItem()
            if sUnit == "mm":
                aNamedValues[4].Value = long( self.aStairwayDialogControl.getControl("NumfDX").getValue() * 100)
            elif sUnit == "cm":
                aNamedValues[4].Value = long( self.aStairwayDialogControl.getControl("NumfDX").getValue() * 1000)
            else:
                aNamedValues[4].Value = long( self.aStairwayDialogControl.getControl("NumfDX").getValue() * 100000)
	# remove an action listener to the button1 control - ote l'audit d'action de controle button1
	aStairwayDialogButton1.removeActionListener(self)
	# remove an action listener to the button2 control - ote l'audit d'action de controle button2
	aStairwayDialogButton2.removeActionListener(self)
        return aNamedValues
	## XEventListener 
    def disposing(self, eventObject):
        self.aStairwayDialogControl = None
	## XActionListener 
    def actionPerformed(self, actionEvent):
        if actionEvent.ActionCommand == "ok":
            self.bOK = True
        else:
            self.bOK = False
        self.aStairwayDialogControl.endExecute()

# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(StairwayInputBox,                                        # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.StairwayInputBox", # implemenation name
                                         ("org.openoffice.comp.pyuno.StairwayInputBox",),)    # list of implemented services
