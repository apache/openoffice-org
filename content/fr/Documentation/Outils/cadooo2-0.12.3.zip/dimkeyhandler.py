# 	$Id$
# -*- coding: latin-1 -*-
## ********************************************************************************
## dimkeyhandler mar f�v 13 14:07:47 CET 2007
## Copyright (C) 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import unohelper, uno
    import traceback
    from com.sun.star.task import XJob
    from com.sun.star.awt.KeyModifier import SHIFT
except ImportError:
    print "probleme d'import"
#===============================
# gestion des evenements clavier
# handling keyboard events
#===============================
class DimKeyHandler(unohelper.Base, XJob):
    """gestion des evenements clavier
    handling keyboard events"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
        # Struct needed to pass arguments throught UNO
        self.aNamedValues = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        self.aNamedValues[0].Name = "CONTEXT"
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # ==================================
    # actions clavier - keyboard actions
    # aNamedValues as tuple of NamedValue
    #   Name         Value
    # KEYCODE     integer
    # L2OSTATE    tuple of 5 integers (0 or 1)
    # SHAPE
    # ==================================
    def execute(self, aArgs):
        aEnv = dict(list(aArgs[0].Value))
        # ----------------------------------------------------------------------------------------------------
        if [516, 520, 524, 527, 531].count(aEnv['KEYEVENT'].KeyCode) and not aEnv['KEYEVENT'].Modifiers:
            # e,   i,   m,   p,   t => link 2 entities
            i = [516, 520, 524, 527, 531].index(aEnv['KEYEVENT'].KeyCode)
            bKHState = list(aEnv['L2OSTATE'])
            bKHState[i] = not bKHState[i]
            aEnv['L2OSTATE'] = tuple(bKHState)
            aStatusBarCheckBox = aEnv['STATUSBARCONTROL'][i]
            if aStatusBarCheckBox.getState() != aEnv['L2OSTATE'][i]:
                aStatusBarCheckBox.setState(aEnv['L2OSTATE'][i])
            if aEnv['DIMVISIBLE']:
                aShape = aEnv['%sDIMSHAPE' % aEnv['DIMTYPE']]
                # print "removing %sDIMSHAPE for shape %s with %d subshapes" % (aEnv['DIMTYPE'], aShape.getShapeType(), aShape.getCount())
                for i in range(aShape.getCount()):
                    aShape.remove(aShape.getByIndex(0))
                aEnv['CONTROLLER'].getCurrentPage().remove(aShape)
                aEnv['DIMTYPE'] = "----"
                aEnv['DIMCOORDS'] = None
                aEnv['DIMVISIBLE'] = False
        # --------------------------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (514, ) and aEnv['KEYEVENT'].Modifiers == SHIFT:
            # ..............................c + shift => close measure
            if aEnv['SHAPE']:
                aGroupShape = aEnv['CONTROLLER'].getCurrentPage()
                for i in aEnv['SPOTTEDID'][:-2]:
                    aGroupShape = aGroupShape.getByIndex(i)
                aGroupShape.remove(aEnv['SHAPE'])
                aEnv['SHAPE'] = None
                aEnv['STEP'] = 0
                aEnv['COORDS'] = ((),)
            aEnv['DIMCOORDS'] = None
            aEnv['DIMTYPE'] = "---"
            aEnv['DIMLIST'] = (None, None)
            aEnv['DIMVISIBLE'] = False
            for t in ('LINEAR', 'ANGULAR', 'RADIAL', 'DIAMETRAL'):
                aEnv['%sDIMSHAPE' % t] = None
            # -----------------------
            if aEnv['REPEATMODE']:
                aEnv['STEP'] = 0
                aEnv['VALIDORIGIN'] = False
                aEnv['GROUPSHAPE'] = None
                aEnv['SHAPE'] = None
                aEnv['VALIDLIST'] = False
                aEnv['COORDS'] = ((),)
            else:
                aEnv['STOPJOB'] = True
        # --------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (1281,) and not aEnv['KEYEVENT'].Modifiers:
            #                                 Esc => kill job
            aEnv['CANCELJOB'] = True
            if aEnv['SHAPE']:
                aGroupShape = aEnv['CONTROLLER'].getCurrentPage()
                for i in aEnv['SPOTTEDID'][:-2]:
                    aGroupShape = aGroupShape.getByIndex(i)
                aGroupShape.remove(aEnv['SHAPE'])
                aEnv['SHAPE'] = None
                aEnv['STEP'] = 0
                aEnv['COORDS'] = ((),)
            if aEnv['DIMVISIBLE']:
                aShape = aEnv['%sDIMSHAPE' % aEnv['DIMTYPE']]
                for i in range(aShape.getCount()):
                    aShape.remove(aShape.getByIndex(0))
                aEnv['CONTROLLER'].getCurrentPage().remove(aShape)
                aEnv['DIMTYPE'] = "----"
                aEnv['DIMCOORDS'] = None
                aEnv['DIMVISIBLE'] = False
        # -------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (512,) and not aEnv['KEYEVENT'].Modifiers:
            #                               a => axonometric mode
            aEnv['ORTHOMODE'] = not aEnv['ORTHOMODE']
            aStatusBarCheckBox = aEnv['STATUSBARCONTROL'][5]
            if aStatusBarCheckBox.getState() != aEnv['ORTHOMODE']:
                aStatusBarCheckBox.setState(aEnv['ORTHOMODE'])
        # --------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (1289,) and not aEnv['KEYEVENT'].Modifiers:
            #                                * => repeat mode
            aEnv['REPEATMODE'] = not aEnv['REPEATMODE']
            aStatusBarCheckBox = aEnv['STATUSBARCONTROL'][6]
            if aStatusBarCheckBox.getState() != aEnv['REPEATMODE']:
                aStatusBarCheckBox.setState(aEnv['REPEATMODE'])
        self.aNamedValues[0].Value = tuple(aEnv.items())
        return self.aNamedValues
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()
g_ImplementationHelper.addImplementation(DimKeyHandler,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.DimKeyHandler", # implemenation name
                                         ("org.openoffice.comp.pyuno.DimKeyHandler",),)    # list of implemented services
