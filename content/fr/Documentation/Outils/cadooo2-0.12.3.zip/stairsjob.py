# 	$Id: stairsjob.py,v 1.1 2006-07-16 10:02:14 gerard Exp $	
# -*- coding: latin-1 -*-
## ********************************************************************************
## stairsjob dim nov  7 16:52:58 CET 2004
## Copyright (C) 2004 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************

try:
    import uno, unohelper
except ImportError:
    print "import impossible de uno et unohelper"

try:
    from com.sun.star.task import XJobExecutor
except ImportError:
    print "import impossible de XJobExecutor"

try:
    import sys, math, traceback
except ImportError:
    print "import impossible de sys et math"

try:
    from com.sun.star.lang import IllegalArgumentException
    from com.sun.star.accessibility.AccessibleRole import SCROLL_BAR, SCROLL_PANE, DOCUMENT, PANEL
except ImportError, e:
    print e
    
##
## class that do the job
##
class StairsJob(unohelper.Base, XJobExecutor):
    """Trac� d'escalier balanc�
    balanced stairway drawing"""
    def __init__(self, ctx):
	self.ctx = ctx
    ## =========================================
    ## wrapper for the compute functions
    ## =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aNamedValues[i].Name = "Function"
                aNamedValues[i].Value = sMethod
            elif i < n-1:
                aNamedValues[i].Name = "Param%d" % i
                aNamedValues[i].Value = aArgs[i-1]
            else:
                aNamedValues[i].Name = "Result"
        aNamedValues = list(aCompute.execute(tuple(aNamedValues)))
        return aNamedValues[-1].Value
    ##
    ## this function is called from within the menu or toolbox button in OpenOffice
    ## fonction appelee par le menu ou le bouton de la barre d'outils dans OpenOffice
    ##
    def trigger(self, args):
        self.smgr = self.ctx.ServiceManager
        # get the central desktop object - recupere l'objet central desktop
        desktop = self.smgr.createInstanceWithContext( "com.sun.star.frame.Desktop",self.ctx)
        if desktop.ActiveFrame.ActiveFrame:
            aCurrentController = desktop.ActiveFrame.ActiveFrame.Controller
        else:
            aCurrentController = desktop.ActiveFrame.Controller
        CurrentComponentModel = aCurrentController.Model
        # access the current draw document - acces au document draw courant
        aShapes = aCurrentController.getSelection()
        aDrawPage = aCurrentController.getCurrentPage()
        aMessage = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MessageBox", self.ctx)
        aMsgL10n = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
        aNamedValue = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aNamedValue[0].Name = "Text"
        if aShapes is None:
            aNamedValue[0].Value = ("s0",)
            aNamedValue = aMsgL10n.execute(aNamedValue)
            aMessage.execute(aNamedValue)
            return
        nEntitySelected = aShapes.getCount()
        aDocumentSettings = CurrentComponentModel.createInstance("com.sun.star.drawing.DocumentSettings")
        fScale = float(aDocumentSettings.getPropertyValue("ScaleNumerator")) / aDocumentSettings.getPropertyValue("ScaleDenominator")
        # -----------------------
        # get stairway parameters
        # -----------------------
        xStepsCountDialog = self.smgr.createInstance("org.openoffice.comp.pyuno.StairwayInputBox")
        aStairwayNamedValues = [uno.createUnoStruct("com.sun.star.beans.NamedValue") for i in range(5)]
        aStairwayNamedValues[0].Name = "ButtonState"
        aStairwayNamedValues[0].Value = False
        aStairwayNamedValues[1].Name = "StepsCount"
        aStairwayNamedValues[1].Value = 17
        aStairwayNamedValues[2].Name = "FirstStepBal"
        aStairwayNamedValues[2].Value = 0
        aStairwayNamedValues[3].Name = "LastStepBal"
        aStairwayNamedValues[3].Value = 0
        aStairwayNamedValues[4].Name = "StrideLineDist"
        aStairwayNamedValues[4].Value = 50000
        aStairwayNamedValues = list(xStepsCountDialog.execute(tuple(aStairwayNamedValues)))
        if aStairwayNamedValues[0].Value:
            nStepsCount = aStairwayNamedValues[1].Value
            n1stStepBal = aStairwayNamedValues[2].Value
            nLastStepBal = aStairwayNamedValues[3].Value
            nStridePos = aStairwayNamedValues[4].Value
        else:
            aNamedValue[0].Value = ("s1",)
            aNamedValue = aMsgL10n.execute(aNamedValue)
            aMessage.execute(aNamedValue)
            return #annulation
        del xStepsCountDialog
        del aStairwayNamedValues
        # -----------------------------------------------------------------
        # getting vertex coordinates - recupere les coordonnees des sommets
        # -----------------------------------------------------------------
        if (nEntitySelected > 8 or nEntitySelected < 6) and not nEntitySelected == 1:
            aNamedValue[0].Value =  ("s2",)
            aNamedValue = aMsgL10n.execute(aNamedValue)
            aMessage.execute(aNamedValue)
            return
        aCoords = []
        aPolars = []
        if nEntitySelected > 1:
            i, n = (0, 1)
            index = range(nEntitySelected)
            ## ordering the selected edges - tri des cotes selectionnes
            while n < nEntitySelected:
                while index[i] == -1:
                    i = i + 1
                aShape = aShapes.getByIndex(index[i])
                aType = aShape.getShapeType()
                if not aType == "com.sun.star.drawing.LineShape":
                    aNamedValue[0].Value = ("s3",)
                    aNamedValue = aMsgL10n.execute(aNamedValue)
                    aMessage.execute(aNamedValue)
                    return
                if n == 1:
                    aCoords.append(uno.createUnoStruct("com.sun.star.awt.Point"))
                    aCoords[-1].X = aShape.PolyPolygon[0][0].X
                    aCoords[-1].Y = aShape.PolyPolygon[0][0].Y
                    aCoords.append(uno.createUnoStruct("com.sun.star.awt.Point"))
                    aCoords[-1].X = aShape.PolyPolygon[0][1].X
                    aCoords[-1].Y = aShape.PolyPolygon[0][1].Y
                    aPolars.append(list(self.compute('toPolarCoord', aCoords[-2], aCoords[-1])))
                    index[0] = -1
                    n = n + 1
                elif self.compute('toPolarCoord', aShape.PolyPolygon[0][0], aCoords[-1])[0] < 50:
                    aCoords.append(uno.createUnoStruct("com.sun.star.awt.Point"))
                    aCoords[-1].X = aShape.PolyPolygon[0][1].X
                    aCoords[-1].Y = aShape.PolyPolygon[0][1].Y
                    aPolars.append(list(self.compute('toPolarCoord', aCoords[-2], aCoords[-1])))
                    n = n + 1
                    index[i] = -1
                    i = 0
                elif self.compute('toPolarCoord', aShape.PolyPolygon[0][1], aCoords[-1])[0] < 50:
                    aCoords.append(uno.createUnoStruct("com.sun.star.awt.Point"))
                    aCoords[-1].X = aShape.PolyPolygon[0][0].X
                    aCoords[-1].Y = aShape.PolyPolygon[0][0].Y
                    aPolars.append(list(self.compute('toPolarCoord', aCoords[-2], aCoords[-1])))
                    n = n + 1
                    index[i] = -1
                    i = 0
                else:
                    i = i + 1
        else:
            aShape = aShapes.getByIndex(0)
            # self.inspectObject(aShape)
            aType = aShape.getShapeType()
            if not aType in("com.sun.star.drawing.PolyPolygonShape", "com.sun.star.drawing.PolyLineShape"):
                aNamedValue[0].Value = ("s3",)
                aNamedValue = aMsgL10n.execute(aNamedValue)
                aMessage.execute(aNamedValue)
                return
            nEntitySelected = len(aShape.PolyPolygon[0])
            for i in range(nEntitySelected-1):
                if i == 0:
                    aCoords.append(uno.createUnoStruct("com.sun.star.awt.Point"))
                    aCoords[-1].X = aShape.PolyPolygon[0][i].X
                    aCoords[-1].Y = aShape.PolyPolygon[0][i].Y
                aCoords.append(uno.createUnoStruct("com.sun.star.awt.Point"))
                aCoords[-1].X = aShape.PolyPolygon[0][i+1].X
                aCoords[-1].Y = aShape.PolyPolygon[0][i+1].Y
                aPolars.append(list(self.compute('toPolarCoord', aCoords[-2], aCoords[-1])))
        aPolars.append(list(self.compute('toPolarCoord', aCoords[-1], aCoords[0])))
        # too much vertex	
        if nEntitySelected > 8:
            aNamedValue[0].Value = ("s2",)
            aNamedValue = aMsgL10n.execute(aNamedValue)
            aMessage.execute(aNamedValue)
            return
        # --------------------------------------------------------------------------------
        # seaching for pairs of side of equal length - recherche des paires de cotes egaux
        # --------------------------------------------------------------------------------
        nIndexPairs = []
        aDistList = [aPolars[i][0] for i in range(nEntitySelected)]
        for i in range(nEntitySelected - 3):
            for j in range(i+3, nEntitySelected):
                if abs(aDistList[i] - aDistList[j]) < 11:
                    nIndexPairs.append([i, j])
        if len(nIndexPairs) > 1:
            i=0
            while 1:
                if nIndexPairs[i][1]-nIndexPairs[i][0] < 3 or nIndexPairs[i][1]-nIndexPairs[i][0] > 4:
                    nIndexPairs.pop(i)
                else:
                    i=i+1
                if i>=len(nIndexPairs):
                    break
        if len(nIndexPairs) == 0 or len(nIndexPairs) > 1:
            aNamedValue[0].Value = ("s4",)
            aNamedValue = aMsgL10n.execute(aNamedValue)
            aMessage.execute(aNamedValue)
            return
        # -----------
        nIndexPairs = nIndexPairs[0]
        nStepWidth = aDistList[nIndexPairs[0]]
        # --------------------------------------------------
        # First step selection - Choix de la premiere marche
        # --------------------------------------------------
        aSize = uno.createUnoStruct("com.sun.star.awt.Size")
        aCoord = []
        for i in range(4):
            aCoord.append(uno.createUnoStruct("com.sun.star.awt.Point"))
        aTextShapeF = CurrentComponentModel.createInstance("com.sun.star.drawing.RectangleShape")
        aCoord[0].X = long((aCoords[nIndexPairs[0]].X + aCoords[nIndexPairs[0]+1].X)/2)
        aCoord[0].Y = long((aCoords[nIndexPairs[0]].Y + aCoords[nIndexPairs[0]+1].Y)/2)
        aTextShapeF.setPosition(aCoord[0])
        aSize.Width = 2000
        aSize.Height = 750
        aTextShapeF.setSize(aSize)
        aDrawPage.add(aTextShapeF)
        aTextShapeF.setPropertyValue("TextFitToSize", uno.Enum("com.sun.star.drawing.TextFitToSizeType", "PROPORTIONAL"))
        aNamedValue[0].Value = ("s5",)
        aNamedValue = aMsgL10n.execute(aNamedValue)
        aTextShapeF.setString(aNamedValue[0].Value[0])
        aQuestionNamedValues = []
        aQuestionNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
        aQuestionNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
        aQuestionNamedValues[0].Name = "ButtonYesState"
        aQuestionNamedValues[0].Value = False
        aQuestionNamedValues[1].Name = "Text"
        aQuestionNamedValues[1].Value = aNamedValue[0].Value[0]
        aQuestion = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.QuestionBox", self.ctx)
        aQuestionNamedValues = list(aQuestion.execute(tuple(aQuestionNamedValues)))
        if not aQuestionNamedValues[0].Value:
            nIndexPairs[0], nIndexPairs[1] = nIndexPairs[1], nIndexPairs[0]
        del aQuestion
        del aQuestionNamedValues
        aCurrentController.select(None)
        aDrawPage.remove(aTextShapeF)
        # ---------------------
        # Lists standardisation
        # ---------------------
        for i in range(nIndexPairs[0]):
            for j in range(nEntitySelected-1):
                aCoords[j].X, aCoords[j+1].X = aCoords[j+1].X, aCoords[j].X
                aCoords[j].Y, aCoords[j+1].Y = aCoords[j+1].Y, aCoords[j].Y
            aPolars.append(aPolars.pop(0))
        nIndexPairs[1] =  abs(nIndexPairs[1] - nIndexPairs[0])
        nIndexPairs[0] = 0
        if aPolars[nIndexPairs[0]+1][0] > aPolars[nIndexPairs[0]-1][0]:
            aCoords.append(aCoords.pop(0))
            aPolars.reverse()
            aPolars.insert(0,aPolars.pop())
            for i in range(nEntitySelected):
                aPolars[i][1] = (aPolars[i][1] + math.pi) % (2 * math.pi)
                if i < (nEntitySelected - 1):
                    aCoords[i+1].X = long(aCoords[i].X + aPolars[i][0] * math.cos(aPolars[i][1]))
                    aCoords[i+1].Y = long(aCoords[i].Y - aPolars[i][0] * math.sin(aPolars[i][1]))
            nIndexPairs[1] =  nEntitySelected - nIndexPairs[1]
        # -------------------------------------------------
        fStridePos = aPolars[1][1] - aPolars[0][1] + math.pi
        if fStridePos > 2 * math.pi:
            fStridePos = fStridePos - 2 * math.pi
        # ecart de la ligne de foulee au collet
        # path line offset from collar
        if nStridePos == 0:
            if (nStepWidth / fScale) < 100000:
                nStridePos = long(nStepWidth / 2 * math.sin(fStridePos))
            else:
                nStridePos = long(65000 * fScale * math.sin(fStridePos))
        else:
            nStridePos = long(nStridePos * fScale * math.sin(fStridePos))
        # ----------------------
        if nEntitySelected == 6:
            aCoords.insert(5, uno.createUnoStruct("com.sun.star.awt.Point"))
            fAngle = (self.compute('toPolarCoord', aCoords[6], aCoords[2])[1] + fStridePos) % (2 * math.pi)
            aPolars.insert(5, [0, fAngle])
            aCoords[5].X, aCoords[5].Y = aCoords[6].X, aCoords[6].Y
            fAngle = (fAngle + math.pi) % (2 * math.pi)
            aPolars.insert(2, [0, fAngle])
            aCoords.insert(2, uno.createUnoStruct("com.sun.star.awt.Point"))
            aCoords[2].X, aCoords[2].Y = aCoords[3].X, aCoords[3].Y
            nIndexPairs[1] = nIndexPairs[1] + 1
        # ---------------------    
        if nEntitySelected == 7:
            aCoords.insert(2, uno.createUnoStruct("com.sun.star.awt.Point"))
            fAngle = aPolars[1][1] + fStridePos
            aPolars.insert(2, [0, fAngle])
            aCoords[2].X, aCoords[2].Y = aCoords[3].X, aCoords[3].Y
            nIndexPairs[1] = nIndexPairs[1] + 1
        ## Drawing path line - trace de la ligne de foulee
        aLineDash = uno.createUnoStruct("com.sun.star.drawing.LineDash")
        aLineDash.Style = uno.Enum("com.sun.star.drawing.DashStyle", "RECT")
        aLineDash.Dots = 1
        aLineDash.DotLen = 100
        aLineDash.Dashes = 1
        aLineDash.DashLen = 500
        aLineDash.Distance = 100
        for i in range(1,4):
            if aPolars[i][0] > 0:
                ## straight line - ligne
                aCoord[0].X = aCoords[i].X + long(nStridePos * math.sin(aPolars[i][1]))
                aCoord[0].Y = aCoords[i].Y + long(nStridePos * math.cos(aPolars[i][1]))
                aCoord[1].X = aCoords[i+1].X + long(nStridePos * math.sin(aPolars[i][1]))
                aCoord[1].Y = aCoords[i+1].Y + long(nStridePos * math.cos(aPolars[i][1]))
                aCoord[3].X = min(aCoord[0].X, aCoord[1].X)
                aCoord[3].Y = min(aCoord[0].Y, aCoord[1].Y)
                aSize.Width = abs(aCoord[0].X - aCoord[1].X) + 1
                aSize.Height = abs(aCoord[0].Y - aCoord[1].Y) + 1
                aNewShape = CurrentComponentModel.createInstance("com.sun.star.drawing.LineShape")
                aNewShape.setPosition(aCoord[3])
                aNewShape.setSize(aSize)
                aNewShape.setPropertyValue("RotateAngle", long(aPolars[i][1] * 18000 / math.pi))
                aDrawPage.add(aNewShape)
                aNewShape.setPropertyValue("LineStyle", uno.Enum("com.sun.star.drawing.LineStyle", "DASH"))
                aNewShape.setPropertyValue("LineDash", aLineDash)
            if i < 3:
                ## arc
                aCoord[0].X = aCoords[i+1].X - abs(nStridePos)
                aCoord[0].Y = aCoords[i+1].Y - abs(nStridePos)
                aSize.Width = aSize.Height = abs(nStridePos) * 2
                aNewShape = CurrentComponentModel.createInstance("com.sun.star.drawing.EllipseShape")
                aNewShape.setPosition(aCoord[0])
                aNewShape.setSize(aSize)
                aNewShape.setPropertyValue("CircleKind", uno.Enum("com.sun.star.drawing.CircleKind", "ARC"))
                aCoord[1].X = long(((aPolars[i][1] - fStridePos) % (2 * math.pi)) * 18000 / math.pi)
                aCoord[1].Y = long(((aPolars[i+1][1] - fStridePos) % (2 * math.pi)) * 18000 / math.pi)
                if nStridePos < 0:
                    aCoord[1].X, aCoord[1].Y = aCoord[1].Y, aCoord[1].X
                aNewShape.setPropertyValue("CircleStartAngle", aCoord[1].X)
                aNewShape.setPropertyValue("CircleEndAngle", aCoord[1].Y)
                aDrawPage.add(aNewShape)
                aNewShape.setPropertyValue("LineStyle", uno.Enum("com.sun.star.drawing.LineStyle", "DASH"))
                aNewShape.setPropertyValue("LineDash", aLineDash)
        # -------------------------------------------------------------------------------
        # Calculating length of path line - longueur de la ligne de foulee
        # Splitting path and collar line - decomposition de la ligne de foulee et de jour
        # -------------------------------------------------------------------------------
        nCollarLength = []
        nStrideLength = []
        nCollarLength.append(max((long(aPolars[1][0]) - nStepWidth), 0))
        nCollarLength.append(long(aPolars[1][0]))
        nStrideLength.append(nCollarLength[0])
        nStrideLength.append(nCollarLength[1])
        # ------------------------------------
        nStrideLength.append(nStrideLength[1] + long(abs((((aPolars[2][1] - aPolars[1][1]) * math.sin(fStridePos) + 2 * math.pi) % (2 * math.pi)) * nStridePos)))
        nStrideLength.append(nStrideLength[2] + long(aPolars[2][0] / 2))
        nStrideLength.append(nStrideLength[3] + long(aPolars[2][0] / 2))
        nStrideLength.append(nStrideLength[4] + long(abs((((aPolars[3][1] - aPolars[2][1]) * math.sin(fStridePos) + 2 * math.pi) % (2 * math.pi)) * nStridePos)))
        nCollarLength.append(nCollarLength[1] + long(aPolars[2][0] / 2))
        nCollarLength.append(nCollarLength[2] + long(aPolars[2][0] / 2))
        # -------------------------------------
        nStrideLength.append(nStrideLength[5] + min(long(aPolars[3][0]), nStepWidth))
        nStrideLength.append(nStrideLength[5] + long(aPolars[3][0]))
        nCollarLength.append(nCollarLength[3] + min(long(aPolars[3][0]), nStepWidth))
        nCollarLength.append(nCollarLength[3] + long(aPolars[3][0]))
        ## Calculating the tread length - calcul du giron
        nTreadLength = long(float(nStrideLength[-1]) / (nStepsCount - 1))
        ## Correcting regular length value - correction des longueurs de marches normales
        if n1stStepBal > 0:
            nStrideLength[0] = (n1stStepBal - 2) * nTreadLength
            nCollarLength[0] = (n1stStepBal - 2) * nTreadLength
        else:
            nCollarLength[0] = (nCollarLength[0] / nTreadLength) * nTreadLength
            nStrideLength[0] = (nStrideLength[0] / nTreadLength) * nTreadLength
        if nLastStepBal > 0:
            nStrideLength[6] = nStrideLength[7] - (nStepsCount - nLastStepBal -1) * nTreadLength
            nCollarLength[4] = nCollarLength[5] - (nStepsCount - nLastStepBal - 1) * nTreadLength
        else:
            nStrideLength[6] = nStrideLength[7] - ((nStrideLength[7] - nStrideLength[6]) / nTreadLength) * nTreadLength
            nCollarLength[4] = nCollarLength[5] - ((nCollarLength[5] - nCollarLength[4]) / nTreadLength) * nTreadLength
        ## -------------------------------------
        ## Drawing de stairs - trace des marches
        ## -------------------------------------
        for i in range(nStepsCount - 2):
            nStrideDist = (i + 1) * nTreadLength
            ## --------------------------------
            #### Case 1 and 8 - Cas 1 et 8 ####
            if nStrideDist <= nStrideLength[0] or nStrideDist >= nStrideLength[6]:
                n = -(nStrideDist <= nStrideLength[0]) + (nStrideDist >= nStrideLength[6])
                nDistance = nStrideDist - nStrideLength[5] * (n > 0)
                nIndex = n + 2
                fAngle = aPolars[nIndex][1]
            ## Coordinates on collar line - coordonnees sur la ligne de jour (collet)
                aCoord[0].X = aCoords[nIndex].X + long(nDistance * math.cos(fAngle))
                aCoord[0].Y = aCoords[nIndex].Y - long(nDistance * math.sin(fAngle))
            ## Coordinates on stride line - coordonnees sur la ligne de foulee
                ## no need but text position - pas besoin sauf pour le texte
                aCoord[1].X = aCoords[nIndex].X + long(nDistance * math.cos(fAngle) + nStridePos * math.sin(fAngle))
                aCoord[1].Y = aCoords[nIndex].Y - long(nDistance * math.sin(fAngle) - nStridePos * math.cos(fAngle))
            ## Coordinates on outside line - coordonnees sur la ligne d'echiffre
                aCoord[2].X = aCoord[0].X + long(nStepWidth * math.sin(fStridePos) * math.sin(fAngle))
                aCoord[2].Y = aCoord[0].Y + long(nStepWidth * math.sin(fStridePos) * math.cos(fAngle))
            ## --------------------------------
            #### Case 2 and 7 - Cas 2 et 7 ####
            elif nStrideDist <= nStrideLength[1] or nStrideDist >= nStrideLength[5]:
                n = -(nStrideDist <= nStrideLength[1]) + (nStrideDist >= nStrideLength[5])
                nDistance = nStrideDist - nStrideLength[5] * (n > 0)
                nIndex = n + 2
                fAngle = aPolars[nIndex][1]
            ## Coordinates on stride line - coordonnees sur la ligne de foulee
                aCoord[1].X = aCoords[nIndex].X + long(nDistance * math.cos(fAngle) + nStridePos * math.sin(fAngle))
                aCoord[1].Y = aCoords[nIndex].Y - long(nDistance * math.sin(fAngle) - nStridePos * math.cos(fAngle))
            ## Coordinates on collar line - coordonnees sur la ligne de jour (collet)
                nDistance = nCollarLength[0]*(n < 0) + (nCollarLength[4] - nCollarLength[3]) * (n > 0)
                nDistance = abs(nDistance - n * self.compute('CollarX', abs(nCollarLength[2] - nCollarLength[2+2*n]), abs(nStrideLength[3] - nStrideLength[3+3*n]), abs(nStrideDist - nStrideLength[3+3*n])))
                aCoord[0].X = aCoords[nIndex].X + long(nDistance * math.cos(fAngle))
                aCoord[0].Y = aCoords[nIndex].Y - long(nDistance * math.sin(fAngle))
            ## Coordinates on outside line - coordonnees sur la ligne d'echiffre
                fAngle = self.compute('toPolarCoord', aCoord[0], aCoord[1])[1]
                nIndex = 6 * (n > 0)
                fOutsideAngle = (aPolars[nIndex - 1][1] + math.pi) % (2 * math.pi)
                rep = self.compute('InterLines', aCoord[0], fAngle, aCoords[nIndex], fOutsideAngle)
                if rep is None:
                    aNamedValue[0].Value = ("s6",)
                    aNamedValue = aMsgL10n.execute(aNamedValue)
                    aMessage.execute(aNamedValue)
                    return
                else:
                    nDistance = rep[0]
                aCoord[2].X = aCoord[0].X + long(nDistance * math.cos(fAngle))
                aCoord[2].Y = aCoord[0].Y - long(nDistance * math.sin(fAngle))
            ## --------------------------------
            #### Case 3 and 6 - Cas 3 et 6 ####
            elif nStrideDist <= nStrideLength[2] or nStrideDist >= nStrideLength[4]:
                n = -(nStrideDist <= nStrideLength[2]) + (nStrideDist >= nStrideLength[4])
                nIndex = (n < 0) + 3 * (n > 0)
                nDistance = nStrideDist - nStrideLength[1] * (n < 0) - nStrideLength[5] * (n > 0)
                fAngle = aPolars[nIndex][1] - fStridePos + float(nDistance) / nStridePos
            ## Coordinates on stride line - coordonnees sur la ligne de foulee
                nIndex = 2 * (n < 0) + 3 * (n > 0)
                aCoord[1].X = aCoords[nIndex].X + long(abs(nStridePos) * math.cos(fAngle))
                aCoord[1].Y = aCoords[nIndex].Y - long(abs(nStridePos) * math.sin(fAngle))
            ## Coordinates on collar line - coordonnees sur la ligne de jour (collet)
                nDistance = nCollarLength[0]*(nStrideDist <= nStrideLength[2]) + (nCollarLength[4] - nCollarLength[3]) * (nStrideDist >= nStrideLength[4])
                nDistance = nDistance - n * self.compute('CollarX', abs(nCollarLength[2] - nCollarLength[2+2*n]), abs(nStrideLength[3] - nStrideLength[3+3*n]), abs(nStrideDist - nStrideLength[3+3*n]))
                if nDistance <= nCollarLength[1] and nDistance >= 0:
                    nIndex = (nStrideDist <= nStrideLength[2]) + 3 * (nStrideDist >= nStrideLength[4])
                    fAngle = aPolars[nIndex][1]
                    aCoord[0].X = aCoords[nIndex].X + long(nDistance * math.cos(fAngle))
                    aCoord[0].Y = aCoords[nIndex].Y - long(nDistance * math.sin(fAngle))
                else:
                    nDistance = nDistance - nCollarLength[1] * (nStrideDist <= nStrideLength[2]) + aPolars[2][0] * (nStrideDist >= nStrideLength[4])
                    fAngle = aPolars[2][1]
                    aCoord[0].X = aCoords[2].X + long(nDistance * math.cos(fAngle))
                    aCoord[0].Y = aCoords[2].Y - long(nDistance * math.sin(fAngle))
            ## Coordinates on outside line - coordonnees sur la ligne d'echiffre
                fAngle = self.compute('toPolarCoord', aCoord[0], aCoord[1])[1]
                nIndex = 5 * (n > 0)
                fOutsideAngle = ((aPolars[nIndex - 1][1] + math.pi) % (2 * math.pi)) * (n < 0) + (aPolars[nIndex][1]) * (n > 0)
                rep = self.compute('InterLines', aCoord[0], fAngle, aCoords[nIndex], fOutsideAngle)
                if rep is None:
                    nDistance = aPolars[nIndex-(n<0)][0] + abs(nStridePos)
                else:
                    nDistance = rep[1]
                # --------------------------------------
                if nDistance <= aPolars[nIndex-(n<0)][0]:
                    aCoord[2].X = aCoords[nIndex].X + long(nDistance * math.cos(fOutsideAngle))
                    aCoord[2].Y = aCoords[nIndex].Y - long(nDistance * math.sin(fOutsideAngle))
                else:
                    fOutsideAngle = (aPolars[6][1] + math.pi) % (2 * math.pi)
                    rep = self.compute('InterLines', aCoord[0], fAngle, aCoords[7], fOutsideAngle)
                    if rep is None:
                        aNamedValue[0].Value = ("s6",)
                        aNamedValue = aMsgL10n.execute(aNamedValue)
                        aMessage.execute(aNamedValue)
                        return
                    else:
                        nDistance = rep[0]
                    aCoord[2].X = aCoord[0].X + long(nDistance * math.cos(fAngle))
                    aCoord[2].Y = aCoord[0].Y - long(nDistance * math.sin(fAngle))
            ## --------------------------------
            #### Case 4 and 5 - Cas 4 et 5 ####
            elif nStrideDist <= nStrideLength[3] or nStrideDist > nStrideLength[3]:
                nDistance = nStrideDist - nStrideLength[2]
            ## Coordinates on stride line - coordonnees sur la ligne de foulee
                fAngle = aPolars[2][1]
                aCoord[1].X = aCoords[2].X + long(nDistance * math.cos(fAngle) + nStridePos * math.sin(fAngle))
                aCoord[1].Y = aCoords[2].Y - long(nDistance * math.sin(fAngle) - nStridePos * math.cos(fAngle))
            ## Coordinates on collar line - coordonnees sur la ligne de jour (collet)
                n = -(nStrideDist <= nStrideLength[3]) + (nStrideDist > nStrideLength[3])
                nDistance = (nCollarLength[1] - nCollarLength[0]) * (n < 0) + (nCollarLength[4] - nCollarLength[3]) * (n > 0)
                nDistance = self.compute('CollarX', abs(nCollarLength[2] - nCollarLength[2+2*n]), abs(nStrideLength[3] - nStrideLength[3+3*n]), abs(nStrideDist - nStrideLength[3+3*n])) - nDistance
                nDistance = -n * nDistance + aPolars[2][0] * (n > 0)
                aCoord[0].X = aCoords[2].X + long(nDistance * math.cos(fAngle))
                aCoord[0].Y = aCoords[2].Y - long(nDistance * math.sin(fAngle))
            ## Coordinates on outside line - coordonnees sur la ligne d'echiffre
                fAngle = self.compute('toPolarCoord', aCoord[0], aCoord[1])[1]
                fOutsideAngle = (aPolars[6][1] + math.pi) % (2 * math.pi)
                rep = self.compute('InterLines', aCoord[0], fAngle, aCoords[7], fOutsideAngle)
                if rep is None:
                    aNamedValue[0].Value = ("s6",)
                    aNamedValue = aMsgL10n.execute(aNamedValue)
                    aMessage.execute(aNamedValue)
                    return
                else:
                    nDistance = rep[0]
                aCoord[2].X = aCoord[0].X + long(nDistance * math.cos(fAngle))
                aCoord[2].Y = aCoord[0].Y - long(nDistance * math.sin(fAngle))
            # -----------------------------------------
            aCoord[3].X = min(aCoord[0].X, aCoord[2].X)
            aCoord[3].Y = min(aCoord[0].Y, aCoord[2].Y)
            aSize.Width = abs(aCoord[0].X - aCoord[2].X) + 1
            aSize.Height = abs(aCoord[0].Y - aCoord[2].Y) + 1
            aNewShape = CurrentComponentModel.createInstance("com.sun.star.drawing.LineShape")
            aNewShape.setPosition(aCoord[3])
            aNewShape.setSize(aSize)
            fAngle = self.compute('toPolarCoord', aCoord[0], aCoord[2])[1]
            aNewShape.setPropertyValue("RotateAngle", long(fAngle * 18000 / math.pi))
            aDrawPage.add(aNewShape)
            ##
            ## Step number drawing - affichage du numero de marche
            ##
            aTextShape = CurrentComponentModel.createInstance("com.sun.star.drawing.TextShape")
            aTextShape.setPosition(aCoord[1])
            aSize.Width = 125 * long(math.log10(i+2) + 1)
            aSize.Height = 350
            aTextShape.setSize(aSize)
            aTextShape.setPropertyValue("TextFitToSize", uno.Enum("com.sun.star.drawing.TextFitToSizeType", "PROPORTIONAL"))
            if fStridePos < 0:
                fAngle = (fAngle + math.pi) % (2 * math.pi)
            aTextShape.setPropertyValue("RotateAngle", long(fAngle * 18000 / math.pi))
            aDrawPage.add(aTextShape)
            aTextCursor = aTextShape.createTextCursor()
            aTextShape.insertString(aTextCursor, "%d" % (i+2), False)
        ##
        ## First step number - numero de la premiere marche
        ##
        aTextShape = CurrentComponentModel.createInstance("com.sun.star.drawing.TextShape")
        ## aCoord[1].X, aCoord[1].Y = [long((aCoords[0].X + aCoords[1].X)/2), long((aCoords[0].Y + aCoords[1].Y)/2)]
        aCoord[1].X = aCoords[1].X - long(abs(nStridePos) * math.cos(aPolars[0][1]))
        aCoord[1].Y = aCoords[1].Y + long(abs(nStridePos) * math.sin(aPolars[0][1]))
        aTextShape.setPosition(aCoord[1])
        aSize.Width = 100
        aSize.Height = 250
        aTextShape.setSize(aSize)
        aTextShape.setPropertyValue("TextFitToSize", uno.Enum("com.sun.star.drawing.TextFitToSizeType", "PROPORTIONAL"))
        fAngle = aPolars[0][1]
        if fStridePos > 0:
            fAngle = (fAngle + math.pi) % (2 * math.pi)
        aTextShape.setPropertyValue("RotateAngle", long(fAngle * 18000 / math.pi))
        aDrawPage.add(aTextShape)
        aTextCursor = aTextShape.createTextCursor()
        aTextShape.insertString(aTextCursor, "1", False)
        ##
        ## Last step number - numero de la derniere marche
        ##
        aTextShape = CurrentComponentModel.createInstance("com.sun.star.drawing.TextShape")
        ##aCoord[1].X, aCoord[1].Y = [long((aCoords[4].X + aCoords[5].X)/2), long((aCoords[4].Y + aCoords[5].Y)/2)]
        aCoord[1].X = aCoords[4].X + long(abs(nStridePos) * math.cos(aPolars[4][1]))
        aCoord[1].Y = aCoords[4].Y - long(abs(nStridePos) * math.sin(aPolars[4][1]))
        aTextShape.setPosition(aCoord[1])
        aSize.Width = 200
        aSize.Height = 250
        aTextShape.setSize(aSize)
        aTextShape.setPropertyValue("TextFitToSize", uno.Enum("com.sun.star.drawing.TextFitToSizeType", "PROPORTIONAL"))
        fAngle = aPolars[4][1]
        if fStridePos < 0:
            fAngle = (fAngle + math.pi) % (2 * math.pi)
        aTextShape.setPropertyValue("RotateAngle", long(fAngle * 18000 / math.pi))
        aDrawPage.add(aTextShape)
        aTextCursor = aTextShape.createTextCursor()
        aTextShape.insertString(aTextCursor, "%d" % nStepsCount, False)
        ##
        ## Stride dimension - cotation du giron
        ##
        aDimShape = CurrentComponentModel.createInstance("com.sun.star.drawing.MeasureShape")
        aCoord[0].X, aCoord[0].Y = [long((aCoords[0].X + aCoords[1].X)/2), long((aCoords[0].Y + aCoords[1].Y)/2)]
        aCoord[1].X = aCoord[0].X + long(nTreadLength * math.cos(aPolars[1][1]))
        aCoord[1].Y = aCoord[0].Y - long(nTreadLength * math.sin(aPolars[1][1]))
        aDrawPage.add(aDimShape)
        aDimShape.setPropertyValue("StartPosition", aCoord[0])
        aDimShape.setPropertyValue("EndPosition", aCoord[1])
        aDimShape.setPropertyValue("CharHeight", 10.0)
        aDimShape.setPropertyValue("MeasureShowUnit", False)
    # **********************************
    # inspection wrapper
    # **********************************
    def inspectObject(self, aObject):
        aDiveIn = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DiveIn", self.ctx)
        aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aParms[0].Name = "inspect"
        aParms[0].Value = aObject
        aParms = aDiveIn.execute(aParms)
        return
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(StairsJob,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.Stairs", # implemenation name
                                         ("org.openoffice.comp.pyuno.Stairs",),)    # list of implemented services
