#	$Id: msgl10n.py,v 1.2 2007/03/05 15:33:37 gerard Exp $
# -*- coding: latin-1 -*-
## ********************************************************************************
## 
## Copyright (C) 2005, 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    from com.sun.star.task import XJob
    import traceback
except ImportError:
    print "probleme d'import"
#=====================================================
# a class to localize all messages
# une classe pour traduire tous messages
#=====================================================
class MsgL10n(unohelper.Base, XJob):
    """All messages l10n
    Traduction de tous messages"""
    def __init__(self, ctx):
        aLinguistic = ctx.ServiceManager.createInstanceWithContext( "com.sun.star.linguistic2.LinguProperties",ctx)
        self.aLocale = aLinguistic.DefaultLocale.Language
        # add new language in the following list
        aLocaleList = ("fr", "en")
        if self.aLocale not in aLocaleList:
            self.aLocale = "en"
        # add translated messages in the following list
        self.aMessages = {"l0":{"fr":"Tracer un segment ",
                                "en":"Drawing a line "},
                          "l1":{"fr":"==> point 1 ",
                                "en":"==> point 1 "},
                          "l2":{"fr":"==> point 2 ",
                                "en":"==> point 2 "},
                          "sq0":{"fr":"Tracer un carr� ",
                                 "en":"Drawing a square "},
                          "sq1":{"fr":"==> centre ",
                                "en":"==> centre "},
                          "sq2":{"fr":"==> demi cot� ",
                                "en":"==> half width "},
                          "rec0":{"fr":"Tracer un rectangle ",
                                 "en":"Drawing a rectangle "},
                          "rec1":{"fr":"==> centre ",
                                "en":"==> centre "},
                          "rec2":{"fr":"==> demi cot� 1 ",
                                "en":"==> half width "},
                          "rec3":{"fr":"==> demi cot� 2 ",
                                  "en":"==> half height "},
                          "c0":{"fr":"Tracer un cercle ",
                                "en":"Drawing a circle "},
                          "c1":{"fr":"==> centre",
                                "en":"==> centre"},
                          "c2":{"fr":"==> rayon",
                                "en":"==> radius"},
                          "c3p0":{"fr":"Tracer un cercle par 3 points",
                                  "en":"Drawing a circle with 3 points"},
                          "c3p1":{"fr":"==> point 1 ",
                                  "en":"==> point 1 "},
                          "c3p2":{"fr":"==> point 2 ",
                                  "en":"==> point 2 "},
                          "c3p3":{"fr":"==> point 3 ",
                                  "en":"==> point 3 "},
                          "p0":{"fr":"Tracer un polygone ",
                                "en":"Drawing a polygon"},
                          "p1":{"fr":"==> point 1 ",
                                "en":"==> point 1 "},
                          "p2":{"fr":"==> point suivant",
                                "en":"==> next point"},
                          "e0":{"fr":"Tracer une ellipse ",
                                "en":"Drawing an ellipse "},
                          "e1":{"fr":"==> centre",
                                "en":"==> centre"},
                          "e2":{"fr":"==> rayon 1 et orientation",
                                "en":"==> radius 1 and orientation"},
                          "e3":{"fr":"==> rayon 2",
                                "en":"==> radius 2"},
                          "ea0":{"fr":"Tracer un arc d'ellipse ",
                                 "en":"Drawing an elliptical arc "},
                          "ea1":{"fr":"==> centre",
                                 "en":"==> centre"},
                          "ea2":{"fr":"==> rayon 1 et orientation",
                                 "en":"==> radius 1 and orientation"},
                          "ea3":{"fr":"==> rayon 2",
                                 "en":"==> radius 2"},
                          "ea4":{"fr":"==> angle initial",
                                 "en":"==> start angle"},
                          "ea5":{"fr":"==> angle final",
                                 "en":"==> end angle"},
                          "a0":{"fr":"Tracer un arc ",
                                "en":"Drawing an arc "},
                          "a1":{"fr":"==> centre",
                                "en":"==> centre"},
                          "a2":{"fr":"==> rayon",
                                "en":"==> radius"},
                          "a3":{"fr":"==> angle initial",
                                "en":"==> start angle"},
                          "a4":{"fr":"==> angle final",
                                "en":"==> end angle"},
                          "t0":{"fr":"Prolonger",
                                "en":"Triming"},
                          "cu0":{"fr":"Couper",
                                 "en":"Cutting"},
                          "o0":{"fr":"Copie d�cal�e d'entit�",
                                "en":"Entity offset copy"},
                          "o1":{"fr":"Saisie de distance",
                                "en":"Distance input"},
                          "o2":{"fr":"D�calage",
                                "en":"Offset"},
                          "o3":{"fr":"Au revoir !",
                                "en":"Bye !"},
                          "o4":{"fr":"Angle nul interdit \nAu revoir !",
                                "en":"Null angle forbidden \nBye !"},
                          "o5":{"fr":"Segments parall�les ou colin�aires \nAu revoir !",
                                "en":"parallel or colinear segments\nBye !"},
                          "s0":{"fr":"S�lectionner un contour.\nAu revoir !",
                                "en":"Select a contour \nBye !"},
                          "s1":{"fr":"Au revoir !",
                                "en":"Bye !"},
                          "s2":{"fr":"Nombre de segments (6, 7 ou 8)\nAu revoir !",
                                "en":"Segments count must be 6, 7 or 8\nBye !"},
                          "s3":{"fr":"Le contour n'est pas un segment\nAu revoir !",
                                "en":"Contour is not a line \nBye !"},
                          "s4":{"fr":"Impossible de trouver l'emmarchement\nAu revoir !",
                                "en":"Unable to find stairs width \nBye !"},
                          "s5":{"fr":"La marche ci-contre\n est la 1ere",
                                "en":"Is this first step"},
                          "s6":{"fr":"Deux segments parall�les \nAu revoir !",
                                "en":"Two parallel segments \nBye !"},
                          "m0":{"fr":"Attention !",
                                "en":"Warning !"},
                          "m1":{"fr":"Valider",
                                "en":"OK"},
                          "q0":{"fr":"Question",
                                "en":"Question"},
                          "q1":{"fr":"Oui",
                                "en":"Yes"},
                          "q2":{"fr":"Non",
                                "en":"No"},
                          "d0":{"fr":"Valider",
                                "en":"OK"},
                          "d1":{"fr":"Annuler",
                                "en":"Cancel"},
                          "d2":{"fr":"Distance",
                                "en":"Distance"},
                          "d3":{"fr":"Saisir la distance ou la coordonn�e X",
                                "en":"Input distance or X coordinate"},
                          "d4":{"fr":"Choisir les unit�s",
                                "en":"Select units"},
                          "d5":{"fr":"Angle",
                                "en":"Angle"},
                          "d6":{"fr":"Saisir l'angle ou la coordonn�e Y",
                                "en":"Input angle or Y coordinate"},
                          "d7":{"fr":"Repère",
                                "en":"Reference"},
                          "d8":{"fr":"Absolu",
                                "en":"Absolute"},
                          "d9":{"fr":"Relatif",
                                "en":"Relative"},
                          "d10":{"fr":"radian",
                                 "en":"radian"},
                          "d11":{"fr":"degr�s",
                                 "en":"degree"},
                          "d12":{"fr":"grade",
                                 "en":"grade"},
                          "k0":{"fr":"Donn�s de dimension",
                                "en":"Dimension data"},
                          "k1":{"fr":"Saisie de distance",
                                "en":"Distance input"},
                          "k2":{"fr":"Donn�s de position",
                                "en":"Position data"},
                          "k3":{"fr":"Saisie de coordonn�es rectangulaires",
                                "en":"rectangular coordinates input"},
                          "k4":{"fr":"Saisie de coordonn�es polaires",
                                "en":"polar coordinates input"},
                          "k5":{"fr":"saisie d'un angle",
                                "en":"angle input"},
                          "st0":{"fr":"Extr�mit�",
                                 "en":"End"},
                          "st1":{"fr":"Intersection",
                                 "en":"Intersection"},
                          "st2":{"fr":"Milieu",
                                 "en":"Middle"},
                          "st3":{"fr":"Perpendiculaire",
                                 "en":"Perpendicular"},
                          "st4":{"fr":"Tangent",
                                 "en":"Tangent"},
                          "st5":{"fr":"Axonom�trie",
                                 "en":"Axonometric"},
                          "st6":{"fr":"* multiple",
                                 "en":"* multiple"},
                          "st7":{"fr":"type d'aimantation",
                                 "en":"magnet type"},
                          "st8":{"fr":"Directe",
                                 "en":"Straight"},
                          "st9":{"fr":"Cong�",
                                 "en":"Fillet"},
                          "st10":{"fr":"Chanfrein",
                                  "en":"Chamfer"},
                          "st11":{"fr":"type de jonction",
                                  "en":"junction type"},
                          "sw0":{"fr":"Nombre de marche et balancement",
                                 "en":"Number of steps and balancing"},
                          "sw1":{"fr":"Valider",
                                 "en":"OK"},
                          "sw2":{"fr":"Annuler",
                                 "en":"Cancel"},
                          "sw3":{"fr":"Saisir le nombre de marches",
                                 "en":"Input steps count"},
                          "sw4":{"fr":"Distance ligne de foul�e/collet",
                                 "en":"Stride line distance"},
                          "sw5":{"fr":"Saisir la distance",
                                 "en":"Input distance"},
                          "sw6":{"fr":"Choisir les unités",
                                 "en":"Select units"},
                          "sw7":{"fr":"Nombre de marches",
                                 "en":"Steps count"},
                          "sw8":{"fr":"Saisir le n de la 1�re marche balanc�e",
                                 "en":"Input 1st balanced step number"},
                          "sw9":{"fr":"1ére marche balanc�e ou 0 pour automatique",
                                 "en":"1st balanced step or 0 for automatic"},
                          "sw10":{"fr":"Saisir le n de la derni�re marche balanc�e",
                                  "en":"Input last balanced step number"},
                          "sw11":{"fr":"Derni�re marche balanc�e ou 0 pour automatique",
                                  "en":"Last balanced step or 0 for automatic"},
                          "di0":{"fr":"Inspection d'objet",
                                 "en":"Diving in object"},
                          "di1":{"fr":"Fermer",
                                 "en":"Close"},
                          "di2":{"fr":"Enregistrer",
                                 "en":"Save"},
                          "di3":{"fr":"Inconnu",
                                 "en":"Unknown"},
                          "di4":{"fr":"Services support�s",
                                 "en":"Supported services"},
                          "di5":{"fr":"Liste des services support�s",
                                 "en":"List of supported services"},
                          "di6":{"fr":"Interfaces",
                                 "en":"Interfaces"},
                          "di7":{"fr":"Liste des interfaces",
                                 "en":"Interfaces list"},
                          "di8":{"fr":"M�thodes",
                                 "en":"Methods"},
                          "di9":{"fr":"Liste des m�thodes",
                                 "en":"List of methods"},
                          "di10":{"fr":"Propri�t�s",
                                  "en":"Properties"},
                          "di11":{"fr":"Liste de propri�t�s",
                                  "en":"List of properties"},
                          "di12":{"fr":"Valeur(s)",
                                  "en":"Value(s)"},
                          "di13":{"fr":"Valeur(s) de la propri�t� ci-dessus",
                                  "en":"Above property value(s)"},
                          "di14":{"fr":"inspecter",
                                  "en":"inspect"},
                          "di15":{"fr":"pr�c�dent",
                                  "en":"previous"},
                          "dim0":{"fr":"cotation",
                                  "en":"dimension"},
                          "fi0":{"fr":"cong�",
                                 "en":"fillet"}}
    # *****************************
    # Called from other components
    # *****************************
    def execute(self, aArgs):
        aArgs[0].Value = tuple([self.aMessages[aMsg][self.aLocale] for aMsg in aArgs[0].Value])
        return aArgs
    # **********************************
    # inspection wrapper
    # **********************************
    def inspectObject(self, aObject):
        aDiveIn = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DiveIn", self.ctx)
        aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aParms[0].Name = "inspect"
        aParms[0].Value = aObject
        aParms = aDiveIn.execute(aParms)
        return
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(MsgL10n,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.MsgL10n", # implemention name
                                         ("org.openoffice.comp.pyuno.MsgL10n",),)    # list of implemented services
