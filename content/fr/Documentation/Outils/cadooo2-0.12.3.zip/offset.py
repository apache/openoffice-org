#	$Id: offset.py,v 1.1 2006-07-16 10:02:13 gerard Exp $
# -*- coding: latin-1 -*-
## ********************************************************************************
## 
## Copyright (C) 2005, 2006, 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    from com.sun.star.task import XJobExecutor
    import math, traceback
except ImportError:
    print "probleme d'import"
# ===========================================
# Decalage d'entites
# Entities offset
# EDITMODE ENTITYPE MODE COMMENT OFFSET
# ===========================================
class OffsetJob(unohelper.Base, XJobExecutor):
    """Drawing Entities offset
    Decalage d'entites de dessin"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
    #=======================
    # Called by the GUI
    #=======================
    def trigger(self, args):
        aEnv = {}
        aEnv['EDITMODE'] = True
        aEnv['ENTITYPE'] = None
        aEnv['MODE'] = ('OFFSET',)
        aNamedValues = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aNamedValues[0].Name = "CONTEXT"
        aMsgL10n = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
        aNamedValues[0].Value = ("o0",)
        aNamedValues = aMsgL10n.execute(aNamedValues)
        aEnv['COMMENT'] = (aNamedValues[0].Value)
        desktop = self.smgr.createInstanceWithContext( "com.sun.star.frame.Desktop",self.ctx)
        # access the current draw document
        aModel = desktop.getCurrentComponent()
        aDocumentSettings = aModel.createInstance("com.sun.star.drawing.DocumentSettings")
        fScale = float(aDocumentSettings.ScaleNumerator) / aDocumentSettings.ScaleDenominator
        aCoordData = {}
        aCoordData["X"] = 0
        aCoordData["XUNIT"] = "m"
        aCoordData["Y"] = 0
        aCoordData["YUNIT"] = "m"
        aNamedValues[0].Value = ("o1", "o2")
        aNamedValues = aMsgL10n.execute(aNamedValues)
        aCoordInput = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DataInputBox", self.ctx)
        aCoordData["TITLE"]  = aNamedValues[0].Value[0]
        aCoordData["FLAG"] = 0
        aCoordData["COMMENT"] = aNamedValues[0].Value[1]
        aCoordData["RETURN"] = False
        aNamedValues[0].Value = tuple(aCoordData.items())
        aCoordData = dict(list(aCoordInput.execute(aNamedValues)[0].Value))
        if aCoordData["RETURN"]:
            aEnv['OFFSET'] = long(aCoordData['X']*fScale)
        else:
            # annulation
            aMessage = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MessageBox", self.ctx)
            aNamedValues[0].Value = ('o3',)
            aNamedValues = aMsgL10n.execute(aNamedValues)
            aMessage.execute(aNamedValues)
            return
        aCadoooJob = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.CadoooJob", self.ctx)
        aNamedValues[0].Value = tuple(aEnv.items())
        aEnv = dict(list(aCadoooJob.execute(aNamedValues)[0].Value))
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(OffsetJob,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.Offset", # implemenation name
                                         ("org.openoffice.comp.pyuno.Offset",),)    # list of implemented services
