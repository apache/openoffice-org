# 	$Id: entitiespot.py,v 1.2 2007/03/05 15:33:37 gerard Exp $
# -*- coding: latin-1 -*-
## ********************************************************************************
## entitiespot lun jan 24 20:15:49 CET 2005
## Copyright (C) 2005 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    import math, traceback
    from com.sun.star.task import XJob
    from com.sun.star.drawing.CircleKind import ARC, SECTION, CUT
except ImportError:
    print "probleme d'import"
# ===============================================
# Indique les entites graphique sous le pointeur
# shows the graphical entities under pointer
# ===============================================
class EntitieSpot(unohelper.Base, XJob):
    """Indique les entites graphique sous le pointeur
    shows the graphical entities under pointer"""
    def __init__(self, ctx):
        smgr = ctx.ServiceManager
        self.aCompute = smgr.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", ctx)
    ## =========================================
    ## wrapper for the compute functions
    ## =========================================
    def compute(self, sMethod, *aArgs):
        aNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aNamedValues[i].Name = "Function"
                aNamedValues[i].Value = sMethod
            elif i < n-1:
                aNamedValues[i].Name = "Param%d" % i
                aNamedValues[i].Value = aArgs[i-1]
            else:
                aNamedValues[i].Name = "Result"
        aNamedValues = list(self.aCompute.execute(tuple(aNamedValues),))
        return aNamedValues[n-1].Value
    # ========================================
    # Look for entities under mouse and
    # rectangle intersection
    #   Name         Value
    # VALIDLIST   True or False
    # MAGNETSIZE
    # DEVICEXSCALE
    # DEVICEYSCALE
    # SPOTLIST
    # MOUSEEVENT
    # EDITMODE
    # SHAPE
    # BORDERLIST
    # SPOTTEDSHAPE
    # ========================================
    def execute(self, aNamedValues):
        aEnv = dict(list(aNamedValues[0].Value))
        nFieldLength = aEnv['MAGNETSIZE'] * aEnv['DEVICEXSCALE']
        # --------------------------------------------------------------------
        if not aEnv['VALIDLIST'] or aNamedValues[1].Value == "create": # create a list of splitted entities
            # EntityList definition
            # Line = entity address (indexes tuple), entity type, Point, Point
            # ellipse = entity address (indexes tuple), entity type, Point, Size, RotateAngle, StartAngle, EndAngle
            self.aEntityList = []
            aShapes = []
            nIndexes = []
            aShapes.append(aEnv['CONTROLLER'].getCurrentPage())
            nEntityCount = [aShapes[-1].getCount()]
            aVisibleArea = aEnv['CONTROLLER'].VisibleArea
            aCoord = (uno.createUnoStruct("com.sun.star.awt.Point"), uno.createUnoStruct("com.sun.star.awt.Point"))
            aCoord[0].X, aCoord[0].Y = aVisibleArea.X + aVisibleArea.Width / 2, aVisibleArea.Y + aVisibleArea.Height / 2
            # ----------------------
            if nEntityCount[-1] > 0:
                nIndexes.append(0)
                # --------
                while True:
                    aShape = aShapes[-1].getByIndex(nIndexes[-1])
                    aType = aShape.getShapeType().split('.')[-1]
                    # -----------------------------------------------------------------------------------------------
                    if aType in ("PolyLineShape", "PolyPolygonShape", "RectangleShape", "LineShape", "EllipseShape"):
                        # ---------------------------------------
                        if not aShape.getName() in ("new", "helpline1", "helpline2", "baseline", "arc"): # do not treat the shape being created or dimension
                            aCoord[1].X = aShape.BoundRect.X + aShape.BoundRect.Width / 2
                            aCoord[1].Y = aShape.BoundRect.Y + aShape.BoundRect.Height / 2
                            nWidth = aVisibleArea.Width + aShape.BoundRect.Width
                            nHeight = aVisibleArea.Height + aShape.BoundRect.Height
                            nRateX = 200 * abs(aCoord[1].X - aCoord[0].X) / nWidth
                            nRateY = 200 * abs(aCoord[1].Y - aCoord[0].Y) / nHeight
                            nMaxRateX = 100 * aVisibleArea.Width / nWidth
                            nMaxRateY = 100 * aVisibleArea.Height / nHeight
                            # PolyPolygonBezierShape and other shapes are excluded (todo)
                            if nRateX <= nMaxRateX and nRateY <= nMaxRateY:
                                self.aEntityList.extend(self.splitShape(aShape, aType, nIndexes))
                    # ---------------------------
                    elif aType in ("GroupShape",): # add a new level to treat a grouped shape
                        aShapes.append(aShape)
                        nEntityCount.append(aShape.getCount())
                        nIndexes.append(-1)
                    # ----------------------
                    while len(nIndexes) > 0:
                        nIndexes[-1] = nIndexes[-1] + 1
                        # ----------------------------------
                        if nIndexes[-1] >= nEntityCount[-1]: # level of grouped shapes completed
                            nIndexes.pop()
                            aShapes.pop()
                            nEntityCount.pop()
                        else:
                            break # still some shapes to split
                    else:
                        break # all shapes done
                aEnv['VALIDLIST'] = 1
        # --------------------------------
        if aNamedValues[1].Value == "add": # add a new splitted entity
            aShape = aEnv['SHAPE']
            aType = aShape.getShapeType().split('.')[-1]
            # ----------------------------------------
            if aShape.getPropertyValue("SizeProtect"): # do not treat the shape being created
                # PolyPolygonBezierShape are excluded (todo)
                if aType in ("PolyLineShape", "PolyPolygonShape", "RectangleShape", "LineShape", "EllipseShape"):
                    self.aEntityList = self.aEntityList + self.splitShape(aShape, aType, (aShape.ZOrder,),)
        # ---------------------------
        if len(self.aEntityList) == 0:
            aEnv['VALIDLIST'] = 0
            aEnv['SPOTLIST'] = None
            aEnv['SPOTTEDSHAPE'] = None
            aEnv['BORDERLIST'] = None
            # print "no entity spotted"
            aNamedValues[0].Value = tuple(aEnv.items())
            return aNamedValues
        # ---------------------------------
        if aNamedValues[1].Value == "spot": # which entity is under mouse pointer
            aMouseCoord = uno.createUnoStruct("com.sun.star.awt.Point")
            aMouseCoord.X, aMouseCoord.Y = self.compute("transformMouseCoord", tuple(aEnv.items()))
            aEnv['SPOTTEDSHAPE'] = None
            aSegments = []
            aDistList =[] # absissa, ordinate, length
            aIndxList = []
            nSubIndx = 1
            nI = nDist = 0
            bEntityAdded = False
            aCoord = (uno.createUnoStruct("com.sun.star.awt.Point"), uno.createUnoStruct("com.sun.star.awt.Point"))
            # -----------------------------------
            for i in range(len(self.aEntityList)):
                # ------------------------------------------
                if self.aEntityList[i][1] in ("LineShape",): # line spotted
                    aDistList.append(self.compute("Dist2Line", self.aEntityList[i][2], self.aEntityList[i][3], aMouseCoord))
                    # ------------------------------------------
                    if abs(aDistList[-1][1]) <= nFieldLength:
                        if aDistList[-1][0]+ nFieldLength >= 0 and aDistList[-1][0] - nFieldLength <= aDistList[-1][2]:
                            aSegments.append(self.aEntityList[i][1:])
                            bEntityAdded = True
                # ---------------------------------------------- # ellipse spotted
                elif self.aEntityList[i][1] in ("EllipseShape", "ArcEllipseShape", "ArcCircleShape", "CircleShape"):
                    aDistList.append(self.compute("Dist2Arc", *(self.aEntityList[i][2:] + (aMouseCoord,))))
                    # -----------------------------------------
                    if abs(aDistList[-1][1]) <= nFieldLength:
                        if aDistList[-1][0] + nFieldLength >= 0 and aDistList[-1][0] - nFieldLength <= aDistList[-1][2]:
                            aSegments.append(self.aEntityList[i][1:])
                            bEntityAdded = True
                    elif abs(self.aEntityList[i][2].X-aMouseCoord.X)+abs(self.aEntityList[i][2].Y-aMouseCoord.Y) <= nFieldLength:
                        aSegments.append(self.aEntityList[i][1:])
                        bEntityAdded = True
                # -------------------------------------
                if aIndxList == self.aEntityList[i][0]:
                    nSubIndx = nSubIndx + 1
                else:
                    aIndxList = self.aEntityList[i][0]
                    nSubIndx = 1
                # --------------------------------------------------------
                if bEntityAdded:
                    bEntityAdded = False
                    if not aEnv['SPOTTEDSHAPE'] or abs(aDistList[-1][1]) < nDist:
                        nDist = abs(aDistList[-1][1])
                        aEnv['GROUPSHAPE'] = aEnv['CONTROLLER'].getCurrentPage()
                        aEnv['SPOTTEDSHAPE'] = tuple(self.aEntityList[i]) + (nSubIndx,)
                        nI = i
                        for j in aEnv['SPOTTEDSHAPE'][0][:-1]:
                            aEnv['GROUPSHAPE'] = aEnv['GROUPSHAPE'].getByIndex(j)
                        j = aEnv['SPOTTEDSHAPE'][0][-1]
                        aShape = aEnv['GROUPSHAPE'].getByIndex(j)
                        aType = aShape.getShapeType().split('.')[-1]
                        aEnv['SPLITTEDSHAPE'] = tuple(self.splitShape(aShape, aType, aEnv['SPOTTEDSHAPE'][0]))
                        aEnv['MOUSERELPOS'] = aDistList[-1]
            if len(aSegments) > 0:
                aEnv['SPOTLIST'] = tuple([tuple(c) for c in aSegments])
            else:
                aEnv['SPOTLIST'] = None
            # in edit mode the border list is set
            if aEnv.has_key('EDITMODE') and len(aSegments) > 0:
                self.aBorderList = [[-1, -1, uno.createUnoStruct("com.sun.star.awt.Point")] for i in range(4)]
                # ------------------------
                for i in range(len(aDistList)):
                    # --------------------------------------------------------
                    if i != nI: # entity cannot be self border
                        # --------------------------------
                        if self.aEntityList[nI][1] == "LineShape": # spotted entity is a line
                            nDist, fAngle1 = self.compute("toPolarCoord", self.aEntityList[nI][2], self.aEntityList[nI][3])
                            # ---------------------------------------
                            if self.aEntityList[i][1] == "LineShape": # border candidate is a line
                                fAngle2 = self.compute("toPolarCoord", self.aEntityList[i][2], self.aEntityList[i][3])[1]
                                aResult = self.compute("InterLines", self.aEntityList[nI][2], fAngle1, self.aEntityList[i][2], fAngle2)
                                # ---------------------------------------
                                if aResult:
                                    if abs(aResult[0]) > 1 and abs(aResult[0] - nDist) > 1:
                                        self.setBorder(aDistList[nI], aResult[0], aResult[2], aResult[3])
                                    elif abs(aResult[0]) <= 1:
                                        self.setBorder(aDistList[nI], aResult[0], self.aEntityList[nI][2].X, self.aEntityList[nI][2].Y)
                                    else:
                                        self.setBorder(aDistList[nI], aResult[0], self.aEntityList[nI][3].X, self.aEntityList[nI][3].Y)
                            # ------------------------------------------------------------------------------------------
                            elif self.aEntityList[i][1] in ("CircleShape", "EllipseShape", "ArcCircleShape", "ArcEllipseShape"):
                                aResult = self.compute("InterLineEllipse", self.aEntityList[nI][2], fAngle1, *self.aEntityList[i][2:5])
                                # --------------
                                if len(aResult): # intersection ?
                                    # ------------------------------------------------------
                                    if abs(aResult[0]) > 1 and abs(aResult[0] - nDist) > 1:
                                        self.setBorder(aDistList[nI], aResult[0], aResult[2], aResult[3])
                                    elif abs(aResult[0]) <= 1:
                                        self.setBorder(aDistList[nI], aResult[0], self.aEntityList[nI][2].X, self.aEntityList[nI][2].Y)
                                    else:
                                        self.setBorder(aDistList[nI], aResult[0], self.aEntityList[nI][3].X, self.aEntityList[nI][3].Y)
                                    # ------------------------------------------------------
                                    if abs(aResult[1]) > 1 and abs(aResult[1] - nDist) > 1:
                                        self.setBorder(aDistList[nI], aResult[1], aResult[4], aResult[5])
                                    elif abs(aResult[1]) <= 1:
                                        self.setBorder(aDistList[nI], aResult[1], self.aEntityList[nI][2].X, self.aEntityList[nI][2].Y)
                                    else:
                                        self.setBorder(aDistList[nI], aResult[1], self.aEntityList[nI][3].X, self.aEntityList[nI][3].Y)
                        # ------------------------------------------------------------------------------------------------------
                        elif self.aEntityList[nI][1] in ("CircleShape", "EllipseShape", "ArcCircleShape", "ArcEllipseShape"): # spotted entity is
                            # ---------------------------------------
                            if self.aEntityList[i][1] == "LineShape": # border candidate is a line
                                fAngle2 = self.compute("toPolarCoord", self.aEntityList[i][2], self.aEntityList[i][3])[1]
                                aResult = self.compute("InterLineEllipse", self.aEntityList[i][2], fAngle2, *self.aEntityList[nI][2:5])
                                # --------------
                                if len(aResult): # intersection ?
                                    aCoord[0].X, aCoord[0].Y = aResult[2:4]
                                    nDist = self.compute("Dist2Arc", *(self.aEntityList[nI][2:] + (aCoord[0],)))[0]
                                    self.setBorder(aDistList[nI], nDist, aResult[2], aResult[3])
                                    aCoord[1].X, aCoord[1].Y = aResult[4:]
                                    nDist = self.compute("Dist2Arc", *(self.aEntityList[nI][2:] + (aCoord[1],)))[0]
                                    self.setBorder(aDistList[nI], nDist, aResult[4], aResult[5])
                            # -------------------------------------------------------------------------------------------
                            elif self.aEntityList[i][1] in ("CircleShape", "EllipseShape", "ArcCircleShape", "ArcEllipseShape"):
                                aResult = self.compute("InterEllipses", *(self.aEntityList[nI][2:5] + self.aEntityList[i][2:5]))
                                # --------------
                                if len(aResult) > 0: # intersection ?
                                    aCoord[0].X, aCoord[0].Y = aResult[:2]
                                    nDist = self.compute("Dist2Arc", *(self.aEntityList[nI][2:] + (aCoord[0],)))[0]
                                    self.setBorder(aDistList[nI], nDist, aResult[0], aResult[1])
                                # --------------
                                if len(aResult) > 2: # intersection ?
                                    aCoord[0].X, aCoord[0].Y = aResult[2:4]
                                    nDist = self.compute("Dist2Arc", *(self.aEntityList[nI][2:] + (aCoord[0],)))[0]
                                    self.setBorder(aDistList[nI], nDist, aResult[2], aResult[3])
                                # --------------
                                if len(aResult) > 4: # intersection ?
                                    aCoord[0].X, aCoord[0].Y = aResult[4:6]
                                    nDist = self.compute("Dist2Arc", *(self.aEntityList[nI][2:] + (aCoord[0],)))[0]
                                    self.setBorder(aDistList[nI], nDist, aResult[4], aResult[5])
                                # --------------
                                if len(aResult) > 6: # intersection ?
                                    aCoord[0].X, aCoord[0].Y = aResult[6:]
                                    nDist = self.compute("Dist2Arc", *(self.aEntityList[nI][2:] + (aCoord[0],)))[0]
                                    self.setBorder(aDistList[nI], nDist, aResult[6], aResult[7])
                if len(self.aBorderList) > 0:
                    aEnv["BORDERLIST"] = tuple([tuple(c) for c in self.aBorderList])
        aNamedValues[0].Value = tuple(aEnv.items())
        return aNamedValues
    # set the border list
    def setBorder(self, aDistList, nDistBorder, nX, nY):
        nDelta =  nDistBorder - aDistList[0]
        nRate = abs(long(aDistList[0] * 100 / aDistList[2]))
        # -----------------------------------------------------------------
        if nDistBorder >= -10 and nDistBorder <= aDistList[2]+10: # within segment limits ?
            # -------------
            if nDelta >= 0: # is this a right border ?
                # ----------------------------
                if self.aBorderList[1][0] < 0: # not yet initialized ?
                    self.aBorderList[1][0] = abs(nDelta)
                # --------------------------------------------
                if abs(nDelta) <= abs(self.aBorderList[1][0]):
                    self.aBorderList[1][0], self.aBorderList[1][1], self.aBorderList[1][2].X, self.aBorderList[1][2].Y = abs(nDelta), nRate, nX, nY
            # --------------
            else: # is this a left Border ?
                # ----------------------------
                if self.aBorderList[0][0] < 0: # not yet initialized ?
                    self.aBorderList[0][0] = abs(nDelta)
                # --------------------------------------------
                if abs(nDelta) <= abs(self.aBorderList[0][0]):
                    self.aBorderList[0][0], self.aBorderList[0][1], self.aBorderList[0][2].X, self.aBorderList[0][2].Y = abs(nDelta), nRate, nX, nY
        # -----------------
        elif nDistBorder < -10: # is this the second left border ?
            # ----------------------------
            if self.aBorderList[2][0] < 0: # not yet initialized ?
                self.aBorderList[2][0] = abs(nDelta)
            if abs(nDelta) <= abs(self.aBorderList[2][0]):
                self.aBorderList[2][0], self.aBorderList[2][1], self.aBorderList[2][2].X, self.aBorderList[2][2].Y = abs(nDelta), nRate, nX, nY
        # ---
        else: # is this the second right border ?
            # ----------------------------
            if self.aBorderList[3][0] < 0: # not yet initialized ?
                self.aBorderList[3][0] = abs(nDelta)
            if abs(nDelta) <= abs(self.aBorderList[3][0]):
                self.aBorderList[3][0], self.aBorderList[3][1], self.aBorderList[3][2].X, self.aBorderList[3][2].Y = abs(nDelta), nRate, nX, nY
    # decompose a shape in segments
    def splitShape(self, aShape, aType, nIndx):
        aSegments = []
        aCoord = (uno.createUnoStruct("com.sun.star.awt.Point"), uno.createUnoStruct("com.sun.star.awt.Point"))
        # -------------------------------------------------------------
        if aType in ("LineShape", "PolyLineShape", "PolyPolygonShape"):
            # --------------------------------------
            for i in range(len(aShape.PolyPolygon)):
                # -------------------------------------------
                for j in range(len(aShape.PolyPolygon[i])-1):
                    aSegments.append((tuple(nIndx), "LineShape",\
                                      uno.createUnoStruct("com.sun.star.awt.Point"),\
                                      uno.createUnoStruct("com.sun.star.awt.Point")))
                    aSegments[-1][2].X, aSegments[-1][2].Y = aShape.PolyPolygon[i][j].X, aShape.PolyPolygon[i][j].Y
                    aSegments[-1][3].X, aSegments[-1][3].Y = aShape.PolyPolygon[i][j+1].X, aShape.PolyPolygon[i][j+1].Y
        # --------------------------------
        elif aType in ("RectangleShape",):
            aSize = aShape.getSize()
            aULCCoord = aShape.getPosition()
            fAngle1 = aShape.RotateAngle * math.pi / 18000
            fCosW = aSize.Width * math.cos(fAngle1)
            fSinW = -aSize.Width * math.sin(fAngle1)
            fCosH = aSize.Height * math.cos(fAngle1 - math.pi / 2)
            fSinH = -aSize.Height * math.sin(fAngle1 - math.pi / 2)
            fCosCW = aShape.CornerRadius * math.cos(fAngle1)
            fSinCW = -aShape.CornerRadius * math.sin(fAngle1)
            fCosCH = aShape.CornerRadius * math.cos(fAngle1 - math.pi / 2)
            fSinCH = -aShape.CornerRadius * math.sin(fAngle1 - math.pi / 2)
            aCoord[0].X, aCoord[0].Y = aULCCoord.X + fCosCW, aULCCoord.Y + fSinCW
            aCoord[1].X, aCoord[1].Y = aULCCoord.X + fCosW - fCosCW, aULCCoord.Y + fSinW - fSinCW
            aSegments.append((tuple(nIndx), "LineShape",\
                              uno.createUnoStruct("com.sun.star.awt.Point"),\
                              uno.createUnoStruct("com.sun.star.awt.Point")))
            aSegments[-1][2].X, aSegments[-1][2].Y = aCoord[0].X, aCoord[0].Y
            aSegments[-1][3].X, aSegments[-1][3].Y = aCoord[1].X, aCoord[1].Y
            aCoord[0].X, aCoord[0].Y = aULCCoord.X + fCosW + fCosCH, aULCCoord.Y + fSinW + fSinCH
            aCoord[1].X, aCoord[1].Y = aULCCoord.X + fCosW + fCosH - fCosCH, aULCCoord.Y + fSinW + fSinH - fSinCH
            aSegments.append((tuple(nIndx), "LineShape",\
                              uno.createUnoStruct("com.sun.star.awt.Point"),\
                              uno.createUnoStruct("com.sun.star.awt.Point")))
            aSegments[-1][2].X, aSegments[-1][2].Y = aCoord[0].X, aCoord[0].Y
            aSegments[-1][3].X, aSegments[-1][3].Y = aCoord[1].X, aCoord[1].Y
            aCoord[0].X, aCoord[0].Y = aULCCoord.X + fCosW + fCosH - fCosCW, aULCCoord.Y + fSinW + fSinH - fSinCW
            aCoord[1].X, aCoord[1].Y = aULCCoord.X + fCosH + fCosCW, aULCCoord.Y + fSinH + fSinCW
            aSegments.append((tuple(nIndx), "LineShape",\
                              uno.createUnoStruct("com.sun.star.awt.Point"),\
                              uno.createUnoStruct("com.sun.star.awt.Point")))
            aSegments[-1][2].X, aSegments[-1][2].Y = aCoord[0].X, aCoord[0].Y
            aSegments[-1][3].X, aSegments[-1][3].Y = aCoord[1].X, aCoord[1].Y
            aCoord[0].X, aCoord[0].Y = aULCCoord.X + fCosH - fCosCH, aULCCoord.Y + fSinH - fSinCH
            aCoord[1].X, aCoord[1].Y = aULCCoord.X + fCosCH, aULCCoord.Y + fSinCH
            aSegments.append((tuple(nIndx), "LineShape",\
                              uno.createUnoStruct("com.sun.star.awt.Point"),\
                              uno.createUnoStruct("com.sun.star.awt.Point")))
            aSegments[-1][2].X, aSegments[-1][2].Y = aCoord[0].X, aCoord[0].Y
            aSegments[-1][3].X, aSegments[-1][3].Y = aCoord[1].X, aCoord[1].Y
            # ---------------------
            if aShape.CornerRadius:
                aCoord[0].X, aCoord[0].Y = aULCCoord.X + fCosCW + fCosCH, aULCCoord.Y + fSinCW + fSinCH
                aSegments.append((tuple(nIndx), "ArcCircleShape",\
                                  uno.createUnoStruct("com.sun.star.awt.Point"),\
                                  uno.createUnoStruct("com.sun.star.awt.Size"),\
                                  float(0),\
                                  fAngle1 + math.pi/2,\
                                  fAngle1 + math.pi))
                aSegments[-1][2].X, aSegments[-1][2].Y = aCoord[0].X, aCoord[0].Y
                aSegments[-1][3].Width = aSegments[-1][3].Height = aShape.CornerRadius
                aCoord[0].X, aCoord[0].Y = aULCCoord.X + fCosW - fCosCW + fCosCH, aULCCoord.Y + fSinW - fSinCW + fSinCH
                aSegments.append((tuple(nIndx), "ArcCircleShape",\
                                  uno.createUnoStruct("com.sun.star.awt.Point"),\
                                  uno.createUnoStruct("com.sun.star.awt.Size"),\
                                  float(0),\
                                  fAngle1,\
                                  fAngle1 + math.pi/2))
                aSegments[-1][2].X, aSegments[-1][2].Y = aCoord[0].X, aCoord[0].Y
                aSegments[-1][3].Width = aSegments[-1][3].Height = aShape.CornerRadius
                aCoord[0].X, aCoord[0].Y = aULCCoord.X + fCosW + fCosH - fCosCW - fCosCH, aULCCoord.Y + fSinW + fSinH - fSinCW - fSinCH
                aSegments.append((tuple(nIndx), "ArcCircleShape",\
                                  uno.createUnoStruct("com.sun.star.awt.Point"),\
                                  uno.createUnoStruct("com.sun.star.awt.Size"),\
                                  float(0),\
                                  fAngle1 + 3*math.pi/2,\
                                  fAngle1))
                aSegments[-1][2].X, aSegments[-1][2].Y = aCoord[0].X, aCoord[0].Y
                aSegments[-1][3].Width = aSegments[-1][3].Height = aShape.CornerRadius
                aCoord[0].X, aCoord[0].Y = aULCCoord.X + fCosH + fCosCW - fCosCH, aULCCoord.Y + fSinH + fSinCW - fSinCH
                aSegments.append((tuple(nIndx), "ArcCircleShape",\
                                  uno.createUnoStruct("com.sun.star.awt.Point"),\
                                  uno.createUnoStruct("com.sun.star.awt.Size"),\
                                  float(0),\
                                  fAngle1 + math.pi,\
                                  fAngle1 + 3*math.pi/2))
                aSegments[-1][2].X, aSegments[-1][2].Y = aCoord[0].X, aCoord[0].Y
                aSegments[-1][3].Width = aSegments[-1][3].Height = aShape.CornerRadius
        # ------------------------------
        elif aType in ("EllipseShape",):
            aSize = aShape.getSize()
            aULCCoord = aShape.getPosition()
            fAngle1 = aShape.RotateAngle * math.pi / 18000
            fCosW = aSize.Width * math.cos(fAngle1) / 2
            fSinW = -aSize.Width * math.sin(fAngle1) / 2
            fCosH = aSize.Height * math.cos(fAngle1) / 2
            fSinH = -aSize.Height * math.sin(fAngle1) / 2
            aCoord[0].X = long(fCosW - fSinH) + aULCCoord.X
            aCoord[0].Y = long(fSinW + fCosH) + aULCCoord.Y
            # --------------------------------------
            if abs(aSize.Width - aSize.Height) < 10:
                aCadoooType = "CircleShape"
            else:
                aCadoooType = "EllipseShape"
            # --------------------------
            if aShape.CircleKind in (ARC, CUT, SECTION):
                aCadoooType = "Arc" + aCadoooType
            aSegments.append((tuple(nIndx), aCadoooType,\
                              uno.createUnoStruct("com.sun.star.awt.Point"),\
                              uno.createUnoStruct("com.sun.star.awt.Size"),\
                              fAngle1,\
                              float(aShape.CircleStartAngle)*math.pi/18000,\
                              float(aShape.CircleEndAngle)*math.pi/18000))
            aSegments[-1][2].X = aCoord[0].X
            aSegments[-1][2].Y = aCoord[0].Y
            aSegments[-1][3].Width, aSegments[-1][3].Height = aSize.Width / 2 , aSize.Height / 2
        return aSegments
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(EntitieSpot,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.EntitieSpot", # implemenation name
                                         ("org.openoffice.comp.pyuno.EntitieSpot",),)    # list of implemented services
