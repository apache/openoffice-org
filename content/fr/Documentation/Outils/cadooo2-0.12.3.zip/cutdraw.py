#	$Id: cutdraw.py,v 1.1 2006-07-16 10:02:12 gerard Exp $
# -*- coding: latin-1 -*-
## ********************************************************************************
## 
## Copyright (C) 2005 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    from com.sun.star.task import XJob
    from com.sun.star.drawing.CircleKind import FULL, SECTION, CUT, ARC
    import math, traceback
except ImportError:
    print "probleme d'import"
#======================================================
# a class to cut an entity
# une classe pour couper une entit�
#======================================================
class CutDraw(unohelper.Base, XJob):
    """Coupe une entite graphique
    cuts a graphical entity"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.aEntitySpot = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.EntitieSpot", self.ctx)
    # **********************************
    # inspection wrapper
    # **********************************
    def inspectObject(self, aObject):
        aDiveIn = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.DiveIn", self.ctx)
        aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aParms[0].Name = "inspect"
        aParms[0].Value = aObject
        aParms = aDiveIn.execute(aParms)
        return
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # ==============================
    def execute(self, aNamedValues):
        self.aEnv = dict(list(aNamedValues[0].Value))
        aNamedValues[1].Value = "spot"
        self.aEnv = dict(list(self.aEntitySpot.execute(aNamedValues)[0].Value))
        sBorder = ""
        if not self.aEnv['SPOTLIST'] is None:
            aGroupShape = self.aEnv['CONTROLLER'].getCurrentPage()
            for i in self.aEnv['SPOTTEDSHAPE'][0][:-1]:
                aGroupShape = aGroupShape.getByIndex(i)
            i = self.aEnv['SPOTTEDSHAPE'][0][-1]
            aShape = aGroupShape.getByIndex(i)
            aType = aShape.getShapeType().split('.')[-1]
            if self.aEnv['SPOTTEDID'] != self.aEnv['SPOTTEDSHAPE'][0]+(self.aEnv['SPOTTEDSHAPE'][-1],):
                self.removeTempShape()
                self.aEnv['SPOTTEDID'] = self.aEnv['SPOTTEDSHAPE'][0][:] + (self.aEnv['SPOTTEDSHAPE'][-1],)
                aCoords = [[]]
                # ---------------------------------------------------
                if self.aEnv['SPOTTEDSHAPE'][1] in ('LineShape',): # is it a line ?
                    self.aEnv['UNOTYPE'] = "LineShape"
                    self.aEnv['ENTITYPE'] = "LINE"
                    self.aEnv['STEP'] = 1
                    self.aEnv['MODE'] = (self.aEnv['MODE'][0],) + ("VERTEX",)
                    # ---------------------------------------
                    if self.aEnv['BORDERLIST'][0][0] >= 0: # does a left border within segment exist ?
                        aCoords[0].append(self.aEnv['BORDERLIST'][0][2])
                    # ------------------------------------
                    else :
                        aCoords[0].append(self.aEnv['SPOTTEDSHAPE'][2])
                    # ---------------------------------------
                    if self.aEnv['BORDERLIST'][1][0] >= 0: # does a right border within segment exist ?
                        aCoords[0].append(self.aEnv['BORDERLIST'][1][2])
                    # ------------------------------------
                    else:
                        aCoords[0].append(self.aEnv['SPOTTEDSHAPE'][3])
                # ---------------------------------------------------------------------------------------------------------
                elif self.aEnv['SPOTTEDSHAPE'][1] in ("CircleShape", "ArcCircleShape", "EllipseShape", "ArcEllipseShape"):
                    self.aEnv['UNOTYPE'] = "EllipseShape"
                    aCoords[0].extend([uno.createUnoStruct("com.sun.star.awt.Point") for i in range(4)])
                    aCoords[0][0].X = self.aEnv['SPOTTEDSHAPE'][2].X
                    aCoords[0][0].Y = self.aEnv['SPOTTEDSHAPE'][2].Y
                    # -------------------- arc produced ------------------------------------
                    if self.aEnv['SPOTTEDSHAPE'][1] in ("CircleShape", "ArcCircleShape"):
                        self.aEnv['ENTITYPE'] = "ARC"
                        self.aEnv['STEP'] = 3
                        self.aEnv['MODE'] = (self.aEnv['MODE'][0],) + ("RADIUS", "STARTANGLE", "ENDANGLE")
                    # arc of ellipse produced
                    else:
                        self.aEnv['ENTITYPE'] = "ELLARC"
                        self.aEnv['STEP'] = 4
                        self.aEnv['MODE'] = (self.aEnv['MODE'][0],) + ("RADIUS", "RADIUS2", "STARTANGLE", "ENDANGLE")
                        aCoords[0].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                        aPoint = self.compute("PointOnEllipse", None, math.pi/2, *self.aEnv['SPOTTEDSHAPE'][2:5])[0]
                        aCoords[0][2].X = aPoint.X
                        aCoords[0][2].Y = aPoint.Y
                    aPoint = self.compute("PointOnEllipse", None, float(0), *self.aEnv['SPOTTEDSHAPE'][2:5])[0]
                    aCoords[0][1].X = aPoint.X
                    aCoords[0][1].Y = aPoint.Y
                    # ---------------------------------------
                    if self.aEnv['BORDERLIST'][0][0] >= 0: # does a left border within segment exist ?
                        aCoords[0][-2].X = self.aEnv['BORDERLIST'][0][2].X
                        aCoords[0][-2].Y = self.aEnv['BORDERLIST'][0][2].Y
                    # ---
                    else:
                        aPoint = self.compute("PointOnEllipse", None, self.aEnv['SPOTTEDSHAPE'][5], *self.aEnv['SPOTTEDSHAPE'][2:5])[0]
                        aCoords[0][-2].X = aPoint.X
                        aCoords[0][-2].Y = aPoint.Y
                    # ---------------------------------------
                    if self.aEnv['BORDERLIST'][1][0] >= 0: # does a right border within segment exist ?
                        aCoords[0][-1].X = self.aEnv['BORDERLIST'][1][2].X
                        aCoords[0][-1].Y = self.aEnv['BORDERLIST'][1][2].Y
                    # ---
                    else:
                        aPoint = self.compute("PointOnEllipse", None, self.aEnv['SPOTTEDSHAPE'][6],*self.aEnv['SPOTTEDSHAPE'][2:5])[0]
                        aCoords[0][-1].X = aPoint.X
                        aCoords[0][-1].Y = aPoint.Y
                    if not aType in ("RectangleShape",) and aShape.CircleKind in (ARC, CUT, SECTION):
                        self.aEnv['CIRCLEKIND'] = aShape.CircleKind
                    else:
                        self.aEnv['CIRCLEKIND'] = ARC
                self.aEnv['COORDS'] = tuple([tuple(c) for c in aCoords])
            else:
                self.aEnv['STEP'] = 0
        else:
            aType = "----"
            self.aEnv['STEP'] = 0
            self.removeTempShape()
            self.aEnv['SPOTTEDID'] = None
        sText = "%s ==> %s" % (self.aEnv['COMMENT'][0], aType)
        self.aEnv['STATUSBARCONTROL'][-1].setText(sText)
        aNamedValues[0].Value = tuple(self.aEnv.items())
        return aNamedValues
    # ----------------------
    # remove temporary shape
    # ----------------------
    def removeTempShape(self):
        if self.aEnv['SHAPE']:
            self.aEnv['GROUPSHAPE'].remove(self.aEnv['SHAPE'])
            self.aEnv['SHAPE'] = None
        return
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(CutDraw,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.CutDraw", # implemenation name
                                         ("org.openoffice.comp.pyuno.CutDraw",),)    # list of implemented services
