# 	$Id: cutjob.py,v 1.1 2006-07-16 10:02:12 gerard Exp $	
# -*- coding: latin-1 -*-
## ********************************************************************************
## cutjob mar jan 11 20:05:11 CET 2005
## Copyright (C) 2004, 2005, 2006, 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    from com.sun.star.task import XJobExecutor
    import traceback
except ImportError:
    print "probleme d'import"
#======================================================
# a class to cut graphical entities
# une classe pour couper une entite graphique
#======================================================
class CutJob(unohelper.Base, XJobExecutor):
    """Coupe une entite graphique
    Cuts a graphical entity"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
    #=======================
    # Called by the GUI
    #=======================
    def trigger(self, args):
        aEnv = {}
        aEnv['EDITMODE'] = True
        aEnv['ENTITYPE'] = None
        aEnv['MODE'] = ('CUT',)
        aEnv['CIRCLEKIND'] = uno.Enum("com.sun.star.drawing.CircleKind", "FULL")
        aNamedValues = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aNamedValues[0].Name = "CONTEXT"
        aMsgL10n = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
        aNamedValues[0].Value = ("cu0",)
        aNamedValues = aMsgL10n.execute(aNamedValues)
        aEnv['COMMENT'] = (aNamedValues[0].Value)
        aCadoooJob = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.CadoooJob", self.ctx)
        aNamedValues[0].Value = tuple(aEnv.items())
        aEnv = dict(list(aCadoooJob.execute(aNamedValues)[0].Value))
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(CutJob,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.Cut", # implemenation name
                                         ("org.openoffice.comp.pyuno.Cut",),)    # list of implemented services
