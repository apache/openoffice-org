# 	$Id: entityposize.py,v 1.1 2006-07-16 10:02:13 gerard Exp $	
## ********************************************************************************
## entityposize mer f�v 16 20:24:21 CET 2005
## Copyright (C) 2005 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import unohelper, uno
    import math, traceback
    from com.sun.star.task import XJob
    from com.sun.star.drawing.CircleKind import ARC
except ImportError:
    print "probleme d'import"
# =============================
# dessin des entites graphiques
# drawing of graphical entities
# =============================
class EntityPosSize(unohelper.Base, XJob):
    """dessin des entites graphique
    drawing of graphical entities"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # =====================
    # needed from dict env
    # UNOTYPE
    # MODE
    # COORDS
    # ORIGINCOORD
    # SHAPE
    # STEP
    # =====================
    def execute(self, aNamedValues):
        aEnv = dict(list(aNamedValues[0].Value))
        aULCCoord = uno.createUnoStruct("com.sun.star.awt.Point")
        aSize = uno.createUnoStruct("com.sun.star.awt.Size")
        idx = aEnv['STEP']
        bPosSizeFlag = True
        # ------------------
        if aEnv['SHAPE'] is None:
            # aEnv['GROUPSHAPE'].remove(aEnv['SHAPE'])
            aEnv['SHAPE'] = aEnv['MODEL'].createInstance("com.sun.star.drawing.%s" % aEnv['UNOTYPE'])
            aEnv['GROUPSHAPE'].add(aEnv['SHAPE'])
        # ----------------------------------
        if aEnv['MODE'][idx] == 'RADIUS': # drawing a circle or ellipse (centre and radius)
            nRadius1 = self.compute("toPolarCoord", aEnv['COORDS'][0][0], aEnv['COORDS'][0][1])[0]
            aULCCoord.X = aEnv['COORDS'][0][0].X - nRadius1
            aULCCoord.Y = aEnv['COORDS'][0][0].Y - nRadius1
            aSize.Width = aSize.Height = 2 * nRadius1
        # -----------------------------------
        elif aEnv['MODE'][idx] == 'WIDTH': # drawing a rectangle
            nRadius, fAngle1 = self.compute("toPolarCoord", aEnv['COORDS'][0][0], aEnv['COORDS'][0][1])
            fCosW = nRadius * math.cos(fAngle1 + math.pi)
            fSinW = -nRadius * math.sin(fAngle1 + math.pi)
            fCosH = nRadius * math.cos(fAngle1 + math.pi / 2)
            fSinH = -nRadius * math.sin(fAngle1 + math.pi / 2)
            aULCCoord.X = aEnv['COORDS'][0][0].X + fCosW + fCosH
            aULCCoord.Y = aEnv['COORDS'][0][0].Y + fSinW + fSinH
            aSize.Width = aSize.Height = 2 * nRadius
            aEnv['SHAPE'].RotateAngle = long(fAngle1 * 18000 / math.pi)
        # -----------------------------------
        elif aEnv['MODE'][idx] == 'HEIGHT': # drawing a rectangle
            nRadius1, fAngle1 = self.compute("toPolarCoord", aEnv['COORDS'][0][0], aEnv['COORDS'][0][1])
            nRadius2 = self.compute("toPolarCoord", aEnv['COORDS'][0][0], aEnv['COORDS'][0][2])[0]
            fCosW = nRadius1 * math.cos(fAngle1+ math.pi)
            fSinW = -nRadius1 * math.sin(fAngle1 + math.pi)
            fCosH = nRadius2 * math.cos(fAngle1 + math.pi / 2)
            fSinH = -nRadius2 * math.sin(fAngle1 + math.pi / 2)
            aULCCoord.X = aEnv['COORDS'][0][0].X + fCosW + fCosH
            aULCCoord.Y = aEnv['COORDS'][0][0].Y + fSinW + fSinH
            aSize.Width, aSize.Height = 2 * nRadius1, 2 * nRadius2
            aEnv['SHAPE'].CornerRadius = aEnv['CORNERRADIUS']
            aEnv['SHAPE'].RotateAngle = long(fAngle1 * 18000 / math.pi)
        # --------------------------------------
        elif aEnv['MODE'][idx] == 'DIAMETER': # drawing a circle (centre and diameter)
            nRadius = self.compute("toPolarCoord", aEnv['COORDS'][0][0], aEnv['COORDS'][0][1])[0] / 2
            aEnv['ORIGINCOORD'].X = (aEnv['COORDS'][0][0].X + aEnv['COORDS'][0][1].X) / 2
            aEnv['ORIGINCOORD'].Y = (aEnv['COORDS'][0][0].Y + aEnv['COORDS'][0][1].Y) / 2
            aULCCoord.X = aEnv['ORIGINCOORD'].X - nRadius
            aULCCoord.Y = aEnv['ORIGINCOORD'].Y - nRadius
            aSize.Width = aSize.Height = 2 * nRadius
        # --------------------------------------
        elif aEnv['MODE'][idx] == '3RDPOINT': # drawing a circle (three points)
            aULCCoord.X, aULCCoord.Y, nRadius = self.compute('Circle3P', *aEnv['COORDS'][0])
            aEnv['ORIGINCOORD'].X, aEnv['ORIGINCOORD'].Y = aULCCoord.X, aULCCoord.Y
            aULCCoord.X = aULCCoord.X - nRadius
            aULCCoord.Y = aULCCoord.Y - nRadius
            aSize.Width = aSize.Height = 2 * nRadius
        # ------------------------------------
        elif aEnv['MODE'][idx] == 'VERTEX': # drawing a line, polyline or polygon (two points)
            aEnv['SHAPE'].PolyPolygon = aEnv['COORDS']
            bPosSizeFlag = False
        # ----------------------------------
        elif aEnv['MODE'][idx] == 'RADIUS2': # drawing an ellipse (centre, first radius, second radius)
            aULCCoord, aSize, fAngle1 = self.getULCAndAngleOfEllipse(aEnv['COORDS'][0])
            aSize.Width, aSize.Height = 2 * aSize.Width, 2 * aSize.Height
            aEnv['SHAPE'].RotateAngle = long(fAngle1 * 18000 / math.pi)
        # ---------------------------------------
        elif aEnv['MODE'][idx] == 'STARTANGLE': # drawing an arc of circle or ellipse (centre, radius, radius2, start angle)
            aEnv['ORIGINCOORD'].X = aEnv['COORDS'][0][0].X
            aEnv['ORIGINCOORD'].Y = aEnv['COORDS'][0][0].Y
            fAngle2 = self.compute("toPolarCoord", aEnv['COORDS'][0][0], aEnv['COORDS'][0][-1])[1]
            if aEnv['ENTITYPE'] == "ARC":
                nRadius1 = self.compute("toPolarCoord", aEnv['COORDS'][0][0], aEnv['COORDS'][0][1])[0]
                aULCCoord.X = aEnv['COORDS'][0][0].X - nRadius1
                aULCCoord.Y = aEnv['COORDS'][0][0].Y - nRadius1
                aSize.Width = aSize.Height = 2 * nRadius1
                fAngle1 = float(0)
            else:
                aULCCoord, aSize, fAngle1 = self.getULCAndAngleOfEllipse(aEnv['COORDS'][0][:-1])
                fAngle2 = self.compute("PointOnEllipse", fAngle2, None, aEnv['COORDS'][0][0], aSize, fAngle1)[1]
                aSize.Width, aSize.Height = 2 * aSize.Width, 2 * aSize.Height
            aEnv['SHAPE'].CircleKind = ARC
            aEnv['SHAPE'].RotateAngle = long(fAngle1 * 18000 / math.pi)
            aEnv['SHAPE'].CircleStartAngle = long(fAngle2 * 18000 / math.pi)
            aEnv['SHAPE'].CircleEndAngle = 36000
        # -------- # drawing an arc of circle or ellipse (centre, radius, radius2, start angle, end angle)---------
        elif aEnv['MODE'][idx] == 'ENDANGLE':
            aEnv['ORIGINCOORD'].X = aEnv['COORDS'][0][0].X
            aEnv['ORIGINCOORD'].Y = aEnv['COORDS'][0][0].Y
            fAngle2 = self.compute("toPolarCoord", aEnv['COORDS'][0][0], aEnv['COORDS'][0][-2])[1]
            fAngle3 = self.compute("toPolarCoord", aEnv['COORDS'][0][0], aEnv['COORDS'][0][-1])[1]
            if aEnv['ENTITYPE'] == "ARC":
                nRadius1 = self.compute("toPolarCoord", aEnv['COORDS'][0][0], aEnv['COORDS'][0][1])[0]
                aULCCoord.X = aEnv['COORDS'][0][0].X - nRadius1
                aULCCoord.Y = aEnv['COORDS'][0][0].Y - nRadius1
                aSize.Width = aSize.Height = 2 * nRadius1
                fAngle1 = float(0)
            else:
                aULCCoord, aSize, fAngle1 = self.getULCAndAngleOfEllipse(aEnv['COORDS'][0][:-2])
                fAngle2 = self.compute("PointOnEllipse", fAngle2, None, aEnv['COORDS'][0][0], aSize, fAngle1)[1]
                fAngle3 = self.compute("PointOnEllipse", fAngle3, None, aEnv['COORDS'][0][0], aSize, fAngle1)[1]
                aSize.Width, aSize.Height = 2 * aSize.Width, 2 * aSize.Height
            aEnv['SHAPE'].CircleKind = aEnv['CIRCLEKIND']
            aEnv['SHAPE'].CircleStartAngle = long(fAngle2 * 18000 / math.pi)
            aEnv['SHAPE'].CircleEndAngle = long(fAngle3 * 18000 / math.pi)
            aEnv['SHAPE'].RotateAngle = long(fAngle1 * 18000 / math.pi)
        if bPosSizeFlag:
            aEnv['SHAPE'].setPosition(aULCCoord)
            aEnv['SHAPE'].setSize(aSize)
        aEnv['SHAPE'].setPropertyValue("SizeProtect", True)
        aEnv['SHAPE'].setPropertyValue("MoveProtect", True)
        aEnv['SHAPE'].setName("new")
        aNamedValues[0].Value = tuple(aEnv.items())
        return aNamedValues
    # ========================================
    def getULCAndAngleOfEllipse(self, aCoords):
        aPoint = uno.createUnoStruct("com.sun.star.awt.Point")
        aSize = uno.createUnoStruct("com.sun.star.awt.Size")
        aSize.Width, fAngle1 = self.compute("toPolarCoord", aCoords[0], aCoords[1])
        aPoint.X, aPoint.Y, aSize.Height = self.compute("Dist2Line", *aCoords)
        aPoint.X = abs(aPoint.X) % aSize.Width
        if abs(aPoint.Y):
            aSize.Height = long(abs(aPoint.Y) / math.sqrt(1E0 - (float(aPoint.X) / aSize.Width) ** 2)) 
        aPoint.X = aCoords[0].X - aSize.Width * math.cos(fAngle1) - aSize.Height * math.sin(fAngle1)
        aPoint.Y = aCoords[0].Y + aSize.Width * math.sin(fAngle1) - aSize.Height * math.cos(fAngle1)
        return aPoint, aSize, fAngle1
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(EntityPosSize,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.EntityPosSize", # implemenation name
                                         ("org.openoffice.comp.pyuno.EntityPosSize",),)    # list of implemented services
