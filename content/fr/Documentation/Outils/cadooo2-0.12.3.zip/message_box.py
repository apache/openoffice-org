# 	$Id: message_box.py,v 1.1 2006-07-16 10:02:13 gerard Exp $	
# -*- coding: latin-1 -*-
## ********************************************************************************
## message_box ven f�v 11 15:07:47 CET 2005
## Copyright (C) 2004 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************

try:
    import uno, unohelper
except ImportError:
    print "import impossible de uno et unohelper"

try:
    from com.sun.star.task import XJob
except ImportError, e:
    print e
    
try:
    from com.sun.star.awt import XActionListener
except ImportError:
    print "import impossible de XActionListener"

class MessageBox(unohelper.Base, XJob, XActionListener):
    """Boite de dialogue contenant un message"""
    def __init__(self, aContext):
        """MessageBox initialization"""
	self.ctx = aContext
        desktop = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.frame.Desktop",self.ctx)
        aModel = desktop.getCurrentComponent()
        self.aController = aModel.getCurrentController()
    # ******************************
    def execute(self, aNamedValues):
	"""Display and management of the message box
        Affichage et gestion de la boite de message"""
        aMsgL10n = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
        aArgs = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aArgs[0].Name = "Translation"
        aArgs[0].Value = ("m0", "m1")
        aArgs = aMsgL10n.execute(aArgs)
        aBox = uno.createUnoStruct("com.sun.star.awt.Rectangle")
        aBox.Width, aBox.Height = 130, 70
        aBox.X = (self.aController.Frame.ComponentWindow.PosSize.X + (self.aController.Frame.ComponentWindow.PosSize.Width - aBox.Width) / 2) / 25e-1
        aBox.Y = (self.aController.Frame.ComponentWindow.PosSize.Y + (self.aController.Frame.ComponentWindow.PosSize.Height - aBox.Height) / 2) / 25e-1
	# create the dialog model and set the properties
	MessageBoxDialogModel = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.awt.UnoControlDialogModel", self.ctx)
	# ---------------------------------------------------------
	MessageBoxDialogModel.setPropertyValue("PositionX", aBox.X)
	MessageBoxDialogModel.setPropertyValue("PositionY", aBox.Y)
	MessageBoxDialogModel.setPropertyValue("Width", aBox.Width)
	MessageBoxDialogModel.setPropertyValue("Height", aBox.Height)
	MessageBoxDialogModel.setPropertyValue("Title", aArgs[0].Value[0])
	# create the button model and set the properties
	MessageBoxButtonModel = MessageBoxDialogModel.createInstance( "com.sun.star.awt.UnoControlButtonModel" )
	MessageBoxButtonModel.setPropertyValue("PositionX", 50)
	MessageBoxButtonModel.setPropertyValue("PositionY", 50)
	MessageBoxButtonModel.setPropertyValue("Width", 30)
	MessageBoxButtonModel.setPropertyValue("Height", 15)
	MessageBoxButtonModel.setPropertyValue("Name", "Button1")
	MessageBoxButtonModel.setPropertyValue("TabIndex", 0)
	MessageBoxButtonModel.setPropertyValue("Label", aArgs[0].Value[1])
	MessageBoxButtonModel.setPropertyValue("DefaultButton", True)
	# create the label model and set the properties
	MessageBoxLabelModel = MessageBoxDialogModel.createInstance( "com.sun.star.awt.UnoControlFixedTextModel" )
	MessageBoxLabelModel.setPropertyValue("PositionX", 10)
	MessageBoxLabelModel.setPropertyValue("PositionY", 10)
	MessageBoxLabelModel.setPropertyValue("Width", 110)
	MessageBoxLabelModel.setPropertyValue("Height", 30)
	MessageBoxLabelModel.setPropertyValue("Name", "Label1")
	MessageBoxLabelModel.setPropertyValue("TabIndex", 1)
	MessageBoxLabelModel.setPropertyValue("Label", aNamedValues[0].Value[0])
	MessageBoxLabelModel.setPropertyValue("MultiLine", True)
	# insert the control models into the dialog model
	MessageBoxDialogModel.insertByName("Button1", MessageBoxButtonModel)
	MessageBoxDialogModel.insertByName("Label1", MessageBoxLabelModel)
	# create the dialog control and set the model 
	self.MessageBoxDialogControl = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.awt.UnoControlDialog", self.ctx)
	self.MessageBoxDialogControl.setModel(MessageBoxDialogModel)
	# add an action listener to the button1 control 
	MessageBoxOkButton = self.MessageBoxDialogControl.getControl("Button1")
        MessageBoxOkButton.setActionCommand("Button1")
        # ButtonActionListener.setPropertyValue("DialogControl", MessageBoxDialogControl)
	MessageBoxOkButton.addActionListener(self)
	# create a peer 
	MessageBoxToolkit = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.awt.Toolkit", self.ctx)
	self.MessageBoxDialogControl.setVisible(0)
	self.MessageBoxDialogControl.createPeer(MessageBoxToolkit, MessageBoxToolkit.getDesktopWindow())
	# execute the dialog 
	self.MessageBoxDialogControl.execute()
	# remove an action listener to the button1 control 
	MessageBoxOkButton.removeActionListener(self)
        return None
	## XEventListener 
    def disposing(self, eventObject):
        self.MessageBoxDialogControl = None
	## XActionListener 
    def actionPerformed(self, actionEvent):
        self.MessageBoxDialogControl.endExecute()

# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(MessageBox,                                        # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.MessageBox", # implemenation name
                                         ("org.openoffice.comp.pyuno.MessageBox",),)    # list of implemented services
