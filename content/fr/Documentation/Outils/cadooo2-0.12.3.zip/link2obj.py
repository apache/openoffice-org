# 	$Id: link2obj.py,v 1.1 2006-07-16 10:02:13 gerard Exp $
# -*- coding: latin-1 -*-
## ********************************************************************************
## link2obj jeu jan 26 20:18:45 CET 2005
## Copyright (C) 2004 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    import math, traceback
    from com.sun.star.task import XJob
except ImportError:
    print "probleme d'import"
# ======================================================================================
# Gerer les liens aux objets lors des traces des entit�
# Handling links to object while drawing entities
# ======================================================================================
class Link2Obj(unohelper.Base, XJob):
    """Gere les liens aux objets
    Handles links to objects"""
    def __init__(self, ctx):
        smgr = ctx.ServiceManager
        # usefull coordinates
        self.aMagneticCoord = uno.createUnoStruct("com.sun.star.awt.Point")
        self.aCompute = smgr.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", ctx)
        self.aEntitieSpot = smgr.createInstanceWithContext("org.openoffice.comp.pyuno.EntitieSpot", ctx)
        self.aMagneticPoleShape = smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MagneticPoleShape", ctx)
    ## =========================================
    ## wrapper for the compute functions
    ## =========================================
    def compute(self, sMethod, *aArgs):
        aNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aNamedValues[i].Name = "Function"
                aNamedValues[i].Value = sMethod
            elif i < n-1:
                aNamedValues[i].Name = "Param%d" % i
                aNamedValues[i].Value = aArgs[i-1]
            else:
                aNamedValues[i].Name = "Result"
        aNamedValues = list(self.aCompute.execute(tuple(aNamedValues),))
        return aNamedValues[n-1].Value
    # ========================================
    # aNamedValues as tuple of NamedValue
    #   Name         Value
    # L2OSTATE    tuple of 5 integers (0 or 1)
    # VALIDLIST   integer (0 or 1)
    # ENTITYPE    string shape type
    # VALIDORIGIN integer (0 or 1)
    # ORIGINCOORD tuple of 2 integers
    # VALIDL2O    integer (0 or 1)
    # L2OCOORD    tuple of 2 integers
    # MOUSEEVENT  struct MouseEvent
    # ========================================
    def execute(self, aNamedValues):
        aEnv = dict(list(self.aEntitieSpot.execute(aNamedValues)[0].Value))
        if aEnv['SPOTLIST'] is None or list(aEnv['L2OSTATE']).count(0) == 5:
            aEnv['MAGNETKIND'] = "0"
            aEnv['VALIDL2O'] = 0
            aNamedValues[0].Value = tuple(aEnv.items())
            aEnv = dict(list(self.aMagneticPoleShape.execute(aNamedValues)[0].Value))
            aNamedValues[0].Value = tuple(aEnv.items())
            return aNamedValues
        ## which point is the closest
        aMouseCoord = uno.createUnoStruct("com.sun.star.awt.Point")
        aMouseCoord.X, aMouseCoord.Y = self.compute('transformMouseCoord', tuple(aEnv.items()))
        self.nElectedDist = int(math.sqrt(aMouseCoord.X ** 2 + aMouseCoord.Y ** 2))
        aCoord = uno.createUnoStruct("com.sun.star.awt.Point")
        aSegments = aEnv['SPOTLIST']
        ## Magnetic ends
        if aEnv['L2OSTATE'][0]:
            for i in range(len(aSegments)):
                # --- a type line ---
                if aSegments[i][0] in ("LineShape",):
                    if self.testCoord((aSegments[i][1].X, aSegments[i][1].Y, aSegments[i][2].X, aSegments[i][2].Y), aMouseCoord):
                        aEnv['MAGNETKIND'] = "e"
                if aSegments[i][0] in ("ArcCircleShape", "ArcEllipseShape"):
                    fCosW = aSegments[i][2].Width * math.cos(-aSegments[i][3])
                    fSinW = aSegments[i][2].Width * math.sin(-aSegments[i][3])
                    fCosH = aSegments[i][2].Height * math.cos(-aSegments[i][3])
                    fSinH = aSegments[i][2].Height * math.sin(-aSegments[i][3])
                    fAngle1 = -aSegments[i][4]
                    fAngle2 = -aSegments[i][5]
                    aCoord.X = aSegments[i][1].X + fCosW * math.cos(fAngle1) - fSinH * math.sin(fAngle1)
                    aCoord.Y = aSegments[i][1].Y + fSinW * math.cos(fAngle1) + fCosH * math.sin(fAngle1)
                    if self.testCoord((aCoord.X, aCoord.Y), aMouseCoord):
                        aEnv['MAGNETKIND'] = "e"
                    aCoord.X = aSegments[i][1].X + fCosW * math.cos(fAngle2) - fSinH * math.sin(fAngle2)
                    aCoord.Y = aSegments[i][1].Y + fSinW * math.cos(fAngle2) + fCosH * math.sin(fAngle2)
                    if self.testCoord((aCoord.X, aCoord.Y), aMouseCoord):
                        aEnv['MAGNETKIND'] = "e"
        ## Magnetic intersection
        if aEnv['L2OSTATE'][1]:
            for i in range(len(aSegments)-1):
                for j in range(i+1, len(aSegments)):
                    ## intersection line - line
                    if aSegments[i][0] in ("LineShape",) and aSegments[j][0] in ("LineShape",):
                        fAngle1 = self.compute('toPolarCoord', aSegments[i][1], aSegments[i][2])[1]
                        fAngle2 = self.compute('toPolarCoord', aSegments[j][1], aSegments[j][2])[1]
                        nDistance = self.compute('InterLines', aSegments[i][1], fAngle1, aSegments[j][1], fAngle2)
                        if not nDistance is None:
                            if self.testCoord(tuple(nDistance[2:]), aMouseCoord):
                                aEnv['MAGNETKIND'] = "i"
                    ## intersection line - ellipse
                    elif aSegments[i][0] in ("LineShape",) and not aSegments[j][0] in ("LineShape",):
                        fAngle1 = self.compute('toPolarCoord', aSegments[i][1], aSegments[i][2])[1]
                        nDistance = self.compute('InterLineEllipse',aSegments[i][1], fAngle1, *aSegments[j][1:4])
                        if len(nDistance) > 0:
                            if self.testCoord(tuple(nDistance[2:]), aMouseCoord):
                                aEnv['MAGNETKIND'] = "i"
                    ## intersection ellipse - line
                    elif aSegments[j][0] in ("LineShape",) and not aSegments[i][0] in ("LineShape",):
                        fAngle1 = self.compute('toPolarCoord', aSegments[j][1], aSegments[j][2])[1]
                        nDistance = self.compute('InterLineEllipse',aSegments[j][1], fAngle1, *aSegments[i][1:4])
                        if len(nDistance) > 0:
                            if self.testCoord(tuple(nDistance[2:]), aMouseCoord):
                                aEnv['MAGNETKIND'] = "i"
                        # intersection ellipse - ellipse
                    elif not aSegments[i][0] in ("LineShape",) and not aSegments[j][0] in ("LineShape",):
                        nDistance = self.compute('InterEllipses', *(aSegments[i][1:4]+ aSegments[j][1:4]))
                        if len(nDistance) > 0:
                            if self.testCoord(tuple(nDistance), aMouseCoord):
                                aEnv['MAGNETKIND'] = "i"
        # Magnetic middle
        if aEnv['L2OSTATE'][2]:
            for i in range(len(aSegments)):
                if aSegments[i][0] in ("LineShape",):
                    if self.testCoord(((aSegments[i][1].X + aSegments[i][2].X)/2, (aSegments[i][1].Y + aSegments[i][2].Y)/2), aMouseCoord):
                        aEnv['MAGNETKIND'] = "m"
                elif aSegments[i][0] in ("CircleShape", "EllipseShape", "ArcCircleShape", "ArcEllipseShape"):
                    if self.testCoord((aSegments[i][1].X, aSegments[i][1].Y), aMouseCoord):
                        aEnv['MAGNETKIND'] = "m"
                    if aSegments[i][0] in ("ArcCircleShape", "ArcEllipseShape"):
                        fCosW = aSegments[i][2].Width * math.cos(-aSegments[i][3])
                        fSinW = aSegments[i][2].Width * math.sin(-aSegments[i][3])
                        fCosH = aSegments[i][2].Height * math.cos(-aSegments[i][3])
                        fSinH = aSegments[i][2].Height * math.sin(-aSegments[i][3])
                        fAngle1 = -(aSegments[i][4] + aSegments[i][5]) / 2
                        if abs(aSegments[i][5]) < abs(aSegments[i][4]):
                            fAngle1 = math.pi + fAngle1
                        aCoord.X = aSegments[i][1].X + fCosW * math.cos(fAngle1) - fSinH * math.sin(fAngle1)
                        aCoord.Y = aSegments[i][1].Y + fSinW * math.cos(fAngle1) + fCosH * math.sin(fAngle1)
                        if self.testCoord((aCoord.X, aCoord.Y), aMouseCoord):
                            aEnv['MAGNETKIND'] = "m"
        # Magnetic perpendicular
        if aEnv['L2OSTATE'][3] and aEnv['VALIDORIGIN'] and aEnv['ENTITYPE'] == "LINE":
            for i in range(len(aSegments)):
                if aSegments[i][0] in ("LineShape",):
                    fAngle1 = self.compute('toPolarCoord', aSegments[i][1], aSegments[i][2])[1]
                    nDistance = self.compute('TangentLineCircle', aSegments[i][1], fAngle1, aEnv['ORIGINCOORD'])
                    if len(nDistance) > 0:
                        if self.testCoord(tuple(nDistance), aMouseCoord):
                            aEnv['MAGNETKIND'] = "p"
        # Magnetic tangent
        if aEnv['L2OSTATE'][4] and aEnv['VALIDORIGIN']:
            if aEnv['ENTITYPE'] in ("CIRCLE", "ARC"):
                for i in range(len(aSegments)):
                    if aSegments[i][0] in ("LineShape",):
                        fAngle1 = self.compute('toPolarCoord', aSegments[i][1], aSegments[i][2])[1]
                        nDistance = self.compute('TangentLineCircle', aSegments[i][1], fAngle1, aEnv['ORIGINCOORD'])
                        if len(nDistance) > 0:
                            if self.testCoord(tuple(nDistance), aMouseCoord):
                                aEnv['MAGNETKIND'] = "t"
                    elif aSegments[i][0] in ("EllipseShape", "ArcEllipseShape", "CircleShape", "ArcCircleShape"):
                        nDistance = self.compute('TangentEllipseCircle', \
                                                 aSegments[i][1], \
                                                 aSegments[i][2], \
                                                 aSegments[i][3], \
                                                 aEnv['ORIGINCOORD'])
                        if len(nDistance) > 0:
                            if self.testCoord(tuple(nDistance), aMouseCoord):
                                aEnv['MAGNETKIND'] = "t"
            if aEnv['ENTITYPE'] in ("LINE",):
                for i in range(len(aSegments)):
                    if aSegments[i][0] in ("EllipseShape", "ArcEllipseShape", "CircleShape", "ArcCircleShape"):
                        nDistance = self.compute('TangentEllipseLine', \
                                                 aSegments[i][1], \
                                                 aSegments[i][2], \
                                                 aSegments[i][3], \
                                                 aEnv['ORIGINCOORD'])
                        if len(nDistance) > 0:
                            if self.testCoord(nDistance, aMouseCoord):
                                aEnv['MAGNETKIND'] = "t"
        if self.nElectedDist <= aEnv['MAGNETSIZE']*aEnv['DEVICEXSCALE']:
            aEnv['L2OCOORD'].X, aEnv['L2OCOORD'].Y = (self.aMagneticCoord.X, self.aMagneticCoord.Y)
            aEnv['VALIDL2O'] = 1
        else:
            aEnv['VALIDL2O'] = 0
            aEnv['MAGNETKIND'] = "0"
        aNamedValues[0].Value = tuple(aEnv.items())
        aEnv = dict(list(self.aMagneticPoleShape.execute(aNamedValues)[0].Value))
        aNamedValues[0].Value = tuple(aEnv.items())
        return aNamedValues
    # test and set coordinates of the closest point
    def testCoord(self, nListCoord, aMouseCoord):
        bFlg = False
        for nX, nY in [(nListCoord[i], nListCoord[i+1]) for i in range(0,len(nListCoord),2)]:
            nCandidateDist = long(math.sqrt((nX-aMouseCoord.X)**2+(nY-aMouseCoord.Y)**2))
            if  nCandidateDist <= self.nElectedDist:
                self.nElectedDist = nCandidateDist
                self.aMagneticCoord.X, self.aMagneticCoord.Y = nX, nY
                bFlg = True
        return bFlg
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(Link2Obj,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.Link2Obj", # implemenation name
                                         ("org.openoffice.comp.pyuno.Link2Obj",),)    # list of implemented services
