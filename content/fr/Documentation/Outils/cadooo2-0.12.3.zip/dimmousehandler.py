#	$Id$
# -*- coding: latin-1 -*-
## ********************************************************************************
## 
## Copyright (C) 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    import math, traceback
    from com.sun.star.task import XJob
except ImportError:
    print "probleme d'import"
# ===================================================
# Gerer les saisies de points et validation d'entites
# Handle points inputs and entities validation
# ===================================================
class DimMouseHandler(unohelper.Base, XJob):
    """Gere les saisies de points et validation d'entite
    Handles points inputs and entities validation"""
    def __init__(self, ctx):
        self.ctx = ctx
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # **********************************
    # Handles mouse clicks
    # MOUSEEVENT  struct MouseEvent
    # VALIDL2O    integer (0 or 1)
    # L2OCOORD    tuple of 2 integers
    # CANCELJOB   integer (0 or 1)
    # STEP
    # COORDS
    # REPEATMODE
    # SHAPE
    # **********************************
    def execute(self, aArgs):
        self.aEnv = dict(list(aArgs[0].Value))
        # +++++++++++++++++++++++++++++++++++++
        if self.aEnv['MOUSEEVENT'].Buttons > 1: # don't handle mouse buttons but left
            return aArgs
        self.removeTempShapes(True, False)
        # ++++++++++++++++++++++++++++++++
        if not self.aEnv['DIMLIST'][0] is None:
            aSpotID = self.aEnv['DIMLIST'][0][0] + (self.aEnv['DIMLIST'][0][-1],)
        else:
            aSpotID = ()
        # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        if self.aEnv['MOUSEEVENT'].ClickCount == 2 or self.aEnv['DIMLIST'][1] or self.aEnv['SPOTTEDID'] is None or self.aEnv['SPOTTEDID'] == aSpotID:
            # print "dimension finished"
            self.aEnv['DIMCOORDS'] = None
            self.aEnv['DIMTYPE'] = "---"
            self.aEnv['DIMLIST'] = (None, None)
            self.aEnv['DIMVISIBLE'] = False
            for t in ('LINEAR', 'ANGULAR', 'RADIAL', 'DIAMETRAL'):
                self.aEnv['%sDIMSHAPE' % t] = None
            # ----------------------------
            if self.aEnv['REPEATMODE']: # repeat mode on ?
                self.aEnv['VALIDORIGIN'] = False
                self.aEnv['VALIDLIST'] = False
                self.aEnv['GROUPSHAPE'] = self.aEnv['CONTROLLER'].getCurrentPage()
            else:
                self.aEnv['STOPJOB'] = True
            aArgs[0].Value = tuple(self.aEnv.items())
            return aArgs
        aDimList = list(self.aEnv['DIMLIST'])
        if aDimList[0] is None:
            aDimList[0] = self.aEnv['SPOTTEDSHAPE']
            # print "%sdimshape stored in 1st place" % self.aEnv['DIMTYPE']
        else:
            aDimList[1] = self.aEnv['SPOTTEDSHAPE']
            # print "%sdimshape stored in 2nd place" % self.aEnv['DIMTYPE']
        self.aEnv['SPOTTEDID'] = None
        self.aEnv['DIMLIST'] = tuple(aDimList)
        aArgs[0].Value = tuple(self.aEnv.items())
        return aArgs
    # *****************************************************
    # remove temporary shapes
    # *****************************************************
    def removeTempShapes(self, bShape = True, bDim = True):
        if self.aEnv['SHAPE'] and bShape:
            aGroupShape = self.aEnv['CONTROLLER'].getCurrentPage()
            for i in self.aEnv['SPOTTEDID'][:-2]:
                aGroupShape = aGroupShape.getByIndex(i)
            aGroupShape.remove(self.aEnv['SHAPE'])
            self.aEnv['SHAPE'] = None
            self.aEnv['STEP'] = 0
            self.aEnv['COORDS'] = ((),)
        if self.aEnv['DIMTYPE'] in ('LINEAR', 'ANGULAR', 'RADIAL', 'DIAMETRAL') and bDim:
            aShape = self.aEnv['%sDIMSHAPE' % self.aEnv['DIMTYPE']]
            if self.aEnv['DIMTYPE'] in ('ANGULAR', 'RADIAL', 'DIAMETRAL'):
                for i in range(aShape.getCount()):
                    aShape.remove(aShape.getByIndex(i))
            self.aEnv['CONTROLLER'].getCurrentPage().remove(aShape)
            self.aEnv['DIMTYPE'] = "----"
            self.aEnv['DIMCOORDS'] = None
            self.aEnv['DIMVISIBLE'] = False
        return
    # **********************************
    # inspection wrapper
    # **********************************
    def inspectObject(self, aObject):
        aDiveIn = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.DiveIn", self.ctx)
        aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aParms[0].Name = "inspect"
        aParms[0].Value = aObject
        aParms = aDiveIn.execute(aParms)
        return
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(DimMouseHandler,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.DimMouseHandler", # implemenation name
                                         ("org.openoffice.comp.pyuno.DimMouseHandler",),)    # list of implemented services
