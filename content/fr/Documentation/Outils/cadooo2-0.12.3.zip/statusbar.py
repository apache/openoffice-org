# 	$Id: statusbar.py,v 1.2 2007/03/05 15:33:37 gerard Exp $	
## ********************************************************************************
## Copyright (C) 2005, 2006, 2007 Gerard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import traceback, operator
    import uno, unohelper
    from com.sun.star.task import XJob
    from com.sun.star.awt.WindowClass import TOP, SIMPLE, CONTAINER
except ImportError, e:
    print e
#=============================================================
# a class to show various informations
# une classe pour afficher diverses informations
#=============================================================
class CadoooStatusBar(unohelper.Base, XJob):
    def __init__(self, aContext):
        self.ctx = aContext
        self.smgr = self.ctx.ServiceManager
    # ******************************
    def execute(self, aNamedValues):
        # named values structure to dictionary conversion
        aEnv = dict(list(aNamedValues[0].Value))
        # translation component
        aMsgL10n = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
        aArgs = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aArgs[0].Name = "Translation"
        aArgs[0].Value = tuple(["st%d" % i for i in range(12)])
        aArgs = aMsgL10n.execute(aArgs)
        # working in the component window
        aPosSize = aEnv['CONTROLLER'].Frame.ComponentWindow.PosSize
        aRect = uno.createUnoStruct("com.sun.star.awt.Rectangle")
        aRect.X, aRect.Y, aRect.Width, aRect.Height = aPosSize.X, aPosSize.Y+aPosSize.Height-45, aPosSize.Width, 45
        aEnv['CONTROLLER'].Frame.ComponentWindow.setPosSize(aPosSize.X, aPosSize.Y, aPosSize.Width, aPosSize.Height-45, 15)
        aEnv['WINPOSSIZE'] = uno.createUnoStruct("com.sun.star.awt.Rectangle")
        aEnv['WINPOSSIZE'].X, aEnv['WINPOSSIZE'].Y = aPosSize.X, aPosSize.Y
        aEnv['WINPOSSIZE'].Width, aEnv['WINPOSSIZE'].Height = aPosSize.Width, aPosSize.Height - 45
        # create a new window dor the status bar
        aWindowDescriptor = uno.createUnoStruct("com.sun.star.awt.WindowDescriptor")
        aWindowDescriptor.Type = TOP
        aWindowDescriptor.WindowServiceName = "dockingwindow"
        aWindowDescriptor.Parent = aEnv['CONTROLLER'].Frame.ContainerWindow
        aWindowDescriptor.ParentIndex = -1
        aWindowDescriptor.Bounds = aRect
        aWindowDescriptor.WindowAttributes = 0
        aWinPeer = aEnv['CONTROLLER'].Frame.ContainerWindow.Toolkit.createWindow(aWindowDescriptor)
        aWinPeer.setBackground(0xf0f0f0)
        aWinPeer.setPosSize(aRect.X, aRect.Y, aRect.Width, aRect.Height, 15)
        aWinPeer.setVisible(True)
        aDevice = aWinPeer.Toolkit.createScreenCompatibleDevice(aRect.Width, aRect.Height)
        aFont = aDevice.getFont(aDevice.getFontDescriptors()[1])
        # create the label model and set the properties
        aLabel = self.ctx.ServiceManager.createInstance( "com.sun.star.awt.UnoControlFixedTextModel" )
        aLabel.Label = "No comment"
        aLabel.Border = 1
        aLabel.BackgroundColor = 0xf0f0f0
        aLabelControl = self.ctx.ServiceManager.createInstance("com.sun.star.awt.UnoControlFixedText")
        aLabelControl.setModel(aLabel)
        aLabel.FontHeight = 7
        aLabelControl.createPeer(aWinPeer.Toolkit, aWinPeer)
        aPeer = aLabelControl.getPeer()
        aPeer.setPosSize(0, 0, aRect.Width, aLabelControl.MinimumSize.Height, 15)
        aPeer.setVisible(True)
        aLabelControl.setDesignMode(False)
        # create the check box
        aCheckBoxControl = []
        aCheckBox = []
        aWidth = 0
        for i in range(7):
            # create check box model
            aCheckBox.append(self.ctx.ServiceManager.createInstance("com.sun.star.awt.UnoControlCheckBoxModel"))
            aCheckBox[-1].Label = aArgs[0].Value[i]
            # create check box controller
            aCheckBoxControl.append(self.ctx.ServiceManager.createInstance("com.sun.star.awt.UnoControlCheckBox"))
            aCheckBoxControl[-1].setModel(aCheckBox[-1])
            aCheckBox[-1].FontHeight = 6
            aCheckBoxControl[-1].createPeer(aWinPeer.Toolkit, aWinPeer)
            aPeer = aCheckBoxControl[-1].getPeer()
            aPeer.setPosSize(aWidth + 5, 30, aCheckBoxControl[-1].MinimumSize.Width, aCheckBoxControl[-1].MinimumSize.Height, 15)
            aPeer.setVisible(True)
            aPeer.setBackground(0xf0f0f0)
            aWidth = aWidth + aCheckBoxControl[-1].MinimumSize.Width
            aCheckBoxControl[-1].setDesignMode(False)
            if i < 5:
                aCheckBoxControl[-1].setState(aEnv['L2OSTATE'][i])
            elif i == 5:
                aCheckBoxControl[-1].setState(aEnv['ORTHOMODE'])
            else:
                aCheckBoxControl[-1].setState(False)
        # create a group box for magnet type
        aWidth = reduce(operator.add, [aCheckBoxControl[i].MinimumSize.Width for i in range(5)])
        aGroupBox = self.ctx.ServiceManager.createInstance( "com.sun.star.awt.UnoControlGroupBoxModel" )
        aGroupBox.Label = "type d'aimantation"
        aGroupBox.FontHeight = 6
        aGroupBoxControl = self.ctx.ServiceManager.createInstance( "com.sun.star.awt.UnoControlGroupBox" )
        aGroupBoxControl.setModel(aGroupBox)
        aGroupBoxControl.createPeer(aWinPeer.Toolkit, aWinPeer)
        aPeer = aGroupBoxControl.getPeer()
        aPeer.setPosSize(0, aLabelControl.MinimumSize.Height, aWidth+5, 45-aLabelControl.MinimumSize.Height, 15)
        aPeer.setVisible(True)
        aGroupBoxControl.setDesignMode(False)
        aEnv['STATUSBARWINDOW'] = aWinPeer
        aEnv['STATUSBARCONTROL'] = tuple(aCheckBoxControl + [aLabelControl,])
        aNamedValues[0].Value = tuple(aEnv.items())
        return aNamedValues
    # **********************************
    # inspection wrapper
    # **********************************
    def inspectObject(self, aObject):
        aDiveIn = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DiveIn", self.ctx)
        aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aParms[0].Name = "inspect"
        aParms[0].Value = aObject
        aEnv = aDiveIn.execute(aParms)
        return

# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(CadoooStatusBar,                                        # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.CadoooStatusBar", # implemenation name
                                         ("org.openoffice.comp.pyuno.CadoooStatusBar",),)    # list of implemented services
