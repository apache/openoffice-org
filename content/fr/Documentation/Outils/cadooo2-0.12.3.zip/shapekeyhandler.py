# 	$Id: shapekeyhandler.py,v 1.1 2006-07-16 10:02:14 gerard Exp $	
## ********************************************************************************
## keyhandler dim jan  2 18:15:58 CET 2005
## Copyright (C) 2004 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import unohelper, uno
    import math, traceback, operator
    from com.sun.star.task import XJob
    from com.sun.star.awt.KeyModifier import SHIFT
except ImportError:
    print "probleme d'import"
#===============================
# gestion des evenements clavier
# handling keyboard events
#===============================
class ShapeKeyHandler(unohelper.Base, XJob):
    """gestion des evenements clavier
    handling keyboard events"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
        # Datum needed by coordinates input form
        self.aCoordData = {}
        self.aCoordData["TITLE"]  = "No Title"
        self.aCoordData["FLAG"] = 0
        self.aCoordData["COMMENT"] = "No comment"
        self.aCoordData["X"] = 0
        self.aCoordData["XUNIT"] = "m"
        self.aCoordData["Y"] = 0
        self.aCoordData["YUNIT"] = "m"
        self.aCoordData["RETURN"] = False
        # Struct needed to pass arguments throught UNO
        self.aNamedValues = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        self.aNamedValues[0].Name = "CONTEXT"
        self.aEntityPosSize = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.EntityPosSize", self.ctx)
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # ==================================
    # actions clavier - keyboard actions
    # aNamedValues as tuple of NamedValue
    #   Name         Value
    # KEYCODE     integer
    # L2OSTATE    tuple of 5 integers (0 or 1)
    # DRAWSCALE
    # COORDS
    # STEP
    # VALIDORIGIN
    # DRAWSCALE
    # ORIGINCOORD
    # BORDERCOORD
    # CANCELJOB
    # ORTHOMODE
    # SHAPE
    # ==================================
    def execute(self, aArgs):
        aEnv = dict(list(aArgs[0].Value))
        # ----------------------------------------------------------------------------------------------------
        if [516, 520, 524, 527, 531].count(aEnv['KEYEVENT'].KeyCode) and not aEnv['KEYEVENT'].Modifiers:
            # e,   i,   m,   p,   t => link 2 entities
            i = [516, 520, 524, 527, 531].index(aEnv['KEYEVENT'].KeyCode)
            bKHState = list(aEnv['L2OSTATE'])
            bKHState[i] = not bKHState[i]
            aEnv['L2OSTATE'] = tuple(bKHState)
            aStatusBarCheckBox = aEnv['STATUSBARCONTROL'][i]
            if aStatusBarCheckBox.getState() != aEnv['L2OSTATE'][i]:
                aStatusBarCheckBox.setState(aEnv['L2OSTATE'][i])
        # --------------------------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (514, 515, 522, 523, 529) and not aEnv['KEYEVENT'].Modifiers:
            # .................................c, ..d, ..k, ..l, ..r
            aMsgL10n = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
            aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
            aParms[0].Name = "Translation"
            # ---------------------------------------------------------------------------
            aCoords = [list(c) for c in aEnv['COORDS']]
            if aEnv['KEYEVENT'].KeyCode in (515, 523, 529) and aEnv['VALIDORIGIN']:
                #                                  l,   d or r => length, diameter or radius requested
                aParms[0].Value = ("k0", "k1")
                aParms = aMsgL10n.execute(aParms)
                aCoordInput = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DataInputBox", self.ctx)
                self.aCoordData["TITLE"]  = aParms[0].Value[0]
                self.aCoordData["FLAG"] = 0
                self.aCoordData["COMMENT"] = aParms[0].Value[1]
                self.aCoordData["RETURN"] = False
                self.aCoordData["X"] = float(aEnv['ORIGINCOORD'].X - aEnv['BORDERCOORD'][0]) / (100000 * aEnv['DRAWSCALE'])
                self.aNamedValues[0].Value = tuple(self.aCoordData.items())
                self.aCoordData = dict(list(aCoordInput.execute(self.aNamedValues)[0].Value))
                # ---------------------------
                if self.aCoordData["RETURN"]:
                    self.aCoordData['X'] = long(self.aCoordData['X']*aEnv['DRAWSCALE'])
                    # ------------------------------------
                    if aEnv["KEYEVENT"].KeyCode == 515:
                        self.aCoordData['X'] = long(self.aCoordData['X']/2)
                    nDist = self.compute('toPolarCoord', aEnv['ORIGINCOORD'], aCoords[-1][-1])[0]
                    # ------
                    if nDist:
                        fK = float(self.aCoordData['X']) / nDist
                        aCoords[-1][-1].X = aEnv['ORIGINCOORD'].X + long(fK * (aCoords[-1][-1].X - aEnv['ORIGINCOORD'].X))
                        aCoords[-1][-1].Y = aEnv['ORIGINCOORD'].Y + long(fK * (aCoords[-1][-1].Y - aEnv['ORIGINCOORD'].Y))
            # -----------------------------------------
            elif aEnv['KEYEVENT'].KeyCode in (514,):
                #                                  c => rectangular coordinates requested
                aParms[0].Value = ("k2", "k3")
                aParms = aMsgL10n.execute(aParms)
                aCoordInput = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DataInputBox", self.ctx)
                self.aCoordData["TITLE"]  = aParms[0].Value[0]
                self.aCoordData["FLAG"] = 1
                self.aCoordData["COMMENT"] = aParms[0].Value[1]
                self.aCoordData["RETURN"] = False
                self.aCoordData["X"] = float(aEnv['ORIGINCOORD'].X - aEnv['BORDERCOORD'][0]) / (100000 * aEnv['DRAWSCALE'])
                self.aCoordData["Y"] = float(aEnv['ORIGINCOORD'].Y - aEnv['BORDERCOORD'][1]) / (100000 * aEnv['DRAWSCALE'])
                self.aNamedValues[0].Value = tuple(self.aCoordData.items())
                self.aCoordData = dict(list(aCoordInput.execute(self.aNamedValues)[0].Value))
                # ---------------------------
                if self.aCoordData["RETURN"]:
                    aCoords[0][-1] = uno.createUnoStruct("com.sun.star.awt.Point")
                    aCoords[0][-1].X = long(self.aCoordData['X']*aEnv['DRAWSCALE'])
                    aCoords[0][-1].Y = long(self.aCoordData['Y']*aEnv['DRAWSCALE'])
                    # -------------------------------
                    if self.aCoordData["FLAG"] & 0x2: # Delta coordinates ?
                        aCoords[0][-1].X = aCoords[0][-1].X + aEnv['ORIGINCOORD'].X
                        aCoords[0][-1].Y = aCoords[0][-1].Y + aEnv['ORIGINCOORD'].Y
                    else:
                        aCoords[0][-1].X = aCoords[0][-1].X + aEnv['BORDERCOORD'][0]
                        aCoords[0][-1].Y = aCoords[0][-1].Y + aEnv['BORDERCOORD'][1]
            # -----------------------------------------
            elif aEnv['KEYEVENT'].KeyCode in (522,):
                #                                  k => polar coordinates requested
                aParms[0].Value = ("k2", "k4")
                aParms = aMsgL10n.execute(aParms)
                aCoordInput = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DataInputBox", self.ctx)
                self.aCoordData["TITLE"]  = aParms[0].Value[0]
                self.aCoordData["FLAG"] = 5
                self.aCoordData["COMMENT"] = aParms[0].Value[1]
                self.aCoordData["RETURN"] = False
                self.aCoordData["X"] = float(aEnv['ORIGINCOORD'].X - aEnv['BORDERCOORD'][0]) / (100000 * aEnv['DRAWSCALE'])
                self.aCoordData["Y"] = float(aEnv['ORIGINCOORD'].Y - aEnv['BORDERCOORD'][1]) / (100000 * aEnv['DRAWSCALE'])
                self.aNamedValues[0].Value = tuple(self.aCoordData.items())
                self.aCoordData = dict(list(aCoordInput.execute(self.aNamedValues)[0].Value))
                # ---------------------------
                if self.aCoordData["RETURN"]:
                    aCoords[0][-1].X = long(self.aCoordData['X']*aEnv['DRAWSCALE'] * math.cos(self.aCoordData["Y"]))
                    aCoords[0][-1].Y = long(self.aCoordData['X']*aEnv['DRAWSCALE'] * math.sin(-self.aCoordData["Y"]))
                    # -------------------------------
                    if self.aCoordData["FLAG"] & 0x2: # delta coordinates ?
                        aCoords[0][-1].X = aCoords[0][-1].X + aEnv['ORIGINCOORD'].X
                        aCoords[0][-1].Y = aCoords[0][-1].Y + aEnv['ORIGINCOORD'].Y
                    else:
                        aCoords[0][-1].X = aCoords[0][-1].X + aEnv['BORDERCOORD'][0]
                        aCoords[0][-1].Y = aCoords[0][-1].Y + aEnv['BORDERCOORD'][1]
            aEnv['COORDS'] = tuple([tuple(c) for c in aCoords])
            # ---------------------
            if aEnv['STEP'] != 0:
                self.aNamedValues[0].Value = tuple(aEnv.items())
                aEnv = dict(list(self.aEntityPosSize.execute(self.aNamedValues)[0].Value))
            aEnv['ORIGINCOORD'].X, aEnv['ORIGINCOORD'].Y = aCoords[0][-1].X, aCoords[0][-1].Y
            aEnv['VALIDORIGIN'] = True
            aEnv['STEP'] = aEnv['STEP'] % aEnv['STEPS'] + 1
            # -------------------------------------
            if aEnv['STEP'] == aEnv['STEPS']:
                aEnv['SHAPE'].setName("")
                aEnv['SHAPE'].LineColor = aEnv['SHAPE'].Style.LineColor
                aEnv['SHAPE'].LineWidth = aEnv['SHAPE'].Style.LineWidth
                # -----------------------
                if aEnv['REPEATMODE']:
                    aEnv['STEP'] = 0
                    aEnv['VALIDORIGIN'] = False
                    aEnv['GROUPSHAPE'] = None
                    aEnv['SHAPE'] = None
                    aEnv['VALIDLIST'] = False
                    aEnv['COORDS'] = ((uno.createUnoStruct("com.sun.star.awt.Point"),),)
                else:
                    aEnv['STOPJOB'] = True
            else:
                aCoords[-1].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                aEnv['COORDS'] = tuple([tuple(c) for c in aCoords])
        # --------------------------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (514, ) and aEnv['KEYEVENT'].Modifiers == SHIFT:
            # .................................c + shift => close polygon
            if reduce(operator.add, [len(c) for c in aEnv['COORDS']]) > 2: # is this trully a polygon ?
                aEnv['COORDS'][-1][-1].X, aEnv['COORDS'][-1][-1].Y = aEnv['COORDS'][0][0].X, aEnv['COORDS'][0][0].Y
            else:
                if aEnv['VALIDL2O']: # valid link to entity ?
                    aEnv['COORDS'][-1][-1].X, aEnv['COORDS'][-1][-1].Y = self.aEnv['L2OCOORD'].X, self.aEnv['L2OCOORD'].Y
            self.aNamedValues[0].Value = tuple(aEnv.items())
            aEnv = dict(list(self.aEntityPosSize.execute(self.aNamedValues)[0].Value))
            aEnv['SHAPE'].LineColor = aEnv['SHAPE'].Style.LineColor
            aEnv['SHAPE'].LineWidth = aEnv['SHAPE'].Style.LineWidth
            aEnv['SHAPE'].setName("")
            # -----------------------
            if aEnv['REPEATMODE']:
                aEnv['STEP'] = 0
                aEnv['VALIDORIGIN'] = False
                aEnv['GROUPSHAPE'] = None
                aEnv['SHAPE'] = None
                aEnv['VALIDLIST'] = False
                aEnv['COORDS'] = ((uno.createUnoStruct("com.sun.star.awt.Point"),),)
            else:
                aEnv['STOPJOB'] = True
        # --------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (1281,) and not aEnv['KEYEVENT'].Modifiers:
            #                                 Esc => kill job
            aEnv['CANCELJOB'] = True
        # -------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (512,) and not aEnv['KEYEVENT'].Modifiers:
            #                                  a => axonometric mode
            aEnv['ORTHOMODE'] = not aEnv['ORTHOMODE']
            aStatusBarCheckBox = aEnv['STATUSBARCONTROL'][5]
            if aStatusBarCheckBox.getState() != aEnv['ORTHOMODE']:
                aStatusBarCheckBox.setState(aEnv['ORTHOMODE'])
        # --------------------------------------------------------------------------------
        elif aEnv['KEYEVENT'].KeyCode in (1289,) and not aEnv['KEYEVENT'].Modifiers:
            #                                  * => repeat mode
            aEnv['REPEATMODE'] = not aEnv['REPEATMODE']
            aStatusBarCheckBox = aEnv['STATUSBARCONTROL'][6]
            if aStatusBarCheckBox.getState() != aEnv['REPEATMODE']:
                aStatusBarCheckBox.setState(aEnv['REPEATMODE'])
        self.aNamedValues[0].Value = tuple(aEnv.items())
        return self.aNamedValues
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()
g_ImplementationHelper.addImplementation(ShapeKeyHandler,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.ShapeKeyHandler", # implemenation name
                                         ("org.openoffice.comp.pyuno.ShapeKeyHandler",),)    # list of implemented services
