#	$Id$
# -*- coding: latin-1 -*-
## ********************************************************************************
## 
## Copyright (C) 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    from com.sun.star.task import XJob
    from com.sun.star.drawing.CircleKind import ARC, FULL
    import traceback, math
except ImportError:
    print "probleme d'import"
#======================================================
# a class to draw dimensions
# une classe pour le trac� de cotes
#======================================================
class DimDraw(unohelper.Base, XJob):
    """Trace une cote
    Draws a dimension"""
    def __init__(self, ctx):
        self.ctx = ctx
        desktop = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.frame.Desktop",self.ctx)
        # access the current draw document
        self.aEntitySpot = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.EntitieSpot", self.ctx)
    # *********************************
    # wrapper for the compute functions
    # *********************************
    def compute(self, sMethod, *aArgs):
        aCompute = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
                aComputeNamedValues[i].Value = 0
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # ******************************
    # Main method
    # ******************************
    def execute(self, aNamedValues):
        self.aEnv = dict(list(aNamedValues[0].Value))
        aNamedValues[1].Value = "spot"
        self.aEnv = dict(list(self.aEntitySpot.execute(aNamedValues)[0].Value))
        aCoords = [[]]
        # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        if self.aEnv['SPOTLIST'] is None and self.aEnv['DIMLIST'][0] is None:
            # print "no entity spotted, no entity stored"
            if not self.aEnv['SPOTTEDID'] is None:
                self.removeTempShapes()
                self.aEnv['SPOTTEDID'] = None
        # +++++++++++++++++++++++++++++++++++++++
        elif not self.aEnv['DIMLIST'][1] is None:
            # print "2 entities stored"
            self.setDimEnvAndCoord(self.aEnv['DIMLIST'][0], self.aEnv['DIMLIST'][1])
        # +++++++++++++++++++++++++++++++++++
        elif self.aEnv['SPOTLIST'] is None: # 1 entity stored
            # ------------------------------------
            if not self.aEnv['SPOTTEDID'] is None:
                # print "no entity spotted 1 stored a previous one spotted"
                self.removeTempShapes()
                self.aEnv['SPOTTEDID'] = None
            else:
                # print "no entity spotted 1 stored"
                pass
            self.setDimEnvAndCoord(self.aEnv['DIMLIST'][0])
        # +++++++++++++++++++++++++++++++++++++++
        elif not self.aEnv['DIMLIST'][0] is None: # 1 entity spotted 1 stored
            aPreviousSpotID = self.aEnv['DIMLIST'][0][0][:] + (self.aEnv['DIMLIST'][0][-1],)
            aNewSpotID = self.aEnv['SPOTTEDSHAPE'][0] + (self.aEnv['SPOTTEDSHAPE'][-1],)
            # -------------------------------
            if aPreviousSpotID == aNewSpotID:
                if not self.aEnv['SPOTTEDID'] is None:
                    self.removeTempShapes()
                    self.aEnv['SPOTTEDID'] = None
                # print "same entity spotted as stored"
                self.aEnv['STEP'] = 0
                self.setDimEnvAndCoord(self.aEnv['DIMLIST'][0])
            # ----------------------------------------
            elif aNewSpotID == self.aEnv['SPOTTEDID']:
                self.setDimEnvAndCoord(self.aEnv['DIMLIST'][0], self.aEnv['SPOTTEDSHAPE'])
                # print "same entity spotted 1 stored"
                self.aEnv['STEP'] = 0
            # ---
            else:
                # ::::::::::::::::::::::::::::::::::::
                if not self.aEnv['SPOTTEDID'] is None:
                    self.removeTempShapes()
                else:
                    self.removeTempShapes(False, True)
                # print "1 stored a new entity spotted"
                self.setDimEnvAndCoord(self.aEnv['DIMLIST'][0], self.aEnv['SPOTTEDSHAPE'])
                aCoords = self.setEntityEnvAndCoord(self.aEnv['SPOTTEDSHAPE'])
                self.aEnv['SPOTTEDID'] = self.aEnv['SPOTTEDSHAPE'][0][:] + (self.aEnv['SPOTTEDSHAPE'][-1],)
        # +++
        else: # 1 spotted none stored
            aNewSpotID = self.aEnv['SPOTTEDSHAPE'][0]+(self.aEnv['SPOTTEDSHAPE'][-1],)
            # -------------------------------------
            if aNewSpotID == self.aEnv['SPOTTEDID']:
                # print "same entity spotted"
                self.setDimEnvAndCoord(self.aEnv['SPOTTEDSHAPE'])
                self.aEnv['STEP'] = 0
            # ---
            else:
                # ::::::::::::::::::::::::::::::::::::
                if not self.aEnv['SPOTTEDID'] is None:
                    self.removeTempShapes()
                # print "new entity spotted"
                self.setDimEnvAndCoord(self.aEnv['SPOTTEDSHAPE'])
                aCoords = self.setEntityEnvAndCoord(self.aEnv['SPOTTEDSHAPE'])
                self.aEnv['SPOTTEDID'] = self.aEnv['SPOTTEDSHAPE'][0][:] + (self.aEnv['SPOTTEDSHAPE'][-1],)
        sText = "%s ==> %s" % (self.aEnv['COMMENT'][0], self.aEnv['DIMTYPE'])
        self.aEnv['STATUSBARCONTROL'][-1].setText(sText)
        self.aEnv['COORDS'] = tuple([tuple(c) for c in aCoords])
        aNamedValues[0].Value = tuple(self.aEnv.items())
        return aNamedValues
    # *****************************************************
    # remove temporary shapes
    # *****************************************************
    def removeTempShapes(self, bShape = True, bDim = True):
        if self.aEnv['SHAPE'] and bShape:
            aGroupShape = self.aEnv['CONTROLLER'].getCurrentPage()
            for i in self.aEnv['SPOTTEDID'][:-2]:
                aGroupShape = aGroupShape.getByIndex(i)
            aGroupShape.remove(self.aEnv['SHAPE'])
            self.aEnv['SHAPE'] = None
            self.aEnv['STEP'] = 0
            self.aEnv['COORDS'] = ((),)
        if self.aEnv['DIMTYPE'] in ('LINEAR', 'ANGULAR', 'RADIAL', 'DIAMETRAL') and bDim:
            aShape = self.aEnv['%sDIMSHAPE' % self.aEnv['DIMTYPE']]
            # print "removing %sDIMSHAPE for shape %s with %d subshapes" % (self.aEnv['DIMTYPE'], aShape.getShapeType(), aShape.getCount())
            for i in range(aShape.getCount()):
                aShape.remove(aShape.getByIndex(0))
            self.aEnv['CONTROLLER'].getCurrentPage().remove(aShape)
            self.aEnv['DIMTYPE'] = "----"
            self.aEnv['DIMCOORDS'] = None
            self.aEnv['DIMVISIBLE'] = False
        return
    # *********************************************
    # set dim env and coordinates
    # *********************************************
    def setDimEnvAndCoord(self, dim1, dim2 = None):
        aDimCoords = [uno.createUnoStruct("com.sun.star.awt.Point") for i in range(4)]
        aMouseCoord = uno.createUnoStruct("com.sun.star.awt.Point")
        aMouseCoord.X, aMouseCoord.Y =  self.compute('transformMouseCoord', tuple(self.aEnv.items()))
        # ++++++++++++++
        if dim2 is None:
            # ---------------------------
            if dim1[1] in ('LineShape',):
                aDimCoords = self.setLinearDimCoords(dim1[2], dim1[3], aMouseCoord)
            # -------------------------------
            elif dim1[1] in ('CircleShape',):
                self.aEnv['DIMTYPE'] = "DIAMETRAL"
                self.aEnv['DIMVALUE'] = "D %6.3f" % (float(2 * dim1[3].Width) / (100000 * aEnv['DRAWSCALE']),)
                aDimCoords[0].X, aDimCoords[0].Y = dim1[2].X, dim1[2].Y
                ret = self.compute("CoordFromAbsOrd",  dim1[2],  aMouseCoord, dim1[3].Width, 0)
                aDimCoords[1].X, aDimCoords[1].Y = ret.X, ret.Y
                aDimCoords[2].X, aDimCoords[2].Y = aMouseCoord.X, aMouseCoord.Y
                nDist, fAngle = self.compute("toPolarCoord", aDimCoords[1], aDimCoords[2])
                # :::::::::::::::::::::::::::::::::::::::::::::::::::::
                if fAngle <= math.pi / 2 or fAngle >= 3 * math.pi / 2:
                    aDimCoords[3].X, aDimCoords[3].Y = aMouseCoord.X + nDist, aMouseCoord.Y
                else:
                    aDimCoords[3].X, aDimCoords[3].Y = aMouseCoord.X - nDist, aMouseCoord.Y
            # ---------------------------------
            elif dim1[1] in ('ArcCircleShape',):
                # :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                if self.aEnv['L2OSTATE'][0] and not self.aEnv['L2OSTATE'][2]:
                    aCoords =  [uno.createUnoStruct("com.sun.star.awt.Point"), uno.createUnoStruct("com.sun.star.awt.Point")]
                    aCoords[0].X = dim1[2].X + dim1[3].Width * math.cos(-dim1[5])
                    aCoords[0].Y = dim1[2].Y + dim1[3].Width * math.sin(-dim1[5])
                    aCoords[1].X = dim1[2].X + dim1[3].Width * math.cos(-dim1[6])
                    aCoords[1].Y = dim1[2].Y + dim1[3].Width * math.sin(-dim1[6])
                    aDimCoords = self.setLinearDimCoords(aCoords[0], aCoords[1], aMouseCoord)
                # :::::::::::::::::::::::::::::::::::::::::::::::::::::::::
                elif self.aEnv['L2OSTATE'][0] and self.aEnv['L2OSTATE'][2]:
                    self.aEnv['DIMTYPE'] = "ANGULAR"
                    self.aEnv['DIMVALUE'] = "%6.2f�" % (math.degrees(((dim1[6] - dim1[5]) < 0) * 2 * math.pi + (dim1[6] - dim1[5])),)
                    aDimCoords[0].X, aDimCoords[0].Y = dim1[2].X, dim1[2].Y
                    aDimCoords[1].X, aDimCoords[1].Y = aMouseCoord.X, aMouseCoord.Y
                    aDimCoords[2].X = dim1[2].X + dim1[3].Width * math.cos(-dim1[5])
                    aDimCoords[2].Y = dim1[2].Y + dim1[3].Width * math.sin(-dim1[5])
                    aDimCoords[3].X = dim1[2].X + dim1[3].Width * math.cos(-dim1[6])
                    aDimCoords[3].Y = dim1[2].Y + dim1[3].Width * math.sin(-dim1[6])
                # :::
                else:
                    self.aEnv['DIMTYPE'] = "RADIAL"
                    self.aEnv['DIMVALUE'] = "R %6.3f" % (float(2 * dim1[3].Width) / (100000 * aEnv['DRAWSCALE']),)
                    aDimCoords[0].X, aDimCoords[0].Y = dim1[2].X, dim1[2].Y
                    ret = self.compute("CoordFromAbsOrd",  dim1[2],  aMouseCoord, dim1[3].Width, 0)
                    aDimCoords[1].X, aDimCoords[1].Y = ret.X, ret.Y
                    aDimCoords[2].X, aDimCoords[2].Y = aMouseCoord.X, aMouseCoord.Y
                    nDist, fAngle = self.compute("toPolarCoord", aDimCoords[1], aDimCoords[2])
                    # .....................................................
                    if fAngle <= math.pi / 2 or fAngle >= 3 * math.pi / 2:
                        aDimCoords[3].X, aDimCoords[3].Y = aMouseCoord.X + nDist, aMouseCoord.Y
                    else:
                        aDimCoords[3].X, aDimCoords[3].Y = aMouseCoord.X - nDist, aMouseCoord.Y
        else:
            # ---------------------------------------------------------
            if dim1[1] in ('LineShape',) and dim2[1] in ('LineShape',):
                aPointA, aPointB = dim1[2:4]
                aPointC, aPointD = dim2[2:4]
                ret = self.compute("InterLines2", aPointA, aPointB, aPointC, aPointD, 0, 0)
                aCoords =  [uno.createUnoStruct("com.sun.star.awt.Point"), uno.createUnoStruct("com.sun.star.awt.Point")]
                # :::::::::::::::::
                if not ret is None:
                    self.aEnv['DIMTYPE'] = "ANGULAR"
                    aDimCoords[0].X, aDimCoords[0].Y = ret[2:]
                    aDimCoords[1].X, aDimCoords[1].Y = aMouseCoord.X, aMouseCoord.Y
                    nAbsABI = self.compute("Dist2Line", aPointA, aPointB, aDimCoords[0])[0]
                    if nAbsABI <= 5:
                        # print "negative absisse ABI"
                        aPointA.X, aPointA.Y = 2 * aDimCoords[0].X - aPointB.X, 2 * aDimCoords[0].Y - aPointB.Y
                    nAbsCDI = self.compute("Dist2Line", aPointC, aPointD, aDimCoords[0])[0]
                    if nAbsCDI <= 5:
                        # print "negative absisse CDI"
                        aPointC.X, aPointC.Y = 2 * aDimCoords[0].X - aPointD.X, 2 * aDimCoords[0].Y - aPointD.Y
                    nOrdCDA = 1 - 2 * (((aPointD.X - aPointC.X) * (aPointA.Y - aPointC.Y) - (aPointD.Y - aPointC.Y) * (aPointA.X - aPointC.X)) < 0)
                    nOrdABC = 1 - 2 * (((aPointB.X - aPointA.X) * (aPointC.Y - aPointA.Y) - (aPointB.Y - aPointA.Y) * (aPointC.X - aPointA.X)) < 0)
                    nOrdABM = 1 - 2 * (((aPointB.X - aPointA.X) * (aMouseCoord.Y - aPointA.Y) - (aPointB.Y - aPointA.Y) * (aMouseCoord.X - aPointA.X)) < 0)
                    nOrdCDM = 1 - 2 * (((aPointD.X - aPointC.X) * (aMouseCoord.Y - aPointC.Y) - (aPointD.Y - aPointC.Y) * (aMouseCoord.X - aPointC.X)) < 0)
                    aPolar1 = self.compute("toPolarCoord", aPointA, aPointB)
                    aPolar2 = self.compute("toPolarCoord", aPointC, aPointD)
                    # .............................
                    if nOrdCDA * nOrdCDM > 0:
                        fAngle1 = aPolar1[1] + ((aPolar1[1] <= math.pi) - (aPolar1[1] > math.pi)) * math.pi
                        aCoords[0].X = aDimCoords[0].X + aPolar1[0] * math.cos(fAngle1)
                        aCoords[0].Y = aDimCoords[0].Y - aPolar1[0] * math.sin(fAngle1)
                    else:
                        fAngle1 = aPolar1[1]
                        aCoords[0].X = aDimCoords[0].X + aPolar1[0] * math.cos(aPolar1[1])
                        aCoords[0].Y = aDimCoords[0].Y - aPolar1[0] * math.sin(aPolar1[1])
                    # .............................
                    if nOrdABC * nOrdABM > 0:
                        fAngle2 = aPolar2[1] + ((aPolar2[1] <= math.pi) - (aPolar2[1] > math.pi)) * math.pi
                        aCoords[1].X = aDimCoords[0].X + aPolar2[0] * math.cos(fAngle2)
                        aCoords[1].Y = aDimCoords[0].Y - aPolar2[0] * math.sin(fAngle2)
                    else:
                        fAngle2 = aPolar2[1]
                        aCoords[1].X = aDimCoords[0].X + aPolar2[0] * math.cos(aPolar2[1])
                        aCoords[1].Y = aDimCoords[0].Y - aPolar2[0] * math.sin(aPolar2[1])
                    fAngle = (2 * ((fAngle2 - fAngle1) < 0) - 1) * ((abs(fAngle2 - fAngle1) > math.pi) * 2 * math.pi - abs(fAngle2 - fAngle1))
                    if fAngle >= 0:
                        aDimCoords[2].X, aDimCoords[2].Y = aCoords[0].X, aCoords[0].Y
                        aDimCoords[3].X, aDimCoords[3].Y = aCoords[1].X, aCoords[1].Y
                    else:
                        aDimCoords[2].X, aDimCoords[2].Y = aCoords[1].X, aCoords[1].Y
                        aDimCoords[3].X, aDimCoords[3].Y = aCoords[0].X, aCoords[0].Y
                    self.aEnv['DIMVALUE'] = "%6.2f�" % (math.degrees(abs(fAngle)),)
                else:
                    nDist1 = self.compute("Dist2Line", aPointA, aPointB,  aMouseCoord)
                    nDist2 = self.compute("Dist2Line", aPointA, aPointB,  aPointC)
                    aCoords[0] = self.compute("CoordFromAbsOrd",  aPointA,  aPointB, nDist1[0]-400, 0)
                    aCoords[1] = self.compute("CoordFromAbsOrd",  aPointA,  aPointB, nDist1[0]-400, nDist2[1])
                    aDimCoords = self.setLinearDimCoords(aCoords[0], aCoords[1], aMouseCoord)
            else:
                # -----------------------------
                if dim1[1] in ("LineShape",):
                    aCoords =  uno.createUnoStruct("com.sun.star.awt.Point")
                    nDist1 = self.compute("Dist2Line", dim1[2], dim1[3],  dim2[2])
                    ret = self.compute("CoordFromAbsOrd",  dim1[2],  dim1[3], nDist1[0], 0)
                    aCoords.X, aCoords.Y = ret.X, ret.Y
                    aDimCoords = self.setLinearDimCoords(aCoords, dim2[2], aMouseCoord)
                # ----------------------------
                elif dim2[1] in ('LineShape',):
                    aCoords =  uno.createUnoStruct("com.sun.star.awt.Point")
                    nDist1 = self.compute("Dist2Line", dim2[2], dim2[3],  dim1[2])
                    ret = self.compute("CoordFromAbsOrd",  dim2[2],  dim2[3], nDist1[0], 0)
                    aCoords.X, aCoords.Y = ret.X, ret.Y
                    aDimCoords = self.setLinearDimCoords(dim1[2], aCoords, aMouseCoord)
                # --
                else:
                    aDimCoords = self.setLinearDimCoords(dim1[2], dim2[2], aMouseCoord)
        self.aEnv['DIMCOORDS'] = tuple(aDimCoords)
        return
    # ******************************************
    # set coordinates for linear dimension
    # ******************************************
    def setLinearDimCoords(self, aStartPoint, aEndPoint, aMousePoint):
        aCoords = [uno.createUnoStruct("com.sun.star.awt.Point") for i in range(7)]
        self.aEnv['DIMTYPE'] = "LINEAR"
        fAngle = self.compute("toPolarCoord", aStartPoint, aEndPoint)[1]
        # ::::::::::::::::::::::::::::::::::::::::::::
        if fAngle > (math.pi/2) and fAngle <= (3*math.pi/2):
            aPoint = aStartPoint
            aStartPoint = aEndPoint
            aEndPoint = aPoint
            # print "swap vertices order"
        else:
            # print "keep vertices order"
            pass
        nDist1 = self.compute("Dist2Line", aStartPoint, aEndPoint,  aMousePoint)
        # ::::::::::::::::::::::::
        if self.aEnv['ORTHOMODE']:
            aCoords[0].X, aCoords[0].Y = aStartPoint.X, aEndPoint.Y
            aCoords[1].X, aCoords[1].Y = aEndPoint.X, aStartPoint.Y
            nDist2 = self.compute("Dist2Line", aCoords[0], aCoords[1], aMousePoint)
            # ............................
            if nDist1[1] * nDist2[1] >= 0:
                self.aEnv['DIMVALUE'] = "%6.3f" % (float(abs(aEndPoint.X - aStartPoint.X)) / (100000 * self.aEnv['DRAWSCALE']),)
                aCoords[2].X, aCoords[2].Y = aStartPoint.X, aMousePoint.Y
                aCoords[3].X, aCoords[3].Y = aEndPoint.X, aMousePoint.Y
                ret = self.compute("CoordFromAbsOrd",  aStartPoint,  aCoords[2], 200, 0)
                aCoords[0].X, aCoords[0].Y = aStartPoint.X, ret.Y
                aCoords[1].X, aCoords[1].Y = aStartPoint.X, aCoords[0].Y + aMousePoint.Y - aStartPoint.Y
                ret = self.compute("CoordFromAbsOrd",  aEndPoint,  aCoords[3], 200, 0)
                aCoords[5].X, aCoords[5].Y = aEndPoint.X, ret.Y
                aCoords[4].X, aCoords[4].Y = aEndPoint.X, aCoords[5].Y + aMousePoint.Y - aEndPoint.Y
            else:
                self.aEnv['DIMVALUE'] = "%6.3f" % (float(abs(aEndPoint.Y - aStartPoint.Y)) / (100000 * self.aEnv['DRAWSCALE']),)
                aCoords[2].X, aCoords[2].Y = aMousePoint.X, aStartPoint.Y
                aCoords[3].X, aCoords[3].Y = aMousePoint.X, aEndPoint.Y
                ret = self.compute("CoordFromAbsOrd",  aStartPoint,  aCoords[2], 200, 0)
                aCoords[0].X, aCoords[0].Y = ret.X, aStartPoint.Y
                aCoords[1].X, aCoords[1].Y = aCoords[0].X + aMousePoint.X - aStartPoint.X, aStartPoint.Y
                ret = self.compute("CoordFromAbsOrd",  aEndPoint,  aCoords[3], 200, 0)
                aCoords[5].X, aCoords[5].Y = ret.X, aEndPoint.Y
                aCoords[4].X, aCoords[4].Y = aCoords[5].X + aMousePoint.X - aEndPoint.X, aEndPoint.Y
        else:
            self.aEnv['DIMVALUE'] = "%6.3f" % (float(nDist1[2]) / (100000 * self.aEnv['DRAWSCALE']),)
            ret = self.compute("CoordFromAbsOrd",  aStartPoint,  aEndPoint, 0, nDist1[1])
            aCoords[2].X, aCoords[2].Y = ret.X, ret.Y
            ret = self.compute("CoordFromAbsOrd",  aStartPoint,  aEndPoint, nDist1[2], nDist1[1])
            aCoords[3].X, aCoords[3].Y = ret.X, ret.Y
            ret = self.compute("CoordFromAbsOrd",  aStartPoint,  aCoords[2], 200, 0)
            aCoords[0].X, aCoords[0].Y = ret.X, ret.Y
            ret = self.compute("CoordFromAbsOrd",  aCoords[0],  aCoords[2], abs(nDist1[1]), 0)
            aCoords[1].X, aCoords[1].Y = ret.X, ret.Y
            ret = self.compute("CoordFromAbsOrd",  aEndPoint,  aCoords[3], 200, 0)
            aCoords[5].X, aCoords[5].Y = ret.X, ret.Y
            ret = self.compute("CoordFromAbsOrd",  aCoords[5],  aCoords[3], abs(nDist1[1]), 0)
            aCoords[4].X, aCoords[4].Y = ret.X, ret.Y
        aCoords[6].X, aCoords[6].Y = aMousePoint.X, aMousePoint.Y
        return aCoords
    # ******************************************
    # set entity env and get coordinates
    # ******************************************
    def setEntityEnvAndCoord(self, cadoooShape):
        aCoords = [[]]
        # ...........................................
        if cadoooShape[1] in ('LineShape',):
            self.aEnv['UNOTYPE'] = "LineShape"
            self.aEnv['ENTITYPE'] = "LINE"
            self.aEnv['STEP'] = 1
            self.aEnv['MODE'] = (self.aEnv['MODE'][0],) + ("VERTEX",)
            aCoords[0].extend([uno.createUnoStruct("com.sun.star.awt.Point") for i in range(2)])
            aCoords[0][0].X, aCoords[0][0].Y = cadoooShape[2].X, cadoooShape[2].Y
            aCoords[0][1].X, aCoords[0][1].Y = cadoooShape[3].X, cadoooShape[3].Y
            # ........................................
        elif cadoooShape[1] in ('CircleShape',):
            self.aEnv['CIRCLEKIND'] = FULL
            self.aEnv['UNOTYPE'] = "EllipseShape"
            self.aEnv['ENTITYPE'] = "CIRCLE"
            self.aEnv['STEP'] = 1
            self.aEnv['MODE'] = (self.aEnv['MODE'][0],) + ("RADIUS",)
            aCoords[0].extend([uno.createUnoStruct("com.sun.star.awt.Point") for i in range(2)])
            aCoords[0][0].X = cadoooShape[2].X
            aCoords[0][0].Y = cadoooShape[2].Y
            aPoint = self.compute("PointOnEllipse", None, math.pi/4, *cadoooShape[2:5])[0]
            aCoords[0][1].X = aPoint.X
            aCoords[0][1].Y = aPoint.Y
            # .........................................................
        elif cadoooShape[1] in ("ArcCircleShape",):
            self.aEnv['CIRCLEKIND'] = ARC
            self.aEnv['UNOTYPE'] = "EllipseShape"
            self.aEnv['ENTITYPE'] = "ARC"
            self.aEnv['STEP'] = 3
            self.aEnv['MODE'] = (self.aEnv['MODE'][0],) + ("RADIUS", "STARTANGLE", "ENDANGLE")
            aCoords[0].extend([uno.createUnoStruct("com.sun.star.awt.Point") for i in range(4)])
            aCoords[0][0].X = cadoooShape[2].X
            aCoords[0][0].Y = cadoooShape[2].Y
            aPoint = self.compute("PointOnEllipse", None, math.pi/4, *cadoooShape[2:5])[0]
            aCoords[0][1].X = aPoint.X
            aCoords[0][1].Y = aPoint.Y
            aPoint = self.compute("PointOnEllipse", None, cadoooShape[5], *cadoooShape[2:5])[0]
            aCoords[0][2].X = aPoint.X
            aCoords[0][2].Y = aPoint.Y
            aPoint = self.compute("PointOnEllipse", None, cadoooShape[6], *cadoooShape[2:5])[0]
            aCoords[0][3].X = aPoint.X
            aCoords[0][3].Y = aPoint.Y
        return aCoords
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(DimDraw,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.DimDraw", # implemenation name
                                         ("org.openoffice.comp.pyuno.DimDraw",),)    # list of implemented services
