#	$Id: offsetmousehandler.py,v 1.1 2006-07-16 10:02:13 gerard Exp $
## ********************************************************************************
## 
## Copyright (C) 2006 G�ard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    import math, traceback
    from com.sun.star.task import XJob
except ImportError:
    print "probleme d'import"
# ===================================================
# Gerer les saisies de points et validation d'entites
# Handle points inputs and entities validation
# ===================================================
class OffsetMouseHandler(unohelper.Base, XJob):
    """Gere les saisies de points et validation d'entite
    Handles points inputs and entities validation"""
    def __init__(self, ctx):
        self.ctx = ctx
        # get the central desktop object
        desktop = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.frame.Desktop",self.ctx)
        # access the current draw document
        self.aController = desktop.CurrentComponent.CurrentController
        # Struct needed to pass arguments throught UNO
        self.aEntityPosSize = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.EntityPosSize", self.ctx)
    # **********************************
    # Handles mouse clicks
    # MOUSEEVENT  struct MouseEvent
    # STOPJOB   integer (0 or 1)
    # STEP
    # COORDS
    # REPEATMODE
    # SHAPE
    # **********************************
    def execute(self, aArgs):
        self.aValues = dict(list(aArgs[0].Value))
        # ----------------------------------------
        if self.aValues['MOUSEEVENT'].Buttons > 1: # don't handle mouse buttons but left
            return aArgs
        # --------------------------------------------
        if self.aValues['MOUSEEVENT'].ClickCount == 1: # one click ?
            # -----------------------------------
            if len(self.aValues['SPOTLIST']) > 0: # entity has been spotted ?
                aGroupShape = self.aController.getCurrentPage()
                for i in self.aValues['SPOTTEDID'][:-2]:
                    aGroupShape = aGroupShape.getByIndex(i)
                i = self.aValues['SPOTTEDSHAPE'][0][-1]
                aShape = aGroupShape.getByIndex(i)
                self.aValues['SHAPE'].Style = aShape.Style
                self.aValues['SHAPE'].LineColor = aShape.LineColor
                self.aValues['SHAPE'].LineWidth = aShape.LineWidth
                self.aValues['SHAPE'].setName("")
                self.aValues['SHAPE'] = None
            # ----------------------------
            if self.aValues['REPEATMODE']: # repeat mode on ?
                self.aValues['VALIDLIST'] = False
                self.aValues['SHAPE'] = None
                self.aValues['GROUPSHAPE'] = self.aController.getCurrentPage()
            else:
                self.aValues['STOPJOB'] = True
        # --------------------------------------------
        elif self.aValues['MOUSEEVENT'].ClickCount == 2:
            self.aValues['STOPJOB'] = True
        aArgs[0].Value = tuple(self.aValues.items())
        return aArgs
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(OffsetMouseHandler,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.OffsetMouseHandler", # implemenation name
                                         ("org.openoffice.comp.pyuno.OffsetMouseHandler",),)    # list of implemented services
