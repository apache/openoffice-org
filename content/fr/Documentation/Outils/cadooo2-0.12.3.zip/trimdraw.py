#	$Id: trimdraw.py,v 1.1 2006-07-16 10:02:14 gerard Exp $
## ********************************************************************************
## 
## Copyright (C) 2005 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    from com.sun.star.task import XJob
    from com.sun.star.drawing.CircleKind import FULL, SECTION, CUT, ARC
    import math, traceback
except ImportError:
    print "probleme d'import"
#======================================================
# a class to trim an entity
# une classe pour prolonger une entit�
#======================================================
class TrimDraw(unohelper.Base, XJob):
    """Prolonge une entite graphique
    Trims a graphical entity"""
    def __init__(self, ctx):
        self.ctx = ctx
        desktop = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.frame.Desktop",self.ctx)
        # access the current draw document
        self.aController = desktop.CurrentComponent.CurrentController
        self.aEntitySpot = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.EntitieSpot", self.ctx)
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # ==============================
    def execute(self, aNamedValues):
        self.aValues = dict(list(aNamedValues[0].Value))
        sText = self.aValues['COMMENT'][0]
        self.aValues['STATUSBARCONTROL'][-1].setText(sText)
        aNamedValues[0].Value = tuple(self.aValues.items())
        aNamedValues[1].Value = "spot"
        self.aValues = dict(list(self.aEntitySpot.execute(aNamedValues)[0].Value))
        aCoords = [[]]
        if not self.aValues['SPOTLIST'] is None: # entity has been spotted ?
            # ..................................................................................................
            if self.aValues['SPOTTEDID'] == self.aValues['SPOTTEDSHAPE'][0]+(self.aValues['SPOTTEDSHAPE'][-1],):
                aNamedValues[0].Value = tuple(self.aValues.items())
                return aNamedValues
            self.removeTempShape()
            self.aValues['SPOTTEDID'] = self.aValues['SPOTTEDSHAPE'][0][:] + (self.aValues['SPOTTEDSHAPE'][-1],)
            # ---------------------------------------------------
            if self.aValues['SPOTTEDSHAPE'][1] in ('LineShape',): # is it a line ?
                self.aValues['UNOTYPE'] = "LineShape"
                self.aValues['ENTITYPE'] = "LINE"
                self.aValues['STEP'] = 1
                self.aValues['MODE'] = (self.aValues['MODE'][0],) + ("VERTEX",)
                # -------------------------------# triming toward left ?----------------------------
                if self.aValues['BORDERLIST'][2][0] >= 0 and self.aValues['BORDERLIST'][2][1] <= 50:
                    aCoords[0].append(self.aValues['BORDERLIST'][2][2])
                    aCoords[0].append(self.aValues['SPOTTEDSHAPE'][3])
                # ------------------------------- # triming toward right ?---------------------------
                elif self.aValues['BORDERLIST'][3][0] >= 0 and self.aValues['BORDERLIST'][3][1] > 50:
                    aCoords[0].append(self.aValues['SPOTTEDSHAPE'][2])
                    aCoords[0].append(self.aValues['BORDERLIST'][3][2])
                # ---
                else: # no entity to treat ?
                    aCoords[0].append(self.aValues['SPOTTEDSHAPE'][2])
                    aCoords[0].append(self.aValues['SPOTTEDSHAPE'][3])
            # ---------------------------------------------------
            elif self.aValues['SPOTTEDSHAPE'][1] in ("ArcCircleShape", "ArcEllipseShape"):
                aShape = self.aValues['GROUPSHAPE'].getByIndex(self.aValues['SPOTTEDSHAPE'][0][-1])
                self.aValues['CIRCLEKIND'] = aShape.CircleKind
                self.aValues['UNOTYPE'] = "EllipseShape"
                aCoords[0].extend([uno.createUnoStruct("com.sun.star.awt.Point") for i in range(4)])
                aCoords[0][0].X = self.aValues['SPOTTEDSHAPE'][2].X
                aCoords[0][0].Y = self.aValues['SPOTTEDSHAPE'][2].Y
                if self.aValues['SPOTTEDSHAPE'][1] in ("ArcCircleShape",):
                    self.aValues['ENTITYPE'] = "ARC"
                    self.aValues['STEP'] = 3
                    self.aValues['MODE'] = (self.aValues['MODE'][0],) + ("RADIUS", "STARTANGLE", "ENDANGLE")
                else:
                    self.aValues['ENTITYPE'] = "ELLARC"
                    self.aValues['STEP'] = 4
                    self.aValues['MODE'] = (self.aValues['MODE'][0],) + ("RADIUS", "RADIUS2", "STARTANGLE", "ENDANGLE")
                    aCoords[0].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                    aPoint = self.compute("PointOnEllipse", None, math.pi/2, *self.aValues['SPOTTEDSHAPE'][2:5])[0]
                    aCoords[0][2].X = aPoint.X
                    aCoords[0][2].Y = aPoint.Y
                aPoint = self.compute("PointOnEllipse", None, float(0), *self.aValues['SPOTTEDSHAPE'][2:5])[0]
                aCoords[0][1].X = aPoint.X
                aCoords[0][1].Y = aPoint.Y
                # -------------------------- # triming toward left ?--------------------------------
                if self.aValues['BORDERLIST'][2][0] >= 0 and self.aValues['BORDERLIST'][2][1] <= 50:
                    aCoords[0][-2].X = self.aValues['BORDERLIST'][2][2].X
                    aCoords[0][-2].Y = self.aValues['BORDERLIST'][2][2].Y
                    aPoint = self.compute("PointOnEllipse", None, self.aValues['SPOTTEDSHAPE'][6],*self.aValues['SPOTTEDSHAPE'][2:5])[0]
                    aCoords[0][-1].X = aPoint.X
                    aCoords[0][-1].Y = aPoint.Y
                # ---------------------------- # triming toward right ?------------------------------
                elif self.aValues['BORDERLIST'][3][0] >= 0 and self.aValues['BORDERLIST'][3][1] > 50:
                    aPoint = self.compute("PointOnEllipse", None, self.aValues['SPOTTEDSHAPE'][5], *self.aValues['SPOTTEDSHAPE'][2:5])[0]
                    aCoords[0][-2].X = aPoint.X
                    aCoords[0][-2].Y = aPoint.Y
                    aCoords[0][-1].X = self.aValues['BORDERLIST'][3][2].X
                    aCoords[0][-1].Y = self.aValues['BORDERLIST'][3][2].Y
                # ---
                else: # no entity to treat ?
                    aPoint = self.compute("PointOnEllipse", None, self.aValues['SPOTTEDSHAPE'][6],*self.aValues['SPOTTEDSHAPE'][2:5])[0]
                    aCoords[0][-1].X = aPoint.X
                    aCoords[0][-1].Y = aPoint.Y
                    aPoint = self.compute("PointOnEllipse", None, self.aValues['SPOTTEDSHAPE'][5], *self.aValues['SPOTTEDSHAPE'][2:5])[0]
                    aCoords[0][-2].X = aPoint.X
                    aCoords[0][-2].Y = aPoint.Y
        else:
            self.removeTempShape()
            self.aValues['SPOTTEDID'] = None
            self.aValues['STEP'] = 0
        self.aValues['COORDS'] = tuple([tuple(c) for c in aCoords])
        aNamedValues[0].Value = tuple(self.aValues.items())
        return aNamedValues
    # ----------------------
    # remove temporary shape
    # ----------------------
    def removeTempShape(self):
        if self.aValues['SHAPE']:
            aGroupShape = self.aController.getCurrentPage()
            for i in self.aValues['SPOTTEDID'][:-2]:
                aGroupShape = aGroupShape.getByIndex(i)
            aGroupShape.remove(self.aValues['SHAPE'])
            self.aValues['SHAPE'] = None
        return
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(TrimDraw,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.TrimDraw", # implemenation name
                                         ("org.openoffice.comp.pyuno.TrimDraw",),)    # list of implemented services
