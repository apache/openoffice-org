#	$Id: trimkeyhandler.py,v 1.1 2006-07-16 10:02:14 gerard Exp $
## ********************************************************************************
## 
## Copyright (C) 2006 G�ard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import unohelper, uno
    import math, traceback, operator
    from com.sun.star.task import XJob
    from com.sun.star.awt.KeyModifier import SHIFT
except ImportError:
    print "probleme d'import"
#===============================
# gestion des evenements clavier
# handling keyboard events
#===============================
class TrimKeyHandler(unohelper.Base, XJob):
    """gestion des evenements clavier
    handling keyboard events"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
        # Datum needed by coordinates input form
        self.aCoordData = {}
        self.aCoordData["TITLE"]  = "No Title"
        self.aCoordData["FLAG"] = 0
        self.aCoordData["COMMENT"] = "No comment"
        self.aCoordData["X"] = 0
        self.aCoordData["XUNIT"] = "m"
        self.aCoordData["Y"] = 0
        self.aCoordData["YUNIT"] = "m"
        self.aCoordData["RETURN"] = False
        # Struct needed to pass arguments throught UNO
        self.aNamedValues = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        self.aNamedValues[0].Name = "CONTEXT"
        self.aEntityPosSize = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.EntityPosSize", self.ctx)
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # ==================================
    # actions clavier - keyboard actions
    # aArgs as tuple of NamedValue
    #   Name         Value
    # KEYCODE     integer
    # DRAWSCALE
    # COORDS
    # STEP
    # DRAWSCALE
    # CANCELJOB
    # ORTHOMODE
    # SHAPE
    # ==================================
    def execute(self, aArgs):
        aValues = dict(list(aArgs[0].Value))
        # ----------------------------------------------------------------------------------------------------
        if [516, 520, 524, 527, 531].count(aValues['KEYEVENT'].KeyCode) and not aValues['KEYEVENT'].Modifiers:
            # e,   i,   m,   p,   t => link 2 entities
            i = [516, 520, 524, 527, 531].index(aValues['KEYEVENT'].KeyCode)
            bKHState = list(aValues['L2OSTATE'])
            bKHState[i] = not bKHState[i]
            aValues['L2OSTATE'] = tuple(bKHState)
            aStatusBarCheckBox = aValues['STATUSBARCONTROL'][i]
            if aStatusBarCheckBox.getState() != aValues['L2OSTATE'][i]:
                aStatusBarCheckBox.setState(aValues['L2OSTATE'][i])
        # ----------------------------------------------------------------------------------------------------------
        elif aValues['KEYEVENT'].KeyCode in (523,) and not aValues['KEYEVENT'].Modifiers and aValues['SPOTTEDSHAPE']:
            # .................................l
            aMsgL10n = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
            aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
            aParms[0].Name = "Translation"
            i = aValues['SPOTTEDSHAPE'][0][-1]
            aShape = aValues['GROUPSHAPE'].getByIndex(i)
            aType = aShape.getShapeType().split('.')[-1]
            aStyle = aShape.Style
            aValues['GROUPSHAPE'].remove(aValues['SHAPE'])
            aValues['SHAPE'] = None
            # ---------------------------------------------
            if aValues['SPOTTEDSHAPE'][1] in ("LineShape",):
                aParms[0].Value = ("k0", "k1")
                aParms = aMsgL10n.execute(aParms)
                aCoords = uno.createUnoStruct("com.sun.star.awt.Point")
                while True:
                    aCoordInput = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DataInputBox", self.ctx)
                    self.aCoordData["TITLE"]  = aParms[0].Value[0]
                    self.aCoordData["FLAG"] = 0
                    self.aCoordData["COMMENT"] = aParms[0].Value[1]
                    self.aCoordData["RETURN"] = False
                    self.aCoordData["X"] = float(aValues['MOUSERELPOS'][0]) / (100000 * aValues['DRAWSCALE'])
                    self.aNamedValues[0].Value = tuple(self.aCoordData.items())
                    self.aCoordData = dict(list(aCoordInput.execute(self.aNamedValues)[0].Value))
                    # ---------------------------
                    if self.aCoordData["RETURN"]:
                        nDist = long(self.aCoordData['X']*aValues['DRAWSCALE'])
                        # ------
                        if nDist:
                            fK = float(nDist) / aValues['MOUSERELPOS'][2]
                            aCoords.X = aValues['SPOTTEDSHAPE'][2].X + long(fK * (aValues['SPOTTEDSHAPE'][3].X - aValues['SPOTTEDSHAPE'][2].X))
                            aCoords.Y = aValues['SPOTTEDSHAPE'][2].Y + long(fK * (aValues['SPOTTEDSHAPE'][3].Y - aValues['SPOTTEDSHAPE'][2].Y))
                            # ------------------------------------------
                            if aType in ("LineShape", "RectangleShape"):
                                aValues['COORDS'][-1][-1].X = aCoords.X
                                aValues['COORDS'][-1][-1].Y = aCoords.Y
                                aArgs[0].Value = tuple(aValues.items())
                                aValues = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                                aValues['SHAPE'].Style = aStyle
                                aValues['SHAPE'].setName("")
                                aValues['SHAPE'] = None
                                # ---------------------------
                                if aType == "RectangleShape": # Rectangle
                                    i = 1
                                    # -------------------------------------------------
                                    for aSplit in aValues['SPLITTEDSHAPE']:
                                        # -----------------------------------------
                                        if i != aValues['SPOTTEDSHAPE'][-1]: # to do ?
                                            # ----------------------------------------------------
                                            if aSplit[1] == "LineShape":
                                                aValues['UNOTYPE'] = "LineShape"
                                                aValues['ENTITYPE'] = "LINE"
                                                aValues['STEP'] = 1
                                                aValues['MODE'] = (aValues['MODE'][0],) + ("VERTEX",)
                                                aShapeCoords = [[aSplit[2], aSplit[3]]]
                                            else:
                                                aValues['UNOTYPE'] = "EllipseShape"
                                                aValues['ENTITYPE'] = "ARC"
                                                aValues['STEP'] = 3
                                                aValues['MODE'] = (aValues['MODE'][0],) + ("RADIUS", "STARTANGLE", "ENDANGLE")
                                                aShapeCoords = [[uno.createUnoStruct("com.sun.star.awt.Point") for j in range(4)]]
                                                aShapeCoords[0][0].X, aShapeCoords[0][0].Y = aSplit[2].X, aSplit[2].Y
                                                nRadius = aSplit[3].Width
                                                aShapeCoords[0][1].X, aShapeCoords[0][1].Y = aSplit[2].X + nRadius, aSplit[2].Y
                                                aShapeCoords[0][2].X = aSplit[2].X + nRadius * math.cos(aSplit[5])
                                                aShapeCoords[0][2].Y = aSplit[2].Y - nRadius * math.sin(aSplit[5])
                                                aShapeCoords[0][3].X = aSplit[2].X + nRadius * math.cos(aSplit[6])
                                                aShapeCoords[0][3].Y = aSplit[2].Y - nRadius * math.sin(aSplit[6])
                                            aValues['COORDS'] = tuple([tuple(c) for c in aShapeCoords])
                                            aArgs[0].Value = tuple(aValues.items())
                                            aValues = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                                            aValues['SHAPE'].Style = aStyle
                                            aValues['SHAPE'].setName("")
                                            aValues['SHAPE'] = None
                                        i = i + 1
                            # --------------------------------------------------
                            elif aType in ("PolyLineShape", "PolyPolygonShape"):
                                idx = 0
                                aShapeCoords = []
                                # ---------------------------------
                                for aPolygon in aShape.PolyPolygon[:]:
                                    aShapeCoords.append([])
                                    # --------------------------
                                    for i in range(len(aPolygon)):
                                        aShapeCoords[-1].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                                        idx = idx + 1
                                        # -----------------------------------------
                                        if aValues['SPOTTEDSHAPE'][-1] == idx:
                                            aShapeCoords[-1][-1].X = aPolygon[i].X
                                            aShapeCoords[-1][-1].Y = aPolygon[i].Y
                                            aShapeCoords[-1].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                                            aShapeCoords[-1][-1].X = aCoords.X
                                            aShapeCoords[-1][-1].Y = aCoords.Y
                                            if i < len(aPolygon)-2:
                                                aShapeCoords.append([])
                                        else:
                                            aShapeCoords[-1][-1].X = aPolygon[i].X
                                            aShapeCoords[-1][-1].Y = aPolygon[i].Y
                                    idx = idx - 1
                                aValues['COORDS'] = tuple([tuple(i) for i in aShapeCoords])
                                aValues['UNOTYPE'] = aType
                                aValues['ENTITYPE'] = "POLYGON"
                                aValues['STEP'] = -1
                                aValues['MODE'] = (aValues['MODE'][0],) + ("VERTEX",)
                                aArgs[0].Value = tuple(aValues.items())
                                aValues = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                                aValues['SHAPE'].Style = aStyle
                                aValues['SHAPE'].setName("")
                                aValues['SHAPE'] = None
                            break
            # ---------------------------------------------
            if aValues['SPOTTEDSHAPE'][1] in ("ArcEllipseShape", "ArcCircleShape"):
                aParms[0].Value = ("k0", "k5")
                aParms = aMsgL10n.execute(aParms)
                aCoords = uno.createUnoStruct("com.sun.star.awt.Point")
                while True:
                    aCoordInput = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DataInputBox", self.ctx)
                    self.aCoordData["TITLE"]  = aParms[0].Value[0]
                    self.aCoordData["FLAG"] = 4
                    self.aCoordData["COMMENT"] = aParms[0].Value[1]
                    self.aCoordData["RETURN"] = False
                    self.aCoordData["Y"] = aValues['SPOTTEDSHAPE'][5] * 180 / math.pi
                    self.aNamedValues[0].Value = tuple(self.aCoordData.items())
                    self.aCoordData = dict(list(aCoordInput.execute(self.aNamedValues)[0].Value))
                    # ---------------------------
                    if self.aCoordData["RETURN"]:
                        fAngle = self.aCoordData["Y"]
                        if fAngle == float(0):
                            fAngle = 2 * math.pi
                        aValues['CIRCLEKIND'] = aShape.CircleKind
                        aValues['UNOTYPE'] = "EllipseShape"
                        aShapeCoords = [uno.createUnoStruct("com.sun.star.awt.Point") for i in range(4)]
                        aShapeCoords[0].X = aValues['SPOTTEDSHAPE'][2].X
                        aShapeCoords[0].Y = aValues['SPOTTEDSHAPE'][2].Y
                        if aValues['SPOTTEDSHAPE'][1] in ("ArcCircleShape",):
                            aValues['ENTITYPE'] = "ARC"
                            aValues['STEP'] = 3
                            aValues['MODE'] = (aValues['MODE'][0],) + ("RADIUS", "STARTANGLE", "ENDANGLE")
                        else:
                            aValues['ENTITYPE'] = "ELLARC"
                            aValues['STEP'] = 4
                            aValues['MODE'] = (aValues['MODE'][0],) + ("RADIUS", "RADIUS2", "STARTANGLE", "ENDANGLE")
                            aShapeCoords[0].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                            aCoords = self.compute("PointOnEllipse", None, math.pi/2, *aValues['SPOTTEDSHAPE'][2:5])[0]
                            aShapeCoords[2].X = aCoords.X
                            aShapeCoords[2].Y = aCoords.Y
                        aCoords = self.compute("PointOnEllipse", None, float(0), *aValues['SPOTTEDSHAPE'][2:5])[0]
                        aShapeCoords[1].X = aCoords.X
                        aShapeCoords[1].Y = aCoords.Y
                        aCoords = self.compute("PointOnEllipse", None, aValues['SPOTTEDSHAPE'][5], *aValues['SPOTTEDSHAPE'][2:5])[0]
                        aShapeCoords[-2].X = aCoords.X
                        aShapeCoords[-2].Y = aCoords.Y
                        aCoords = self.compute("PointOnEllipse", None, fAngle, *aValues['SPOTTEDSHAPE'][2:5])[0]
                        aShapeCoords[-1].X = aCoords.X
                        aShapeCoords[-1].Y = aCoords.Y
                        aArgs[0].Value = tuple(aValues.items())
                        aValues = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                        aValues['SHAPE'].Style = aStyle
                        aValues['SHAPE'].setName("")
                        aValues['SHAPE'] = None
                        break
            aValues['GROUPSHAPE'].remove(aShape)
            # ----------------------------
            if aValues['REPEATMODE']: # repeat mode on ?
                aValues['VALIDLIST'] = False
                aValues['SHAPE'] = None
                aValues['GROUPSHAPE'] = self.aController.getCurrentPage()
            else:
                aValues['STOPJOB'] = True
        # --------------------------------------------------------------------------------
        elif aValues['KEYEVENT'].KeyCode in (1281,) and not aValues['KEYEVENT'].Modifiers:
            #                                 Esc => kill job
            aValues['CANCELJOB'] = True
        # -------------------------------------------------------------------------------
        elif aValues['KEYEVENT'].KeyCode in (512,) and not aValues['KEYEVENT'].Modifiers:
            #                                  a => axonometric mode
            aValues['ORTHOMODE'] = not aValues['ORTHOMODE']
            aStatusBarCheckBox = aValues['STATUSBARCONTROL'][5]
            if aStatusBarCheckBox.getState() != aValues['ORTHOMODE']:
                aStatusBarCheckBox.setState(aValues['ORTHOMODE'])
        # --------------------------------------------------------------------------------
        elif aValues['KEYEVENT'].KeyCode in (1289,) and not aValues['KEYEVENT'].Modifiers:
            #                                  * => repeat mode
            aValues['REPEATMODE'] = not aValues['REPEATMODE']
            aStatusBarCheckBox = aValues['STATUSBARCONTROL'][6]
            if aStatusBarCheckBox.getState() != aValues['REPEATMODE']:
                aStatusBarCheckBox.setState(aValues['REPEATMODE'])
        aArgs[0].Value = tuple(aValues.items())
        return aArgs
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()
g_ImplementationHelper.addImplementation(TrimKeyHandler,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.TrimKeyHandler", # implemenation name
                                         ("org.openoffice.comp.pyuno.TrimKeyHandler",),)    # list of implemented services
