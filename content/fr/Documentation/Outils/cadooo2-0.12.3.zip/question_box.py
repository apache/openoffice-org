# 	$Id: question_box.py,v 1.1 2006-07-16 10:02:14 gerard Exp $	
# -*- coding: latin-1 -*-
## ********************************************************************************
## question_box ven f�v 11 15:19:10 CET 2005
## Copyright (C) 2004 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************

try:
	import uno, unohelper
except ImportError:
	print "import impossible de uno et unohelper"

try:
    from com.sun.star.task import XJob
except ImportError, e:
    print e
    
try:
    from com.sun.star.awt import XActionListener
except ImportError:
    print "import impossible de XActionListener"

class QuestionBox(unohelper.Base, XJob, XActionListener):
    def __init__(self, aContext):
	self.ctx = aContext
	self.bOK = False
        desktop = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.frame.Desktop",self.ctx)
        aModel = desktop.getCurrentComponent()
        self.aController = aModel.getCurrentController()
    # ******************************
    def execute(self, aNamedValues):
	"""Boite de question"""
        aMsgL10n = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
        aArgs = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aArgs[0].Name = "Translation"
        aArgs[0].Value = ("q0", "q1", "q2")
        aArgs = aMsgL10n.execute(aArgs)
        aBox = uno.createUnoStruct("com.sun.star.awt.Rectangle")
        aBox.Width, aBox.Height = 130, 70
        aBox.X = (self.aController.Frame.ComponentWindow.PosSize.X + (self.aController.Frame.ComponentWindow.PosSize.Width - aBox.Width) / 2) / 25e-1
        aBox.Y = (self.aController.Frame.ComponentWindow.PosSize.Y + (self.aController.Frame.ComponentWindow.PosSize.Height - aBox.Height) / 2) / 25e-1
	# create the dialog model and set the properties
	QuestionBoxDialogModel = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.awt.UnoControlDialogModel", self.ctx)
	# -------------------------------------------------------
	QuestionBoxDialogModel.setPropertyValue("PositionX", aBox.X)
	QuestionBoxDialogModel.setPropertyValue("PositionY", aBox.Y)
	QuestionBoxDialogModel.setPropertyValue("Width", aBox.Width)
	QuestionBoxDialogModel.setPropertyValue("Height", aBox.Height)
	QuestionBoxDialogModel.setPropertyValue("Title", aArgs[0].Value[0])
	# create the button model and set the properties
	QuestionBoxButtonModel1 = QuestionBoxDialogModel.createInstance( "com.sun.star.awt.UnoControlButtonModel" )
	QuestionBoxButtonModel1.setPropertyValue("PositionX", 20)
	QuestionBoxButtonModel1.setPropertyValue("PositionY", 50)
	QuestionBoxButtonModel1.setPropertyValue("Width", 30)
	QuestionBoxButtonModel1.setPropertyValue("Height", 15)
	QuestionBoxButtonModel1.setPropertyValue("Name", "ButtonYes")
	QuestionBoxButtonModel1.setPropertyValue("TabIndex", 0)
	QuestionBoxButtonModel1.setPropertyValue("Label", aArgs[0].Value[1])
	QuestionBoxButtonModel1.setPropertyValue("DefaultButton", True)
	# create the button model and set the properties
	QuestionBoxButtonModel2 = QuestionBoxDialogModel.createInstance( "com.sun.star.awt.UnoControlButtonModel" )
	QuestionBoxButtonModel2.setPropertyValue("PositionX", 80)
	QuestionBoxButtonModel2.setPropertyValue("PositionY", 50)
	QuestionBoxButtonModel2.setPropertyValue("Width", 30)
	QuestionBoxButtonModel2.setPropertyValue("Height", 15)
	QuestionBoxButtonModel2.setPropertyValue("Name", "ButtonNo")
	QuestionBoxButtonModel2.setPropertyValue("TabIndex", 1)
	QuestionBoxButtonModel2.setPropertyValue("Label", aArgs[0].Value[2])
	# create the label model and set the properties
	QuestionBoxLabelModel = QuestionBoxDialogModel.createInstance( "com.sun.star.awt.UnoControlFixedTextModel" )
	QuestionBoxLabelModel.setPropertyValue("PositionX", 10)
	QuestionBoxLabelModel.setPropertyValue("PositionY", 10)
	QuestionBoxLabelModel.setPropertyValue("Width", 110)
	QuestionBoxLabelModel.setPropertyValue("Height", 15)
	QuestionBoxLabelModel.setPropertyValue("Name", "Label1")
	QuestionBoxLabelModel.setPropertyValue("TabIndex", 2)
	QuestionBoxLabelModel.setPropertyValue("Label", aNamedValues[1].Value)
	QuestionBoxLabelModel.setPropertyValue("MultiLine", True)
	# insert the control models into the dialog model
	QuestionBoxDialogModel.insertByName("ButtonYes", QuestionBoxButtonModel1)
	QuestionBoxDialogModel.insertByName("ButtonNo", QuestionBoxButtonModel2)
	QuestionBoxDialogModel.insertByName("Label1", QuestionBoxLabelModel)
	# create the dialog control and set the model 
	self.QuestionBoxDialogControl = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.awt.UnoControlDialog", self.ctx)
	self.QuestionBoxDialogControl.setModel(QuestionBoxDialogModel)
	# add an action listener to the buttonYes control 
	QuestionBoxYesButton = self.QuestionBoxDialogControl.getControl("ButtonYes")
        QuestionBoxYesButton.setActionCommand("yes")
	QuestionBoxYesButton.addActionListener(self)
	# add an action listener to the buttonNo control 
	QuestionBoxNoButton = self.QuestionBoxDialogControl.getControl("ButtonNo")
        QuestionBoxNoButton.setActionCommand("no")
	QuestionBoxNoButton.addActionListener(self)
	# create a peer 
	QuestionBoxToolkit = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.awt.Toolkit", self.ctx)
	self.QuestionBoxDialogControl.setVisible(0)
	self.QuestionBoxDialogControl.createPeer(QuestionBoxToolkit, QuestionBoxToolkit.getDesktopWindow())
	# execute the dialog 
	self.QuestionBoxDialogControl.execute()
	# remove an action listener to the button1 control 
	QuestionBoxYesButton.removeActionListener(self)
	QuestionBoxNoButton.removeActionListener(self)
        aNamedValues[0].Value = self.bOK
	return aNamedValues
	# XEventListener 
    def disposing(self, eventObject):
        self.QuestionBoxDialogControl = None
	# XActionListener 
    def actionPerformed(self, actionEvent):
        if actionEvent.ActionCommand == "yes":
            self.bOK = True
        else:
            self.bOK = False
        self.QuestionBoxDialogControl.endExecute()

# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(QuestionBox,                                        # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.QuestionBox", # implemenation name
                                         ("org.openoffice.comp.pyuno.QuestionBox",),)    # list of implemented services
