# 	$Id: rectanglejob.py,v 1.1 2007/01/30 12:52:46 gerard Exp $
# -*- coding: latin-1 -*-
## ********************************************************************************
## rectanglejob
## Copyright (C) 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    from com.sun.star.task import XJobExecutor
    import traceback
except ImportError:
    print "probleme d'import"
#======================================================
# a class to draw a rectangle
# une classe pour tracer un rectangle
#======================================================
class RectangleJob(unohelper.Base, XJobExecutor):
    """Trace un rectangle
    Draws a rectangle"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
    #=======================
    # Called by the GUI
    #=======================
    def trigger(self, args):
        aEnv = {}
        aEnv['UNOTYPE'] = "RectangleShape"
        aEnv['ENTITYPE'] = "RECTANGLE"
        aEnv['STEPS'] = 3
        aEnv['MODE'] = ('CREATE', 'WIDTH', 'HEIGHT')
        aEnv['CORNERRADIUS'] = 0
        aNamedValues = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aNamedValues[0].Name = "CONTEXT"
        aMsgL10n = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
        aNamedValues[0].Value = ("rec0", "rec1", "rec2", "rec3")
        aNamedValues = aMsgL10n.execute(aNamedValues)
        aEnv['COMMENT'] = (aNamedValues[0].Value)
        aCadoooJob = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.CadoooJob", self.ctx)
        aNamedValues[0].Value = tuple(aEnv.items())
        aEnv = dict(list(aCadoooJob.execute(aNamedValues)[0].Value))
    # **********************************
    # inspection wrapper
    # **********************************
    def inspectObject(self, aObject):
        aDiveIn = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DiveIn", self.ctx)
        aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aParms[0].Name = "inspect"
        aParms[0].Value = aObject
        aParms = dict(list(aDiveIn.execute(aParms)[0].Value))
        return
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(RectangleJob,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.Rectangle", # implemenation name
                                         ("org.openoffice.comp.pyuno.Rectangle",),)    # list of implemented services
