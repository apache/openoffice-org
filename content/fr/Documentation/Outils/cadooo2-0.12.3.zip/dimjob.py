# 	$Id$
# -*- coding: latin-1 -*-
## ********************************************************************************
## dimjob mar f�v 13 14:50:27 CET 2007
## Copyright (C) 2007 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    from com.sun.star.task import XJobExecutor
    import traceback
except ImportError:
    print "probleme d'import"
#================================================
# a class to dimension
# une classe pour coter
#================================================
class DimJob(unohelper.Base, XJobExecutor):
    """dessine une cote
    Draws a dimension"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
    #=======================
    # Called by the GUI
    #=======================
    def trigger(self, args):
        aEnv = {}
        aEnv['UNOTYPE'] = "MeasureShape"
        aEnv['ENTITYPE'] = "MEASURE"
        aEnv['STEPS'] = 2
        aEnv['MODE'] = ('CREATE', 'VERTEX')
        aEnv['DIMMODE'] = True
        aEnv['DIMLIST'] = (None, None)
        aEnv['DIMTYPE'] = "---"
        aEnv['LINEARDIMSHAPE'] = None
        aEnv['ANGULARDIMSHAPE'] = None
        aEnv['RADIALDIMSHAPE'] = None
        aEnv['DIAMETRALDIMSHAPE'] = None
        aEnv['DIMCOORDS'] = None
        aEnv['DIMVISIBLE'] = False
        aNamedValues = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aNamedValues[0].Name = "CONTEXT"
        aMsgL10n = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.MsgL10n", self.ctx)
        aNamedValues[0].Value = ("dim0",)
        aNamedValues = aMsgL10n.execute(aNamedValues)
        aEnv['COMMENT'] = (aNamedValues[0].Value)
        aCadoooJob = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.CadoooJob", self.ctx)
        aNamedValues[0].Value = tuple(aEnv.items())
        aEnv = dict(list(aCadoooJob.execute(aNamedValues)[0].Value))
    # **********************************
    # inspection wrapper
    # **********************************
    def inspectObject(self, aObject):
        aDiveIn = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.DiveIn", self.ctx)
        aParms = (uno.createUnoStruct("com.sun.star.beans.NamedValue"),)
        aParms[0].Name = "inspect"
        aParms[0].Value = aObject
        aParms = dict(list(aDiveIn.execute(aParms)[0].Value))
        return
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(DimJob,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.Dimension", # implemenation name
                                         ("org.openoffice.comp.pyuno.Dimension",),)    # list of implemented services
