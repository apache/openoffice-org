#	$Id: cutmousehandler.py,v 1.1 2006-07-16 10:02:12 gerard Exp $
# -*- coding: latin-1 -*-
## ********************************************************************************
## 
## Copyright (C) 2006 G�rard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    import math, traceback
    from com.sun.star.task import XJob
    from com.sun.star.drawing.CircleKind import ARC
except ImportError:
    print "probleme d'import"
# ===================================================
# Gerer les saisies de points et validation d'entites
# Handle points inputs and entities validation
# ===================================================
class CutMouseHandler(unohelper.Base, XJob):
    """Gere les saisies de points et validation d'entite
    Handles points inputs and entities validation"""
    def __init__(self, ctx):
        self.ctx = ctx
        self.smgr = self.ctx.ServiceManager
        self.aEntityPosSize = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.EntityPosSize", self.ctx)
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.smgr.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # **********************************
    # Handles mouse clicks
    # MOUSEEVENT  struct MouseEvent
    # CANCELJOB   integer (0 or 1)
    # STEP
    # COORDS
    # REPEATMODE
    # SHAPE
    # **********************************
    def execute(self, aArgs):
        aEnv = dict(list(aArgs[0].Value))
        nPrecis = 0
        aNamedValues = (uno.createUnoStruct("com.sun.star.beans.NamedValue"), uno.createUnoStruct("com.sun.star.beans.NamedValue"))
        # ----------------------------------------
        if aEnv['MOUSEEVENT'].Buttons > 1: # don't handle mouse buttons but left
            aNamedValues[0].Value = tuple(aEnv)
            return aNamedValues
        # --------------------------------------------
        if aEnv['MOUSEEVENT'].ClickCount == 1: # one click ?
            # --------edit the spotted shape if one------------------
            if aEnv['SPOTTEDSHAPE']:
                aShapeCoords = [list(c) for c in aEnv['COORDS']]
                i = aEnv['SPOTTEDSHAPE'][0][-1]
                aShape = aEnv['GROUPSHAPE'].getByIndex(i)
                aType = aShape.getShapeType().split('.')[-1]
                aStyle = aShape.Style
                aCoords = [uno.createUnoStruct("com.sun.star.awt.Point") for i in range(2)]
                aEnv['GROUPSHAPE'].remove(aEnv['SHAPE'])
                aEnv['SHAPE'] = None
                # ----------------------------------------------------------
                if aType in ("LineShape", "EllipseShape", "RectangleShape"):
                    # ---------------------------------------------------------------------------------------
                    if aEnv['SPOTTEDSHAPE'][1] in ("LineShape", "ArcCircleShape", "ArcEllipseShape"):
                        # -------------------------------------------
                        if aEnv['SPOTTEDSHAPE'][1] == "LineShape":
                            aCoords[0].X, aCoords[0].Y = aEnv['SPOTTEDSHAPE'][2].X, aEnv['SPOTTEDSHAPE'][2].Y
                            aCoords[1].X, aCoords[1].Y = aEnv['SPOTTEDSHAPE'][3].X, aEnv['SPOTTEDSHAPE'][3].Y
                        # ---
                        else:
                            aPoint = self.compute("PointOnEllipse", None, aEnv['SPOTTEDSHAPE'][5], *aEnv['SPOTTEDSHAPE'][2:5])[0]
                            aCoords[0].X, aCoords[0].Y = aPoint.X, aPoint.Y
                            aPoint = self.compute("PointOnEllipse", None, aEnv['SPOTTEDSHAPE'][6], *aEnv['SPOTTEDSHAPE'][2:5])[0]
                            aCoords[1].X, aCoords[1].Y = aPoint.X, aPoint.Y
                            if aType in ("RectangleShape",):
                                aEnv['CIRCLEKIND'] = ARC
                            else:
                                aEnv['CIRCLEKIND'] = aShape.CircleKind
                        # -----------------------
                        for i,j in ((-2,-1),(-1,-2)):
                            # ---------------------------------------
                            if aEnv['BORDERLIST'][i+2][0] >= nPrecis:
                                aShapeCoords[0][i].X, aShapeCoords[0][i].Y = aCoords[i].X, aCoords[i].Y
                                aShapeCoords[0][j].X, aShapeCoords[0][j].Y = aEnv['BORDERLIST'][i+2][2].X, aEnv['BORDERLIST'][i+2][2].Y
                                aEnv['COORDS'] = tuple([tuple(c) for c in aShapeCoords])
                                aEnv['STEP'] = len(aEnv['COORDS'][0]) - 1
                                aNamedValues[0].Value = tuple(aEnv.items())
                                aEnv = dict(list(self.aEntityPosSize.execute(aNamedValues)[0].Value))
                                aEnv['SHAPE'].Style = aStyle
                                aEnv['SHAPE'].setName("")
                                aEnv['SHAPE'] = None
                    # ----------------------------------------------------------------------
                    elif aEnv['SPOTTEDSHAPE'][1] in ("CircleShape", "EllipseShape"):
                        aShapeCoords[0][-1], aShapeCoords[0][-2] = aShapeCoords[0][-2], aShapeCoords[0][-1]
                        aEnv['COORDS'] = tuple([tuple(c) for c in aShapeCoords])
                        aEnv['STEP'] = len(aEnv['COORDS'][0]) - 1
                        aNamedValues[0].Value = tuple(aEnv.items())
                        aEnv = dict(list(self.aEntityPosSize.execute(aNamedValues)[0].Value))
                        aEnv['SHAPE'].Style = aStyle
                        aEnv['SHAPE'].setName("")
                        aEnv['SHAPE'] = None
                    # ---------------------------
                    if aType == "RectangleShape": # Rectangle
                        i = 1
                        # -------------------------------------------------
                        for aSplit in aEnv['SPLITTEDSHAPE']:
                            # -----------------------------------------
                            if i != aEnv['SPOTTEDSHAPE'][-1]: # to do ?
                                # ----------------------------------------------------
                                if aSplit[1] == "LineShape":
                                    aEnv['UNOTYPE'] = "LineShape"
                                    aEnv['ENTITYPE'] = "LINE"
                                    aEnv['STEP'] = 1
                                    aEnv['MODE'] = (aEnv['MODE'][0],) + ("VERTEX",)
                                    aShapeCoords = [[aSplit[2], aSplit[3]]]
                                else:
                                    aEnv['UNOTYPE'] = "EllipseShape"
                                    aEnv['ENTITYPE'] = "ARC"
                                    aEnv['CIRCLEKIND'] = ARC
                                    aEnv['STEP'] = 3
                                    aEnv['MODE'] = (aEnv['MODE'][0],) + ("RADIUS", "STARTANGLE", "ENDANGLE")
                                    aShapeCoords = [[uno.createUnoStruct("com.sun.star.awt.Point") for j in range(4)]]
                                    aShapeCoords[0][0].X, aShapeCoords[0][0].Y = aSplit[2].X, aSplit[2].Y
                                    nRadius = aSplit[3].Width
                                    aShapeCoords[0][1].X, aShapeCoords[0][1].Y = aSplit[2].X + nRadius, aSplit[2].Y
                                    aShapeCoords[0][2].X = aSplit[2].X + nRadius * math.cos(aSplit[5])
                                    aShapeCoords[0][2].Y = aSplit[2].Y - nRadius * math.sin(aSplit[5])
                                    aShapeCoords[0][3].X = aSplit[2].X + nRadius * math.cos(aSplit[6])
                                    aShapeCoords[0][3].Y = aSplit[2].Y - nRadius * math.sin(aSplit[6])
                                aEnv['COORDS'] = tuple([tuple(c) for c in aShapeCoords])
                                aNamedValues[0].Value = tuple(aEnv.items())
                                aEnv = dict(list(self.aEntityPosSize.execute(aNamedValues)[0].Value))
                                aEnv['SHAPE'].Style = aStyle
                                aEnv['SHAPE'].setName("")
                                aEnv['SHAPE'] = None
                            i = i + 1
                # --------------------------------------------------
                elif aType in ("PolyLineShape", "PolyPolygonShape"):
                    idx = 0
                    aShapeCoords = []
                    bNewPoint = True
                    # ------------------------------------
                    for aPolygon in aShape.PolyPolygon[:]:
                        aShapeCoords.append([])
                        # ----------------------------
                        for i in range(len(aPolygon)):
                            if bNewPoint:
                                aShapeCoords[-1].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                            bNewPoint = True
                            idx = idx + 1
                            # ------------------------------------
                            if aEnv['SPOTTEDSHAPE'][-1] == idx:
                                #----------------------------------
                                if aEnv['BORDERLIST'][0][0] > nPrecis: # left border ?
                                    aShapeCoords[-1][-1].X = aPolygon[i].X
                                    aShapeCoords[-1][-1].Y = aPolygon[i].Y
                                    aShapeCoords[-1].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                                    aShapeCoords[-1][-1].X = aEnv['BORDERLIST'][0][2].X
                                    aShapeCoords[-1][-1].Y = aEnv['BORDERLIST'][0][2].Y
                                    if i < len(aPolygon) - 2:
                                        aShapeCoords.append([])
                                #----------------------------------
                                if aEnv['BORDERLIST'][1][0] > nPrecis: # right border ?
                                    # ---------------------------------
                                    if aEnv['BORDERLIST'][0][0] > nPrecis: # left border ?
                                        # -----------------------
                                        if i < len(aPolygon) - 2:
                                            aShapeCoords[-1].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                                        else:
                                            aShapeCoords[-1].append([uno.createUnoStruct("com.sun.star.awt.Point")])
                                    # ---------
                                    elif i > 0:
                                        aShapeCoords[-1][-1].X = aPolygon[i].X
                                        aShapeCoords[-1][-1].Y = aPolygon[i].Y
                                        aShapeCoords.append([uno.createUnoStruct("com.sun.star.awt.Point")])
                                    aShapeCoords[-1][-1].X = aEnv['BORDERLIST'][1][2].X
                                    aShapeCoords[-1][-1].Y = aEnv['BORDERLIST'][1][2].Y
                                # ---------------------------------------
                                elif not aEnv['BORDERLIST'][0][0] > nPrecis:
                                    if i == 0:
                                        bNewPoint = False
                                    else:
                                        aShapeCoords[-1][-1].X = aPolygon[i].X
                                        aShapeCoords[-1][-1].Y = aPolygon[i].Y
                                        if i < len(aPolygon) - 2:
                                            aShapeCoords.append([])
                                        else:
                                            break
                            else:
                                aShapeCoords[-1][-1].X = aPolygon[i].X
                                aShapeCoords[-1][-1].Y = aPolygon[i].Y
                        idx = idx - 1
                    aEnv['COORDS'] = tuple([tuple(i) for i in aShapeCoords])
                    aEnv['UNOTYPE'] = "PolyLineShape"
                    aEnv['ENTITYPE'] = "POLYGON"
                    aEnv['STEP'] = 1
                    aEnv['MODE'] = (aEnv['MODE'][0],) + ("VERTEX",)
                    aNamedValues[0].Value = tuple(aEnv.items())
                    aEnv = dict(list(self.aEntityPosSize.execute(aNamedValues)[0].Value))
                    aEnv['SHAPE'].Style = aStyle
                    aEnv['SHAPE'].setName("")
                    aEnv['SHAPE'] = None
                aEnv['GROUPSHAPE'].remove(aShape)
                # ----------------------------
                if aEnv['REPEATMODE']: # repeat mode on ?
                    aEnv['VALIDLIST'] = False
                    aEnv['SHAPE'] = None
                    aEnv['GROUPSHAPE'] = aEnv['CONTROLLER'].getCurrentPage()
                else:
                    aEnv['STOPJOB'] = True
            else:
                aEnv['STOPJOB'] = True
        aNamedValues[0].Value = tuple(aEnv.items())
        return aNamedValues
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(CutMouseHandler,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.CutMouseHandler", # implemenation name
                                         ("org.openoffice.comp.pyuno.CutMouseHandler",),)    # list of implemented services
