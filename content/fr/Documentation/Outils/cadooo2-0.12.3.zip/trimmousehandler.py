#	$Id: trimmousehandler.py,v 1.1 2006-07-16 10:02:14 gerard Exp $
## ********************************************************************************
## 
## Copyright (C) 2005 G�ard Deneux
## gerard.deneux@free.fr

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU Lesser General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## Lesser General Public License for more details.
## http://www.opensource.org/licenses/lgpl-license.php

## You should have received a copy of the GNU Lesser General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
## ******************************************************************************
try:
    import uno, unohelper
    import math
    from com.sun.star.task import XJob
except ImportError:
    print "probleme d'import"
# ===================================================
# Gerer les saisies de points et validation d'entites
# Handle points inputs and entities validation
# ===================================================
class TrimMouseHandler(unohelper.Base, XJob):
    """Gere les saisies de points et validation d'entite
    Handles points inputs and entities validation"""
    def __init__(self, ctx):
        self.ctx = ctx
        # get the central desktop object
        desktop = self.ctx.ServiceManager.createInstanceWithContext( "com.sun.star.frame.Desktop",self.ctx)
        # access the current draw document
        self.aController = desktop.CurrentComponent.CurrentController
        # Struct needed to pass arguments throught UNO
        self.aEntityPosSize = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.EntityPosSize", self.ctx)
    # =========================================
    # wrapper for the compute functions
    # =========================================
    def compute(self, sMethod, *aArgs):
        aCompute = self.ctx.ServiceManager.createInstanceWithContext("org.openoffice.comp.pyuno.Compute", self.ctx)
        aComputeNamedValues = []
        n = len(aArgs) + 2
        for i in range(n):
            aComputeNamedValues.append(uno.createUnoStruct("com.sun.star.beans.NamedValue"))
            if i == 0:
                aComputeNamedValues[i].Name = "Function"
                aComputeNamedValues[i].Value = sMethod
            elif i < n-1:
                aComputeNamedValues[i].Name = "Param%d" % i
                aComputeNamedValues[i].Value = aArgs[i-1]
            else:
                aComputeNamedValues[i].Name = "Result"
        aComputeNamedValues = list(aCompute.execute(tuple(aComputeNamedValues),))
        return aComputeNamedValues[n-1].Value
    # **********************************
    # Handles mouse clicks
    # MOUSEEVENT  struct MouseEvent
    # CANCELJOB   integer (0 or 1)
    # STEP
    # COORDS
    # REPEATMODE
    # SHAPE
    # **********************************
    def execute(self, aArgs):
        aValues = dict(list(aArgs[0].Value))
        # ----------------------------------------
        if aValues['MOUSEEVENT'].Buttons > 1: # don't handle mouse buttons but left
            return aArgs
        aShapeCoords = [list(c) for c in aValues['COORDS']]
        # --------------------------------------------
        if aValues['MOUSEEVENT'].ClickCount == 1: # one click ?
            # --------------------------
            if aValues['SPOTTEDSHAPE']: # edit mode on ?
                i = aValues['SPOTTEDSHAPE'][0][-1]
                aShape = aValues['GROUPSHAPE'].getByIndex(i)
                aType = aShape.getShapeType().split('.')[-1]
                aStyle = aShape.Style
                aCoords = [uno.createUnoStruct("com.sun.star.awt.Point") for i in range(2)]
                aValues['GROUPSHAPE'].remove(aValues['SHAPE'])
                aValues['SHAPE'] = None
                # ----------------------------------------------------------
                if aType in ("LineShape", "EllipseShape", "RectangleShape"):
                    # ---------------------------------------------------------------------------------------
                    if aValues['SPOTTEDSHAPE'][1] in ("LineShape", "ArcCircleShape", "ArcEllipseShape"):
                        aArgs[0].Value = tuple(aValues.items())
                        aValues = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                        aValues['SHAPE'].Style = aStyle
                        aValues['SHAPE'].setName("")
                        aValues['SHAPE'] = None
                    # ---------------------------
                    if aType == "RectangleShape": # Rectangle
                        i = 1
                        # -------------------------------------------------
                        for aSplit in aValues['SPLITTEDSHAPE']:
                            # -----------------------------------------
                            if i != aValues['SPOTTEDSHAPE'][-1]: # to do ?
                                # ----------------------------------------------------
                                if aSplit[1] == "LineShape":
                                    aValues['UNOTYPE'] = "LineShape"
                                    aValues['ENTITYPE'] = "LINE"
                                    aValues['STEP'] = 1
                                    aValues['MODE'] = (aValues['MODE'][0],) + ("VERTEX",)
                                    aShapeCoords = [[aSplit[2], aSplit[3]]]
                                else:
                                    aValues['UNOTYPE'] = "EllipseShape"
                                    aValues['ENTITYPE'] = "ARC"
                                    aValues['STEP'] = 3
                                    aValues['MODE'] = (aValues['MODE'][0],) + ("RADIUS", "STARTANGLE", "ENDANGLE")
                                    aShapeCoords = [[uno.createUnoStruct("com.sun.star.awt.Point") for j in range(4)]]
                                    aShapeCoords[0][0].X, aShapeCoords[0][0].Y = aSplit[2].X, aSplit[2].Y
                                    nRadius = aSplit[3].Width
                                    aShapeCoords[0][1].X, aShapeCoords[0][1].Y = aSplit[2].X + nRadius, aSplit[2].Y
                                    aShapeCoords[0][2].X = aSplit[2].X + nRadius * math.cos(aSplit[5])
                                    aShapeCoords[0][2].Y = aSplit[2].Y - nRadius * math.sin(aSplit[5])
                                    aShapeCoords[0][3].X = aSplit[2].X + nRadius * math.cos(aSplit[6])
                                    aShapeCoords[0][3].Y = aSplit[2].Y - nRadius * math.sin(aSplit[6])
                                aValues['COORDS'] = tuple([tuple(c) for c in aShapeCoords])
                                aArgs[0].Value = tuple(aValues.items())
                                aValues = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                                aValues['SHAPE'].Style = aStyle
                                aValues['SHAPE'].setName("")
                                aValues['SHAPE'] = None
                            i = i + 1
                # --------------------------------------------------
                elif aType in ("PolyLineShape", "PolyPolygonShape"):
                    idx = 0
                    aShapeCoords = []
                    # ---------------------------------
                    for aPolygon in aShape.PolyPolygon[:]:
                        aShapeCoords.append([])
                        # --------------------------
                        for i in range(len(aPolygon)):
                            aShapeCoords[-1].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                            idx = idx + 1
                            # -----------------------------------------
                            if aValues['SPOTTEDSHAPE'][-1] == idx:
                                #----------------------------------------------------------------------------------
                                if aValues['BORDERLIST'][2][0] > 0 and aValues['BORDERLIST'][2][1] <= 50: # left border ?
                                    if i > 0:
                                        aShapeCoords[-1][-1].X = aPolygon[i].X
                                        aShapeCoords[-1][-1].Y = aPolygon[i].Y
                                        aShapeCoords.append([uno.createUnoStruct("com.sun.star.awt.Point")])
                                    aShapeCoords[-1][-1].X = aValues['BORDERLIST'][2][2].X
                                    aShapeCoords[-1][-1].Y = aValues['BORDERLIST'][2][2].Y
                                #---------------------------------------------------------------------------------
                                elif aValues['BORDERLIST'][3][0] > 0 and aValues['BORDERLIST'][2][1] > 50: # right border ?
                                    aShapeCoords[-1][-1].X = aPolygon[i].X
                                    aShapeCoords[-1][-1].Y = aPolygon[i].Y
                                    aShapeCoords[-1].append(uno.createUnoStruct("com.sun.star.awt.Point"))
                                    aShapeCoords[-1][-1].X = aValues['BORDERLIST'][3][2].X
                                    aShapeCoords[-1][-1].Y = aValues['BORDERLIST'][3][2].Y
                                    if i < len(aPolygon)-2:
                                        aShapeCoords.append([])
                                else:
                                    aShapeCoords[-1][-1].X = aPolygon[i].X
                                    aShapeCoords[-1][-1].Y = aPolygon[i].Y
                            else:
                                aShapeCoords[-1][-1].X = aPolygon[i].X
                                aShapeCoords[-1][-1].Y = aPolygon[i].Y
                        idx = idx - 1
                    aValues['COORDS'] = tuple([tuple(i) for i in aShapeCoords])
                    aValues['UNOTYPE'] = aType
                    aValues['ENTITYPE'] = "POLYGON"
                    aValues['STEP'] = -1
                    aValues['MODE'] = (aValues['MODE'][0],) + ("VERTEX",)
                    aArgs[0].Value = tuple(aValues.items())
                    aValues = dict(list(self.aEntityPosSize.execute(aArgs)[0].Value))
                    aValues['SHAPE'].Style = aStyle
                    aValues['SHAPE'].setName("")
                    aValues['SHAPE'] = None
                aValues['GROUPSHAPE'].remove(aShape)
                # ----------------------------
                if aValues['REPEATMODE']: # repeat mode on ?
                    aValues['VALIDLIST'] = False
                    aValues['SHAPE'] = None
                    aValues['GROUPSHAPE'] = self.aController.getCurrentPage()
                    aShapeCoords = [[uno.createUnoStruct("com.sun.star.awt.Point")]]
                else:
                    aValues['STOPJOB'] = True
        aArgs[0].Value = tuple(aValues.items())
        return aArgs
# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

g_ImplementationHelper.addImplementation(TrimMouseHandler,                                 # UNO object class
                                         "org.openoffice.comp.pyuno.deneux.TrimMouseHandler", # implemenation name
                                         ("org.openoffice.comp.pyuno.TrimMouseHandler",),)    # list of implemented services
