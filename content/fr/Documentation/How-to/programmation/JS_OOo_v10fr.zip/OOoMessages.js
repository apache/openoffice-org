//  OOoMessages : tous les textes de messages traduisibles de la bo�te � outils

  // OOoTools module
  var OOo_serviceKO = "Impossible de cr�er le service : ";
  var OOo_connectKO = "Connexion OpenOffice impossible";
  var OOo_structureKO = "Nom de structure inconnu : ";
  var OOo_inspectionKO = "Cet objet ne peut pas �tre inspect�";
  var OOo_nbrArgsKO = "Nombre d'arguments incorrect";
  var OOo_argRank = "L'argument de rang ";
  var OOo_notString = " (d�marrant � 0) devrait �tre une cha�ne de caract�res";
  var OOo_convertToURLKO = "ConvertToURL impossible";
  var OOo_convertFromURLKO = "ConvertFromURL impossible";



  // OOo_Example module 
  var OOoMess001 = "Connect� � OpenOffice";
  var OOoMess002 = "D�connect� d'OpenOffice";
  var OOoMess105 = "Le document va fermer";
  var OOoMess107 = "La table n'est pas tri�e";
  var OOoMess108 = "La table est maintenant tri�e !";
  var OOoMess109 = "Veuillez remplir la zone ";
  var OOoMess111 = "Bonjour � tous";
  var OOoMess112 = "�crit avec ";
  var OOoMess113 = "OpenOffice.org ";

