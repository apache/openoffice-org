/*************************************************************************
 *
 *  $RCSfile: mdb_statement.cxx,v $
 *
 *  $Revision: 1.1.2.1 $
 *
 *  last change: $Author: jbu $ $Date: 2003/06/03 21:48:21 $
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Joerg Budischewski
 *
 *   Copyright: 2000 by Sun Microsystems, Inc.
 *
 *   All Rights Reserved.
 *
 *   Contributor(s): Joerg Budischewski
 *
 *
 ************************************************************************/
#include "mdb_statement.hxx"
//#include "mdb_sequenceresultset.hxx"
#include "mdb_resultset.hxx"

#include <osl/thread.h>

#include <rtl/ustrbuf.hxx>

#include <cppuhelper/typeprovider.hxx>
#include <cppuhelper/queryinterface.hxx>

#include <com/sun/star/beans/PropertyAttribute.hpp>

#include <com/sun/star/sdbc/ResultSetConcurrency.hpp>
#include <com/sun/star/sdbc/ResultSetType.hpp>

using osl::Mutex;
using osl::MutexGuard;

using rtl::OUString;
using rtl::OUStringBuffer;
using rtl::OString;

using com::sun::star::uno::Any;
using com::sun::star::uno::makeAny;
using com::sun::star::uno::Type;
using com::sun::star::uno::RuntimeException;
using com::sun::star::uno::Exception;
using com::sun::star::uno::Sequence;
using com::sun::star::uno::Reference;
using com::sun::star::uno::XInterface;

using com::sun::star::lang::IllegalArgumentException;

using com::sun::star::sdbc::XWarningsSupplier;
using com::sun::star::sdbc::XCloseable;
using com::sun::star::sdbc::XStatement;
using com::sun::star::sdbc::XResultSet;
using com::sun::star::sdbc::XConnection;
using com::sun::star::sdbc::SQLException;

using com::sun::star::beans::Property;
using com::sun::star::beans::XPropertySetInfo;
using com::sun::star::beans::XPropertySet;
using com::sun::star::beans::XFastPropertySet;
using com::sun::star::beans::XMultiPropertySet;

#define ASCII_STR(x) OUString( RTL_CONSTASCII_USTRINGPARAM( x ) )
namespace mdb_sdbc_driver
{
static ::cppu::IPropertyArrayHelper & getStatementPropertyArrayHelper()
{
    static ::cppu::IPropertyArrayHelper *pArrayHelper;
	if( ! pArrayHelper )
    {
		MutexGuard guard( Mutex::getGlobalMutex() );
		if( ! pArrayHelper )
        {
            static Property aTable[] =
                {
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("CursorName") ), 0,
                        ::getCppuType( (OUString *)0) , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("EscapeProcessing") ), 0,
                        ::getBooleanCppuType() , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("FetchDirection") ), 0,
                        ::getCppuType( (sal_Int32 *)0) , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("FetchSize") ), 0,
                        ::getCppuType( (sal_Int32 *)0) , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("MaxFieldSize") ), 0,
                        ::getCppuType( (sal_Int32 *)0) , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("MaxRows") ), 0,
                        ::getCppuType( (sal_Int32 *)0) , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("QueryTimeOut") ), 0,
                        ::getCppuType( (sal_Int32 *)0) , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("ResultSetConcurrency") ), 0,
                        ::getCppuType( (sal_Int32 *)0) , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("ResultSetType") ), 0,
                        ::getCppuType( (sal_Int32 *)0) , 0 )
                };
            OSL_ASSERT( sizeof(aTable)/ sizeof(Property)  == STATEMENT_SIZE );
			static ::cppu::OPropertyArrayHelper arrayHelper( aTable, STATEMENT_SIZE, sal_True );
            pArrayHelper = &arrayHelper;
        }
    }
    return *pArrayHelper;
}

Statement::Statement( const ::rtl::Reference< RefCountedMutex > & refMutex,
                      const Reference< XConnection > & conn,
                      struct ConnectionSettings *pSettings )
    : OComponentHelper( refMutex->mutex ),
      OPropertySetHelper( OComponentHelper::rBHelper ),
      m_refMutex( refMutex ),
      m_connection( conn ), 
      m_pSettings( pSettings )
{
    m_props[STATEMENT_QUERY_TIME_OUT] = makeAny( (sal_Int32)0 );
    m_props[STATEMENT_MAX_ROWS] = makeAny( (sal_Int32)0 );
    m_props[STATEMENT_RESULT_SET_CONCURRENCY] = makeAny(
        com::sun::star::sdbc::ResultSetConcurrency::READ_ONLY );
    m_props[STATEMENT_RESULT_SET_TYPE] = makeAny(
        com::sun::star::sdbc::ResultSetType::SCROLL_INSENSITIVE );    
}

Statement::~Statement()
{
    POSTGRE_TRACE( "dtor Statement" );
}

void Statement::checkClosed() throw (SQLException, RuntimeException )
{
    if( ! m_pSettings || ! m_pSettings->pConnection )
        throw SQLException(
            ASCII_STR("mdb_driver: Statement or connection has already been closed !" ),
            *this, OUString(),1,Any());
}

Any Statement::queryInterface( const Type & reqType ) throw (RuntimeException)
{
    Any ret;

    ret = OComponentHelper::queryInterface( reqType );
    if( ! ret.hasValue() )
        ret = ::cppu::queryInterface( reqType,
                                    static_cast< XWarningsSupplier * > ( this  ),
                                    static_cast< XStatement * > ( this ),
                                    static_cast< XCloseable * > ( this ),
                                    static_cast< XPropertySet * > ( this ),
                                    static_cast< XMultiPropertySet * > ( this ),
                                    static_cast< XFastPropertySet * > ( this ) );
    return ret;
}


Sequence< Type > Statement::getTypes() throw ( RuntimeException )
{
    static cppu::OTypeCollection *pCollection;
    if( ! pCollection )
    {
        MutexGuard guard( osl::Mutex::getGlobalMutex() );
        if( !pCollection )
        {
            static cppu::OTypeCollection collection(
                getCppuType( (Reference< XWarningsSupplier> *) 0 ),
                getCppuType( (Reference< XStatement> *) 0 ),
                getCppuType( (Reference< XCloseable> *) 0 ),
                getCppuType( (Reference< XPropertySet >*) 0 ),
                getCppuType( (Reference< XFastPropertySet > *) 0 ),
                getCppuType( (Reference< XMultiPropertySet > *) 0 ),
                OComponentHelper::getTypes());
            pCollection = &collection;
        }
    }
    return pCollection->getTypes();
}

Sequence< sal_Int8> Statement::getImplementationId() throw ( RuntimeException )
{
    static cppu::OImplementationId *pId;
    if( ! pId )
    {
        MutexGuard guard( osl::Mutex::getGlobalMutex() );
        if( ! pId )
        {
            static cppu::OImplementationId id(sal_False);
            pId = &id;
        }
    }
    return pId->getImplementationId();
}

void Statement::close(  ) throw (SQLException, RuntimeException)
{
    // let the connection die without acquired mutex !
    Reference< XConnection > r;
    Reference< XCloseable > resultSet;
    {
        MutexGuard guard( m_refMutex->mutex );
        m_pSettings = 0;
        r = m_connection;
        m_connection.clear();
        
        resultSet = m_lastResultset;
        m_lastResultset.clear();
    }
    if( resultSet.is() )
    {
        resultSet->close();
        POSTGRE_TRACE( "statement closed" );
    }

}

void Statement::raiseSQLException(
    const OUString & sql, const char * errorMsg, const char *errorType )
    throw( SQLException )
{
    OUStringBuffer buf(128);
    buf.appendAscii( "mdb_driver: ");
    if( errorType )
    {
        buf.appendAscii( "[" );
        buf.appendAscii( errorType );
        buf.appendAscii( "]" );
    }
    buf.append(
        rtl::OStringToOUString( errorMsg, strlen(errorMsg) , m_pSettings->encoding ) );
    buf.appendAscii( " (caused by statement '" );
    buf.append( sql );
    buf.appendAscii( "')" );
    throw SQLException( buf.makeStringAndClear(), *this, OUString(), 1, Any() );
}
    
::com::sun::star::uno::Reference< XResultSet > Statement::executeQuery(const OUString& sql )
        throw (SQLException, RuntimeException)
{
    osl::ClearableMutexGuard guard( m_refMutex->mutex );
    checkClosed();
    OString o = rtl::OUStringToOString( sql, m_pSettings->encoding );
	AnyVector aRows;
    Sequence< OUString > seqColumns;
	if (!mdb_ExecuteQuery(
			m_pSettings->pConnection,o,aRows,seqColumns)
		)
	{
 	   return new ResultSet(
    	    m_refMutex, *this, Sequence< OUString >(), Sequence< Sequence< Any > > (), m_pSettings->tc );
	}

    return new ResultSet(
        m_refMutex, *this,    seqColumns,
        Sequence< Sequence< Any > > ( &aRows[0],aRows.size() ), m_pSettings->tc );
}

sal_Int32 Statement::executeUpdate( const OUString& sql )
        throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    OString o = rtl::OUStringToOString( sql, m_pSettings->encoding );

    POSTGRE_TRACE_1( "mdb_statement: executing update %s\n" , o.getStr() );
//    PGresult *result = PQexec( m_pSettings->pConnection, o.getStr() );
//    if( ! result )
//        raiseSQLException( sql, PQerrorMessage( m_pSettings->pConnection ) );

//    ExecStatusType state = PQresultStatus( result );
/*
    switch( state )
    {
    case PGRES_COMMAND_OK:
        break; 
    case PGRES_TUPLES_OK: // success
        raiseSQLException( sql, "not a command" );
        break; 
    case PGRES_EMPTY_QUERY:
    case PGRES_COPY_OUT:
    case PGRES_COPY_IN:
    case PGRES_BAD_RESPONSE:
    case PGRES_NONFATAL_ERROR:
    case PGRES_FATAL_ERROR:
    default:
        raiseSQLException( sql, PQresultErrorMessage( result ) , PQresStatus( state ) );
    }
    sal_Int32 affectedTuples = atoi( PQcmdTuples(result) );
    PQclear( result );
*/
    sal_Int32 affectedTuples = 1;
    return affectedTuples;
}

sal_Bool Statement::execute( const OUString& sql )
        throw (SQLException, RuntimeException)
{
    throw SQLException( ASCII_STR( "mdb_statement: execute() method is not supported, use executeUpdate or executeQuery instead" ),
                        *this, OUString() , 1 , Any () );
    return sal_False;
}

Reference< XConnection > Statement::getConnection(  )
        throw (SQLException, RuntimeException)
{
    Reference< XConnection > ret;
    {
        MutexGuard guard( m_refMutex->mutex );
        checkClosed();
        ret = m_connection;
    }
    return ret;
}


Any Statement::getWarnings(  )
        throw (SQLException,RuntimeException)
{
    return Any();
}

void Statement::clearWarnings(  )
        throw (SQLException, RuntimeException)
{
}

::cppu::IPropertyArrayHelper & Statement::getInfoHelper()
{
    return getStatementPropertyArrayHelper(); 
}


sal_Bool Statement::convertFastPropertyValue(
		Any & rConvertedValue, Any & rOldValue, sal_Int32 nHandle, const Any& rValue )
		throw (IllegalArgumentException)
{
    sal_Bool bRet;
    switch( nHandle )
    {
    case STATEMENT_CURSOR_NAME:
    {
        OUString val;
        bRet = ( rValue >>= val );
        m_props[nHandle] = makeAny( val );
        break;
    }
    case STATEMENT_ESCAPE_PROCESSING:
    {
        sal_Bool val;
        bRet = ( rValue >>= val );
        m_props[nHandle] = makeAny( val );
        break;
    }
    case STATEMENT_FETCH_DIRECTION:
    case STATEMENT_FETCH_SIZE:
    case STATEMENT_MAX_FIELD_SIZE:
    case STATEMENT_MAX_ROWS:
    case STATEMENT_QUERY_TIME_OUT:
    case STATEMENT_RESULT_SET_CONCURRENCY:
    case STATEMENT_RESULT_SET_TYPE:
    {
        sal_Int32 val;
        bRet = ( rValue >>= val );
        m_props[nHandle] = makeAny( val );
        break;
    }
    default:
    {
        OUStringBuffer buf(128);
        buf.appendAscii( "mdb_statement: Invalid property handle (" );
        buf.append( nHandle );
        buf.appendAscii( ")" );
        throw IllegalArgumentException( buf.makeStringAndClear(), *this, 2 );
    }
    }
    return bRet;
}
    

void Statement::setFastPropertyValue_NoBroadcast(
    sal_Int32 nHandle,const Any& rValue ) throw (Exception)
{
    m_props[nHandle] = rValue;
}

void Statement::getFastPropertyValue( Any& rValue, sal_Int32 nHandle ) const
{
    rValue = m_props[nHandle];
}

Reference < XPropertySetInfo >  Statement::getPropertySetInfo()
        throw(RuntimeException)
{
    return OPropertySetHelper::createPropertySetInfo( getStatementPropertyArrayHelper() );
}

void Statement::disposing()
{
    close();
}


}

