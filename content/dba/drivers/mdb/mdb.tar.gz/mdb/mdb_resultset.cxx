/*************************************************************************
 *
 *  $RCSfile: mdb_resultset.cxx,v $
 *
 *  $Revision: 1.1.2.1 $
 *
 *  last change: $Author: jbu $ $Date: 2003/06/03 21:48:19 $
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Joerg Budischewski
 *
 *   Copyright: 2000 by Sun Microsystems, Inc.
 *
 *   All Rights Reserved.
 *
 *   Contributor(s): Joerg Budischewski
 *
 *
 ************************************************************************/
#include <osl/thread.h>

#include <rtl/ustrbuf.hxx>

#include <cppuhelper/typeprovider.hxx>
#include <cppuhelper/queryinterface.hxx>

#include "mdb_statement.hxx"
#include "mdb_resultset.hxx"
#include "mdb_resultsetmetadata.hxx"

#include <com/sun/star/lang/DisposedException.hpp>

using osl::Mutex;
using osl::MutexGuard;

using rtl::OUString;
using rtl::OUStringToOString;
using rtl::OUStringBuffer;
using rtl::OString;

using com::sun::star::beans::XPropertySetInfo;
using com::sun::star::beans::XPropertySet;
using com::sun::star::beans::XMultiPropertySet;
using com::sun::star::beans::XFastPropertySet;

using com::sun::star::uno::Any;
using com::sun::star::uno::makeAny;
using com::sun::star::uno::Type;
using com::sun::star::uno::RuntimeException;
using com::sun::star::uno::Exception;
using com::sun::star::uno::Sequence;
using com::sun::star::uno::Reference;
using com::sun::star::uno::XInterface;

using com::sun::star::lang::IllegalArgumentException;

using com::sun::star::sdbc::XWarningsSupplier;
using com::sun::star::sdbc::XCloseable;
using com::sun::star::sdbc::XStatement;
using com::sun::star::sdbc::XResultSet;
using com::sun::star::sdbc::XConnection;
using com::sun::star::sdbc::SQLException;
using com::sun::star::sdbc::XRow;
using com::sun::star::sdbc::XColumnLocate;
using com::sun::star::sdbc::XResultSetMetaData;
using com::sun::star::sdbc::XResultSetMetaDataSupplier;


using com::sun::star::beans::Property;

namespace mdb_sdbc_driver
{
#define ASCII_STR(x) OUString( RTL_CONSTASCII_USTRINGPARAM( x ) )

static ::cppu::IPropertyArrayHelper & getResultSetPropertyArrayHelper()
{
    static ::cppu::IPropertyArrayHelper *pArrayHelper;
	if( ! pArrayHelper )
    {
		MutexGuard guard( Mutex::getGlobalMutex() );
		if( ! pArrayHelper )
        {
            static Property aTable[] =
                {
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("CursorName") ), 0,
                        ::getCppuType( (OUString *)0) , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("EscapeProcessing") ), 0,
                        ::getBooleanCppuType() , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("FetchDirection") ), 0,
                        ::getCppuType( (sal_Int32 *)0) , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("FetchSize") ), 0,
                        ::getCppuType( (sal_Int32 *)0) , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("ResultSetConcurrency") ), 0,
                        ::getCppuType( (sal_Int32 *)0) , 0 ),
                    Property(
                        OUString( RTL_CONSTASCII_USTRINGPARAM("ResultSetType") ), 0,
                        ::getCppuType( (sal_Int32 *)0) , 0 )
                };
            OSL_ASSERT( sizeof(aTable) / sizeof(Property) == RESULTSET_SIZE );
			static ::cppu::OPropertyArrayHelper arrayHelper( aTable, RESULTSET_SIZE, sal_True );
            pArrayHelper = &arrayHelper;
        }
    }
    return *pArrayHelper;
}

ResultSet::ResultSet( const ::rtl::Reference< RefCountedMutex > & refMutex,
                      const Reference< XInterface > & owner,
                      ConnectionSettings **ppSettings,
                      void * result )
    : OComponentHelper( refMutex->mutex ),
      OPropertySetHelper( OComponentHelper::rBHelper ),
      m_refMutex( refMutex ),
      m_owner( owner ),
      m_row( -1 ),
      m_ppSettings( ppSettings ),
      m_result( result )
{
    POSTGRE_TRACE( "ctor ResultSet" );
//    m_rowCount = PQntuples( m_result );
//    m_fieldCount = PQnfields( m_result );
    m_row = -1;
}

ResultSet::ResultSet( const ::rtl::Reference< RefCountedMutex > & refMutex,
                      const Reference< XInterface > & owner,
    const Sequence< OUString > &colNames,
    const Sequence< Sequence< Any > > &data,
    const Reference< com::sun::star::script::XTypeConverter > & tc) :
    m_data(data ),
    m_columnNames( colNames ),
    OComponentHelper( refMutex->mutex ),
    OPropertySetHelper( OComponentHelper::rBHelper ),
    m_refMutex( refMutex ),
    m_owner( owner ),
    m_row( -1 )
{
    m_rowCount = data.getLength();
    m_fieldCount = colNames.getLength();
    m_row = -1;
}


ResultSet::~ResultSet()
{
}

Any ResultSet::queryInterface( const Type & reqType ) throw (RuntimeException)
{
    Any ret;

    ret = OComponentHelper::queryInterface( reqType );
    if( ! ret.hasValue() )
        ret = ::cppu::queryInterface( reqType,
                                    static_cast< XResultSet * > ( this  ),
                                    static_cast< XResultSetMetaDataSupplier * > ( this ),
                                    static_cast< XRow * > ( this ),
                                    static_cast< XColumnLocate * > ( this ),
                                    static_cast< XCloseable * > ( this ),
                                    static_cast< XPropertySet * > ( this ),
                                    static_cast< XMultiPropertySet * > ( this ),
                                    static_cast< XFastPropertySet * > ( this ) );
    return ret;
}

void ResultSet::close(  ) throw (SQLException, RuntimeException)
{
    Reference< XInterface > owner;
    {
        MutexGuard guard( m_refMutex->mutex );
        if( m_result )
        {
//            PQclear(m_result );
            m_result = 0;
            m_row = -1;
        }
        owner = m_owner;
        m_owner.clear();
    }
}

Sequence<Type > ResultSet::getTypes() throw( RuntimeException )
{
    static cppu::OTypeCollection *pCollection;
    if( ! pCollection )
    {
        MutexGuard guard( osl::Mutex::getGlobalMutex() );
        if( !pCollection )
        {
            static cppu::OTypeCollection collection(
                getCppuType( (Reference< XResultSet> *) 0 ),
                getCppuType( (Reference< XResultSetMetaDataSupplier> *) 0 ),
                getCppuType( (Reference< XRow> *) 0 ),
                getCppuType( (Reference< XColumnLocate> *) 0 ),
                getCppuType( (Reference< XCloseable> *) 0 ),
                getCppuType( (Reference< XPropertySet >*) 0 ),
                getCppuType( (Reference< XFastPropertySet > *) 0 ),
                getCppuType( (Reference< XMultiPropertySet > *) 0 ),
                OComponentHelper::getTypes());
            pCollection = &collection;
        }
    }
    return pCollection->getTypes();
}

Sequence< sal_Int8> ResultSet::getImplementationId() throw( RuntimeException )
{
    static cppu::OImplementationId *pId;
    if( ! pId )
    {
        MutexGuard guard( osl::Mutex::getGlobalMutex() );
        if( ! pId )
        {
            static cppu::OImplementationId id(sal_False);
            pId = &id;
        }
    }
    return pId->getImplementationId();
}

Reference< XResultSetMetaData > ResultSet::getMetaData(  ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
	return
    	new ResultSetMetaData(m_refMutex, this, m_columnNames);
}

sal_Bool ResultSet::next(  ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    m_row ++;
    return m_row < m_rowCount;
}

sal_Bool ResultSet::isBeforeFirst(  ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    return m_row == -1;
}

sal_Bool ResultSet::isAfterLast(  ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    return m_row >= m_rowCount;
}
    
sal_Bool ResultSet::isFirst(  ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    return m_row == 0 && m_rowCount;
}

sal_Bool ResultSet::isLast(  ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    return m_row >= 0 && m_row + 1 == m_rowCount;
}

void ResultSet::beforeFirst(  ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    m_row = -1;
}

void ResultSet::afterLast(  ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    m_row = m_rowCount;
}

sal_Bool ResultSet::first(  ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    sal_Bool bRet = ( m_rowCount > 0 );
    if( bRet )
        m_row = 0;
    return bRet;
}

sal_Bool ResultSet::last(  ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    sal_Bool bRet = ( m_rowCount > 0 );
    if( bRet )
        m_row = m_rowCount -1;
    return bRet;
}

sal_Int32 ResultSet::getRow(  ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    return m_row +1;
}

sal_Bool ResultSet::absolute( sal_Int32 row ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    if( row > 0 )
    {
        m_row = row -1;
        if( m_row > m_rowCount )
            m_row = m_rowCount;
    }
    else
    {
        m_row = m_rowCount + row;
        if( m_row < -1 )
            m_row = -1;
    }
    return sal_True;
}

sal_Bool ResultSet::relative( sal_Int32 rows ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    m_row += rows;

    if( m_row > m_rowCount )
        m_row = m_rowCount;
    else if ( m_row < -1 )
        m_row = -1;
    return sal_True;
}

sal_Bool ResultSet::previous(  ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    sal_Bool bRet = ( m_row != -1 );
    if( bRet )
        m_row --;
    return bRet;
}

void ResultSet::refreshRow(  ) throw (SQLException, RuntimeException)
{
    // TODO: not supported for now
}

sal_Bool ResultSet::rowUpdated(  ) throw (SQLException, RuntimeException)
{
    return sal_False;
}

sal_Bool ResultSet::rowInserted(  ) throw (SQLException, RuntimeException)
{
    return sal_False;
}

sal_Bool ResultSet::rowDeleted(  ) throw (SQLException, RuntimeException)
{
    return sal_False;
}

Reference< XInterface > ResultSet::getStatement() throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    return m_owner;
}


//----------------- XRow interface ----------------------------------------------------

sal_Bool ResultSet::wasNull(  ) throw (SQLException, RuntimeException)
{
    return m_wasNull;
}


OUString ResultSet::getString( sal_Int32 columnIndex ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    checkColumnIndex( columnIndex );
    return getValueAsString(  columnIndex );
}

inline Any ResultSet::convertTo( const OUString & str , const Type & type )
{
    Any aRet;
    try
    {
        aRet = (*m_ppSettings)->tc->convertTo( makeAny(str), type );
    }
    catch( com::sun::star::lang::IllegalArgumentException & e )
    {}
    catch( com::sun::star::script::CannotConvertException & e )
    {}
    return aRet;
}

sal_Bool ResultSet::getBoolean( sal_Int32 columnIndex ) throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    checkColumnIndex( columnIndex );

    sal_Bool b = sal_False;

//    m_wasNull = PQgetisnull( m_result, m_row, columnIndex -1 );
//    char * p = PQgetvalue( m_result, m_row, columnIndex -1 );
/*
    switch(p[0])
    {
    case '1':
    case 't':
    case 'T':
    case 'y':
    case 'Y':
        return sal_True;
    }
*/
    return sal_False;
}

sal_Int8 ResultSet::getByte( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    checkColumnIndex( columnIndex );
    sal_Int8 b = 0;
    convertTo( getValueAsString( columnIndex ), getCppuType( &b )) >>= b;
    return b;
}

sal_Int16 ResultSet::getShort( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    checkColumnIndex( columnIndex );
    sal_Int16 i = 0;
    convertTo( getValueAsString( columnIndex ), getCppuType( &i )) >>= i;
    return i;
}

sal_Int32 ResultSet::getInt( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    checkColumnIndex( columnIndex );
    sal_Int32 i = 0;
    convertTo( getValueAsString( columnIndex ), getCppuType( &i )) >>= i;
    return i;
}

sal_Int64 ResultSet::getLong( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    checkColumnIndex( columnIndex );
    sal_Int64 i = 0;
    convertTo( getValueAsString( columnIndex ), getCppuType( &i )) >>= i;
    return i;
}

float ResultSet::getFloat( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    checkColumnIndex( columnIndex );
    float f = 0.;
    convertTo( getValueAsString( columnIndex ), getCppuType( &f )) >>= f;
    return f;
}

double ResultSet::getDouble( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    checkColumnIndex( columnIndex );
    double d = 0.;
    convertTo( getValueAsString( columnIndex ), getCppuType( &d )) >>= d;
    return d;
}

Sequence< sal_Int8 > ResultSet::getBytes( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    checkColumnIndex( columnIndex );

//    m_wasNull = PQgetisnull( m_result, m_row, columnIndex -1 );
    size_t length;
//    char * res = (char*) PQunescapeBytea(
//        (unsigned char*) PQgetvalue( m_result, m_row, columnIndex -1 ), &length);
//    Sequence< sal_Int8 > ret( (sal_Int8*)res, length );
//    if( res )
//        free( res );
    return NULL;
}

::com::sun::star::util::Date ResultSet::getDate( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    return com::sun::star::util::Date();
}

::com::sun::star::util::Time ResultSet::getTime( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    return com::sun::star::util::Time();
}

::com::sun::star::util::DateTime ResultSet::getTimestamp( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    return com::sun::star::util::DateTime();
}

Reference< ::com::sun::star::io::XInputStream > ResultSet::getBinaryStream( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    return 0;
}

Reference< ::com::sun::star::io::XInputStream > ResultSet::getCharacterStream( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    return 0;
}

Any ResultSet::getObject(
        sal_Int32 columnIndex,
        const Reference< ::com::sun::star::container::XNameAccess >& typeMap )
        throw (SQLException, RuntimeException)
{
    return Any();
}

Reference< ::com::sun::star::sdbc::XRef > ResultSet::getRef( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    return Reference< com::sun::star::sdbc::XRef > ();
}

Reference< ::com::sun::star::sdbc::XBlob > ResultSet::getBlob( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    return Reference< com::sun::star::sdbc::XBlob > ();
}

Reference< ::com::sun::star::sdbc::XClob > ResultSet::getClob( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    return Reference< com::sun::star::sdbc::XClob > ();
}

Reference< ::com::sun::star::sdbc::XArray > ResultSet::getArray( sal_Int32 columnIndex )
        throw (SQLException, RuntimeException)
{
    return Reference< com::sun::star::sdbc::XArray > ();
}


sal_Int32 ResultSet::findColumn( const ::rtl::OUString& columnName )
        throw (SQLException, RuntimeException)
{
    MutexGuard guard( m_refMutex->mutex );
    checkClosed();
    return 0;
//    return PQfnumber( m_result, OUStringToOString( columnName, (*m_ppSettings)->encoding ).getStr())+1;
}

::cppu::IPropertyArrayHelper & ResultSet::getInfoHelper()
{
    return getResultSetPropertyArrayHelper(); 
}


sal_Bool ResultSet::convertFastPropertyValue(
		Any & rConvertedValue, Any & rOldValue, sal_Int32 nHandle, const Any& rValue )
		throw (IllegalArgumentException)
{
    sal_Bool bRet;
    switch( nHandle )
    {
    case RESULTSET_CURSOR_NAME:
    {
        OUString val;
        bRet = ( rValue >>= val );
        m_props[nHandle] = makeAny( val );
        break;
    }
    case RESULTSET_ESCAPE_PROCESSING:
    {
        sal_Bool val;
        bRet = ( rValue >>= val );
        m_props[nHandle] = makeAny( val );
        break;
    }
    case RESULTSET_FETCH_DIRECTION:
    case RESULTSET_FETCH_SIZE:
    case RESULTSET_RESULT_SET_CONCURRENCY:
    case RESULTSET_RESULT_SET_TYPE:
    {
        sal_Int32 val;
        bRet = ( rValue >>= val );
        m_props[nHandle] = makeAny( val );
        break;
    }
    default:
    {
        OUStringBuffer buf(128);
        buf.appendAscii( "mdb_resultset: Invalid property handle (" );
        buf.append( nHandle );
        buf.appendAscii( ")" );
        throw IllegalArgumentException( buf.makeStringAndClear(), *this, 2 );
    }
    }
    return bRet;
}
    

void ResultSet::setFastPropertyValue_NoBroadcast(
    sal_Int32 nHandle,const Any& rValue ) throw (Exception)
{
    m_props[nHandle] = rValue;
}

void ResultSet::getFastPropertyValue( Any& rValue, sal_Int32 nHandle ) const
{
    rValue = m_props[nHandle];
}

Reference < XPropertySetInfo >  ResultSet::getPropertySetInfo()
        throw(RuntimeException)
{
    return OPropertySetHelper::createPropertySetInfo( getResultSetPropertyArrayHelper() );
}

void ResultSet::disposing()
{
    close();
}

void ResultSet::checkClosed() throw ( SQLException, RuntimeException )
{
//    if( ! m_columnNames.getLength() )
//     {
//        throw SQLException( ASCII_STR( "mdb_resultset: already closed" ), *this,  OUString(), 1, Any() );
//    }

//    if( ! m_ppSettings || ! *m_ppSettings || ! (*m_ppSettings)->pConnection )
//    {
//        throw SQLException( ASCII_STR( "mdb_resultset: statement has been closed already" ),
//                            *this, OUString(), 1, Any() );
//    }
}

void ResultSet::checkColumnIndex(sal_Int32 index ) throw ( SQLException, RuntimeException )
{
    if( index < 1 || index > m_fieldCount )
    {
        OUStringBuffer buf(128);
        buf.appendAscii( "mdb_resultset: index out of range (" );
        buf.append( index );
        buf.appendAscii( ", allowed range is 1 to " );
        buf.append( m_fieldCount );
        buf.appendAscii( ")" );
        throw SQLException( buf.makeStringAndClear(), *this, OUString(), 1, Any() );
    }

    if( m_row < 0 || m_row >= m_rowCount )
    {
        OUStringBuffer buf( 128 );
        buf.appendAscii( "mdb_resultset: row index out of range, allowed is 1 to " );
        buf.append( m_rowCount );
        buf.appendAscii( ", got " );
        buf.append( index );
        throw SQLException( buf.makeStringAndClear(), *this, OUString(),1, Any() );
    }
}
}
