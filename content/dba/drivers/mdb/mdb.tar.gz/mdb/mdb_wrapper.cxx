
#include <mdb_wrapper.hxx>


char *mdb_access_types1[] = 
	{"Unknown 0x00",
         "Boolean",
         "Byte",
         "Integer",
         "Long Integer",
         "Currency",
         "Single",
         "Double",
         "DateTime (Short)",
         "Unknown 0x09",
         "Text",
         "OLE",
         "Memo/Hyperlink",
         "Unknown 0x0d",
         "Unknown 0x0e",
  	"Replication ID",
	"Numeric"};

struct BaseTypeDef { const char * typeName; sal_Int32 length; sal_Int32 value; };
 BaseTypeDef mdb_access_types[] =
            {
                { "Unknown 0x00" , 4,	com::sun::star::sdbc::DataType::OTHER },
                { "Boolean", 		 1,	com::sun::star::sdbc::DataType::BIT },
                { "Byte" , 		 1,	com::sun::star::sdbc::DataType::SMALLINT },
                { "Integer" , 		 4,	com::sun::star::sdbc::DataType::INTEGER },
                { "Long Integer" ,   8,	com::sun::star::sdbc::DataType::BIGINT },
                { "Currency", 		 8,	com::sun::star::sdbc::DataType::DOUBLE },
                { "Single", 		 4,	com::sun::star::sdbc::DataType::REAL },
                { "Double", 		 8,	com::sun::star::sdbc::DataType::DOUBLE },
                { "DateTime(Short)", 8,	com::sun::star::sdbc::DataType::BIGINT },
                { "Unknown 0x09" , 4,	com::sun::star::sdbc::DataType::OTHER },
                { "Text", 		65535,com::sun::star::sdbc::DataType::VARCHAR },
                { "OLE" , 		0,com::sun::star::sdbc::DataType::OBJECT },
                { "Memo/Hyperlink", 65535,com::sun::star::sdbc::DataType::VARCHAR },

                { "Unknown 0x0d" , 4, com::sun::star::sdbc::DataType::OTHER },
                { "Unknown 0x0e" , 4, com::sun::star::sdbc::DataType::OTHER },
                { "Replication ID" , 16, com::sun::star::sdbc::DataType::INTEGER },
                { "Numeric" , 	8, com::sun::star::sdbc::DataType::INTEGER },

                { 0,0, 0 }

            };

	::MdbHandle * OpenMDB(char * sFileName)
	{
		MdbHandle *mdb;
	 
	  	/* initialize the library */
	 	mdb_init();
	
	 	/* open the database */
	 	
	 	if (!(mdb = mdb_open (sFileName))) {
			fprintf(stderr,"Couldn't open database.\n");
		}
		return mdb;
	}
	void CloseMDB(::MdbHandle * mdb)
	{
		mdb_free_handle (mdb);
		mdb_exit();
	}
sal_Bool getTableStrings( MdbHandle *aMdb,
                         ::std::vector< ::rtl::OUString >&   _rStrings,
                         rtl_TextEncoding encoding,
                         sal_Bool   forceLoad = sal_False )
{
int   i, j, k;
MdbHandle *mdb=aMdb;
MdbCatalogEntry *entry;
MdbTableDef *table;
MdbColumn *col;
char delimiter[4] = " | ";
int line_break=1;
int skip_sys=1;
int opt;

::std::vector< ::rtl::OUString >    m_aTableNames;
::rtl::OUString aTableName;


 	if (!mdb) {
		fprintf(stderr,"Couldn't open database.\n");
		return sal_False;
	}
	

 	/* read the catalog */
 	mdb_read_catalog (mdb, MDB_TABLE);

 	/* loop over each entry in the catalog */
 	for (i=0; i < mdb->num_catalog; i++) {
		entry = g_ptr_array_index (mdb->catalog, i);

     	/* if it's a table */
     	if (entry->object_type == MDB_TABLE) {
	 		/* skip the MSys tables */
			if (!skip_sys || strncmp (entry->object_name, "MSys", 4))
			{
				aTableName = ::rtl::OUString::createFromAscii(entry->object_name);
				m_aTableNames.push_back( aTableName ); // Table name

	       		if (line_break) 
					fprintf (stdout, "%s\n", entry->object_name);
				else if (delimiter) 
					fprintf (stdout, "%s%s", entry->object_name, delimiter);
				else 
					fprintf (stdout, "%s ", entry->object_name);
	     	}
		}
	}
	if (!line_break) 
		fprintf (stdout, "\n");

    _rStrings = m_aTableNames;
    return( sal_True );

}
sal_Bool getColumnStrings( ::MdbHandle *aMdb,
							::rtl::OUString aTableName,
                         	AnyVector  & aColumns,
                             rtl_TextEncoding encoding)
{
int   i, j, k;
MdbHandle *mdb=aMdb;
MdbCatalogEntry *entry;
MdbTableDef *table;
MdbColumn *col;
int line_break=1;
int skip_sys=0;
int opt;

::rtl::OUString 				    aColumnName;
char *mTableName=::rtl::OUStringToOString(aTableName,encoding).getStr();
if (!mTableName) return sal_False;

 	if (!mdb) {
		fprintf(stderr,"Couldn't open database.\n");
		return sal_False;
	}
	

 	/* read the catalog */
 	mdb_read_catalog (mdb, MDB_TABLE);

 	/* loop over each entry in the catalog */
 	for (i=0; i < mdb->num_catalog; i++)
 	{
		entry = g_ptr_array_index (mdb->catalog, i);
     	/* if it's a table */
     	if (entry->object_type == MDB_TABLE) 
     	{
	 		/* is wanted table */
			if (!strcmp (entry->object_name, mTableName))
			{
	    	   table = mdb_read_table (entry);

		       /* get the columns */
		       mdb_read_columns (table);
		        Sequence< Any > aRow( 18 );

	    	   /* loop over the columns, dumping the names and types */

	       		for (k = 0; k < table->num_cols; k++)
			   {
			    col = g_ptr_array_index (table->columns, k);
			    // Catalog
			    aRow[0] <<= ::rtl::OUString::createFromAscii("");
			    // Schema
			    aRow[1] <<= ::rtl::OUString::createFromAscii("");
			    // TABLE_NAME
			    aRow[2] <<=  ::rtl::OUString::createFromAscii(entry->object_name) ;
				// COLUMN_NAME
				aRow[3] <<=  ::rtl::OUString::createFromAscii(col->name);;
			    // DATA_TYPE
			    aRow[4] <<= ::rtl::OUString::valueOf( mdb_access_types[col->col_type].value ,10);
			    // TYPE_NAME, not used
			    aRow[5] <<= ::rtl::OUString::createFromAscii(mdb_access_types[col->col_type].typeName);
			    // COLUMN_SIZE
			    aRow[6] <<= ::rtl::OUString::valueOf((long)col->col_size,10);
			    // BUFFER_LENGTH, not used
			    aRow[7] <<=::rtl::OUString::createFromAscii("");
			    // DECIMAL_DIGITS.
			    aRow[8] <<= ::rtl::OUString::createFromAscii("0");
			    // NUM_PREC_RADIX
			    aRow[9] <<= ::rtl::OUString::createFromAscii("10");
			    // NULLABLE
			    aRow[10] <<= ::rtl::OUString::createFromAscii("1");
			    // REMARKS
			    aRow[11] <<= ::rtl::OUString::createFromAscii("");
			    // COULUMN_DEF, not used
			    aRow[12] <<= ::rtl::OUString::createFromAscii("");
			    // SQL_DATA_TYPE, not used
			    aRow[13] <<= ::rtl::OUString::createFromAscii("");
			    // SQL_DATETIME_SUB, not used
			    aRow[14] <<= ::rtl::OUString::createFromAscii("");
			    // CHAR_OCTET_LENGTH
			    aRow[15] <<= ::rtl::OUString::valueOf((long)mdb_access_types[col->col_type].length,10);
			    // ORDINAL_POSITION
			    aRow[16] <<= ::rtl::OUString::valueOf((long)k,10);
			    // IS_NULLABLE
			    aRow[17] <<= ::rtl::OUString::createFromAscii("YES");
			    
			    aColumns.push_back( aRow );
				 }

	     	}
		}
	}

    return( sal_True );

}

sal_Bool getTypeInfos(AnyVector & aTypes)
{
	int   i=0;
	while(mdb_access_types[i].typeName)
	{
	     Sequence< Any > aRow( 18 );

	    // TYPE_NAME
	    aRow[0] <<= ::rtl::OUString::createFromAscii(mdb_access_types[i].typeName) ;
	    // DATA_TYPE
	    aRow[1] <<= ::rtl::OUString::valueOf((long)mdb_access_types[i].value,10);
	    // PRECISION
	    aRow[2] <<=  ::rtl::OUString::valueOf((long)mdb_access_types[i].length,10);
		// LITERAL_PREFIX
		aRow[3] <<=  ::rtl::OUString::createFromAscii("\"");
	    // LITERAL_SUFFIX
	    aRow[4] <<= ::rtl::OUString::createFromAscii("\"");
	    // CREATE_PARAMS
	    aRow[5] <<= ::rtl::OUString::createFromAscii(mdb_access_types[i].typeName) ;
	    // NULLABLE
	    aRow[6] <<= ::rtl::OUString::createFromAscii("1");
	    // CASE_SENSITIVE
	    aRow[7] <<= ::rtl::OUString::createFromAscii("0");
	    // SEARCHABLE. full
	    aRow[8] <<= ::rtl::OUString::createFromAscii("3");
	    // UNSIGNED_ATTRIBUTE
	    aRow[9] <<= ::rtl::OUString::createFromAscii("0");
	    // FIXED_PREC_SCALE
	    aRow[10] <<= ::rtl::OUString::createFromAscii("1");
	    // AUTO_INCREMENT
	    aRow[11] <<= ::rtl::OUString::createFromAscii("0");
	    // LOCAL_TYPE_NAME
	    aRow[12] <<= ::rtl::OUString::createFromAscii(mdb_access_types[i].typeName) ;
	    // MINIMUM_SCALE
	    aRow[13] <<= ::rtl::OUString::createFromAscii("0");
	    // MAXIMUM_SCALE
	    aRow[14] <<= ::rtl::OUString::createFromAscii("0");
	    // SQL_DATA_TYPE
	    aRow[15] <<= ::rtl::OUString::createFromAscii("0");
	    // SQL_DATETIME_SUB
	    aRow[16] <<= ::rtl::OUString::createFromAscii("0");
	    // NUM_PREC_RADIX
	    aRow[17] <<= ::rtl::OUString::createFromAscii("10");
	
	   aTypes.push_back( aRow );
	   i++;
	}

    return( sal_True );

}

sal_Bool mdb_ExecuteQuery(
							::MdbHandle *aMdb,
							const OString& aSqlStr,
							AnyVector & aRows,
						    Sequence< OUString > &seqColumns )
{
	if (!aMdb) return sal_False;
	MdbSQL *sql=mdb_sql_init();
	if (!sql) return sal_False;
	sql->mdb=aMdb;
	sql->max_rows = -1;
	
    if (!mdbsql_run_query(sql,aSqlStr.getStr() ))
    	return sal_False;

int j;
MdbSQLColumn *sqlcol;
unsigned long row_count = 0;

	Sequence< OUString > seq( sql->num_columns );

	for (j=0;j<sql->num_columns;j++) {
		sqlcol = g_ptr_array_index(sql->columns,j);
		seq[j] = ::rtl::OUString::createFromAscii(sqlcol->name);
		fprintf(stdout, "%s%s", sqlcol->name, "|");
	}
	fprintf(stdout,"\n");
	
	seqColumns = seq;


		while((sql->max_rows == -1 || row_count < sql->max_rows)
			 && mdb_fetch_row(sql->cur_table)) 
		{
		    Sequence< Any > row( sql->num_columns );
	  		for (j=0;j<sql->num_columns;j++) {
				sqlcol = g_ptr_array_index(sql->columns,j);
				row[j] <<= ::rtl::OUString::createFromAscii(sql->bound_values[j]);
				fprintf(stdout, "%s%s", sql->bound_values[j], "|");
			}
			fprintf(stdout,"\n");
			aRows.push_back(row);
		}
	mdb_sql_reset(sql);
	
}

