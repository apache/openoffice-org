#ifndef _MDB_WRAPPER_HXX_
#define _MDB_WRAPPER_HXX_

#include <hash_map>

#ifndef _CONNECTIVITY_FDATABASEMETADATARESULTSET_HXX_
#include <FDatabaseMetaDataResultSet.hxx>
#endif

#ifndef _COMPHELPER_PROPERTY_ARRAY_HELPER_HXX_
#include <comphelper/proparrhlp.hxx>
#endif

#ifndef _COMPHELPER_PROPERTYCONTAINER_HXX_
#include <comphelper/propertycontainer.hxx>
#endif

#include <com/sun/star/lang/XInitialization.hpp>

//#include <rtl/ref.hxx>
//#include <rtl/byteseq.hxx>

#include<com/sun/star/sdbc/TransactionIsolation.hpp>
#include<com/sun/star/sdbc/ResultSetType.hpp>
#include<com/sun/star/sdbc/XPreparedStatement.hpp>
#include<com/sun/star/sdbc/XParameters.hpp>
#include<com/sun/star/sdbc/DataType.hpp>
#include<com/sun/star/sdbc/ColumnValue.hpp>

using ::osl::MutexGuard;

using ::rtl::OUString;
using ::rtl::OString;

using com::sun::star::sdbc::SQLException;
using com::sun::star::sdbc::XStatement;
using com::sun::star::sdbc::XResultSet;
using com::sun::star::sdbc::XRow;
using com::sun::star::sdbc::XCloseable;
using com::sun::star::sdbc::XParameters;
using com::sun::star::sdbc::XPreparedStatement;

using com::sun::star::uno::RuntimeException;
using com::sun::star::uno::Sequence;

using com::sun::star::uno::Reference;
using com::sun::star::uno::Sequence;
using com::sun::star::uno::Any;
using com::sun::star::uno::makeAny;
using com::sun::star::uno::UNO_QUERY;

#include "mdb_allocator.hxx"
using namespace mdb_sdbc_driver;

typedef std::vector< Sequence< Any >, Allocator< Sequence< Any > > > AnyVector;


extern "C"
{

#include <mdbsql.h>
//#include <mdbtools.h>
}

::MdbHandle * OpenMDB(char * sFileName);
void CloseMDB(::MdbHandle * mdb);

sal_Bool getTableStrings( ::MdbHandle *aMdb,
                         ::std::vector< ::rtl::OUString >&   _rStrings,
                             rtl_TextEncoding encoding,
                         sal_Bool                            forceLoad = sal_False );

sal_Bool getColumnStrings( ::MdbHandle *aMdb,
							::rtl::OUString aTableName,
                         	AnyVector  & aColumns,
                             rtl_TextEncoding encoding);
sal_Bool getTypeInfos(AnyVector & aTypes);
sal_Bool mdb_ExecuteQuery(::MdbHandle *aMdb,
							const ::rtl::OString& aSqlStr,
							AnyVector & aRows,
						    Sequence< OUString > &seqColumns );

#endif //_MDB_WRAPPER_HXX_
