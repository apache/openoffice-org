//----------------------------------------------------------------------
// Mergehelp.c
// (c) 2002 S. Brouwer (simonbr@openoffice.org)
// This software is free to distribute, modify etc. 
// provided that this copyright message is preserved in it.
//----------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include <process.h>

int
findmatchingfilename(void);

#define BUFSIZE 0x10000

void
mergehelp (); 

FILE *infile, *infile2, *outfile;

char buf1[BUFSIZE];
char buf2[BUFSIZE];


void
main (int argc, char *argv[])
{
	if ((argc==2)&&(strcmp(argv[1],"/?")==0))
	{
		puts("Merge translated help strings into OOo getcontent.out");
		puts("MERGEHELP infile infile2 outfile");
		puts("  infile specifies the translated \"getcontent.out\" file");
		puts("  infile2 specifies the original \"getcontent.out\" file");
		puts("  outfile specifies the name of the merged \"getcontent.out\" file");
		puts("(c) 2002 S. Brouwer\n This software is free to distribute, modify etc. provided that this copyright message is preserved in it.");
		exit(1);
	}

	if (argc!=4)
	{
		puts("usage: MERGEHELP infile infile2 outfile");
		puts("       MERGEHELP /?   for help");
		exit(1);
	}

	if ((infile = fopen(argv[1], "rt"))== NULL)
	{
		printf("Error: Cannot open input file %s\n", argv[1]);
		exit (1);
	}

	if ((infile2 = fopen(argv[2], "rt"))== NULL)
	{
		printf("Error: Cannot open input file %s\n", argv[2]);
		exit (1);
	}

	if ((outfile = fopen(argv[3], "wt"))== NULL)
	{
		printf("Error: Cannot open output file %s\n", argv[3]);
		exit (1);
	}

	mergehelp ();

	fclose(infile);
	fclose(infile2);
	fclose(outfile);
	exit (0);
}


void
mergehelp (char *inpath, char *outpath)
{
	int newfile;

	buf1[0]='\0';
	
	for (;;)
	{
//		printf ("\nfile name= %s", buf1+4);
		if (findmatchingfilename())
		{
			printf ("\nMerging file %s", buf1+4);
			fgets (buf1, BUFSIZE-2, infile);
			fgets (buf1, BUFSIZE-2, infile);

			fgets (buf2, BUFSIZE-2, infile2);
			fputs (buf2, outfile);
			fgets (buf2, BUFSIZE-2, infile2);
			fputs (buf2, outfile);
			
			newfile=0;
			while (!newfile)
			{
				fgets (buf1, BUFSIZE-2, infile);
				if (feof(infile))
					return;
				fputs (buf1, outfile); 

				if (strncmp (buf1, "****", 4)==0)
				{
					do 
					{
						fgets (buf2, BUFSIZE-2, infile2);
						if feof (infile2)
						{
							puts ("\nERROR: unexpected end of file"); 
							exit (1); 
						}
						if (strncmp (buf2, "####", 4)==0)
						{
							puts ("\nERROR: translated file has too few strings"); 
							exit (1); 
						}
					}while (strncmp (buf2, "****", 4)!=0);

					fgets (buf2, BUFSIZE-2, infile2); 
					fputs (buf2, outfile);
					fgets (buf1, BUFSIZE-2, infile);
				}
				else if (strncmp (buf1, "####", 4)==0)
				{
					for (;;)
					{
						fgets (buf2, BUFSIZE-2, infile2);
						if (feof(infile2))
							break;
						if (strncmp (buf2, "####", 4)==0)
							break;
						if (strncmp (buf2, "****", 4)==0)
						{
							puts ("\nERROR: translated file has too many strings");
							exit (1); 
						}
					}
					newfile=1;					
				}
			}
		}
		else
		{
			printf("."); 
			for (;;)
			{	
				fgets(buf1, BUFSIZE-2, infile);
				if (feof(infile))
					return;
				fputs(buf1, outfile);
				if (strncmp (buf1, "####", 4)==0)
				break;
			}
		}
	}
}

int
findmatchingfilename(void)
{
	rewind (infile2);
	
	while (!feof (infile2))
	{
		fgets(buf2, BUFSIZE-2, infile2);
		if (strcmp(buf1, buf2)==0)
			return (1);
	}
	return (0);
}