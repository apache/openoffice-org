#include <stdio.h>
#include <string.h>
#include <process.h>

void
getsubj (FILE *infile, FILE *outfile);


void
main (int argc, char *argv[])
{
	FILE *infile, *outfile;

	if ((argc==2)&&(strcmp(argv[1],"/?")==0))
	{
		puts("Get subject from OOo XML help file.\n");
		puts("GETSUBJ [path]infile [path]outfile\n");
		puts("  infile, outfile    specify the input and output files");
		puts("(c) 2002 S. Brouwer\n This software is free to distribute, modify etc. provided that this copyright message is preserved in it.");
		exit(1);
	}

	if (argc!=3)
	{
		puts("usage: GETSUBJ [path]infile [path]outfile\n");
		puts("       GETSUBJ /?   for help\n");
		exit(1);
	}

	if ((infile = fopen(argv[1], "rt"))== NULL)
	{
		puts("Error: Cannot open input file.");
		exit (1);
	}

	if ((outfile = fopen(argv[2], "at"))== NULL)
	{
		puts("Error: Cannot open output file.");
		exit (1);
	}

	getsubj (infile, outfile);

	fclose(infile);
	fclose(outfile);
	exit (0);
}

char buffer [200];

void
getsubj (FILE *infile, FILE *outfile)
{
	char *cp; 

	while (fgets(buffer, 198, infile)!=NULL)
	{
		if ((cp=strstr(buffer, "<dc:description>"))==NULL)
			continue;
		cp+=strlen ("<dc:description>");
		while (*cp!='<')
		{
			putc (*cp++, outfile); 
			if (cp>buffer+200)
			{
				puts ("Error: end of field not found");
				exit (1);
			}
		}
		break;
	}
	fputs (": ",outfile);

	while (fgets(buffer, 198, infile)!=NULL)
	{
		if ((cp=strstr(buffer, "<dc:subject>"))==NULL)
			continue;
		cp+=strlen ("<dc:subject>");
		while (*cp!='<')
		{
			putc (*cp++, outfile); 
			if (cp>buffer+200)
			{
				puts ("Error: end of field not found");
				exit (1);
			}
		}
		break;
	}
	fputs ("\n",outfile);
}
