//----------------------------------------------------------------------
// Mergecontrib.c
// (c) 2002 S. Brouwer (simonbr@openoffice.org)
// This software is free to distribute, modify etc. 
// provided that this copyright message is preserved in it.
//----------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include <process.h>
#include <conio.h>

int
findmatchingfilename(void);

#define BUFSIZE 0x10000

void
mergehelp (); 

FILE *infile, *infile2, *outfile;

char buf1[BUFSIZE];
char buf2[BUFSIZE];


void
main (int argc, char *argv[])
{
	if ((argc==2)&&(strcmp(argv[1],"/?")==0))
	{
		puts("Merge translated sections of t9n.txt into main t9n.txt");
		puts("MERGECONTRIB infile infile2 outfile");
		puts("  infile specifies the original \"t9n.txt\" file");
		puts("  infile2 specifies the translated partial \"t9n.txt\" file");
		puts("  outfile specifies the name of the merged \"t9n.txt\" file");
		puts("(c) 2002 S. Brouwer\n This software is free to distribute, modify etc. provided that this copyright message is preserved in it.");
		exit(1);
	}

	if (argc!=4)
	{
		puts("usage: MERGECONTRIB infile infile2 outfile");
		puts("       MERGECONTRIB /?   for help");
		exit(1);
	}

	if ((infile = fopen(argv[1], "rt"))== NULL)
	{
		printf("Error: Cannot open input file %s\n", argv[1]);
		exit (1);
	}

	if ((infile2 = fopen(argv[2], "rt"))== NULL)
	{
		printf("Error: Cannot open input file %s\n", argv[2]);
		exit (1);
	}

	if ((outfile = fopen(argv[3], "wt"))== NULL)
	{
		printf("Error: Cannot open output file %s\n", argv[3]);
		exit (1);
	}

	mergehelp ();

	fclose(infile);
	fclose(infile2);
	fclose(outfile);
	exit (0);
}


void
mergehelp (char *inpath, char *outpath)
{
	int newfile, c;

	buf1[0]='\0';
	
	for (;;)
	{
		if (findmatchingfilename())
		{
			printf ("\nProcessing file %s", buf1+4);
			fgets (buf1, BUFSIZE-2, infile); // "translated by..."

			fgets (buf2, BUFSIZE-2, infile2); // "translated by..."
			
			if (strncmp (buf2, "translated (by/date):", strlen("translated (by/date):"))!=0)
			{
				puts ("\nERROR: \"translated (by/date):\" not found");
				exit (1); 
			}
		
			if (strstr(buf2, "(not translated yet)")!=NULL)
			{
				puts ("\nERROR: \"translated by\" not updated"); 
				exit (1); 
			}
			
			if (strstr(buf1, "(not translated yet)")==NULL) // section already translated
			{				
				if (strcmp(buf1, buf2)!=0)
				{
					printf("\nWarning: Section already translated; different name and/or date found.\n");
					printf("Old: %sNew: %sOK? (Y/N): ", buf1, buf2);
					
					for (;;)
					{
						c=getche();
						if ((c=='y')||(c=='Y'))
							break;
						if ((c=='n')||(c=='N'))
						{
							puts ("\n processing aborted."); 
							exit (1); 
						}
					}
				}
			}

			fputs (buf2, outfile);

			fgets (buf1, BUFSIZE-2, infile);	// "reviewed by..."
			fgets (buf2, BUFSIZE-2, infile2);	// "reviewed by..."
			if (strncmp (buf2, "reviewed (by/date)  :", strlen("reviewed (by/date)  :"))!=0)
			{
				puts ("\nERROR: \"reviewed (by/date)  :\" not found");
				exit (1); 
			}
			fputs (buf2, outfile);
			
			newfile=0;
			while (!newfile) // while not a new line starting with #### found
			{
				fgets (buf1, BUFSIZE-2, infile);
				if (feof(infile))
					return;						// input file completely processed
				// fputs (buf1, outfile);

				if (strncmp (buf1, "****", 4)==0)	// line pair
				{
					do							
					{
						fgets (buf2, BUFSIZE-2, infile2);
						if feof (infile2)
						{
							puts ("\nERROR: unexpected end of file"); 
							exit (1); 
						}
						if (strncmp (buf2, "####", 4)==0)
						{
							puts ("\nERROR: unexpected end of section in translated file"); 
							exit (1); 
						}
						fputs (buf2, outfile);	// copy empty lines, comments, ...
					}while (strncmp (buf2, "****", 4)!=0);

					if (strcmp (buf1, buf2)!=0)
					{
						puts ("\nERROR: non-matching original strings"); 
						exit (1); 
					}
					
					fgets (buf2, BUFSIZE-2, infile2); 
					fputs (buf2, outfile);
					fgets (buf1, BUFSIZE-2, infile);
				}
				else if (strncmp (buf1, "####", 4)==0)
				{
					for (;;)					
					{
						fgets (buf2, BUFSIZE-2, infile2);
						if (feof(infile2))
							break;
						if (strncmp (buf2, "####", 4)==0)
							break;
						if (strncmp (buf2, "****", 4)==0)
						{
							puts ("\nERROR: translated file has too many strings");
							exit (1); 
						}
						fputs (buf2, outfile);
					}

					fputs (buf1, outfile);
					newfile=1;					
				}
			}
		}
		else
		{
			printf("."); // copy the original section
			for (;;)
			{	
				fgets(buf1, BUFSIZE-2, infile);
				if (feof(infile))
					return;
				fputs(buf1, outfile);
				if (strncmp (buf1, "####", 4)==0)
				break;
			}
		}
	}
}

int
findmatchingfilename(void)
{
	rewind (infile2);
	
	while (!feof (infile2))
	{
		fgets(buf2, BUFSIZE-2, infile2);
		if (strcmp(buf1, buf2)==0)
			return (1);
	}
	return (0);
}