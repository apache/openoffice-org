//----------------------------------------------------------------------
// replace.c
// (c) 2002 S. Brouwer (simonbr@openoffice.org)
// This software is free to distribute, modify etc. 
// provided that this copyright message is preserved in it.
//----------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include <process.h>

#define BUFSIZE 0x10000

void
replacestrings (char *inpath, char *outpath); 

FILE *infile, *infile2, *outfile;

int line, pos; 

char buf[BUFSIZE];
char infilepath[1024]; 
char outfilepath[1024]; 

void
main (int argc, char *argv[])
{
	if ((argc==2)&&(strcmp(argv[1],"/?")==0))
	{
		puts("replace original strings by translated ones into OOo XML help files.\n");
		puts("REPLACESTRINGS [path]infile inpath outpath\n");
		puts("  infile specifies the translation file\n");
		puts("  inpath specifies where the original XML files are");
		puts("  outpath specifies where to put the translated XML files");
		puts("(c) 2002 S. Brouwer\n This software is free to distribute, modify etc. provided that this copyright message is preserved in it.");
		exit(1);
	}

	if (argc!=4)
	{
		puts("usage: REPLACESTRINGS [path]infile inpath outpath\n");
		puts("       REPLACESTRINGS /?   for help\n");
		exit(1);
	}

	if ((infile = fopen(argv[1], "rt"))== NULL)
	{
		printf("Error: Cannot open input file %s\n", argv[1]);
		exit (1);
	}

	replacestrings (argv[2], argv[3]);

	fclose(infile);
	exit (0);
}


void
replacestrings (char *inpath, char *outpath)
{
	int line; 
	int pos;
	int orig_line, orig_pos, length; 
	int c, i; 
	unsigned char *cp, *icp; 

	infile2=NULL;
	
	for (;;)
	{
		fgets(buf, BUFSIZE-2, infile);
		if (feof (infile))
		{
			if (infile2!=NULL)
			{
				for(;;)
				{
					if ((c=fgetc(infile2))<0) // output the rest of the file
						break;
					fputc(c, outfile);					
				}
				fclose (infile2);
				fclose (outfile);
				return; 
			}
		}
		buf[strlen(buf)-1]='\0'; 
		if (strncmp("####", buf, 4)==0)
		{
			if (infile2!=NULL)
			{
				for(;;)
				{
					if ((c=fgetc(infile2))<0) // output the rest of the file
						break;
					fputc(c, outfile);					
				}
				fclose (infile2);
				infile2=NULL;
				fclose (outfile);
				outfile=NULL;
			}
			printf("Processing file %s\n", buf+4);
			sprintf (infilepath, "%s\\%s", inpath, buf+4);
			sprintf (outfilepath, "%s\\%s", outpath, buf+4);
			if 	((infile2 = fopen(infilepath, "rt"))== NULL)
			{
				printf("Error: Cannot open input file %s", infilepath);
				exit (1);
			}
			line=pos=1;

			if ((outfile=fopen(outfilepath, "rt"))!=NULL)
			{
				fclose (outfile);
				printf ("ERROR: file %s already exists\n", outfilepath);
				exit (1); 
			}
			if 	((outfile = fopen(outfilepath, "wt"))== NULL)
			{
				printf("ERROR: Cannot open output file %s\n", outfilepath);
				exit (1);
			}
			continue;
		}

		if (strncmp("****", buf, 4)==0)
		{
			sscanf(buf+4, "%i;%i;%i", &orig_line, &orig_pos, &length);
			icp=strchr(buf, ')');
			icp++;
			
			while ((line<orig_line)||(pos<orig_pos))
			{
				c=fgetc(infile2); 
				if feof (infile2)
				{
					printf ("ERROR: unexpected end of file\n"); 
					exit (1); 
				}
				fputc (c, outfile);	// copy unchanged parts
				//printf ("%c", c); 
				if (c=='\n')
				{
					line++;
					pos=0;
				}
				pos++;
			}
			
			for (i=0; i<length; i++)
			{

				c=fgetc(infile2); 
				if feof (infile2)
				{
					printf ("ERROR: unexpected end of file\n"); 
					exit (1); 
				}
				if (c!=*icp++)
				{
					printf ("Error: string \"%s\" does not match\n", buf);
					exit (1);
				}
			}
			pos+=length; // Note: this assumes never '\n' in a chunk!
			fgets(buf, BUFSIZE-2, infile);
			buf[strlen(buf)-1]='\0'; 
			
			cp=buf;
			// output buf, with conversion of ISO8859-1 to UTF-8
			while (*cp!='\0')
			{
				if ((*cp & 0x80) == 0) 
				{
					fputc (*cp, outfile);
				}
				else 
				{
					fputc (0xC0|(0x03 & (*cp >> 6)), outfile);
					fputc (0x80|(0x3F & *cp), outfile);
				}
				cp++;
			}
			
		}
	}
}