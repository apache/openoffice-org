// -------------------------------------------------------------------
// getcontent.c
// extracts the "strings to be translated" from the OpenOffice.org 
// XML help files. 
//
// Copyright message: 
// (c) 2002 original author S. Brouwer (simonbr@openoffice.org)
// The software is free to distribute, modify etc. etc. as long as
// this copyright message is preserved.
// -------------------------------------------------------------------

// includes 
#include <stdio.h>
#include <string.h>
#include <process.h>

// prototypes
void getcontent(void);

int	 checktag(char *tag);
void xmlparse_init(void);
int  xmlparse(void);

void handle_attributes(void);
int  evaluate_rules(void);

// buffer size "64 k ought to be enough for everybody ;)"
#define BUFSIZE 0x10000

// return values of xml_parse()
#define OPEN_TAG	0
#define CLOSE_TAG	1
#define SINGLETON	2
#define CHUNK		3
#define END_OF_FILE 4

// global variables
FILE *infile, *outfile;

char buf[BUFSIZE];		// buffer containing an element
int line, pos;			// current line and position
int start_line, start_pos; // line and position of the start of an element
char remark[256];		// contains "remark" string

int document;		// variables to keep track of which parts of the 
int meta;			// XPaths have already been found at current nesting level
int body;

// xml parsing state 
int parsing_a_tag;
int level;			// current nesting level

int help_switch_level;		// level at which help:switch tag was encountered
int spacer_last_printed;	// indicates if anything else was printed after the last spacer

void
main (int argc, char *argv[])
{
	if ((argc==2)&&(strcmp(argv[1],"/?")==0))
	{
		puts("Get content from OOo XML help file.\n");
		puts("GETCONTENT [path]infile [path]outfile <string>\n");
		puts("  infile, outfile    specify the input and output files");
		puts("(c) 2002 S. Brouwer\n This software is free to distribute, modify etc. provided that this copyright message is preserved in it.");
		exit(1);
	}

	if (argc!=3)
	{
		puts("usage: GETCONTENT [path]infile [path]outfile string\n");
		puts("       GETCONTENT /?   for help\n");
		exit(1);
	}

	if ((infile = fopen(argv[1], "rt"))== NULL)
	{
		printf("Error: Cannot open input file %s\n", argv[1]);
		exit (1);
	}

	if ((outfile = fopen(argv[2], "at"))== NULL)
	{
		printf("Error: Cannot open output file %s\n", argv[2]);
		exit (1);
	}

	fprintf(outfile, "####%s\n", argv[1]);
	fprintf(outfile, "translated (by/date): (not translated yet)\n"); 
	fprintf(outfile, "reviewed (by/date)  : (not reviewed yet)\n"); 
	fprintf(outfile, "\n"); 

	line=pos=1;

	getcontent ();

	fputs ("\n\n\n", outfile);

	fclose(infile);
	fclose(outfile);
	exit (0);
}


void
getcontent (void)
{
	int enable_out=0;		// indicates if chunks must be emitted
	char *cp;
	int enable_level=0;		// indicates the nesting level at which 
							// enableout was set
	int parseresult; 

	spacer_last_printed=0;

	xmlparse_init();
	remark[0]='\0';

	for (;;)
	{
		start_line=line;					// mark beginning of element
		start_pos=pos;

		parseresult=xmlparse();			// get an element
		
		if (parseresult==END_OF_FILE)
			return;						// done

		if (parseresult==CLOSE_TAG)
		{
			remark[0]='\0';
			if (level<enable_level)
				enable_out=0;
			continue;
		}

		if ((parseresult==CHUNK)&&enable_out)
		{
			cp=buf;
			while (*cp!='\0')
			{
				if (*cp++>' ')			// chunk not "empty"
				{
					cp=buf; 
					while (*cp!='\0')
					{
						if (*cp++=='\n')
						{
							printf ("ERROR: chunk contains newline"); 
							exit (1); 
						}
					}
					fprintf(outfile, "****%i;%i;%i(%s)%s\n%s\n\n", start_line, start_pos, strlen(buf), remark, buf, buf);
					spacer_last_printed=0;
					break;
				}
			}
			continue;
		}

		handle_attributes();		// handle XPath rules containing '@'

		if (parseresult==OPEN_TAG)
		{
			if (!enable_out)
			{
				if (evaluate_rules())
				{
					if (!spacer_last_printed)
					{
						fprintf(outfile, "-------------------------------\n\n");
						spacer_last_printed=1; 
					}
					enable_out=1;
					enable_level=level;
				}
			}
			else						// already enable_out: don't change
				evaluate_rules();		// (just keep track)
		}
	}	
}		

// evaluate if an XPath rule is valid.
// this is called whenever an "open" tag is processed
int
evaluate_rules(void)
{
	if (level==1)
	{
		meta=body=0;				// outside /office:document/office:meta
									// and     /office:document/office:body
		document=checktag("office:document");
		return (0);
	}

	if (!document)
		return (0);					// do not check further if not inside /office:document

	if ((level==2)&&document)
	{
		if (checktag("office:meta"))
			meta=1;						// inside /office:document/office:meta
		else if (checktag("office:body"))
			body=1;						// inside /office:document/office:body
		return (0);
	}

	// XPath: /office:document/office:meta/dc:subject
	if ((level==3) && meta && checktag ("dc:subject"))
	{
		sprintf (remark, "subject");
		return (1);
	}
	
	// all other rules are inside /office:document/office:body
	// and level of at least 3
	if ((!body)||(level<3))
		return (0);

	// XPath: /office:document/office:body//text:p
	if (checktag ("text:p"))
	{
		sprintf (remark, "text:p");
		return (1);
	}
	
	// XPath: /office:document/office:body//text:h
	if (checktag ("text:h"))
	{
		sprintf (remark, "text:h");
		return (1);
	}

	// XPath: /office:document/office:body//help:to-be-embedded
	if (checktag ("help:to-be-embedded"))
	{
		sprintf (remark, "help:to-be-embedded");
		return (1);
	}
	
	// XPath: /office:document/office:body//help:link
	if (checktag ("help:link"))
	{
		sprintf (remark, "help:link");
		return (1);
	}

	// XPath: /office:document/office:body//text:list-item
	if (checktag ("text:list-item"))
	{
		sprintf (remark, "text:list-item");
		return (1);
	}

	// XPath: /office:document/office:body//table:table-cell
	if (checktag ("table:table-cell"))
	{
		sprintf (remark, "table:table-cell");
		return (1);
	}

	// XPath: /office:document/office:body//help:to-pop-up
	if (checktag ("help:to-pop-up"))
	{
		sprintf (remark, "help:to-pop-up");
		return (1);
	}

	// XPath: /office:document/office:body//text:span
	if (checktag ("text:span"))
	{
		sprintf (remark, "text:span");
		return (1);
	}

	// XPath: /office:document/office:body//help:help-text
	if (checktag ("help:help-text"))
	{
		sprintf (remark, "help:help-text");
		return (1);
	}

	// XPath: /office:document/office:body//help:productname
	if (checktag ("help:productname"))
	{
		sprintf (remark, "help:productname");
		return (1);
	}

	// XPath: /office:document/office:body//help:productversion
	if (checktag ("help:productversion"))
	{
		sprintf (remark, "help:productversion");
		return (1);
	}

	// XPath: /office:document/office:body//text:a
	if (checktag ("text:a"))
	{
		sprintf (remark, "text:a");
		return (1);
	}
	
	if (checktag ("help:switch"))
	{
		help_switch_level=level;
		return (0);
	}
	
	if (level<help_switch_level)
		help_switch_level=0;

	// XPath: /office:document/office:body//help:switch/help_case
	//	and	  /office:document/office:body//help:switch/help_default	
	if (help_switch_level&&(level==help_switch_level+1)) 
	{
		if (checktag ("help_case") ||
			checktag ("help_default"))
		{
			return(1);
		}
	}	
	return (0);
}

void
handle_attributes(void)
{
	int loc_line, loc_pos;
	char *tp, *cp;

	loc_line=start_line; 
	loc_pos=start_pos;

	// XPath: /office:document/office:body//help:key-word/@value
	if (checktag ("help:key-word"))
	{
		if ((tp=strstr(buf,"value=\""))==NULL)
			return;
		if (*(tp-1)>' ')
			return;

		tp+=strlen("value=\"");
		cp=buf;	
		while (cp!=tp)			// calculate line and pos of the attribute
		{
			if (*cp++=='\n')
			{
				loc_line++;
				loc_pos=0;
			}
			loc_pos++;
		}

		cp=tp;
		while (*cp!='\"')
		{
			if (*cp=='\n')
			{ 
				puts ("ERROR: attribute contains newline"); 
				exit (1);
			}
			if (*cp=='\0')
			{ 
				puts ("ERROR: missing end of string"); 
				exit (1);
			}
			cp++;
		}
		*cp='\0';

		fprintf(outfile, "****%i;%i;%i(keyword)%s\n%s\n\n", loc_line, loc_pos, strlen(tp), tp, tp); // data out
		return; 
	}

	// XPath: /office:document/office:body//draw:image/@svg:desc
	if (checktag ("draw:image"))
	{
		if ((tp=strstr(buf,"svg:desc=\""))==NULL)
			return;
		if (*(tp-1)>' ')
			return;

		tp+=strlen("svg:desc=\"");

		cp=buf;
		while (cp!=tp)
		{
			if (*cp++=='\n')
			{
				loc_line++;
				loc_pos=0;
			}
			loc_pos++;
		}
		
		cp=tp;

		while (*cp!='\"')
		{
			if (*cp=='\n')
			{ 
				puts ("ERROR: attribute contains newline"); 
				exit (1);
			}
			if (*cp=='\0')
			{ 
				puts ("ERROR: missing end of string"); 
				exit (1);
			}
			cp++;
		}
		*cp='\0';

		fprintf(outfile, "****%i;%i;%i(image title);%s\n%s\n\n", loc_line, loc_pos, strlen(tp), tp, tp); // data out
	}
}


void
xmlparse_init (void)
{
	parsing_a_tag=0;
	level=0;
}


// a very simple xml parse routine
int
xmlparse (void)
{	
	int count=0;	// number of chars in current element
	int c;

	for (;;)
	{
		if ((c=fgetc(infile))<0)
		{
			if (level!=0)
			{	
				puts ("ERROR: unexpected end of file\n");
				exit (1);
			}
			return (END_OF_FILE);
		}
		
		if (c=='\n')
		{
			line++;
			pos=0;
		}
		pos++;

		if ((level!=0)||parsing_a_tag)
		{	
			buf[count++]=(char)c;
			if (count>BUFSIZE-2)
			{
				puts ("ERROR: element too big for buffer");
				exit (1);
			}
		}
		
		buf[count]='\0';

		if (parsing_a_tag)
		{
			if (c=='>')
			{
				parsing_a_tag=0;
				if ((buf[0]=='!')&&(buf[1]=='-')&&(buf[2]=='-')) // comment
					continue;
				if (buf[0]=='/')
				{
					level--;
					return (CLOSE_TAG);
				}
				if (buf[count-2]=='/')
					return (SINGLETON);
				level++;
				return (OPEN_TAG);
			}
		}
		else
		{
			if (c=='<')
			{
				parsing_a_tag=1;
				if (level>0)
				{ 
					buf[count-1]='\0';
					return (CHUNK);
				}
			}
		}
	}
}
			
// -----------------------------------------------------------------------
// this routine checks if the specified tag is found in buffer. 
// return value=1 on match, 0 on no match
// -----------------------------------------------------------------------
int checktag(char *tag)
{
	char *cp; 
	
	cp=buf;
	while (*tag==*cp)
	{
		tag++;
		cp++;
		if (*tag=='\0')
		{
			if ((*cp<=' ')||(*cp=='>')||(*cp=='/'))
				return (1);
			else 
				return (0);
		}
	}	
	return (0);
}