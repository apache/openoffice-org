/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/mailnews/addrbook/public/../../../../mailnews/addrbook/public/nsIAbListener.idl
 */

#ifndef __gen_nsIAbListener_h__
#define __gen_nsIAbListener_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIEnumerator_h__
#include "nsIEnumerator.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
typedef PRUint32 abListenerNotifyFlagValue;


/* starting interface:    nsIAbListener */
#define NS_IABLISTENER_IID_STR "8c5b1f3d-983a-4854-a0e2-3719dba1a920"

#define NS_IABLISTENER_IID \
  {0x8c5b1f3d, 0x983a, 0x4854, \
    { 0xa0, 0xe2, 0x37, 0x19, 0xdb, 0xa1, 0xa9, 0x20 }}

/**
  * nsIAbListener
  *
  * Implement this interface to receive notifications of address book
  * items being added, removed or changed with loaded address books.
  *
  * Subscribe to events by using nsIAddrBookSession. See nsIAddrBookSession.idl
  * for details of individual types of events that may be subscribed to.
  *
  */
class NS_NO_VTABLE nsIAbListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABLISTENER_IID)

  /**
   * Called when an address book item (book, card or list) is added
   *
   * @param       parentDir       The parent of the item being added.
   *
   * @param       item            The item being added to the database (a
   *                              directory or card).
   *
   */
  /* void onItemAdded (in nsISupports parentDir, in nsISupports item); */
  NS_IMETHOD OnItemAdded(nsISupports *parentDir, nsISupports *item) = 0;

  /**
   * Called when an address book, mailing list or card is removed. This
   * is partially configurable when setting up the listener via
   * nsIAddrBookSession
   *
   * @param       parentDir       The parent of the item being removed, this
   *                              may be an empty directory in the case of a
   *                              top level address book.
   *
   * @param       item            The item being removed from the database.
   *
   */
  /* void onItemRemoved (in nsISupports parentDir, in nsISupports item); */
  NS_IMETHOD OnItemRemoved(nsISupports *parentDir, nsISupports *item) = 0;

  /**
   * Called when an address book item is changed. Note the current
   * implementation means that property is either the literal string "DirName"
   * or null, with oldValue and newValue being specified if the property is
   * "DirName" otherwise they are null.
   *
   * @param       item            The item being updated (a directory or a
   *                              card).
   *
   * @param       property        The property of the item being changed.
   *                              
   * @param       oldValue        The old value of the item property being
   *                              changed if it is known, null otherwise.
   *                              
   * @param       newValue        The new value of the item property being
   *                              changed.
   *                              
   */
  /* void onItemPropertyChanged (in nsISupports item, in string property, in wstring oldValue, in wstring newValue); */
  NS_IMETHOD OnItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABLISTENER \
  NS_IMETHOD OnItemAdded(nsISupports *parentDir, nsISupports *item); \
  NS_IMETHOD OnItemRemoved(nsISupports *parentDir, nsISupports *item); \
  NS_IMETHOD OnItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABLISTENER(_to) \
  NS_IMETHOD OnItemAdded(nsISupports *parentDir, nsISupports *item) { return _to OnItemAdded(parentDir, item); } \
  NS_IMETHOD OnItemRemoved(nsISupports *parentDir, nsISupports *item) { return _to OnItemRemoved(parentDir, item); } \
  NS_IMETHOD OnItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue) { return _to OnItemPropertyChanged(item, property, oldValue, newValue); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABLISTENER(_to) \
  NS_IMETHOD OnItemAdded(nsISupports *parentDir, nsISupports *item) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnItemAdded(parentDir, item); } \
  NS_IMETHOD OnItemRemoved(nsISupports *parentDir, nsISupports *item) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnItemRemoved(parentDir, item); } \
  NS_IMETHOD OnItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnItemPropertyChanged(item, property, oldValue, newValue); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbListener : public nsIAbListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABLISTENER

  nsAbListener();

private:
  ~nsAbListener();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbListener, nsIAbListener)

nsAbListener::nsAbListener()
{
  /* member initializers and constructor code */
}

nsAbListener::~nsAbListener()
{
  /* destructor code */
}

/* void onItemAdded (in nsISupports parentDir, in nsISupports item); */
NS_IMETHODIMP nsAbListener::OnItemAdded(nsISupports *parentDir, nsISupports *item)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onItemRemoved (in nsISupports parentDir, in nsISupports item); */
NS_IMETHODIMP nsAbListener::OnItemRemoved(nsISupports *parentDir, nsISupports *item)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onItemPropertyChanged (in nsISupports item, in string property, in wstring oldValue, in wstring newValue); */
NS_IMETHODIMP nsAbListener::OnItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbListener_h__ */
