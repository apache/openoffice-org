/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM ../../../../../toolkit/components/autocomplete/public/nsIAutoCompleteSimpleResult.idl
 */

#ifndef __gen_nsIAutoCompleteSimpleResult_h__
#define __gen_nsIAutoCompleteSimpleResult_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAutoCompleteResult_h__
#include "nsIAutoCompleteResult.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAutoCompleteSimpleResult */
#define NS_IAUTOCOMPLETESIMPLERESULT_IID_STR "cc79f293-7114-4287-870b-d28aa61aa7df"

#define NS_IAUTOCOMPLETESIMPLERESULT_IID \
  {0xcc79f293, 0x7114, 0x4287, \
    { 0x87, 0x0b, 0xd2, 0x8a, 0xa6, 0x1a, 0xa7, 0xdf }}

/**
 * This class implements nsIAutoCompleteResult and provides simple methods
 * for setting the value and result items. It can be used whenever some basic
 * auto complete results are needed that can be pre-generated and filled into
 * an array.
 */
class NS_NO_VTABLE nsIAutoCompleteSimpleResult : public nsIAutoCompleteResult {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IAUTOCOMPLETESIMPLERESULT_IID)

  /**
   * A writer for the readonly attribute 'searchString' which should contain
   * the string that the user typed.
   */
  /* void setSearchString (in AString aSearchString); */
  NS_IMETHOD SetSearchString(const nsAString & aSearchString) = 0;

  /**
   * A writer for the readonly attribute 'errorDescription'.
   */
  /* void setErrorDescription (in AString aErrorDescription); */
  NS_IMETHOD SetErrorDescription(const nsAString & aErrorDescription) = 0;

  /**
   * A writer for the readonly attribute 'defaultIndex' which should contain
   * the index of the list that will be selected by default (normally 0).
   */
  /* void setDefaultIndex (in long aDefaultIndex); */
  NS_IMETHOD SetDefaultIndex(PRInt32 aDefaultIndex) = 0;

  /**
   * A writer for the readonly attribute 'searchResult' which should contain
   * one of the constants nsIAutoCompleteResult.RESULT_* indicating the success
   * of the search.
   */
  /* void setSearchResult (in unsigned short aSearchResult); */
  NS_IMETHOD SetSearchResult(PRUint16 aSearchResult) = 0;

  /**
   * Appends a result item consisting of the given value and comment. This is
   * how you add results.
   */
  /* void appendMatch (in AString aValue, in AString aComment); */
  NS_IMETHOD AppendMatch(const nsAString & aValue, const nsAString & aComment) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIAUTOCOMPLETESIMPLERESULT \
  NS_IMETHOD SetSearchString(const nsAString & aSearchString); \
  NS_IMETHOD SetErrorDescription(const nsAString & aErrorDescription); \
  NS_IMETHOD SetDefaultIndex(PRInt32 aDefaultIndex); \
  NS_IMETHOD SetSearchResult(PRUint16 aSearchResult); \
  NS_IMETHOD AppendMatch(const nsAString & aValue, const nsAString & aComment); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIAUTOCOMPLETESIMPLERESULT(_to) \
  NS_IMETHOD SetSearchString(const nsAString & aSearchString) { return _to SetSearchString(aSearchString); } \
  NS_IMETHOD SetErrorDescription(const nsAString & aErrorDescription) { return _to SetErrorDescription(aErrorDescription); } \
  NS_IMETHOD SetDefaultIndex(PRInt32 aDefaultIndex) { return _to SetDefaultIndex(aDefaultIndex); } \
  NS_IMETHOD SetSearchResult(PRUint16 aSearchResult) { return _to SetSearchResult(aSearchResult); } \
  NS_IMETHOD AppendMatch(const nsAString & aValue, const nsAString & aComment) { return _to AppendMatch(aValue, aComment); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIAUTOCOMPLETESIMPLERESULT(_to) \
  NS_IMETHOD SetSearchString(const nsAString & aSearchString) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSearchString(aSearchString); } \
  NS_IMETHOD SetErrorDescription(const nsAString & aErrorDescription) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetErrorDescription(aErrorDescription); } \
  NS_IMETHOD SetDefaultIndex(PRInt32 aDefaultIndex) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDefaultIndex(aDefaultIndex); } \
  NS_IMETHOD SetSearchResult(PRUint16 aSearchResult) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSearchResult(aSearchResult); } \
  NS_IMETHOD AppendMatch(const nsAString & aValue, const nsAString & aComment) { return !_to ? NS_ERROR_NULL_POINTER : _to->AppendMatch(aValue, aComment); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAutoCompleteSimpleResult : public nsIAutoCompleteSimpleResult
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIAUTOCOMPLETESIMPLERESULT

  nsAutoCompleteSimpleResult();

private:
  ~nsAutoCompleteSimpleResult();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAutoCompleteSimpleResult, nsIAutoCompleteSimpleResult)

nsAutoCompleteSimpleResult::nsAutoCompleteSimpleResult()
{
  /* member initializers and constructor code */
}

nsAutoCompleteSimpleResult::~nsAutoCompleteSimpleResult()
{
  /* destructor code */
}

/* void setSearchString (in AString aSearchString); */
NS_IMETHODIMP nsAutoCompleteSimpleResult::SetSearchString(const nsAString & aSearchString)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setErrorDescription (in AString aErrorDescription); */
NS_IMETHODIMP nsAutoCompleteSimpleResult::SetErrorDescription(const nsAString & aErrorDescription)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setDefaultIndex (in long aDefaultIndex); */
NS_IMETHODIMP nsAutoCompleteSimpleResult::SetDefaultIndex(PRInt32 aDefaultIndex)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setSearchResult (in unsigned short aSearchResult); */
NS_IMETHODIMP nsAutoCompleteSimpleResult::SetSearchResult(PRUint16 aSearchResult)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void appendMatch (in AString aValue, in AString aComment); */
NS_IMETHODIMP nsAutoCompleteSimpleResult::AppendMatch(const nsAString & aValue, const nsAString & aComment)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAutoCompleteSimpleResult_h__ */
