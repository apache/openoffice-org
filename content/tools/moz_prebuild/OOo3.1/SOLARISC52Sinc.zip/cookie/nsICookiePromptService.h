/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsICookiePromptService.idl
 */

#ifndef __gen_nsICookiePromptService_h__
#define __gen_nsICookiePromptService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIDOMWindow; /* forward declaration */

class nsICookie; /* forward declaration */


/* starting interface:    nsICookiePromptService */
#define NS_ICOOKIEPROMPTSERVICE_IID_STR "ce002b28-92b7-4701-8621-cc925866fb87"

#define NS_ICOOKIEPROMPTSERVICE_IID \
  {0xce002b28, 0x92b7, 0x4701, \
    { 0x86, 0x21, 0xcc, 0x92, 0x58, 0x66, 0xfb, 0x87 }}

class NS_NO_VTABLE nsICookiePromptService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICOOKIEPROMPTSERVICE_IID)

  enum { DENY_COOKIE = 0U };

  enum { ACCEPT_COOKIE = 1U };

  enum { ACCEPT_SESSION_COOKIE = 2U };

  /* long cookieDialog (in nsIDOMWindow parent, in nsICookie cookie, in ACString hostname, in long cookiesFromHost, in boolean changingCookie, out boolean rememberDecision); */
  NS_IMETHOD CookieDialog(nsIDOMWindow *parent, nsICookie *cookie, const nsACString & hostname, PRInt32 cookiesFromHost, PRBool changingCookie, PRBool *rememberDecision, PRInt32 *_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICOOKIEPROMPTSERVICE \
  NS_IMETHOD CookieDialog(nsIDOMWindow *parent, nsICookie *cookie, const nsACString & hostname, PRInt32 cookiesFromHost, PRBool changingCookie, PRBool *rememberDecision, PRInt32 *_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICOOKIEPROMPTSERVICE(_to) \
  NS_IMETHOD CookieDialog(nsIDOMWindow *parent, nsICookie *cookie, const nsACString & hostname, PRInt32 cookiesFromHost, PRBool changingCookie, PRBool *rememberDecision, PRInt32 *_retval) { return _to CookieDialog(parent, cookie, hostname, cookiesFromHost, changingCookie, rememberDecision, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICOOKIEPROMPTSERVICE(_to) \
  NS_IMETHOD CookieDialog(nsIDOMWindow *parent, nsICookie *cookie, const nsACString & hostname, PRInt32 cookiesFromHost, PRBool changingCookie, PRBool *rememberDecision, PRInt32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CookieDialog(parent, cookie, hostname, cookiesFromHost, changingCookie, rememberDecision, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsCookiePromptService : public nsICookiePromptService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICOOKIEPROMPTSERVICE

  nsCookiePromptService();

private:
  ~nsCookiePromptService();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsCookiePromptService, nsICookiePromptService)

nsCookiePromptService::nsCookiePromptService()
{
  /* member initializers and constructor code */
}

nsCookiePromptService::~nsCookiePromptService()
{
  /* destructor code */
}

/* long cookieDialog (in nsIDOMWindow parent, in nsICookie cookie, in ACString hostname, in long cookiesFromHost, in boolean changingCookie, out boolean rememberDecision); */
NS_IMETHODIMP nsCookiePromptService::CookieDialog(nsIDOMWindow *parent, nsICookie *cookie, const nsACString & hostname, PRInt32 cookiesFromHost, PRBool changingCookie, PRBool *rememberDecision, PRInt32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

#define NS_COOKIEPROMPTSERVICE_CONTRACTID "@mozilla.org/embedcomp/cookieprompt-service;1"

#endif /* __gen_nsICookiePromptService_h__ */
