/* -*- Mode: C++; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- */

/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is mozilla.org code.
 *
 * The Initial Developer of the Original Code is
 * John B. Keiser
 * Portions created by the Initial Developer are Copyright (C) 2001
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

#ifndef nsIOptionElement_h___
#define nsIOptionElement_h___

#include "nsISupports.h"

// IID for the nsIOption interface
#define NS_IOPTIONELEMENT_IID    \
{ 0xd49fe03a, 0x1dd1, 0x11b2,    \
  { 0xa0, 0xe0, 0x83, 0x66, 0x76, 0x19, 0xaf, 0x69 } }

/**
 * This interface is used to notify a SELECT when OPTION
 * elements are added and removed from its subtree.
 * Note that the nsIDOMHTMLSelectElement and nsIContent
 * interfaces are the ones to use to access and enumerate
 * OPTIONs within a SELECT element.
 */
class nsIOptionElement : public nsISupports {
public:

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IOPTIONELEMENT_IID)

  /**
   * Select the option element from its own point of view.  This should only be
   * used by SelectElement, really.  Everyone else is safe using GetSelected()
   * on the DOMHTMLOptionElement, which goes through the <select> to make sure
   * everything gets updated correctly.
   */
  NS_IMETHOD SetSelectedInternal(PRBool aValue, PRBool aNotify) = 0;
};

#endif // nsIOptionElement_h___

