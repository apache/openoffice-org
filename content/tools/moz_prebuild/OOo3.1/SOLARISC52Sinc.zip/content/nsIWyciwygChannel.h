/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIWyciwygChannel.idl
 */

#ifndef __gen_nsIWyciwygChannel_h__
#define __gen_nsIWyciwygChannel_h__


#ifndef __gen_nsIChannel_h__
#include "nsIChannel.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIWyciwygChannel */
#define NS_IWYCIWYGCHANNEL_IID_STR "c36730c0-a3b9-4732-9973-c5e7dbe0dabe"

#define NS_IWYCIWYGCHANNEL_IID \
  {0xc36730c0, 0xa3b9, 0x4732, \
    { 0x99, 0x73, 0xc5, 0xe7, 0xdb, 0xe0, 0xda, 0xbe }}

/**
 * A channel to  manage all cache-related interactions for layout
 * when it is dealing with dynamic pages created through 
 * document.write(). This interface provides methods that will
 * help layout save dynamic pages in cache for future retrievals.
 */
class NS_NO_VTABLE nsIWyciwygChannel : public nsIChannel {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IWYCIWYGCHANNEL_IID)

  /**
     * Append data to the cache entry; opens the cache entry if necessary.
     */
  /* void writeToCacheEntry (in ACString aScript); */
  NS_IMETHOD WriteToCacheEntry(const nsACString & aScript) = 0;

  /**
     * Close the cache entry; subsequent writes have undefined behavior.
     */
  /* void closeCacheEntry (in nsresult reason); */
  NS_IMETHOD CloseCacheEntry(nsresult reason) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIWYCIWYGCHANNEL \
  NS_IMETHOD WriteToCacheEntry(const nsACString & aScript); \
  NS_IMETHOD CloseCacheEntry(nsresult reason); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIWYCIWYGCHANNEL(_to) \
  NS_IMETHOD WriteToCacheEntry(const nsACString & aScript) { return _to WriteToCacheEntry(aScript); } \
  NS_IMETHOD CloseCacheEntry(nsresult reason) { return _to CloseCacheEntry(reason); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIWYCIWYGCHANNEL(_to) \
  NS_IMETHOD WriteToCacheEntry(const nsACString & aScript) { return !_to ? NS_ERROR_NULL_POINTER : _to->WriteToCacheEntry(aScript); } \
  NS_IMETHOD CloseCacheEntry(nsresult reason) { return !_to ? NS_ERROR_NULL_POINTER : _to->CloseCacheEntry(reason); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsWyciwygChannel : public nsIWyciwygChannel
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIWYCIWYGCHANNEL

  nsWyciwygChannel();

private:
  ~nsWyciwygChannel();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsWyciwygChannel, nsIWyciwygChannel)

nsWyciwygChannel::nsWyciwygChannel()
{
  /* member initializers and constructor code */
}

nsWyciwygChannel::~nsWyciwygChannel()
{
  /* destructor code */
}

/* void writeToCacheEntry (in ACString aScript); */
NS_IMETHODIMP nsWyciwygChannel::WriteToCacheEntry(const nsACString & aScript)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void closeCacheEntry (in nsresult reason); */
NS_IMETHODIMP nsWyciwygChannel::CloseCacheEntry(nsresult reason)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIWyciwygChannel_h__ */
