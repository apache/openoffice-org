/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIImageDocument.idl
 */

#ifndef __gen_nsIImageDocument_h__
#define __gen_nsIImageDocument_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIImageDocument */
#define NS_IIMAGEDOCUMENT_IID_STR "b482f6d8-40a9-4f20-89f3-772d417a4c81"

#define NS_IIMAGEDOCUMENT_IID \
  {0xb482f6d8, 0x40a9, 0x4f20, \
    { 0x89, 0xf3, 0x77, 0x2d, 0x41, 0x7a, 0x4c, 0x81 }}

/**
 * @status UNDER_DEVELOPMENT
 */
class NS_NO_VTABLE nsIImageDocument : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IIMAGEDOCUMENT_IID)

  /* readonly attribute boolean imageResizingEnabled; */
  NS_IMETHOD GetImageResizingEnabled(PRBool *aImageResizingEnabled) = 0;

  /* readonly attribute boolean imageIsOverflowing; */
  NS_IMETHOD GetImageIsOverflowing(PRBool *aImageIsOverflowing) = 0;

  /* readonly attribute boolean imageIsResized; */
  NS_IMETHOD GetImageIsResized(PRBool *aImageIsResized) = 0;

  /* void shrinkToFit (); */
  NS_IMETHOD ShrinkToFit(void) = 0;

  /* void restoreImage (); */
  NS_IMETHOD RestoreImage(void) = 0;

  /* void toggleImageSize (); */
  NS_IMETHOD ToggleImageSize(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIIMAGEDOCUMENT \
  NS_IMETHOD GetImageResizingEnabled(PRBool *aImageResizingEnabled); \
  NS_IMETHOD GetImageIsOverflowing(PRBool *aImageIsOverflowing); \
  NS_IMETHOD GetImageIsResized(PRBool *aImageIsResized); \
  NS_IMETHOD ShrinkToFit(void); \
  NS_IMETHOD RestoreImage(void); \
  NS_IMETHOD ToggleImageSize(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIIMAGEDOCUMENT(_to) \
  NS_IMETHOD GetImageResizingEnabled(PRBool *aImageResizingEnabled) { return _to GetImageResizingEnabled(aImageResizingEnabled); } \
  NS_IMETHOD GetImageIsOverflowing(PRBool *aImageIsOverflowing) { return _to GetImageIsOverflowing(aImageIsOverflowing); } \
  NS_IMETHOD GetImageIsResized(PRBool *aImageIsResized) { return _to GetImageIsResized(aImageIsResized); } \
  NS_IMETHOD ShrinkToFit(void) { return _to ShrinkToFit(); } \
  NS_IMETHOD RestoreImage(void) { return _to RestoreImage(); } \
  NS_IMETHOD ToggleImageSize(void) { return _to ToggleImageSize(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIIMAGEDOCUMENT(_to) \
  NS_IMETHOD GetImageResizingEnabled(PRBool *aImageResizingEnabled) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetImageResizingEnabled(aImageResizingEnabled); } \
  NS_IMETHOD GetImageIsOverflowing(PRBool *aImageIsOverflowing) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetImageIsOverflowing(aImageIsOverflowing); } \
  NS_IMETHOD GetImageIsResized(PRBool *aImageIsResized) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetImageIsResized(aImageIsResized); } \
  NS_IMETHOD ShrinkToFit(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->ShrinkToFit(); } \
  NS_IMETHOD RestoreImage(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->RestoreImage(); } \
  NS_IMETHOD ToggleImageSize(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->ToggleImageSize(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsImageDocument : public nsIImageDocument
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIIMAGEDOCUMENT

  nsImageDocument();

private:
  ~nsImageDocument();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsImageDocument, nsIImageDocument)

nsImageDocument::nsImageDocument()
{
  /* member initializers and constructor code */
}

nsImageDocument::~nsImageDocument()
{
  /* destructor code */
}

/* readonly attribute boolean imageResizingEnabled; */
NS_IMETHODIMP nsImageDocument::GetImageResizingEnabled(PRBool *aImageResizingEnabled)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean imageIsOverflowing; */
NS_IMETHODIMP nsImageDocument::GetImageIsOverflowing(PRBool *aImageIsOverflowing)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean imageIsResized; */
NS_IMETHODIMP nsImageDocument::GetImageIsResized(PRBool *aImageIsResized)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void shrinkToFit (); */
NS_IMETHODIMP nsImageDocument::ShrinkToFit()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void restoreImage (); */
NS_IMETHODIMP nsImageDocument::RestoreImage()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void toggleImageSize (); */
NS_IMETHODIMP nsImageDocument::ToggleImageSize()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIImageDocument_h__ */
