/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIDOMPopupBlockedEvent.idl
 */

#ifndef __gen_nsIDOMPopupBlockedEvent_h__
#define __gen_nsIDOMPopupBlockedEvent_h__


#ifndef __gen_nsIDOMEvent_h__
#include "nsIDOMEvent.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIURI; /* forward declaration */


/* starting interface:    nsIDOMPopupBlockedEvent */
#define NS_IDOMPOPUPBLOCKEDEVENT_IID_STR "fadc9149-9267-4b41-b4cb-1f76446d7629"

#define NS_IDOMPOPUPBLOCKEDEVENT_IID \
  {0xfadc9149, 0x9267, 0x4b41, \
    { 0xb4, 0xcb, 0x1f, 0x76, 0x44, 0x6d, 0x76, 0x29 }}

/**
 * The nsIDOMPopupBlockedEvent interface is the datatype for events
 * posted when a popup window is blocked.
 */
class NS_NO_VTABLE nsIDOMPopupBlockedEvent : public nsIDOMEvent {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IDOMPOPUPBLOCKEDEVENT_IID)

  /* readonly attribute nsIURI requestingWindowURI; */
  NS_IMETHOD GetRequestingWindowURI(nsIURI * *aRequestingWindowURI) = 0;

  /* readonly attribute nsIURI popupWindowURI; */
  NS_IMETHOD GetPopupWindowURI(nsIURI * *aPopupWindowURI) = 0;

  /**
   * The string of features passed to the window.open() call
   * (as the third argument)
   */
  /* readonly attribute DOMString popupWindowFeatures; */
  NS_IMETHOD GetPopupWindowFeatures(nsAString & aPopupWindowFeatures) = 0;

  /* void initPopupBlockedEvent (in DOMString typeArg, in boolean canBubbleArg, in boolean cancelableArg, in nsIURI requestingWindowURI, in nsIURI popupWindowURI, in DOMString popupWindowFeatures); */
  NS_IMETHOD InitPopupBlockedEvent(const nsAString & typeArg, PRBool canBubbleArg, PRBool cancelableArg, nsIURI *requestingWindowURI, nsIURI *popupWindowURI, const nsAString & popupWindowFeatures) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIDOMPOPUPBLOCKEDEVENT \
  NS_IMETHOD GetRequestingWindowURI(nsIURI * *aRequestingWindowURI); \
  NS_IMETHOD GetPopupWindowURI(nsIURI * *aPopupWindowURI); \
  NS_IMETHOD GetPopupWindowFeatures(nsAString & aPopupWindowFeatures); \
  NS_IMETHOD InitPopupBlockedEvent(const nsAString & typeArg, PRBool canBubbleArg, PRBool cancelableArg, nsIURI *requestingWindowURI, nsIURI *popupWindowURI, const nsAString & popupWindowFeatures); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIDOMPOPUPBLOCKEDEVENT(_to) \
  NS_IMETHOD GetRequestingWindowURI(nsIURI * *aRequestingWindowURI) { return _to GetRequestingWindowURI(aRequestingWindowURI); } \
  NS_IMETHOD GetPopupWindowURI(nsIURI * *aPopupWindowURI) { return _to GetPopupWindowURI(aPopupWindowURI); } \
  NS_IMETHOD GetPopupWindowFeatures(nsAString & aPopupWindowFeatures) { return _to GetPopupWindowFeatures(aPopupWindowFeatures); } \
  NS_IMETHOD InitPopupBlockedEvent(const nsAString & typeArg, PRBool canBubbleArg, PRBool cancelableArg, nsIURI *requestingWindowURI, nsIURI *popupWindowURI, const nsAString & popupWindowFeatures) { return _to InitPopupBlockedEvent(typeArg, canBubbleArg, cancelableArg, requestingWindowURI, popupWindowURI, popupWindowFeatures); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIDOMPOPUPBLOCKEDEVENT(_to) \
  NS_IMETHOD GetRequestingWindowURI(nsIURI * *aRequestingWindowURI) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetRequestingWindowURI(aRequestingWindowURI); } \
  NS_IMETHOD GetPopupWindowURI(nsIURI * *aPopupWindowURI) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPopupWindowURI(aPopupWindowURI); } \
  NS_IMETHOD GetPopupWindowFeatures(nsAString & aPopupWindowFeatures) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPopupWindowFeatures(aPopupWindowFeatures); } \
  NS_IMETHOD InitPopupBlockedEvent(const nsAString & typeArg, PRBool canBubbleArg, PRBool cancelableArg, nsIURI *requestingWindowURI, nsIURI *popupWindowURI, const nsAString & popupWindowFeatures) { return !_to ? NS_ERROR_NULL_POINTER : _to->InitPopupBlockedEvent(typeArg, canBubbleArg, cancelableArg, requestingWindowURI, popupWindowURI, popupWindowFeatures); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsDOMPopupBlockedEvent : public nsIDOMPopupBlockedEvent
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIDOMPOPUPBLOCKEDEVENT

  nsDOMPopupBlockedEvent();

private:
  ~nsDOMPopupBlockedEvent();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsDOMPopupBlockedEvent, nsIDOMPopupBlockedEvent)

nsDOMPopupBlockedEvent::nsDOMPopupBlockedEvent()
{
  /* member initializers and constructor code */
}

nsDOMPopupBlockedEvent::~nsDOMPopupBlockedEvent()
{
  /* destructor code */
}

/* readonly attribute nsIURI requestingWindowURI; */
NS_IMETHODIMP nsDOMPopupBlockedEvent::GetRequestingWindowURI(nsIURI * *aRequestingWindowURI)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsIURI popupWindowURI; */
NS_IMETHODIMP nsDOMPopupBlockedEvent::GetPopupWindowURI(nsIURI * *aPopupWindowURI)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute DOMString popupWindowFeatures; */
NS_IMETHODIMP nsDOMPopupBlockedEvent::GetPopupWindowFeatures(nsAString & aPopupWindowFeatures)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void initPopupBlockedEvent (in DOMString typeArg, in boolean canBubbleArg, in boolean cancelableArg, in nsIURI requestingWindowURI, in nsIURI popupWindowURI, in DOMString popupWindowFeatures); */
NS_IMETHODIMP nsDOMPopupBlockedEvent::InitPopupBlockedEvent(const nsAString & typeArg, PRBool canBubbleArg, PRBool cancelableArg, nsIURI *requestingWindowURI, nsIURI *popupWindowURI, const nsAString & popupWindowFeatures)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIDOMPopupBlockedEvent_h__ */
