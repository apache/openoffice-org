/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIDOMDOMStringList.idl
 */

#ifndef __gen_nsIDOMDOMStringList_h__
#define __gen_nsIDOMDOMStringList_h__


#ifndef __gen_domstubs_h__
#include "domstubs.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIDOMDOMStringList */
#define NS_IDOMDOMSTRINGLIST_IID_STR "893f2075-b62b-11d7-af68-000a95687b38"

#define NS_IDOMDOMSTRINGLIST_IID \
  {0x893f2075, 0xb62b, 0x11d7, \
    { 0xaf, 0x68, 0x00, 0x0a, 0x95, 0x68, 0x7b, 0x38 }}

class NS_NO_VTABLE nsIDOMDOMStringList : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IDOMDOMSTRINGLIST_IID)

  /* DOMString item (in unsigned long index); */
  NS_IMETHOD Item(PRUint32 index, nsAString & _retval) = 0;

  /* readonly attribute unsigned long length; */
  NS_IMETHOD GetLength(PRUint32 *aLength) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIDOMDOMSTRINGLIST \
  NS_IMETHOD Item(PRUint32 index, nsAString & _retval); \
  NS_IMETHOD GetLength(PRUint32 *aLength); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIDOMDOMSTRINGLIST(_to) \
  NS_IMETHOD Item(PRUint32 index, nsAString & _retval) { return _to Item(index, _retval); } \
  NS_IMETHOD GetLength(PRUint32 *aLength) { return _to GetLength(aLength); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIDOMDOMSTRINGLIST(_to) \
  NS_IMETHOD Item(PRUint32 index, nsAString & _retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->Item(index, _retval); } \
  NS_IMETHOD GetLength(PRUint32 *aLength) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLength(aLength); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsDOMDOMStringList : public nsIDOMDOMStringList
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIDOMDOMSTRINGLIST

  nsDOMDOMStringList();

private:
  ~nsDOMDOMStringList();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsDOMDOMStringList, nsIDOMDOMStringList)

nsDOMDOMStringList::nsDOMDOMStringList()
{
  /* member initializers and constructor code */
}

nsDOMDOMStringList::~nsDOMDOMStringList()
{
  /* destructor code */
}

/* DOMString item (in unsigned long index); */
NS_IMETHODIMP nsDOMDOMStringList::Item(PRUint32 index, nsAString & _retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute unsigned long length; */
NS_IMETHODIMP nsDOMDOMStringList::GetLength(PRUint32 *aLength)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIDOMDOMStringList_h__ */
