/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIDOMNameList.idl
 */

#ifndef __gen_nsIDOMNameList_h__
#define __gen_nsIDOMNameList_h__


#ifndef __gen_domstubs_h__
#include "domstubs.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIDOMNameList */
#define NS_IDOMNAMELIST_IID_STR "e9ceba95-b62b-11d7-af68-000a95687b38"

#define NS_IDOMNAMELIST_IID \
  {0xe9ceba95, 0xb62b, 0x11d7, \
    { 0xaf, 0x68, 0x00, 0x0a, 0x95, 0x68, 0x7b, 0x38 }}

class NS_NO_VTABLE nsIDOMNameList : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IDOMNAMELIST_IID)

  /* DOMString getName (in unsigned long index)  raises (DOMException); */
  NS_IMETHOD GetName(PRUint32 index, nsAString & _retval) = 0;

  /* DOMString getNamespaceURI (in unsigned long index)  raises (DOMException); */
  NS_IMETHOD GetNamespaceURI(PRUint32 index, nsAString & _retval) = 0;

  /* readonly attribute unsigned long length; */
  NS_IMETHOD GetLength(PRUint32 *aLength) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIDOMNAMELIST \
  NS_IMETHOD GetName(PRUint32 index, nsAString & _retval); \
  NS_IMETHOD GetNamespaceURI(PRUint32 index, nsAString & _retval); \
  NS_IMETHOD GetLength(PRUint32 *aLength); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIDOMNAMELIST(_to) \
  NS_IMETHOD GetName(PRUint32 index, nsAString & _retval) { return _to GetName(index, _retval); } \
  NS_IMETHOD GetNamespaceURI(PRUint32 index, nsAString & _retval) { return _to GetNamespaceURI(index, _retval); } \
  NS_IMETHOD GetLength(PRUint32 *aLength) { return _to GetLength(aLength); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIDOMNAMELIST(_to) \
  NS_IMETHOD GetName(PRUint32 index, nsAString & _retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetName(index, _retval); } \
  NS_IMETHOD GetNamespaceURI(PRUint32 index, nsAString & _retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNamespaceURI(index, _retval); } \
  NS_IMETHOD GetLength(PRUint32 *aLength) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLength(aLength); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsDOMNameList : public nsIDOMNameList
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIDOMNAMELIST

  nsDOMNameList();

private:
  ~nsDOMNameList();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsDOMNameList, nsIDOMNameList)

nsDOMNameList::nsDOMNameList()
{
  /* member initializers and constructor code */
}

nsDOMNameList::~nsDOMNameList()
{
  /* destructor code */
}

/* DOMString getName (in unsigned long index)  raises (DOMException); */
NS_IMETHODIMP nsDOMNameList::GetName(PRUint32 index, nsAString & _retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* DOMString getNamespaceURI (in unsigned long index)  raises (DOMException); */
NS_IMETHODIMP nsDOMNameList::GetNamespaceURI(PRUint32 index, nsAString & _retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute unsigned long length; */
NS_IMETHODIMP nsDOMNameList::GetLength(PRUint32 *aLength)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIDOMNameList_h__ */
