/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbDirFactory.idl
 */

#ifndef __gen_nsIAbDirFactory_h__
#define __gen_nsIAbDirFactory_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsISimpleEnumerator_h__
#include "nsISimpleEnumerator.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAbDirectory; /* forward declaration */

class nsIAbDirectoryProperties; /* forward declaration */


/* starting interface:    nsIAbDirFactory */
#define NS_IABDIRFACTORY_IID_STR "c2308606-1dd1-11b2-87d4-85fca9b1dc08"

#define NS_IABDIRFACTORY_IID \
  {0xc2308606, 0x1dd1, 0x11b2, \
    { 0x87, 0xd4, 0x85, 0xfc, 0xa9, 0xb1, 0xdc, 0x08 }}

class NS_NO_VTABLE nsIAbDirFactory : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABDIRFACTORY_IID)

  /**
     * Instantiate new top level address book
     * directories given some properties. 
     * More than one directory may be
     * returned depending on the implementation
     * and integration with the associated address book
     * sources
     *
     * @param aProperties
     *        nsIAbDirectoryProperties with the properties
     * @return
     *        Enumeration of nsIAbDirectory
     *        interfaces
     */
  /* nsISimpleEnumerator createDirectory (in nsIAbDirectoryProperties aProperties); */
  NS_IMETHOD CreateDirectory(nsIAbDirectoryProperties *aProperties, nsISimpleEnumerator **_retval) = 0;

  /**
     * Delete a top level address book directory
     * 
     */
  /* void deleteDirectory (in nsIAbDirectory directory); */
  NS_IMETHOD DeleteDirectory(nsIAbDirectory *directory) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABDIRFACTORY \
  NS_IMETHOD CreateDirectory(nsIAbDirectoryProperties *aProperties, nsISimpleEnumerator **_retval); \
  NS_IMETHOD DeleteDirectory(nsIAbDirectory *directory); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABDIRFACTORY(_to) \
  NS_IMETHOD CreateDirectory(nsIAbDirectoryProperties *aProperties, nsISimpleEnumerator **_retval) { return _to CreateDirectory(aProperties, _retval); } \
  NS_IMETHOD DeleteDirectory(nsIAbDirectory *directory) { return _to DeleteDirectory(directory); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABDIRFACTORY(_to) \
  NS_IMETHOD CreateDirectory(nsIAbDirectoryProperties *aProperties, nsISimpleEnumerator **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateDirectory(aProperties, _retval); } \
  NS_IMETHOD DeleteDirectory(nsIAbDirectory *directory) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeleteDirectory(directory); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbDirFactory : public nsIAbDirFactory
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABDIRFACTORY

  nsAbDirFactory();

private:
  ~nsAbDirFactory();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbDirFactory, nsIAbDirFactory)

nsAbDirFactory::nsAbDirFactory()
{
  /* member initializers and constructor code */
}

nsAbDirFactory::~nsAbDirFactory()
{
  /* destructor code */
}

/* nsISimpleEnumerator createDirectory (in nsIAbDirectoryProperties aProperties); */
NS_IMETHODIMP nsAbDirFactory::CreateDirectory(nsIAbDirectoryProperties *aProperties, nsISimpleEnumerator **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deleteDirectory (in nsIAbDirectory directory); */
NS_IMETHODIMP nsAbDirFactory::DeleteDirectory(nsIAbDirectory *directory)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbDirFactory_h__ */
