/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbAddressCollecter.idl
 */

#ifndef __gen_nsIAbAddressCollecter_h__
#define __gen_nsIAbAddressCollecter_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAbCard; /* forward declaration */


/* starting interface:    nsIAbAddressCollecter */
#define NS_IABADDRESSCOLLECTER_IID_STR "fe04c8e6-501e-11d3-a527-0060b0fc04b7"

#define NS_IABADDRESSCOLLECTER_IID \
  {0xfe04c8e6, 0x501e, 0x11d3, \
    { 0xa5, 0x27, 0x00, 0x60, 0xb0, 0xfc, 0x04, 0xb7 }}

class NS_NO_VTABLE nsIAbAddressCollecter : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABADDRESSCOLLECTER_IID)

  /* [noscript] void collectAddress (in string address, in boolean aCreateCard); */
  NS_IMETHOD CollectAddress(const char *address, PRBool aCreateCard) = 0;

  /* void collectUnicodeAddress (in wstring address, in boolean aCreateCard); */
  NS_IMETHOD CollectUnicodeAddress(const PRUnichar *address, PRBool aCreateCard) = 0;

  /* nsIAbCard getCardFromAttribute (in string aName, in string aValue); */
  NS_IMETHOD GetCardFromAttribute(const char *aName, const char *aValue, nsIAbCard **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABADDRESSCOLLECTER \
  NS_IMETHOD CollectAddress(const char *address, PRBool aCreateCard); \
  NS_IMETHOD CollectUnicodeAddress(const PRUnichar *address, PRBool aCreateCard); \
  NS_IMETHOD GetCardFromAttribute(const char *aName, const char *aValue, nsIAbCard **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABADDRESSCOLLECTER(_to) \
  NS_IMETHOD CollectAddress(const char *address, PRBool aCreateCard) { return _to CollectAddress(address, aCreateCard); } \
  NS_IMETHOD CollectUnicodeAddress(const PRUnichar *address, PRBool aCreateCard) { return _to CollectUnicodeAddress(address, aCreateCard); } \
  NS_IMETHOD GetCardFromAttribute(const char *aName, const char *aValue, nsIAbCard **_retval) { return _to GetCardFromAttribute(aName, aValue, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABADDRESSCOLLECTER(_to) \
  NS_IMETHOD CollectAddress(const char *address, PRBool aCreateCard) { return !_to ? NS_ERROR_NULL_POINTER : _to->CollectAddress(address, aCreateCard); } \
  NS_IMETHOD CollectUnicodeAddress(const PRUnichar *address, PRBool aCreateCard) { return !_to ? NS_ERROR_NULL_POINTER : _to->CollectUnicodeAddress(address, aCreateCard); } \
  NS_IMETHOD GetCardFromAttribute(const char *aName, const char *aValue, nsIAbCard **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCardFromAttribute(aName, aValue, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbAddressCollecter : public nsIAbAddressCollecter
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABADDRESSCOLLECTER

  nsAbAddressCollecter();

private:
  ~nsAbAddressCollecter();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbAddressCollecter, nsIAbAddressCollecter)

nsAbAddressCollecter::nsAbAddressCollecter()
{
  /* member initializers and constructor code */
}

nsAbAddressCollecter::~nsAbAddressCollecter()
{
  /* destructor code */
}

/* [noscript] void collectAddress (in string address, in boolean aCreateCard); */
NS_IMETHODIMP nsAbAddressCollecter::CollectAddress(const char *address, PRBool aCreateCard)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void collectUnicodeAddress (in wstring address, in boolean aCreateCard); */
NS_IMETHODIMP nsAbAddressCollecter::CollectUnicodeAddress(const PRUnichar *address, PRBool aCreateCard)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAbCard getCardFromAttribute (in string aName, in string aValue); */
NS_IMETHODIMP nsAbAddressCollecter::GetCardFromAttribute(const char *aName, const char *aValue, nsIAbCard **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbAddressCollecter_h__ */
