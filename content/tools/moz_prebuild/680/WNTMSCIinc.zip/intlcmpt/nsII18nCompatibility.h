/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM k:/localcws/src/moz/wntmsci10.pro/misc/build/mozilla/intl/compatibility/idl/nsII18nCompatibility.idl
 */

#ifndef __gen_nsII18nCompatibility_h__
#define __gen_nsII18nCompatibility_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
// Define Contractid and CID
// {93941450-664A-11d3-9151-006008A6EDF6}
#define NS_I18NCOMPATIBILITY_CID \
{ 0x93941450, 0x664a, 0x11d3, { 0x91, 0x51, 0x0, 0x60, 0x8, 0xa6, 0xed, 0xf6 } }
#define NS_I18NCOMPATIBILITY_CONTRACTID "@mozilla.org/intl/compatibility;1"

/* starting interface:    nsII18nCompatibility */
#define NS_II18NCOMPATIBILITY_IID_STR "93941450-664a-11d3-9151-006008a6edf6"

#define NS_II18NCOMPATIBILITY_IID \
  {0x93941450, 0x664a, 0x11d3, \
    { 0x91, 0x51, 0x00, 0x60, 0x08, 0xa6, 0xed, 0xf6 }}

class NS_NO_VTABLE nsII18nCompatibility : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_II18NCOMPATIBILITY_IID)

  /* wstring CSIDtoCharsetName (in unsigned short csid); */
  NS_IMETHOD CSIDtoCharsetName(PRUint16 csid, PRUnichar **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSII18NCOMPATIBILITY \
  NS_IMETHOD CSIDtoCharsetName(PRUint16 csid, PRUnichar **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSII18NCOMPATIBILITY(_to) \
  NS_IMETHOD CSIDtoCharsetName(PRUint16 csid, PRUnichar **_retval) { return _to CSIDtoCharsetName(csid, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSII18NCOMPATIBILITY(_to) \
  NS_IMETHOD CSIDtoCharsetName(PRUint16 csid, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CSIDtoCharsetName(csid, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsI18nCompatibility : public nsII18nCompatibility
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSII18NCOMPATIBILITY

  nsI18nCompatibility();

private:
  ~nsI18nCompatibility();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsI18nCompatibility, nsII18nCompatibility)

nsI18nCompatibility::nsI18nCompatibility()
{
  /* member initializers and constructor code */
}

nsI18nCompatibility::~nsI18nCompatibility()
{
  /* destructor code */
}

/* wstring CSIDtoCharsetName (in unsigned short csid); */
NS_IMETHODIMP nsI18nCompatibility::CSIDtoCharsetName(PRUint16 csid, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsII18nCompatibility_h__ */
