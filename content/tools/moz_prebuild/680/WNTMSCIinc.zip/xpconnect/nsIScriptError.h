/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM k:/localcws/src/moz/wntmsci10.pro/misc/build/mozilla/js/src/xpconnect/idl/nsIScriptError.idl
 */

#ifndef __gen_nsIScriptError_h__
#define __gen_nsIScriptError_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIConsoleMessage_h__
#include "nsIConsoleMessage.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIScriptError */
#define NS_ISCRIPTERROR_IID_STR "fc9e5a94-1dd1-11b2-888b-d8907b2c6996"

#define NS_ISCRIPTERROR_IID \
  {0xfc9e5a94, 0x1dd1, 0x11b2, \
    { 0x88, 0x8b, 0xd8, 0x90, 0x7b, 0x2c, 0x69, 0x96 }}

class NS_NO_VTABLE nsIScriptError : public nsIConsoleMessage {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ISCRIPTERROR_IID)

  /** pseudo-flag for default case */
  enum { errorFlag = 0U };

  /** message is warning */
  enum { warningFlag = 1U };

  /** exception was thrown for this case - exception-aware hosts can ignore */
  enum { exceptionFlag = 2U };

  /** error or warning is due to strict option */
  enum { strictFlag = 4U };

  /* readonly attribute wstring sourceName; */
  NS_IMETHOD GetSourceName(PRUnichar * *aSourceName) = 0;

  /* readonly attribute wstring sourceLine; */
  NS_IMETHOD GetSourceLine(PRUnichar * *aSourceLine) = 0;

  /* readonly attribute PRUint32 lineNumber; */
  NS_IMETHOD GetLineNumber(PRUint32 *aLineNumber) = 0;

  /* readonly attribute PRUint32 columnNumber; */
  NS_IMETHOD GetColumnNumber(PRUint32 *aColumnNumber) = 0;

  /* readonly attribute PRUint32 flags; */
  NS_IMETHOD GetFlags(PRUint32 *aFlags) = 0;

  /**
     * Categories I know about -
     * XUL javascript
     * content javascript (both of these from nsDocShell, currently)
     * component javascript (errors in JS components)
     */
  /* readonly attribute string category; */
  NS_IMETHOD GetCategory(char * *aCategory) = 0;

  /* void init (in wstring message, in wstring sourceName, in wstring sourceLine, in PRUint32 lineNumber, in PRUint32 columnNumber, in PRUint32 flags, in string category); */
  NS_IMETHOD Init(const PRUnichar *message, const PRUnichar *sourceName, const PRUnichar *sourceLine, PRUint32 lineNumber, PRUint32 columnNumber, PRUint32 flags, const char *category) = 0;

  /* string toString (); */
  NS_IMETHOD ToString(char **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSISCRIPTERROR \
  NS_IMETHOD GetSourceName(PRUnichar * *aSourceName); \
  NS_IMETHOD GetSourceLine(PRUnichar * *aSourceLine); \
  NS_IMETHOD GetLineNumber(PRUint32 *aLineNumber); \
  NS_IMETHOD GetColumnNumber(PRUint32 *aColumnNumber); \
  NS_IMETHOD GetFlags(PRUint32 *aFlags); \
  NS_IMETHOD GetCategory(char * *aCategory); \
  NS_IMETHOD Init(const PRUnichar *message, const PRUnichar *sourceName, const PRUnichar *sourceLine, PRUint32 lineNumber, PRUint32 columnNumber, PRUint32 flags, const char *category); \
  NS_IMETHOD ToString(char **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSISCRIPTERROR(_to) \
  NS_IMETHOD GetSourceName(PRUnichar * *aSourceName) { return _to GetSourceName(aSourceName); } \
  NS_IMETHOD GetSourceLine(PRUnichar * *aSourceLine) { return _to GetSourceLine(aSourceLine); } \
  NS_IMETHOD GetLineNumber(PRUint32 *aLineNumber) { return _to GetLineNumber(aLineNumber); } \
  NS_IMETHOD GetColumnNumber(PRUint32 *aColumnNumber) { return _to GetColumnNumber(aColumnNumber); } \
  NS_IMETHOD GetFlags(PRUint32 *aFlags) { return _to GetFlags(aFlags); } \
  NS_IMETHOD GetCategory(char * *aCategory) { return _to GetCategory(aCategory); } \
  NS_IMETHOD Init(const PRUnichar *message, const PRUnichar *sourceName, const PRUnichar *sourceLine, PRUint32 lineNumber, PRUint32 columnNumber, PRUint32 flags, const char *category) { return _to Init(message, sourceName, sourceLine, lineNumber, columnNumber, flags, category); } \
  NS_IMETHOD ToString(char **_retval) { return _to ToString(_retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSISCRIPTERROR(_to) \
  NS_IMETHOD GetSourceName(PRUnichar * *aSourceName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSourceName(aSourceName); } \
  NS_IMETHOD GetSourceLine(PRUnichar * *aSourceLine) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSourceLine(aSourceLine); } \
  NS_IMETHOD GetLineNumber(PRUint32 *aLineNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLineNumber(aLineNumber); } \
  NS_IMETHOD GetColumnNumber(PRUint32 *aColumnNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetColumnNumber(aColumnNumber); } \
  NS_IMETHOD GetFlags(PRUint32 *aFlags) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFlags(aFlags); } \
  NS_IMETHOD GetCategory(char * *aCategory) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCategory(aCategory); } \
  NS_IMETHOD Init(const PRUnichar *message, const PRUnichar *sourceName, const PRUnichar *sourceLine, PRUint32 lineNumber, PRUint32 columnNumber, PRUint32 flags, const char *category) { return !_to ? NS_ERROR_NULL_POINTER : _to->Init(message, sourceName, sourceLine, lineNumber, columnNumber, flags, category); } \
  NS_IMETHOD ToString(char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ToString(_retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsScriptError : public nsIScriptError
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSISCRIPTERROR

  nsScriptError();

private:
  ~nsScriptError();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsScriptError, nsIScriptError)

nsScriptError::nsScriptError()
{
  /* member initializers and constructor code */
}

nsScriptError::~nsScriptError()
{
  /* destructor code */
}

/* readonly attribute wstring sourceName; */
NS_IMETHODIMP nsScriptError::GetSourceName(PRUnichar * *aSourceName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute wstring sourceLine; */
NS_IMETHODIMP nsScriptError::GetSourceLine(PRUnichar * *aSourceLine)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute PRUint32 lineNumber; */
NS_IMETHODIMP nsScriptError::GetLineNumber(PRUint32 *aLineNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute PRUint32 columnNumber; */
NS_IMETHODIMP nsScriptError::GetColumnNumber(PRUint32 *aColumnNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute PRUint32 flags; */
NS_IMETHODIMP nsScriptError::GetFlags(PRUint32 *aFlags)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute string category; */
NS_IMETHODIMP nsScriptError::GetCategory(char * *aCategory)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void init (in wstring message, in wstring sourceName, in wstring sourceLine, in PRUint32 lineNumber, in PRUint32 columnNumber, in PRUint32 flags, in string category); */
NS_IMETHODIMP nsScriptError::Init(const PRUnichar *message, const PRUnichar *sourceName, const PRUnichar *sourceLine, PRUint32 lineNumber, PRUint32 columnNumber, PRUint32 flags, const char *category)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* string toString (); */
NS_IMETHODIMP nsScriptError::ToString(char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

#define NS_SCRIPTERROR_CLASSNAME "Script Error"
#define NS_SCRIPTERROR_CID \
{ 0xe38e53b9, 0x5bb0, 0x456a, { 0xb5, 0x53, 0x57, 0x93, 0x70, 0xcb, 0x15, 0x67 }}
#define NS_SCRIPTERROR_CONTRACTID "@mozilla.org/scripterror;1"

#endif /* __gen_nsIScriptError_h__ */
