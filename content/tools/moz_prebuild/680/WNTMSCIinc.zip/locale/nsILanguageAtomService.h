/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM k:/localcws/src/moz/wntmsci10.pro/misc/build/mozilla/intl/locale/idl/nsILanguageAtomService.idl
 */

#ifndef __gen_nsILanguageAtomService_h__
#define __gen_nsILanguageAtomService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsILanguageAtom_h__
#include "nsILanguageAtom.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsILanguageAtomService */
#define NS_ILANGUAGEATOMSERVICE_IID_STR "a6cf911f-15b3-11d2-932e-00805f8add32"

#define NS_ILANGUAGEATOMSERVICE_IID \
  {0xa6cf911f, 0x15b3, 0x11d2, \
    { 0x93, 0x2e, 0x00, 0x80, 0x5f, 0x8a, 0xdd, 0x32 }}

class NS_NO_VTABLE nsILanguageAtomService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ILANGUAGEATOMSERVICE_IID)

  /* nsILanguageAtom LookupLanguage (in wstring aLanguage); */
  NS_IMETHOD LookupLanguage(const PRUnichar *aLanguage, nsILanguageAtom **_retval) = 0;

  /* nsILanguageAtom LookupCharSet (in string aCharSet); */
  NS_IMETHOD LookupCharSet(const char *aCharSet, nsILanguageAtom **_retval) = 0;

  /* nsIAtom GetLocaleLanguageGroup (); */
  NS_IMETHOD GetLocaleLanguageGroup(nsIAtom **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSILANGUAGEATOMSERVICE \
  NS_IMETHOD LookupLanguage(const PRUnichar *aLanguage, nsILanguageAtom **_retval); \
  NS_IMETHOD LookupCharSet(const char *aCharSet, nsILanguageAtom **_retval); \
  NS_IMETHOD GetLocaleLanguageGroup(nsIAtom **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSILANGUAGEATOMSERVICE(_to) \
  NS_IMETHOD LookupLanguage(const PRUnichar *aLanguage, nsILanguageAtom **_retval) { return _to LookupLanguage(aLanguage, _retval); } \
  NS_IMETHOD LookupCharSet(const char *aCharSet, nsILanguageAtom **_retval) { return _to LookupCharSet(aCharSet, _retval); } \
  NS_IMETHOD GetLocaleLanguageGroup(nsIAtom **_retval) { return _to GetLocaleLanguageGroup(_retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSILANGUAGEATOMSERVICE(_to) \
  NS_IMETHOD LookupLanguage(const PRUnichar *aLanguage, nsILanguageAtom **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->LookupLanguage(aLanguage, _retval); } \
  NS_IMETHOD LookupCharSet(const char *aCharSet, nsILanguageAtom **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->LookupCharSet(aCharSet, _retval); } \
  NS_IMETHOD GetLocaleLanguageGroup(nsIAtom **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLocaleLanguageGroup(_retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsLanguageAtomService : public nsILanguageAtomService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSILANGUAGEATOMSERVICE

  nsLanguageAtomService();

private:
  ~nsLanguageAtomService();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsLanguageAtomService, nsILanguageAtomService)

nsLanguageAtomService::nsLanguageAtomService()
{
  /* member initializers and constructor code */
}

nsLanguageAtomService::~nsLanguageAtomService()
{
  /* destructor code */
}

/* nsILanguageAtom LookupLanguage (in wstring aLanguage); */
NS_IMETHODIMP nsLanguageAtomService::LookupLanguage(const PRUnichar *aLanguage, nsILanguageAtom **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsILanguageAtom LookupCharSet (in string aCharSet); */
NS_IMETHODIMP nsLanguageAtomService::LookupCharSet(const char *aCharSet, nsILanguageAtom **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAtom GetLocaleLanguageGroup (); */
NS_IMETHODIMP nsLanguageAtomService::GetLocaleLanguageGroup(nsIAtom **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

#define NS_LANGUAGEATOMSERVICE_CID \
  {0xa6cf9120, 0x15b3, 0x11d2, {0x93, 0x2e, 0x00, 0x80, 0x5f, 0x8a, 0xdd, 0x32}}
#define NS_LANGUAGEATOMSERVICE_CONTRACTID \
  "@mozilla.org/intl/nslanguageatomservice;1"

#endif /* __gen_nsILanguageAtomService_h__ */
