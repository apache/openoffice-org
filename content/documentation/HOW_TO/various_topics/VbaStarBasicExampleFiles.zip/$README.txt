This zip file contains the following files:

ExcelExamples.xls - Sample Excel workbook with VBA macro code

PortedExcelExamples.sxc - Calc version of ExcelExamples.xls, where the VBA macro code has been ported to StarBasic.

Multi-page Form.sxc - Calc spreadsheet demonstrating StarBasic emulation of the Microsoft Office MultiPage Control.