README for Label Templates
**************************

This package comprises of the following files:

1	This README document.
2	The HOWTO file in PDF format.
3	A basic, single sheet template for Avery J8163 labels, 
	'Avery Labels(J8163).stw'
4	A multi-sheet (5) template for Avery J8163 labels with pre-entered 
	OpenOffice.org fields, 'Avery Labels(J8163) + Fields.stw'
5	A sample 'calc' spreadsheet with dummy entries for use as a data source 
	model, 'SampleDatasource.sxc'
