Copyright 2006 Nicole Follet-Dunn.

http://homepage.mac.com/cinder1013
cinder1013@mac.com

Clipart for Teachers index below.

Clipart for Teachers is free library; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation; either version 2.1 of the License, or any later version.

Clipart for Teachers is distributed in the hope that it will be useful,but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along with Clipart for Teachers; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Index of Clipart Images:

apple.gif
bubbles.gif
chalkboard_banner.gif
chalkboard_banner_abc.gif
chalkboard_banner_globe.gif
chalkboard_banner_relative.gif
chalkboard_banner_theorem.gif
chalkboard_frame.gif
chalkboard_side.gif
cloud.gif
congrats.gif
experiment.gif
good_work.gif
graph_banner.gif
graph_banner_xy.gif
great_job.gif
inkpot.gif
lightning_bolt.gif
lightning_bolt_black.gif
lightning_bolt_blue.gif
lightning_bolt_red.gif
lightning_cloud.gif
lightning_cloud_black.gif
lightning_cloud_red.gif
look_down.gif
look_left.gif
look_right.gif
look_up.gif
music_staff_banner.gif
music_staff_frame.gif
nucleon.gif
number_one.gif
ribbon_green.gif
ribbon_purple.gif
ribbon_wine.gif
ribbon_yellow.gif
shooting_star.gif
square_frame.gif
stars.gif
super.gif
xy_frame.gif

