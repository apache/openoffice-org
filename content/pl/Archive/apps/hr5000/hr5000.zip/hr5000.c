/* This program copies from .txt files in the following format:
   -cmdlineparam#DESCRIPTION
   source1.txt+source2.txt+source3.txt target.html
   source1.txt+source2.txt+source3.txt target.html
   / comment 
   Nie odpowiadam za ewentualne zaoranie dysku mog�ce wynikn�� 
   z niew�a�ciwej konfiguracji pliku make.txt czy te� b��du 
   w programie. Licencja GNU/GPL.
   
   http://prace.sciaga.pl/26399.html
   http://www.cppreference.com/
   http://www-ccs.ucsd.edu/c/   
*/
   
#include <stdio.h>
#include <conio.h>
#include <string.h>
#define MAX 200 



int choose(char bigyes, char smallyes, char bigno, char smallno) {
  char ch=0x20;
  int i=2;
  
  while (i==2) {
  ch=getch();
  if ((ch==bigyes) || (ch==smallyes)) i=1;
  if ((ch==bigno) || (ch==smallno)) i=0;
  }
  printf("%c",ch);
 
 return i; 
}


int main(int argc, char *argv[]) {
  char *lista = "katalog.txt";
  char *bat = "make.bat";
  char *cat = ".";
  char *lang = "pl";
  FILE *input; 
  FILE *output; 
  char params[MAX+2];
  char user[MAX+2];
  char src[MAX+2];
  char dst[MAX+2];
  char ch=0x20, lastch=0xA;
  int flag=0, letter=0, linetype=0, allow=0, x=0, a=0, i=0;
  
    
   x=1;
  while (x<argc) {
   if (strstr(argv[x],"-cat")!=0) {
    lista=argv[x+1];
   }
   if (strstr(argv[x],"-bat")!=0) {
    bat=argv[x+1];
   }
   if (strstr(argv[x],"-wd")!=0) {
    cat=argv[x+1];
   }
   if (strstr(argv[x],"-l")!=0) {
	lang=argv[x+1];
   if ((strstr(lang, "pl")==0) && (strstr(lang, "en")==0)) {
		printf("\nUNSUPPORTED LANGUAGE, &s.\VERSIONS OF THE SOFTWARE ARE AVAILABLE IN:\n English (en), Polski (pl)\n", lang); return 1;}
		
		
		
   }
   if ((strstr(argv[x],"-cat")==0) && (strstr(argv[x],"-bat")==0) && (strstr(argv[x],"-wd")==0) && (strstr(argv[x],"-l")==0)  )  {
	   
	{if (strstr(lang, "pl")!=0) {
	printf("\nHyperRenamer5000 (HR5000) by Konrad Stobiecki @2005");
    printf("\nSpis polecen:");
    printf("\n-cat {nazwa}    --- zmienia katalog dokumentow, np. -cat katalog.txt");
    printf("\n-bat {nazwa}    --- zmienia nazwe pliku wykonywalnego, np. -bat make.bat");
    printf("\n-wd {katalog}   --- zmienia katalog roboczy, np. -wd ..");
    printf("\n-l {jezyk}      --- okresla jezyk, lista dostepnych: -l ?");
    printf("\n-?              --- wy�wietla ta informacje\n");
    }
    if (strstr(lang, "en")!=0) {
	printf("\nHyperRenamer5000 (HR5000) by Konrad Stobiecki @2005");
    printf("\nList of commands:");
    printf("\n-cat {file}   --- changes the catalogue file name, ie. -cat katalog.txt");
    printf("\n-bat {file}   --- changes the batch name, ie. -bat make.bat");
    printf("\n-wd {dir}     --- adjusts the working directory, ie. -wd ..");
    printf("\n-l {language} --- adjusts the language, to list the available ones: -l ?");
    printf("\n-?            --- shows this help\n");
    }}
    
    
    return 0;
   }
   
   x=x+2;
  }

  input=fopen(lista, "r");
  output=fopen( bat, "w" ); 
  
    {if (strstr(lang, "pl")!=0) {
   printf("\nHyperRenamer5000 (HR5000) by Konrad Stobiecki @2005.\nWcisnij ENTER dla zadnych parametrow. 'A' lub 'a' aby skopiowac wszystko.\n'Q' lub 'q' wyjscie.\nParametry ? ");
   }
     if (strstr(lang, "en")!=0) {
  printf("\nHyperRenamer5000 (HR5000) by Konrad Stobiecki @2005.\nPress ENTER for no parameters. 'A' or 'a' to copy all.\n'Q' or 'q' to quit.\nParameters ? ");
   }}
  

    x=0;
    
   while ((ch != 0xD) && (x < MAX)) {
   ch=getch();
   if (ch !=0xD)
   {
    params[x]=ch;
    params[x+1]=' ';
    params[x+2]='\0';
   }
   if ((ch ==0xD) && (x==0))
   {
	params[x]=ch;
	params[x+1]='\0';
   }
   x++;
   printf("%c", ch);
   
  }

  if ((params[0] != 0xD) && (params[0] != 0x20) && (params[0] !=  0x2F) && params[0] != 0x2D) {
   if (    ((params[0] != 'a') || (params[0] != 'A')) && ( params[1] != ' ' )     ) {
     x=2;
     

         {if (strstr(lang, "en")!=0) {
     printf("\nKopiowanie dla: %s\n", params); 
   	 }
   	     if (strstr(lang, "pl")!=0) {
	    printf("\nCopying for: %s\n", params); 
      }}
	  
    }   
   else if ( (params[0] == 'a') || (params[0] == 'A') ) {
	   
       x=1;
	   {if (strstr(lang, "pl")!=0) {
	   printf("\nKopiowanie calosci.\n"); 
       }
       if (strstr(lang, "en")!=0) {
       printf("\nCopying all.\n"); 
       }}
     
     }
       
   else if  ( (params[0] == 'q') || (params[0] == 'Q') ) return 0;
   
   
   else {x=0; 
   
      {if (strstr(lang, "pl")!=0) {
       printf("Bedziesz zapytany o pliki do skopiowania.\n"); 
         }
         if (strstr(lang, "en")!=0) {
       printf("You will be prompted for files to copy.\n"); 
       }}
       
       
       
     }
     
  
  }
  else {x=0; 
  
    {if (strstr(lang, "pl")!=0) {
       printf("Bedziesz zapytany o pliki do skopiowania.\n");
       }
       if (strstr(lang, "en")!=0) {
       printf("You will be prompted for files to copy.\n");
       }}
       
    }
    
    {if (strstr(lang, "pl")!=0) {
  fprintf( output, "@REM Stworzono w HR5000\n@ECHO ---KOPIOWANIE---\n@cd %s\n", cat);
    }
    if (strstr(lang, "en")!=0) {
  fprintf( output, "@REM Created in HR5000\n@ECHO ---COPYING---\n@cd %s\n", cat);}
    }
    
     ch = getc( input );
      
   while( ch != EOF ) {

	   
	   if ((ch == 0x20) || (ch == 0xA)) letter=0;
	   if (lastch == 0xA)
	    {
		 if ((linetype==1) && (x==0)) {
			 
			{if (strstr(lang, "pl")!=0) {
	      printf("Kopiowac dla %s?", user); allow=choose('T', 't', 'N', 'n');
            }
            if (strstr(lang, "en")!=0) {
	      printf("Copy for %s?", user); allow=choose('Y', 'y', 'N', 'n');
	      }}

	      
	      
	      printf("\n");
		 }
	     
		 if ((linetype==1) && (x==1)) {
		  allow=1;
	     }
	     
	     if ((linetype==1) && (x==2)) {
		     i=strstr(params, user);

		     if (strstr(params, user) != 0) allow=1; 
		     else allow=0;
	     }
		 
		 
		 if ((linetype==2) && (allow==1)) {
 		  
			 
		  if (strstr(src,"md\0")!=0) {
			  
			  {if (strstr(lang, "pl")!=0) {
	      printf("ladowanie: %s %s\n", src, dst);
            }
            if (strstr(lang, "en")!=0) {
	      printf("loading: %s %s\n", src, dst);
	      }}
		   
 		   fprintf(output, "%s %s \n", src, dst);		 
	      }		 
	      else { 
		      
		        {if (strstr(lang, "pl")!=0) {
	      printf("zaladowano: %s --> %s\n", src, dst);
            }
            if (strstr(lang, "en")!=0) {
	      printf("loading: %s --> %s\n", src, dst);
	      }}
		      
 		   
 		   fprintf(output, "copy /B %s %s \n", src, dst);
		  }
 		  
 		  
	      i=0; while (i!=(MAX+2)) {src[i]='\0'; i++; } 
	      i=0; while (i!=(MAX+2)) {dst[i]='\0'; i++; } 
	     }
		 
	     if (linetype==1) {
	      i=0; while (i!=(MAX+2)) {src[i]='\0'; i++; } 
	      i=0; while (i!=(MAX+2)) {dst[i]='\0'; i++; } 
         }
		 
             
		 switch (ch) {
		  case 0x2D: linetype=1; break;
		  case 0x2F: linetype=0; break;
		  case 0xA: linetype=0; break;
		  default: linetype=2; flag=1; break;
	     }
	    }
        
        switch (linetype) {
	     case 0: break; 
	     case 1: switch (ch) {
	              case 0x2D: if (lastch==0xA) {printf("\n:: "); flag=3; letter=0; i=0; while (i!=(MAX+2)) {user[i]='\0'; i++;} }
	                         else {user[letter-1]=ch; user[letter]=' '; user[letter+1]='\0'; printf("%c", ch);} break;
	              case 0x23: printf("\n::: "); flag=0; break;
	              default: if ((flag==3) && (letter>0)) {user[letter-1]=ch; user[letter]=' '; user[letter+1]='\0';} printf("%c", ch);
                 } break;
                 
         case 2: 
                 
                 if ((flag == 1) && (ch == 0x20)) flag=2;
	             
                 if ((flag == 2) && ((ch == 0x20) || (ch == 0xA)) && (letter>0)) flag=0;
         
                 if ((flag == 1) && (ch!=0x20) && (ch!=0xA) && (letter>0)) {
	             src[letter-1]=ch; src[letter]='\0';
	             }
                 
	             if ((flag == 2) && (ch != 0xA) && (ch != 0x20) && (letter>0)) {
				 dst[letter-1]=ch; dst[letter]='\0';
				 }
		         
	             break;
        }
	             
        
        
     
     letter = letter++;
     lastch = ch;
     ch = getc( input );
   
     
     

   }
   
  {if (strstr(lang, "pl")!=0) {
   printf( "\n\nPlik danych:\n%s\n", lista );
   printf( "Plik wyjsciowy:\n%s\n", bat );
     }
     if (strstr(lang, "en")!=0) {
   printf( "\n\nData file:\n%s\n", lista );
   printf( "Output file:\n%s\n", bat );
    }}   
   
   		
   
 
 fclose (input);
 fclose (output);
 return 5000;  
}

/*
0x20 - SPC
0x20 - 0x7a - vaild chars
0xA, 0xD - BR
0x23 - HASH
0x2B - ADD
0x2F - SLASH
0x2D - DASH*/