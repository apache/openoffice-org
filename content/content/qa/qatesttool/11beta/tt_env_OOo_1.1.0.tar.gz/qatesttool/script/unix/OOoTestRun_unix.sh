#!/bin/bash

#########################################################################
#
#  $RCSfile: OOoTestRun_unix.sh,v $
#
#  $Revision: 1.1 $
#
#  last change: $Author: tbo $ $Date: 2003/09/09 17:29:19 $
#
#  The Contents of this file are made available subject to the terms of
#  either of the following licenses
#
#         - GNU Lesser General Public License Version 2.1
#         - Sun Industry Standards Source License Version 1.1
#
#  Sun Microsystems Inc., October, 2000
#
#  GNU Lesser General Public License Version 2.1
#  =============================================
#  Copyright 2000 by Sun Microsystems, Inc.
#  901 San Antonio Road, Palo Alto, CA 94303, USA
#
#  This library is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Lesser General Public
#  License version 2.1, as published by the Free Software Foundation.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public
#  License along with this library; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
#  MA  02111-1307  USA
#
#
#  Sun Industry Standards Source License Version 1.1
#  =================================================
#  The contents of this file are subject to the Sun Industry Standards
#  Source License Version 1.1 (the License); You may not use this file
#  except in compliance with the License. You may obtain a copy of the
#  License at http://www.openoffice.org/license.html.
#
#  Software provided under this License is provided on an AS IS basis,
#  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
#  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
#  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
#  See the License for the specific provisions governing your rights and
#  obligations concerning the Software.
#
#  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
#
#  Copyright: 2000 by Sun Microsystems, Inc.
#
#  All Rights Reserved.
#
#  Contributor(s): _______________________________________
#
#########################################################################
#
# Owner : thorsten.bosbach@sun.com
#
# short description : run several testscripts on unix
#
#########################################################################

# set location of testscripts
# (the directory, where directory 'qatesttool' exists)
sLocation=/testtool

# set location of TestTool
# (full path including executable 'testtool')
sTestTool=/testtool/linux/testtool

# set location of close-office file
# (see cvs)
sExitOfficeBas="$sLocation/qatesttool/global/tools/closeoffice.bas"

# insert tests here
testList=("
   /qatesttool/framework/first/first.bas\
   /qatesttool/framework/first/topten.bas\
   /qatesttool/framework/update/f_updt.bas\
 	/qatesttool/math/update/m_updt.bas\
   /qatesttool/graphics/update/d_updt.bas\
   /qatesttool/graphics/update/i_updt.bas\
   /qatesttool/base/update/b_resource.bas\
   /qatesttool/base/update/b_updt.bas\
   /qatesttool/calc/update/c_updt.bas\
   /qatesttool/chart/update/ch_updt.bas\
   /qatesttool/writer/update/w_updt.bas\
   /qatesttool/writer/update/ww_updt.bas\
   /qatesttool/writer/update/ma_updt.bas\
   /qatesttool/xml/update/xc_updt.bas\
   /qatesttool/xml/update/xd_updt.bas\
   /qatesttool/xml/update/xi_updt.bas\
   /qatesttool/xml/update/xm_updt.bas\
   /qatesttool/xml/update/xw_updt.bas\
   /qatesttool/graphics/update/gallery.bas\
   /qatesttool/framework/basic/f_basic.bas\
   /qatesttool/framework/basic/check_control_settings_calc.bas\
   /qatesttool/framework/basic/check_control_settings_graphics.bas\
   /qatesttool/framework/basic/check_control_settings_writer.bas\
")

echo "****************************************************"
echo "************ STARTING ************"
echo "****************************************************"

for x in $testList ;
do
	echo $x
done

# check if there is a virtual display available

 echo "DISPLAY is set to: " $DISPLAY
 echo "My name is: " $USER
 i=0

        for x in $testList ;
        do
                 echo "Running soffices' prozesses: "
               # kill office, if exists
		          #killall -9 soffice.bin
		          pkill -9 soffice.bin
                ps -fe | grep $USER | grep "soffice.bin" | grep -v "grep"
		
                echo "****************************************************"
                echo "Will run: " $x

                sTest="$sLocation$x"
                for z in "1" "2" ;
                do
                        $sTestTool -run $sTest &
                        sleep 1
                        echo " "

                        ######### save the PID from the last BackGround job
                        testtoolpid=$!
                        echo "PID of Testtool: " $testtoolpid

                         if ps -p $testtoolpid > /dev/null ; then
                            echo " Sucksessfull started"
                         else
                            echo " There might be something wrong with starting the Testtool!"
                         fi

                        ######### wait until Testtool has finished & closed
                         while ps -p $testtoolpid > /dev/null ; 
                         do
                                    sleep 2
                                    i=$((i+2))
                         done

                         ####### for the second run use the office exit script!
                         sTest=$sExitOfficeBas
                done
        done

        echo "Duration:" $((i/60)) "min" $((i%60)) "sec " 

echo "****************************************************"
echo "************ FINISHED ************"
echo "****************************************************"
