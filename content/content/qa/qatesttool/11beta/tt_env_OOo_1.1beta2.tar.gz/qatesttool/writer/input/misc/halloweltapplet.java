import java.awt.Graphics;
public class HalloWeltApplet extends java.applet.Applet {
public void paint (Graphics g) {
g.drawString("Hallo Welt!", 40, 20);}
}