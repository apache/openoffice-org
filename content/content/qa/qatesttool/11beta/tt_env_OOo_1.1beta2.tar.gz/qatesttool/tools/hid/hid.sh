 perl hid.pl hid.lst hid.txt cons.txt
