#*************************************************************************
#*
#*  $RCSfile: hid.pl,v $
#*
#*  $Revision: 1.1 $
#*
#*  last change: $Author: tbo $ $Date: 2003/05/12 11:17:58 $
#*
#*  The Contents of this file are made available subject to the terms of
#*  either of the following licenses
#*
#*         - GNU Lesser General Public License Version 2.1
#*         - Sun Industry Standards Source License Version 1.1
#*
#*  Sun Microsystems Inc., October, 2000
#*
#*  GNU Lesser General Public License Version 2.1
#*  =============================================
#*  Copyright 2000 by Sun Microsystems, Inc.
#*  901 San Antonio Road, Palo Alto, CA 94303, USA
#*
#*  This library is free software; you can redistribute it and/or
#*  modify it under the terms of the GNU Lesser General Public
#*  License version 2.1, as published by the Free Software Foundation.
#*
#*  This library is distributed in the hope that it will be useful,
#*  but WITHOUT ANY WARRANTY; without even the implied warranty of
#*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#*  Lesser General Public License for more details.
#*
#*  You should have received a copy of the GNU Lesser General Public
#*  License along with this library; if not, write to the Free Software
#*  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
#*  MA  02111-1307  USA
#*
#*
#*  Sun Industry Standards Source License Version 1.1
#*  =================================================
#*  The contents of this file are subject to the Sun Industry Standards
#*  Source License Version 1.1 (the License); You may not use this file
#*  except in compliance with the License. You may obtain a copy of the
#*  License at http://www.openoffice.org/license.html.
#*
#*  Software provided under this License is provided on an AS IS basis,
#*  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
#*  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
#*  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
#*  See the License for the specific provisions governing your rights and
#*  obligations concerning the Software.
#*
#*  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
#*
#*  Copyright: 2000 by Sun Microsystems, Inc.
#*
#*  All Rights Reserved.
#*
#*  Contributor(s): _______________________________________
#*
#*
#******************************************************************
#*
#* Owner : thorsten.bosbach@sun.com
#*
#* short description : Generate a cleaned hid.lst
#*
#******************************************************************
#
# syntax : hid.pl Input Output ConstantEntries
# usually: hid.pl hid.lst hid.txt const.txt
#

for (@ARGV){print $_."\n";}
open (HID,"<".@ARGV[0]) || die "Can't find old HID-file (first argument)";
@ary=( <HID> );
close HID;
open (HID,">".@ARGV[1]) || die "Can't find new HID-file (second argument)";

@longnum = @longname = ();

for (@ary) {
   s/MN_VIEW 21//g;                       # remove slots that are wrong
   s/MN_INSERT 24//g;
   s/MN_SUB_TOOLBAR 92//g;
   s/SID_OBJECT_MIRROR 27085//g;
   s/UID_SQLERROR_BUTTONMORE 38844//g;
   s/MN_EXTRA 22//g;                     # -------------------------------------------
   s/RID_UNDO_DELETE_WARNING 20558//g;
   s/ +/ /g;                              # remove double blanks
   @x = split(/\s+/) ;                    # seperate Longnames and HIDs
#   @x[0]=~ tr/a-z/A-Z/;
#   @x[1]=~ tr/a-z/A-Z/;
   $longname[++$#longname] = @x[0];
   $longnum[++$#longnum]   = @x[1];
   $_=@x[0]." ".@x[1]."\n";
}

@ary = @ary[ sort{                        # sort
                @longnum[$a] <=> @longnum[$b] ||
                @longname[$a] cmp @longname[$b] 
                }0..$#ary
           ];

# @ary = grep( !/^ *$/, @ary);

#remove double entries

$n="";
for (@ary) {
    if ($n eq $_   || $_>0  ){
       $_="";
     }
     else{
        $n=$_;
     }
 }

@ary = grep( !/^ *$/, @ary);

# to insert the constant entries  at the beginning, read it and write it out 
open (CON,"<".@ARGV[2]) || die "Can't find constant entries-file: const.txt (third argument)";
@const=( <CON> );
close CON;
print HID @const;

print HID @ary;
close HID;
