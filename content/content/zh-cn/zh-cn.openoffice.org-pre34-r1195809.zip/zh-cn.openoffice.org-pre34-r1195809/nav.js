//<SCRIPT language=JavaScript>
//document.write('js导航') ;
//document.write('<br>');
var text=' \
<table class="zh_menu">\
<tr><th>概览</th></tr>\
  <tr><td><a href="index.html">简介</a><br />\
  <a href="http://marketing.openoffice.org/ooocon2008/programme.html">北京OOo2008年会</a><br />\
  <a href="about-features.html">重要特性</a><br />\
  <a href="about-odf.html">ODF</a><br />\
  <a href="about-licenses.html">授权声明</a><br />\
  <a href="about-ooo.html">关于我们</a>\
  </td></tr>\
<tr><th>下载</th></tr>\
  <tr><td><a href="downloads.html">最新版本</a><br />\
  <a href="downloads_ago.html">历史版本</a><br />\
  <a href="downloads-addons.html">功能强化套件</a><br />\
  <a href="downloads-cdrom.html">光碟</a><br />\
  <a href="downloads-businesses.html">商品化版本</a>\
  </td></tr>\
<tr><th>帮助</th></tr>\
  <tr><td><a href="http://zh.openoffice.org/nonav/servlets/HelpTOC">站点帮助</a><br />\
  <a href="help-faq.html">常见问题</a> <br />\
  <a href="help-doc.html">说明文件</a> <br />\
  <a href="help-mailinglist.html">社区</a>\
  </td></tr>\
<tr><th>开发</th></tr>\
  <tr><td><a href="dev-ooo-zh.html">参与开发</a><br />\
  <a href="dev-zh_tasks.html">工作一览表</a><br />\
  <a href="http://www.openoffice.org/project_issues.html" target="_new">报告错误(英)</a>\
  </td></tr>\
</table>\
';
document.write(text) ;
// </SCRIPT>