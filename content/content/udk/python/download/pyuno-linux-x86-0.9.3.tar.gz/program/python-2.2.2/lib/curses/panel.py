"""curses.panel

Module for using panels with curses.
"""

__revision__ = "$Id: panel.py,v 1.1 2000/12/22 21:58:29 akuchling Exp $"

from _curses_panel import *

