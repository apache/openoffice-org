/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM ../../../../mailnews/addrbook/public/nsILDAPPrefsService.idl
 */

#ifndef __gen_nsILDAPPrefsService_h__
#define __gen_nsILDAPPrefsService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsILDAPURL_h__
#include "nsILDAPURL.h"
#endif

#ifndef __gen_nsILDAPService_h__
#include "nsILDAPService.h"
#endif

#ifndef __gen_nsIPrefBranch_h__
#include "nsIPrefBranch.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsILDAPPrefsService */
#define NS_ILDAPPREFSSERVICE_IID_STR "5a4911e0-44cd-11d5-9074-0010a4b26cda"

#define NS_ILDAPPREFSSERVICE_IID \
  {0x5a4911e0, 0x44cd, 0x11d5, \
    { 0x90, 0x74, 0x00, 0x10, 0xa4, 0xb2, 0x6c, 0xda }}

/**
 * this service implements migrating ldap prefs from 4.x format
 * to mozilla format.
 */
class NS_NO_VTABLE nsILDAPPrefsService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ILDAPPREFSSERVICE_IID)

  /**
     * Convert 4.x ldap prefs to mozilla format
     * hostname, dn, scope, port are converted to uri
     * Also converts the autocompletion preference from 4.x format 
     * (ldap_2.servers.<server-name>.autocomplete.enabled)
     * to mozilla format (ldap_2.servers.directoryServer)
     */
  /* void migrate (); */
  NS_IMETHOD Migrate(void) = 0;

  /**
      * This will create an array with entries 
      * "ldap_2.servers.<server-name>"
      * Each entry in the array is unique. 
      * 
      * @param aPrefBranch  prefBranch object.
      * @param aCount       Receives the number of elements in the array.
      * @param aChildArray  Receives the array with "ldap_2.servers.<server-name>".
      * 
      * @return  NS_OK The preference list was successfully retrieved.
      * @return  Other The preference(s) do not exist or an error occurred.
      */
  /* void getServerList (in nsIPrefBranch aPrefBranch, out unsigned long aCount, [array, size_is (aCount), retval] out string aChildArray); */
  NS_IMETHOD GetServerList(nsIPrefBranch *aPrefBranch, PRUint32 *aCount, char ***aChildArray) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSILDAPPREFSSERVICE \
  NS_IMETHOD Migrate(void); \
  NS_IMETHOD GetServerList(nsIPrefBranch *aPrefBranch, PRUint32 *aCount, char ***aChildArray); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSILDAPPREFSSERVICE(_to) \
  NS_IMETHOD Migrate(void) { return _to Migrate(); } \
  NS_IMETHOD GetServerList(nsIPrefBranch *aPrefBranch, PRUint32 *aCount, char ***aChildArray) { return _to GetServerList(aPrefBranch, aCount, aChildArray); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSILDAPPREFSSERVICE(_to) \
  NS_IMETHOD Migrate(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->Migrate(); } \
  NS_IMETHOD GetServerList(nsIPrefBranch *aPrefBranch, PRUint32 *aCount, char ***aChildArray) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetServerList(aPrefBranch, aCount, aChildArray); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsLDAPPrefsService : public nsILDAPPrefsService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSILDAPPREFSSERVICE

  nsLDAPPrefsService();

private:
  ~nsLDAPPrefsService();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsLDAPPrefsService, nsILDAPPrefsService)

nsLDAPPrefsService::nsLDAPPrefsService()
{
  /* member initializers and constructor code */
}

nsLDAPPrefsService::~nsLDAPPrefsService()
{
  /* destructor code */
}

/* void migrate (); */
NS_IMETHODIMP nsLDAPPrefsService::Migrate()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void getServerList (in nsIPrefBranch aPrefBranch, out unsigned long aCount, [array, size_is (aCount), retval] out string aChildArray); */
NS_IMETHODIMP nsLDAPPrefsService::GetServerList(nsIPrefBranch *aPrefBranch, PRUint32 *aCount, char ***aChildArray)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsILDAPPrefsService_h__ */
