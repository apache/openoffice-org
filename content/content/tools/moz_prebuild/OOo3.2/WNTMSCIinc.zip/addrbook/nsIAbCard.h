/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/mailnews/addrbook/public/../../../../mailnews/addrbook/public/nsIAbCard.idl
 */

#ifndef __gen_nsIAbCard_h__
#define __gen_nsIAbCard_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
// Constants used for default email.
// "0": screen name, "1": other email #1, "2": other email #2
#define AB_DEFAULT_EMAIL_IS_SCREEN_NAME "0"
#define AB_DEFAULT_EMAIL_IS_EMAIL_1     "1"
#define AB_DEFAULT_EMAIL_IS_EMAIL_2     "2"
// Constants used for card types.
// "" or "0": normal, "1": AOL groups, "2": AOL additional email address
#define AB_CARD_IS_NORMAL_CARD            "0"
#define AB_CARD_IS_AOL_GROUPS             "1"
#define AB_CARD_IS_AOL_ADDITIONAL_EMAIL   "2"

/* starting interface:    nsIAbPreferMailFormat */
#define NS_IABPREFERMAILFORMAT_IID_STR "97448252-f189-11d4-a422-001083003d0c"

#define NS_IABPREFERMAILFORMAT_IID \
  {0x97448252, 0xf189, 0x11d4, \
    { 0xa4, 0x22, 0x00, 0x10, 0x83, 0x00, 0x3d, 0x0c }}

class NS_NO_VTABLE nsIAbPreferMailFormat {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABPREFERMAILFORMAT_IID)

  enum { unknown = 0U };

  enum { plaintext = 1U };

  enum { html = 2U };

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABPREFERMAILFORMAT \

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABPREFERMAILFORMAT(_to) \

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABPREFERMAILFORMAT(_to) \

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbPreferMailFormat : public nsIAbPreferMailFormat
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABPREFERMAILFORMAT

  nsAbPreferMailFormat();

private:
  ~nsAbPreferMailFormat();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbPreferMailFormat, nsIAbPreferMailFormat)

nsAbPreferMailFormat::nsAbPreferMailFormat()
{
  /* member initializers and constructor code */
}

nsAbPreferMailFormat::~nsAbPreferMailFormat()
{
  /* destructor code */
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbCard */
#define NS_IABCARD_IID_STR "6b46bdd5-10db-44f4-99c9-c7ffe0d3d954"

#define NS_IABCARD_IID \
  {0x6b46bdd5, 0x10db, 0x44f4, \
    { 0x99, 0xc9, 0xc7, 0xff, 0xe0, 0xd3, 0xd9, 0x54 }}

class NS_NO_VTABLE nsIAbCard : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABCARD_IID)

  /* attribute wstring firstName; */
  NS_IMETHOD GetFirstName(PRUnichar * *aFirstName) = 0;
  NS_IMETHOD SetFirstName(const PRUnichar * aFirstName) = 0;

  /* attribute wstring lastName; */
  NS_IMETHOD GetLastName(PRUnichar * *aLastName) = 0;
  NS_IMETHOD SetLastName(const PRUnichar * aLastName) = 0;

  /* attribute wstring phoneticFirstName; */
  NS_IMETHOD GetPhoneticFirstName(PRUnichar * *aPhoneticFirstName) = 0;
  NS_IMETHOD SetPhoneticFirstName(const PRUnichar * aPhoneticFirstName) = 0;

  /* attribute wstring phoneticLastName; */
  NS_IMETHOD GetPhoneticLastName(PRUnichar * *aPhoneticLastName) = 0;
  NS_IMETHOD SetPhoneticLastName(const PRUnichar * aPhoneticLastName) = 0;

  /* attribute wstring displayName; */
  NS_IMETHOD GetDisplayName(PRUnichar * *aDisplayName) = 0;
  NS_IMETHOD SetDisplayName(const PRUnichar * aDisplayName) = 0;

  /* attribute wstring nickName; */
  NS_IMETHOD GetNickName(PRUnichar * *aNickName) = 0;
  NS_IMETHOD SetNickName(const PRUnichar * aNickName) = 0;

  /* attribute wstring primaryEmail; */
  NS_IMETHOD GetPrimaryEmail(PRUnichar * *aPrimaryEmail) = 0;
  NS_IMETHOD SetPrimaryEmail(const PRUnichar * aPrimaryEmail) = 0;

  /* attribute wstring secondEmail; */
  NS_IMETHOD GetSecondEmail(PRUnichar * *aSecondEmail) = 0;
  NS_IMETHOD SetSecondEmail(const PRUnichar * aSecondEmail) = 0;

  /* attribute wstring defaultEmail; */
  NS_IMETHOD GetDefaultEmail(PRUnichar * *aDefaultEmail) = 0;
  NS_IMETHOD SetDefaultEmail(const PRUnichar * aDefaultEmail) = 0;

  /* attribute wstring cardType; */
  NS_IMETHOD GetCardType(PRUnichar * *aCardType) = 0;
  NS_IMETHOD SetCardType(const PRUnichar * aCardType) = 0;

  /* attribute wstring workPhone; */
  NS_IMETHOD GetWorkPhone(PRUnichar * *aWorkPhone) = 0;
  NS_IMETHOD SetWorkPhone(const PRUnichar * aWorkPhone) = 0;

  /* attribute wstring homePhone; */
  NS_IMETHOD GetHomePhone(PRUnichar * *aHomePhone) = 0;
  NS_IMETHOD SetHomePhone(const PRUnichar * aHomePhone) = 0;

  /* attribute wstring faxNumber; */
  NS_IMETHOD GetFaxNumber(PRUnichar * *aFaxNumber) = 0;
  NS_IMETHOD SetFaxNumber(const PRUnichar * aFaxNumber) = 0;

  /* attribute wstring pagerNumber; */
  NS_IMETHOD GetPagerNumber(PRUnichar * *aPagerNumber) = 0;
  NS_IMETHOD SetPagerNumber(const PRUnichar * aPagerNumber) = 0;

  /* attribute wstring cellularNumber; */
  NS_IMETHOD GetCellularNumber(PRUnichar * *aCellularNumber) = 0;
  NS_IMETHOD SetCellularNumber(const PRUnichar * aCellularNumber) = 0;

  /* attribute wstring workPhoneType; */
  NS_IMETHOD GetWorkPhoneType(PRUnichar * *aWorkPhoneType) = 0;
  NS_IMETHOD SetWorkPhoneType(const PRUnichar * aWorkPhoneType) = 0;

  /* attribute wstring homePhoneType; */
  NS_IMETHOD GetHomePhoneType(PRUnichar * *aHomePhoneType) = 0;
  NS_IMETHOD SetHomePhoneType(const PRUnichar * aHomePhoneType) = 0;

  /* attribute wstring faxNumberType; */
  NS_IMETHOD GetFaxNumberType(PRUnichar * *aFaxNumberType) = 0;
  NS_IMETHOD SetFaxNumberType(const PRUnichar * aFaxNumberType) = 0;

  /* attribute wstring pagerNumberType; */
  NS_IMETHOD GetPagerNumberType(PRUnichar * *aPagerNumberType) = 0;
  NS_IMETHOD SetPagerNumberType(const PRUnichar * aPagerNumberType) = 0;

  /* attribute wstring cellularNumberType; */
  NS_IMETHOD GetCellularNumberType(PRUnichar * *aCellularNumberType) = 0;
  NS_IMETHOD SetCellularNumberType(const PRUnichar * aCellularNumberType) = 0;

  /* attribute wstring homeAddress; */
  NS_IMETHOD GetHomeAddress(PRUnichar * *aHomeAddress) = 0;
  NS_IMETHOD SetHomeAddress(const PRUnichar * aHomeAddress) = 0;

  /* attribute wstring homeAddress2; */
  NS_IMETHOD GetHomeAddress2(PRUnichar * *aHomeAddress2) = 0;
  NS_IMETHOD SetHomeAddress2(const PRUnichar * aHomeAddress2) = 0;

  /* attribute wstring homeCity; */
  NS_IMETHOD GetHomeCity(PRUnichar * *aHomeCity) = 0;
  NS_IMETHOD SetHomeCity(const PRUnichar * aHomeCity) = 0;

  /* attribute wstring homeState; */
  NS_IMETHOD GetHomeState(PRUnichar * *aHomeState) = 0;
  NS_IMETHOD SetHomeState(const PRUnichar * aHomeState) = 0;

  /* attribute wstring homeZipCode; */
  NS_IMETHOD GetHomeZipCode(PRUnichar * *aHomeZipCode) = 0;
  NS_IMETHOD SetHomeZipCode(const PRUnichar * aHomeZipCode) = 0;

  /* attribute wstring homeCountry; */
  NS_IMETHOD GetHomeCountry(PRUnichar * *aHomeCountry) = 0;
  NS_IMETHOD SetHomeCountry(const PRUnichar * aHomeCountry) = 0;

  /* attribute wstring workAddress; */
  NS_IMETHOD GetWorkAddress(PRUnichar * *aWorkAddress) = 0;
  NS_IMETHOD SetWorkAddress(const PRUnichar * aWorkAddress) = 0;

  /* attribute wstring workAddress2; */
  NS_IMETHOD GetWorkAddress2(PRUnichar * *aWorkAddress2) = 0;
  NS_IMETHOD SetWorkAddress2(const PRUnichar * aWorkAddress2) = 0;

  /* attribute wstring workCity; */
  NS_IMETHOD GetWorkCity(PRUnichar * *aWorkCity) = 0;
  NS_IMETHOD SetWorkCity(const PRUnichar * aWorkCity) = 0;

  /* attribute wstring workState; */
  NS_IMETHOD GetWorkState(PRUnichar * *aWorkState) = 0;
  NS_IMETHOD SetWorkState(const PRUnichar * aWorkState) = 0;

  /* attribute wstring workZipCode; */
  NS_IMETHOD GetWorkZipCode(PRUnichar * *aWorkZipCode) = 0;
  NS_IMETHOD SetWorkZipCode(const PRUnichar * aWorkZipCode) = 0;

  /* attribute wstring workCountry; */
  NS_IMETHOD GetWorkCountry(PRUnichar * *aWorkCountry) = 0;
  NS_IMETHOD SetWorkCountry(const PRUnichar * aWorkCountry) = 0;

  /* attribute wstring jobTitle; */
  NS_IMETHOD GetJobTitle(PRUnichar * *aJobTitle) = 0;
  NS_IMETHOD SetJobTitle(const PRUnichar * aJobTitle) = 0;

  /* attribute wstring department; */
  NS_IMETHOD GetDepartment(PRUnichar * *aDepartment) = 0;
  NS_IMETHOD SetDepartment(const PRUnichar * aDepartment) = 0;

  /* attribute wstring company; */
  NS_IMETHOD GetCompany(PRUnichar * *aCompany) = 0;
  NS_IMETHOD SetCompany(const PRUnichar * aCompany) = 0;

  /* attribute wstring aimScreenName; */
  NS_IMETHOD GetAimScreenName(PRUnichar * *aAimScreenName) = 0;
  NS_IMETHOD SetAimScreenName(const PRUnichar * aAimScreenName) = 0;

  /* attribute wstring anniversaryYear; */
  NS_IMETHOD GetAnniversaryYear(PRUnichar * *aAnniversaryYear) = 0;
  NS_IMETHOD SetAnniversaryYear(const PRUnichar * aAnniversaryYear) = 0;

  /* attribute wstring anniversaryMonth; */
  NS_IMETHOD GetAnniversaryMonth(PRUnichar * *aAnniversaryMonth) = 0;
  NS_IMETHOD SetAnniversaryMonth(const PRUnichar * aAnniversaryMonth) = 0;

  /* attribute wstring anniversaryDay; */
  NS_IMETHOD GetAnniversaryDay(PRUnichar * *aAnniversaryDay) = 0;
  NS_IMETHOD SetAnniversaryDay(const PRUnichar * aAnniversaryDay) = 0;

  /* attribute wstring spouseName; */
  NS_IMETHOD GetSpouseName(PRUnichar * *aSpouseName) = 0;
  NS_IMETHOD SetSpouseName(const PRUnichar * aSpouseName) = 0;

  /* attribute wstring familyName; */
  NS_IMETHOD GetFamilyName(PRUnichar * *aFamilyName) = 0;
  NS_IMETHOD SetFamilyName(const PRUnichar * aFamilyName) = 0;

  /* attribute wstring defaultAddress; */
  NS_IMETHOD GetDefaultAddress(PRUnichar * *aDefaultAddress) = 0;
  NS_IMETHOD SetDefaultAddress(const PRUnichar * aDefaultAddress) = 0;

  /* attribute wstring category; */
  NS_IMETHOD GetCategory(PRUnichar * *aCategory) = 0;
  NS_IMETHOD SetCategory(const PRUnichar * aCategory) = 0;

  /**
	 * webPage1 is work web page
	 */
  /* attribute wstring webPage1; */
  NS_IMETHOD GetWebPage1(PRUnichar * *aWebPage1) = 0;
  NS_IMETHOD SetWebPage1(const PRUnichar * aWebPage1) = 0;

  /**
	 * webPage2 is home web page
	 */
  /* attribute wstring webPage2; */
  NS_IMETHOD GetWebPage2(PRUnichar * *aWebPage2) = 0;
  NS_IMETHOD SetWebPage2(const PRUnichar * aWebPage2) = 0;

  /* attribute wstring birthYear; */
  NS_IMETHOD GetBirthYear(PRUnichar * *aBirthYear) = 0;
  NS_IMETHOD SetBirthYear(const PRUnichar * aBirthYear) = 0;

  /* attribute wstring birthMonth; */
  NS_IMETHOD GetBirthMonth(PRUnichar * *aBirthMonth) = 0;
  NS_IMETHOD SetBirthMonth(const PRUnichar * aBirthMonth) = 0;

  /* attribute wstring birthDay; */
  NS_IMETHOD GetBirthDay(PRUnichar * *aBirthDay) = 0;
  NS_IMETHOD SetBirthDay(const PRUnichar * aBirthDay) = 0;

  /* attribute wstring custom1; */
  NS_IMETHOD GetCustom1(PRUnichar * *aCustom1) = 0;
  NS_IMETHOD SetCustom1(const PRUnichar * aCustom1) = 0;

  /* attribute wstring custom2; */
  NS_IMETHOD GetCustom2(PRUnichar * *aCustom2) = 0;
  NS_IMETHOD SetCustom2(const PRUnichar * aCustom2) = 0;

  /* attribute wstring custom3; */
  NS_IMETHOD GetCustom3(PRUnichar * *aCustom3) = 0;
  NS_IMETHOD SetCustom3(const PRUnichar * aCustom3) = 0;

  /* attribute wstring custom4; */
  NS_IMETHOD GetCustom4(PRUnichar * *aCustom4) = 0;
  NS_IMETHOD SetCustom4(const PRUnichar * aCustom4) = 0;

  /* attribute wstring notes; */
  NS_IMETHOD GetNotes(PRUnichar * *aNotes) = 0;
  NS_IMETHOD SetNotes(const PRUnichar * aNotes) = 0;

  /* attribute unsigned long lastModifiedDate; */
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate) = 0;
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate) = 0;

  /* attribute unsigned long popularityIndex; */
  NS_IMETHOD GetPopularityIndex(PRUint32 *aPopularityIndex) = 0;
  NS_IMETHOD SetPopularityIndex(PRUint32 aPopularityIndex) = 0;

  /* attribute unsigned long preferMailFormat; */
  NS_IMETHOD GetPreferMailFormat(PRUint32 *aPreferMailFormat) = 0;
  NS_IMETHOD SetPreferMailFormat(PRUint32 aPreferMailFormat) = 0;

  /* attribute boolean isMailList; */
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList) = 0;
  NS_IMETHOD SetIsMailList(PRBool aIsMailList) = 0;

  /**
	 * If isMailList is true then mailListURI
	 * will contain the URI of the associated
	 * mail list
	 */
  /* attribute string mailListURI; */
  NS_IMETHOD GetMailListURI(char * *aMailListURI) = 0;
  NS_IMETHOD SetMailListURI(const char * aMailListURI) = 0;

  /**
   * allowRemoteContent to be displayed in HTML mail received from this contact.
   */
  /* attribute boolean allowRemoteContent; */
  NS_IMETHOD GetAllowRemoteContent(PRBool *aAllowRemoteContent) = 0;
  NS_IMETHOD SetAllowRemoteContent(PRBool aAllowRemoteContent) = 0;

  /**
   * Card type helper attributes
   */
  /* readonly attribute boolean isANormalCard; */
  NS_IMETHOD GetIsANormalCard(PRBool *aIsANormalCard) = 0;

  /* readonly attribute boolean isASpecialGroup; */
  NS_IMETHOD GetIsASpecialGroup(PRBool *aIsASpecialGroup) = 0;

  /* readonly attribute boolean isAnEmailAddress; */
  NS_IMETHOD GetIsAnEmailAddress(PRBool *aIsAnEmailAddress) = 0;

  /* wstring getCardValue (in string name); */
  NS_IMETHOD GetCardValue(const char *name, PRUnichar **_retval) = 0;

  /* void setCardValue (in string attrname, in wstring value); */
  NS_IMETHOD SetCardValue(const char *attrname, const PRUnichar *value) = 0;

  /* void copy (in nsIAbCard srcCard); */
  NS_IMETHOD Copy(nsIAbCard *srcCard) = 0;

  /* void editCardToDatabase (in string uri); */
  NS_IMETHOD EditCardToDatabase(const char *uri) = 0;

  /* boolean equals (in nsIAbCard card); */
  NS_IMETHOD Equals(nsIAbCard *card, PRBool *_retval) = 0;

  /* string convertToBase64EncodedXML (); */
  NS_IMETHOD ConvertToBase64EncodedXML(char **_retval) = 0;

  /* wstring convertToXMLPrintData (); */
  NS_IMETHOD ConvertToXMLPrintData(PRUnichar **_retval) = 0;

  /* string convertToEscapedVCard (); */
  NS_IMETHOD ConvertToEscapedVCard(char **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABCARD \
  NS_IMETHOD GetFirstName(PRUnichar * *aFirstName); \
  NS_IMETHOD SetFirstName(const PRUnichar * aFirstName); \
  NS_IMETHOD GetLastName(PRUnichar * *aLastName); \
  NS_IMETHOD SetLastName(const PRUnichar * aLastName); \
  NS_IMETHOD GetPhoneticFirstName(PRUnichar * *aPhoneticFirstName); \
  NS_IMETHOD SetPhoneticFirstName(const PRUnichar * aPhoneticFirstName); \
  NS_IMETHOD GetPhoneticLastName(PRUnichar * *aPhoneticLastName); \
  NS_IMETHOD SetPhoneticLastName(const PRUnichar * aPhoneticLastName); \
  NS_IMETHOD GetDisplayName(PRUnichar * *aDisplayName); \
  NS_IMETHOD SetDisplayName(const PRUnichar * aDisplayName); \
  NS_IMETHOD GetNickName(PRUnichar * *aNickName); \
  NS_IMETHOD SetNickName(const PRUnichar * aNickName); \
  NS_IMETHOD GetPrimaryEmail(PRUnichar * *aPrimaryEmail); \
  NS_IMETHOD SetPrimaryEmail(const PRUnichar * aPrimaryEmail); \
  NS_IMETHOD GetSecondEmail(PRUnichar * *aSecondEmail); \
  NS_IMETHOD SetSecondEmail(const PRUnichar * aSecondEmail); \
  NS_IMETHOD GetDefaultEmail(PRUnichar * *aDefaultEmail); \
  NS_IMETHOD SetDefaultEmail(const PRUnichar * aDefaultEmail); \
  NS_IMETHOD GetCardType(PRUnichar * *aCardType); \
  NS_IMETHOD SetCardType(const PRUnichar * aCardType); \
  NS_IMETHOD GetWorkPhone(PRUnichar * *aWorkPhone); \
  NS_IMETHOD SetWorkPhone(const PRUnichar * aWorkPhone); \
  NS_IMETHOD GetHomePhone(PRUnichar * *aHomePhone); \
  NS_IMETHOD SetHomePhone(const PRUnichar * aHomePhone); \
  NS_IMETHOD GetFaxNumber(PRUnichar * *aFaxNumber); \
  NS_IMETHOD SetFaxNumber(const PRUnichar * aFaxNumber); \
  NS_IMETHOD GetPagerNumber(PRUnichar * *aPagerNumber); \
  NS_IMETHOD SetPagerNumber(const PRUnichar * aPagerNumber); \
  NS_IMETHOD GetCellularNumber(PRUnichar * *aCellularNumber); \
  NS_IMETHOD SetCellularNumber(const PRUnichar * aCellularNumber); \
  NS_IMETHOD GetWorkPhoneType(PRUnichar * *aWorkPhoneType); \
  NS_IMETHOD SetWorkPhoneType(const PRUnichar * aWorkPhoneType); \
  NS_IMETHOD GetHomePhoneType(PRUnichar * *aHomePhoneType); \
  NS_IMETHOD SetHomePhoneType(const PRUnichar * aHomePhoneType); \
  NS_IMETHOD GetFaxNumberType(PRUnichar * *aFaxNumberType); \
  NS_IMETHOD SetFaxNumberType(const PRUnichar * aFaxNumberType); \
  NS_IMETHOD GetPagerNumberType(PRUnichar * *aPagerNumberType); \
  NS_IMETHOD SetPagerNumberType(const PRUnichar * aPagerNumberType); \
  NS_IMETHOD GetCellularNumberType(PRUnichar * *aCellularNumberType); \
  NS_IMETHOD SetCellularNumberType(const PRUnichar * aCellularNumberType); \
  NS_IMETHOD GetHomeAddress(PRUnichar * *aHomeAddress); \
  NS_IMETHOD SetHomeAddress(const PRUnichar * aHomeAddress); \
  NS_IMETHOD GetHomeAddress2(PRUnichar * *aHomeAddress2); \
  NS_IMETHOD SetHomeAddress2(const PRUnichar * aHomeAddress2); \
  NS_IMETHOD GetHomeCity(PRUnichar * *aHomeCity); \
  NS_IMETHOD SetHomeCity(const PRUnichar * aHomeCity); \
  NS_IMETHOD GetHomeState(PRUnichar * *aHomeState); \
  NS_IMETHOD SetHomeState(const PRUnichar * aHomeState); \
  NS_IMETHOD GetHomeZipCode(PRUnichar * *aHomeZipCode); \
  NS_IMETHOD SetHomeZipCode(const PRUnichar * aHomeZipCode); \
  NS_IMETHOD GetHomeCountry(PRUnichar * *aHomeCountry); \
  NS_IMETHOD SetHomeCountry(const PRUnichar * aHomeCountry); \
  NS_IMETHOD GetWorkAddress(PRUnichar * *aWorkAddress); \
  NS_IMETHOD SetWorkAddress(const PRUnichar * aWorkAddress); \
  NS_IMETHOD GetWorkAddress2(PRUnichar * *aWorkAddress2); \
  NS_IMETHOD SetWorkAddress2(const PRUnichar * aWorkAddress2); \
  NS_IMETHOD GetWorkCity(PRUnichar * *aWorkCity); \
  NS_IMETHOD SetWorkCity(const PRUnichar * aWorkCity); \
  NS_IMETHOD GetWorkState(PRUnichar * *aWorkState); \
  NS_IMETHOD SetWorkState(const PRUnichar * aWorkState); \
  NS_IMETHOD GetWorkZipCode(PRUnichar * *aWorkZipCode); \
  NS_IMETHOD SetWorkZipCode(const PRUnichar * aWorkZipCode); \
  NS_IMETHOD GetWorkCountry(PRUnichar * *aWorkCountry); \
  NS_IMETHOD SetWorkCountry(const PRUnichar * aWorkCountry); \
  NS_IMETHOD GetJobTitle(PRUnichar * *aJobTitle); \
  NS_IMETHOD SetJobTitle(const PRUnichar * aJobTitle); \
  NS_IMETHOD GetDepartment(PRUnichar * *aDepartment); \
  NS_IMETHOD SetDepartment(const PRUnichar * aDepartment); \
  NS_IMETHOD GetCompany(PRUnichar * *aCompany); \
  NS_IMETHOD SetCompany(const PRUnichar * aCompany); \
  NS_IMETHOD GetAimScreenName(PRUnichar * *aAimScreenName); \
  NS_IMETHOD SetAimScreenName(const PRUnichar * aAimScreenName); \
  NS_IMETHOD GetAnniversaryYear(PRUnichar * *aAnniversaryYear); \
  NS_IMETHOD SetAnniversaryYear(const PRUnichar * aAnniversaryYear); \
  NS_IMETHOD GetAnniversaryMonth(PRUnichar * *aAnniversaryMonth); \
  NS_IMETHOD SetAnniversaryMonth(const PRUnichar * aAnniversaryMonth); \
  NS_IMETHOD GetAnniversaryDay(PRUnichar * *aAnniversaryDay); \
  NS_IMETHOD SetAnniversaryDay(const PRUnichar * aAnniversaryDay); \
  NS_IMETHOD GetSpouseName(PRUnichar * *aSpouseName); \
  NS_IMETHOD SetSpouseName(const PRUnichar * aSpouseName); \
  NS_IMETHOD GetFamilyName(PRUnichar * *aFamilyName); \
  NS_IMETHOD SetFamilyName(const PRUnichar * aFamilyName); \
  NS_IMETHOD GetDefaultAddress(PRUnichar * *aDefaultAddress); \
  NS_IMETHOD SetDefaultAddress(const PRUnichar * aDefaultAddress); \
  NS_IMETHOD GetCategory(PRUnichar * *aCategory); \
  NS_IMETHOD SetCategory(const PRUnichar * aCategory); \
  NS_IMETHOD GetWebPage1(PRUnichar * *aWebPage1); \
  NS_IMETHOD SetWebPage1(const PRUnichar * aWebPage1); \
  NS_IMETHOD GetWebPage2(PRUnichar * *aWebPage2); \
  NS_IMETHOD SetWebPage2(const PRUnichar * aWebPage2); \
  NS_IMETHOD GetBirthYear(PRUnichar * *aBirthYear); \
  NS_IMETHOD SetBirthYear(const PRUnichar * aBirthYear); \
  NS_IMETHOD GetBirthMonth(PRUnichar * *aBirthMonth); \
  NS_IMETHOD SetBirthMonth(const PRUnichar * aBirthMonth); \
  NS_IMETHOD GetBirthDay(PRUnichar * *aBirthDay); \
  NS_IMETHOD SetBirthDay(const PRUnichar * aBirthDay); \
  NS_IMETHOD GetCustom1(PRUnichar * *aCustom1); \
  NS_IMETHOD SetCustom1(const PRUnichar * aCustom1); \
  NS_IMETHOD GetCustom2(PRUnichar * *aCustom2); \
  NS_IMETHOD SetCustom2(const PRUnichar * aCustom2); \
  NS_IMETHOD GetCustom3(PRUnichar * *aCustom3); \
  NS_IMETHOD SetCustom3(const PRUnichar * aCustom3); \
  NS_IMETHOD GetCustom4(PRUnichar * *aCustom4); \
  NS_IMETHOD SetCustom4(const PRUnichar * aCustom4); \
  NS_IMETHOD GetNotes(PRUnichar * *aNotes); \
  NS_IMETHOD SetNotes(const PRUnichar * aNotes); \
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate); \
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate); \
  NS_IMETHOD GetPopularityIndex(PRUint32 *aPopularityIndex); \
  NS_IMETHOD SetPopularityIndex(PRUint32 aPopularityIndex); \
  NS_IMETHOD GetPreferMailFormat(PRUint32 *aPreferMailFormat); \
  NS_IMETHOD SetPreferMailFormat(PRUint32 aPreferMailFormat); \
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList); \
  NS_IMETHOD SetIsMailList(PRBool aIsMailList); \
  NS_IMETHOD GetMailListURI(char * *aMailListURI); \
  NS_IMETHOD SetMailListURI(const char * aMailListURI); \
  NS_IMETHOD GetAllowRemoteContent(PRBool *aAllowRemoteContent); \
  NS_IMETHOD SetAllowRemoteContent(PRBool aAllowRemoteContent); \
  NS_IMETHOD GetIsANormalCard(PRBool *aIsANormalCard); \
  NS_IMETHOD GetIsASpecialGroup(PRBool *aIsASpecialGroup); \
  NS_IMETHOD GetIsAnEmailAddress(PRBool *aIsAnEmailAddress); \
  NS_IMETHOD GetCardValue(const char *name, PRUnichar **_retval); \
  NS_IMETHOD SetCardValue(const char *attrname, const PRUnichar *value); \
  NS_IMETHOD Copy(nsIAbCard *srcCard); \
  NS_IMETHOD EditCardToDatabase(const char *uri); \
  NS_IMETHOD Equals(nsIAbCard *card, PRBool *_retval); \
  NS_IMETHOD ConvertToBase64EncodedXML(char **_retval); \
  NS_IMETHOD ConvertToXMLPrintData(PRUnichar **_retval); \
  NS_IMETHOD ConvertToEscapedVCard(char **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABCARD(_to) \
  NS_IMETHOD GetFirstName(PRUnichar * *aFirstName) { return _to GetFirstName(aFirstName); } \
  NS_IMETHOD SetFirstName(const PRUnichar * aFirstName) { return _to SetFirstName(aFirstName); } \
  NS_IMETHOD GetLastName(PRUnichar * *aLastName) { return _to GetLastName(aLastName); } \
  NS_IMETHOD SetLastName(const PRUnichar * aLastName) { return _to SetLastName(aLastName); } \
  NS_IMETHOD GetPhoneticFirstName(PRUnichar * *aPhoneticFirstName) { return _to GetPhoneticFirstName(aPhoneticFirstName); } \
  NS_IMETHOD SetPhoneticFirstName(const PRUnichar * aPhoneticFirstName) { return _to SetPhoneticFirstName(aPhoneticFirstName); } \
  NS_IMETHOD GetPhoneticLastName(PRUnichar * *aPhoneticLastName) { return _to GetPhoneticLastName(aPhoneticLastName); } \
  NS_IMETHOD SetPhoneticLastName(const PRUnichar * aPhoneticLastName) { return _to SetPhoneticLastName(aPhoneticLastName); } \
  NS_IMETHOD GetDisplayName(PRUnichar * *aDisplayName) { return _to GetDisplayName(aDisplayName); } \
  NS_IMETHOD SetDisplayName(const PRUnichar * aDisplayName) { return _to SetDisplayName(aDisplayName); } \
  NS_IMETHOD GetNickName(PRUnichar * *aNickName) { return _to GetNickName(aNickName); } \
  NS_IMETHOD SetNickName(const PRUnichar * aNickName) { return _to SetNickName(aNickName); } \
  NS_IMETHOD GetPrimaryEmail(PRUnichar * *aPrimaryEmail) { return _to GetPrimaryEmail(aPrimaryEmail); } \
  NS_IMETHOD SetPrimaryEmail(const PRUnichar * aPrimaryEmail) { return _to SetPrimaryEmail(aPrimaryEmail); } \
  NS_IMETHOD GetSecondEmail(PRUnichar * *aSecondEmail) { return _to GetSecondEmail(aSecondEmail); } \
  NS_IMETHOD SetSecondEmail(const PRUnichar * aSecondEmail) { return _to SetSecondEmail(aSecondEmail); } \
  NS_IMETHOD GetDefaultEmail(PRUnichar * *aDefaultEmail) { return _to GetDefaultEmail(aDefaultEmail); } \
  NS_IMETHOD SetDefaultEmail(const PRUnichar * aDefaultEmail) { return _to SetDefaultEmail(aDefaultEmail); } \
  NS_IMETHOD GetCardType(PRUnichar * *aCardType) { return _to GetCardType(aCardType); } \
  NS_IMETHOD SetCardType(const PRUnichar * aCardType) { return _to SetCardType(aCardType); } \
  NS_IMETHOD GetWorkPhone(PRUnichar * *aWorkPhone) { return _to GetWorkPhone(aWorkPhone); } \
  NS_IMETHOD SetWorkPhone(const PRUnichar * aWorkPhone) { return _to SetWorkPhone(aWorkPhone); } \
  NS_IMETHOD GetHomePhone(PRUnichar * *aHomePhone) { return _to GetHomePhone(aHomePhone); } \
  NS_IMETHOD SetHomePhone(const PRUnichar * aHomePhone) { return _to SetHomePhone(aHomePhone); } \
  NS_IMETHOD GetFaxNumber(PRUnichar * *aFaxNumber) { return _to GetFaxNumber(aFaxNumber); } \
  NS_IMETHOD SetFaxNumber(const PRUnichar * aFaxNumber) { return _to SetFaxNumber(aFaxNumber); } \
  NS_IMETHOD GetPagerNumber(PRUnichar * *aPagerNumber) { return _to GetPagerNumber(aPagerNumber); } \
  NS_IMETHOD SetPagerNumber(const PRUnichar * aPagerNumber) { return _to SetPagerNumber(aPagerNumber); } \
  NS_IMETHOD GetCellularNumber(PRUnichar * *aCellularNumber) { return _to GetCellularNumber(aCellularNumber); } \
  NS_IMETHOD SetCellularNumber(const PRUnichar * aCellularNumber) { return _to SetCellularNumber(aCellularNumber); } \
  NS_IMETHOD GetWorkPhoneType(PRUnichar * *aWorkPhoneType) { return _to GetWorkPhoneType(aWorkPhoneType); } \
  NS_IMETHOD SetWorkPhoneType(const PRUnichar * aWorkPhoneType) { return _to SetWorkPhoneType(aWorkPhoneType); } \
  NS_IMETHOD GetHomePhoneType(PRUnichar * *aHomePhoneType) { return _to GetHomePhoneType(aHomePhoneType); } \
  NS_IMETHOD SetHomePhoneType(const PRUnichar * aHomePhoneType) { return _to SetHomePhoneType(aHomePhoneType); } \
  NS_IMETHOD GetFaxNumberType(PRUnichar * *aFaxNumberType) { return _to GetFaxNumberType(aFaxNumberType); } \
  NS_IMETHOD SetFaxNumberType(const PRUnichar * aFaxNumberType) { return _to SetFaxNumberType(aFaxNumberType); } \
  NS_IMETHOD GetPagerNumberType(PRUnichar * *aPagerNumberType) { return _to GetPagerNumberType(aPagerNumberType); } \
  NS_IMETHOD SetPagerNumberType(const PRUnichar * aPagerNumberType) { return _to SetPagerNumberType(aPagerNumberType); } \
  NS_IMETHOD GetCellularNumberType(PRUnichar * *aCellularNumberType) { return _to GetCellularNumberType(aCellularNumberType); } \
  NS_IMETHOD SetCellularNumberType(const PRUnichar * aCellularNumberType) { return _to SetCellularNumberType(aCellularNumberType); } \
  NS_IMETHOD GetHomeAddress(PRUnichar * *aHomeAddress) { return _to GetHomeAddress(aHomeAddress); } \
  NS_IMETHOD SetHomeAddress(const PRUnichar * aHomeAddress) { return _to SetHomeAddress(aHomeAddress); } \
  NS_IMETHOD GetHomeAddress2(PRUnichar * *aHomeAddress2) { return _to GetHomeAddress2(aHomeAddress2); } \
  NS_IMETHOD SetHomeAddress2(const PRUnichar * aHomeAddress2) { return _to SetHomeAddress2(aHomeAddress2); } \
  NS_IMETHOD GetHomeCity(PRUnichar * *aHomeCity) { return _to GetHomeCity(aHomeCity); } \
  NS_IMETHOD SetHomeCity(const PRUnichar * aHomeCity) { return _to SetHomeCity(aHomeCity); } \
  NS_IMETHOD GetHomeState(PRUnichar * *aHomeState) { return _to GetHomeState(aHomeState); } \
  NS_IMETHOD SetHomeState(const PRUnichar * aHomeState) { return _to SetHomeState(aHomeState); } \
  NS_IMETHOD GetHomeZipCode(PRUnichar * *aHomeZipCode) { return _to GetHomeZipCode(aHomeZipCode); } \
  NS_IMETHOD SetHomeZipCode(const PRUnichar * aHomeZipCode) { return _to SetHomeZipCode(aHomeZipCode); } \
  NS_IMETHOD GetHomeCountry(PRUnichar * *aHomeCountry) { return _to GetHomeCountry(aHomeCountry); } \
  NS_IMETHOD SetHomeCountry(const PRUnichar * aHomeCountry) { return _to SetHomeCountry(aHomeCountry); } \
  NS_IMETHOD GetWorkAddress(PRUnichar * *aWorkAddress) { return _to GetWorkAddress(aWorkAddress); } \
  NS_IMETHOD SetWorkAddress(const PRUnichar * aWorkAddress) { return _to SetWorkAddress(aWorkAddress); } \
  NS_IMETHOD GetWorkAddress2(PRUnichar * *aWorkAddress2) { return _to GetWorkAddress2(aWorkAddress2); } \
  NS_IMETHOD SetWorkAddress2(const PRUnichar * aWorkAddress2) { return _to SetWorkAddress2(aWorkAddress2); } \
  NS_IMETHOD GetWorkCity(PRUnichar * *aWorkCity) { return _to GetWorkCity(aWorkCity); } \
  NS_IMETHOD SetWorkCity(const PRUnichar * aWorkCity) { return _to SetWorkCity(aWorkCity); } \
  NS_IMETHOD GetWorkState(PRUnichar * *aWorkState) { return _to GetWorkState(aWorkState); } \
  NS_IMETHOD SetWorkState(const PRUnichar * aWorkState) { return _to SetWorkState(aWorkState); } \
  NS_IMETHOD GetWorkZipCode(PRUnichar * *aWorkZipCode) { return _to GetWorkZipCode(aWorkZipCode); } \
  NS_IMETHOD SetWorkZipCode(const PRUnichar * aWorkZipCode) { return _to SetWorkZipCode(aWorkZipCode); } \
  NS_IMETHOD GetWorkCountry(PRUnichar * *aWorkCountry) { return _to GetWorkCountry(aWorkCountry); } \
  NS_IMETHOD SetWorkCountry(const PRUnichar * aWorkCountry) { return _to SetWorkCountry(aWorkCountry); } \
  NS_IMETHOD GetJobTitle(PRUnichar * *aJobTitle) { return _to GetJobTitle(aJobTitle); } \
  NS_IMETHOD SetJobTitle(const PRUnichar * aJobTitle) { return _to SetJobTitle(aJobTitle); } \
  NS_IMETHOD GetDepartment(PRUnichar * *aDepartment) { return _to GetDepartment(aDepartment); } \
  NS_IMETHOD SetDepartment(const PRUnichar * aDepartment) { return _to SetDepartment(aDepartment); } \
  NS_IMETHOD GetCompany(PRUnichar * *aCompany) { return _to GetCompany(aCompany); } \
  NS_IMETHOD SetCompany(const PRUnichar * aCompany) { return _to SetCompany(aCompany); } \
  NS_IMETHOD GetAimScreenName(PRUnichar * *aAimScreenName) { return _to GetAimScreenName(aAimScreenName); } \
  NS_IMETHOD SetAimScreenName(const PRUnichar * aAimScreenName) { return _to SetAimScreenName(aAimScreenName); } \
  NS_IMETHOD GetAnniversaryYear(PRUnichar * *aAnniversaryYear) { return _to GetAnniversaryYear(aAnniversaryYear); } \
  NS_IMETHOD SetAnniversaryYear(const PRUnichar * aAnniversaryYear) { return _to SetAnniversaryYear(aAnniversaryYear); } \
  NS_IMETHOD GetAnniversaryMonth(PRUnichar * *aAnniversaryMonth) { return _to GetAnniversaryMonth(aAnniversaryMonth); } \
  NS_IMETHOD SetAnniversaryMonth(const PRUnichar * aAnniversaryMonth) { return _to SetAnniversaryMonth(aAnniversaryMonth); } \
  NS_IMETHOD GetAnniversaryDay(PRUnichar * *aAnniversaryDay) { return _to GetAnniversaryDay(aAnniversaryDay); } \
  NS_IMETHOD SetAnniversaryDay(const PRUnichar * aAnniversaryDay) { return _to SetAnniversaryDay(aAnniversaryDay); } \
  NS_IMETHOD GetSpouseName(PRUnichar * *aSpouseName) { return _to GetSpouseName(aSpouseName); } \
  NS_IMETHOD SetSpouseName(const PRUnichar * aSpouseName) { return _to SetSpouseName(aSpouseName); } \
  NS_IMETHOD GetFamilyName(PRUnichar * *aFamilyName) { return _to GetFamilyName(aFamilyName); } \
  NS_IMETHOD SetFamilyName(const PRUnichar * aFamilyName) { return _to SetFamilyName(aFamilyName); } \
  NS_IMETHOD GetDefaultAddress(PRUnichar * *aDefaultAddress) { return _to GetDefaultAddress(aDefaultAddress); } \
  NS_IMETHOD SetDefaultAddress(const PRUnichar * aDefaultAddress) { return _to SetDefaultAddress(aDefaultAddress); } \
  NS_IMETHOD GetCategory(PRUnichar * *aCategory) { return _to GetCategory(aCategory); } \
  NS_IMETHOD SetCategory(const PRUnichar * aCategory) { return _to SetCategory(aCategory); } \
  NS_IMETHOD GetWebPage1(PRUnichar * *aWebPage1) { return _to GetWebPage1(aWebPage1); } \
  NS_IMETHOD SetWebPage1(const PRUnichar * aWebPage1) { return _to SetWebPage1(aWebPage1); } \
  NS_IMETHOD GetWebPage2(PRUnichar * *aWebPage2) { return _to GetWebPage2(aWebPage2); } \
  NS_IMETHOD SetWebPage2(const PRUnichar * aWebPage2) { return _to SetWebPage2(aWebPage2); } \
  NS_IMETHOD GetBirthYear(PRUnichar * *aBirthYear) { return _to GetBirthYear(aBirthYear); } \
  NS_IMETHOD SetBirthYear(const PRUnichar * aBirthYear) { return _to SetBirthYear(aBirthYear); } \
  NS_IMETHOD GetBirthMonth(PRUnichar * *aBirthMonth) { return _to GetBirthMonth(aBirthMonth); } \
  NS_IMETHOD SetBirthMonth(const PRUnichar * aBirthMonth) { return _to SetBirthMonth(aBirthMonth); } \
  NS_IMETHOD GetBirthDay(PRUnichar * *aBirthDay) { return _to GetBirthDay(aBirthDay); } \
  NS_IMETHOD SetBirthDay(const PRUnichar * aBirthDay) { return _to SetBirthDay(aBirthDay); } \
  NS_IMETHOD GetCustom1(PRUnichar * *aCustom1) { return _to GetCustom1(aCustom1); } \
  NS_IMETHOD SetCustom1(const PRUnichar * aCustom1) { return _to SetCustom1(aCustom1); } \
  NS_IMETHOD GetCustom2(PRUnichar * *aCustom2) { return _to GetCustom2(aCustom2); } \
  NS_IMETHOD SetCustom2(const PRUnichar * aCustom2) { return _to SetCustom2(aCustom2); } \
  NS_IMETHOD GetCustom3(PRUnichar * *aCustom3) { return _to GetCustom3(aCustom3); } \
  NS_IMETHOD SetCustom3(const PRUnichar * aCustom3) { return _to SetCustom3(aCustom3); } \
  NS_IMETHOD GetCustom4(PRUnichar * *aCustom4) { return _to GetCustom4(aCustom4); } \
  NS_IMETHOD SetCustom4(const PRUnichar * aCustom4) { return _to SetCustom4(aCustom4); } \
  NS_IMETHOD GetNotes(PRUnichar * *aNotes) { return _to GetNotes(aNotes); } \
  NS_IMETHOD SetNotes(const PRUnichar * aNotes) { return _to SetNotes(aNotes); } \
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate) { return _to GetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate) { return _to SetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD GetPopularityIndex(PRUint32 *aPopularityIndex) { return _to GetPopularityIndex(aPopularityIndex); } \
  NS_IMETHOD SetPopularityIndex(PRUint32 aPopularityIndex) { return _to SetPopularityIndex(aPopularityIndex); } \
  NS_IMETHOD GetPreferMailFormat(PRUint32 *aPreferMailFormat) { return _to GetPreferMailFormat(aPreferMailFormat); } \
  NS_IMETHOD SetPreferMailFormat(PRUint32 aPreferMailFormat) { return _to SetPreferMailFormat(aPreferMailFormat); } \
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList) { return _to GetIsMailList(aIsMailList); } \
  NS_IMETHOD SetIsMailList(PRBool aIsMailList) { return _to SetIsMailList(aIsMailList); } \
  NS_IMETHOD GetMailListURI(char * *aMailListURI) { return _to GetMailListURI(aMailListURI); } \
  NS_IMETHOD SetMailListURI(const char * aMailListURI) { return _to SetMailListURI(aMailListURI); } \
  NS_IMETHOD GetAllowRemoteContent(PRBool *aAllowRemoteContent) { return _to GetAllowRemoteContent(aAllowRemoteContent); } \
  NS_IMETHOD SetAllowRemoteContent(PRBool aAllowRemoteContent) { return _to SetAllowRemoteContent(aAllowRemoteContent); } \
  NS_IMETHOD GetIsANormalCard(PRBool *aIsANormalCard) { return _to GetIsANormalCard(aIsANormalCard); } \
  NS_IMETHOD GetIsASpecialGroup(PRBool *aIsASpecialGroup) { return _to GetIsASpecialGroup(aIsASpecialGroup); } \
  NS_IMETHOD GetIsAnEmailAddress(PRBool *aIsAnEmailAddress) { return _to GetIsAnEmailAddress(aIsAnEmailAddress); } \
  NS_IMETHOD GetCardValue(const char *name, PRUnichar **_retval) { return _to GetCardValue(name, _retval); } \
  NS_IMETHOD SetCardValue(const char *attrname, const PRUnichar *value) { return _to SetCardValue(attrname, value); } \
  NS_IMETHOD Copy(nsIAbCard *srcCard) { return _to Copy(srcCard); } \
  NS_IMETHOD EditCardToDatabase(const char *uri) { return _to EditCardToDatabase(uri); } \
  NS_IMETHOD Equals(nsIAbCard *card, PRBool *_retval) { return _to Equals(card, _retval); } \
  NS_IMETHOD ConvertToBase64EncodedXML(char **_retval) { return _to ConvertToBase64EncodedXML(_retval); } \
  NS_IMETHOD ConvertToXMLPrintData(PRUnichar **_retval) { return _to ConvertToXMLPrintData(_retval); } \
  NS_IMETHOD ConvertToEscapedVCard(char **_retval) { return _to ConvertToEscapedVCard(_retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABCARD(_to) \
  NS_IMETHOD GetFirstName(PRUnichar * *aFirstName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFirstName(aFirstName); } \
  NS_IMETHOD SetFirstName(const PRUnichar * aFirstName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFirstName(aFirstName); } \
  NS_IMETHOD GetLastName(PRUnichar * *aLastName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLastName(aLastName); } \
  NS_IMETHOD SetLastName(const PRUnichar * aLastName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetLastName(aLastName); } \
  NS_IMETHOD GetPhoneticFirstName(PRUnichar * *aPhoneticFirstName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPhoneticFirstName(aPhoneticFirstName); } \
  NS_IMETHOD SetPhoneticFirstName(const PRUnichar * aPhoneticFirstName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPhoneticFirstName(aPhoneticFirstName); } \
  NS_IMETHOD GetPhoneticLastName(PRUnichar * *aPhoneticLastName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPhoneticLastName(aPhoneticLastName); } \
  NS_IMETHOD SetPhoneticLastName(const PRUnichar * aPhoneticLastName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPhoneticLastName(aPhoneticLastName); } \
  NS_IMETHOD GetDisplayName(PRUnichar * *aDisplayName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDisplayName(aDisplayName); } \
  NS_IMETHOD SetDisplayName(const PRUnichar * aDisplayName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDisplayName(aDisplayName); } \
  NS_IMETHOD GetNickName(PRUnichar * *aNickName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNickName(aNickName); } \
  NS_IMETHOD SetNickName(const PRUnichar * aNickName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetNickName(aNickName); } \
  NS_IMETHOD GetPrimaryEmail(PRUnichar * *aPrimaryEmail) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPrimaryEmail(aPrimaryEmail); } \
  NS_IMETHOD SetPrimaryEmail(const PRUnichar * aPrimaryEmail) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPrimaryEmail(aPrimaryEmail); } \
  NS_IMETHOD GetSecondEmail(PRUnichar * *aSecondEmail) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSecondEmail(aSecondEmail); } \
  NS_IMETHOD SetSecondEmail(const PRUnichar * aSecondEmail) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSecondEmail(aSecondEmail); } \
  NS_IMETHOD GetDefaultEmail(PRUnichar * *aDefaultEmail) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDefaultEmail(aDefaultEmail); } \
  NS_IMETHOD SetDefaultEmail(const PRUnichar * aDefaultEmail) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDefaultEmail(aDefaultEmail); } \
  NS_IMETHOD GetCardType(PRUnichar * *aCardType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCardType(aCardType); } \
  NS_IMETHOD SetCardType(const PRUnichar * aCardType) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCardType(aCardType); } \
  NS_IMETHOD GetWorkPhone(PRUnichar * *aWorkPhone) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkPhone(aWorkPhone); } \
  NS_IMETHOD SetWorkPhone(const PRUnichar * aWorkPhone) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkPhone(aWorkPhone); } \
  NS_IMETHOD GetHomePhone(PRUnichar * *aHomePhone) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomePhone(aHomePhone); } \
  NS_IMETHOD SetHomePhone(const PRUnichar * aHomePhone) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomePhone(aHomePhone); } \
  NS_IMETHOD GetFaxNumber(PRUnichar * *aFaxNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFaxNumber(aFaxNumber); } \
  NS_IMETHOD SetFaxNumber(const PRUnichar * aFaxNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFaxNumber(aFaxNumber); } \
  NS_IMETHOD GetPagerNumber(PRUnichar * *aPagerNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPagerNumber(aPagerNumber); } \
  NS_IMETHOD SetPagerNumber(const PRUnichar * aPagerNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPagerNumber(aPagerNumber); } \
  NS_IMETHOD GetCellularNumber(PRUnichar * *aCellularNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCellularNumber(aCellularNumber); } \
  NS_IMETHOD SetCellularNumber(const PRUnichar * aCellularNumber) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCellularNumber(aCellularNumber); } \
  NS_IMETHOD GetWorkPhoneType(PRUnichar * *aWorkPhoneType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkPhoneType(aWorkPhoneType); } \
  NS_IMETHOD SetWorkPhoneType(const PRUnichar * aWorkPhoneType) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkPhoneType(aWorkPhoneType); } \
  NS_IMETHOD GetHomePhoneType(PRUnichar * *aHomePhoneType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomePhoneType(aHomePhoneType); } \
  NS_IMETHOD SetHomePhoneType(const PRUnichar * aHomePhoneType) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomePhoneType(aHomePhoneType); } \
  NS_IMETHOD GetFaxNumberType(PRUnichar * *aFaxNumberType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFaxNumberType(aFaxNumberType); } \
  NS_IMETHOD SetFaxNumberType(const PRUnichar * aFaxNumberType) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFaxNumberType(aFaxNumberType); } \
  NS_IMETHOD GetPagerNumberType(PRUnichar * *aPagerNumberType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPagerNumberType(aPagerNumberType); } \
  NS_IMETHOD SetPagerNumberType(const PRUnichar * aPagerNumberType) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPagerNumberType(aPagerNumberType); } \
  NS_IMETHOD GetCellularNumberType(PRUnichar * *aCellularNumberType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCellularNumberType(aCellularNumberType); } \
  NS_IMETHOD SetCellularNumberType(const PRUnichar * aCellularNumberType) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCellularNumberType(aCellularNumberType); } \
  NS_IMETHOD GetHomeAddress(PRUnichar * *aHomeAddress) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomeAddress(aHomeAddress); } \
  NS_IMETHOD SetHomeAddress(const PRUnichar * aHomeAddress) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomeAddress(aHomeAddress); } \
  NS_IMETHOD GetHomeAddress2(PRUnichar * *aHomeAddress2) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomeAddress2(aHomeAddress2); } \
  NS_IMETHOD SetHomeAddress2(const PRUnichar * aHomeAddress2) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomeAddress2(aHomeAddress2); } \
  NS_IMETHOD GetHomeCity(PRUnichar * *aHomeCity) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomeCity(aHomeCity); } \
  NS_IMETHOD SetHomeCity(const PRUnichar * aHomeCity) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomeCity(aHomeCity); } \
  NS_IMETHOD GetHomeState(PRUnichar * *aHomeState) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomeState(aHomeState); } \
  NS_IMETHOD SetHomeState(const PRUnichar * aHomeState) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomeState(aHomeState); } \
  NS_IMETHOD GetHomeZipCode(PRUnichar * *aHomeZipCode) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomeZipCode(aHomeZipCode); } \
  NS_IMETHOD SetHomeZipCode(const PRUnichar * aHomeZipCode) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomeZipCode(aHomeZipCode); } \
  NS_IMETHOD GetHomeCountry(PRUnichar * *aHomeCountry) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHomeCountry(aHomeCountry); } \
  NS_IMETHOD SetHomeCountry(const PRUnichar * aHomeCountry) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetHomeCountry(aHomeCountry); } \
  NS_IMETHOD GetWorkAddress(PRUnichar * *aWorkAddress) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkAddress(aWorkAddress); } \
  NS_IMETHOD SetWorkAddress(const PRUnichar * aWorkAddress) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkAddress(aWorkAddress); } \
  NS_IMETHOD GetWorkAddress2(PRUnichar * *aWorkAddress2) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkAddress2(aWorkAddress2); } \
  NS_IMETHOD SetWorkAddress2(const PRUnichar * aWorkAddress2) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkAddress2(aWorkAddress2); } \
  NS_IMETHOD GetWorkCity(PRUnichar * *aWorkCity) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkCity(aWorkCity); } \
  NS_IMETHOD SetWorkCity(const PRUnichar * aWorkCity) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkCity(aWorkCity); } \
  NS_IMETHOD GetWorkState(PRUnichar * *aWorkState) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkState(aWorkState); } \
  NS_IMETHOD SetWorkState(const PRUnichar * aWorkState) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkState(aWorkState); } \
  NS_IMETHOD GetWorkZipCode(PRUnichar * *aWorkZipCode) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkZipCode(aWorkZipCode); } \
  NS_IMETHOD SetWorkZipCode(const PRUnichar * aWorkZipCode) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkZipCode(aWorkZipCode); } \
  NS_IMETHOD GetWorkCountry(PRUnichar * *aWorkCountry) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWorkCountry(aWorkCountry); } \
  NS_IMETHOD SetWorkCountry(const PRUnichar * aWorkCountry) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWorkCountry(aWorkCountry); } \
  NS_IMETHOD GetJobTitle(PRUnichar * *aJobTitle) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetJobTitle(aJobTitle); } \
  NS_IMETHOD SetJobTitle(const PRUnichar * aJobTitle) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetJobTitle(aJobTitle); } \
  NS_IMETHOD GetDepartment(PRUnichar * *aDepartment) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDepartment(aDepartment); } \
  NS_IMETHOD SetDepartment(const PRUnichar * aDepartment) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDepartment(aDepartment); } \
  NS_IMETHOD GetCompany(PRUnichar * *aCompany) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCompany(aCompany); } \
  NS_IMETHOD SetCompany(const PRUnichar * aCompany) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCompany(aCompany); } \
  NS_IMETHOD GetAimScreenName(PRUnichar * *aAimScreenName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAimScreenName(aAimScreenName); } \
  NS_IMETHOD SetAimScreenName(const PRUnichar * aAimScreenName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAimScreenName(aAimScreenName); } \
  NS_IMETHOD GetAnniversaryYear(PRUnichar * *aAnniversaryYear) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAnniversaryYear(aAnniversaryYear); } \
  NS_IMETHOD SetAnniversaryYear(const PRUnichar * aAnniversaryYear) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAnniversaryYear(aAnniversaryYear); } \
  NS_IMETHOD GetAnniversaryMonth(PRUnichar * *aAnniversaryMonth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAnniversaryMonth(aAnniversaryMonth); } \
  NS_IMETHOD SetAnniversaryMonth(const PRUnichar * aAnniversaryMonth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAnniversaryMonth(aAnniversaryMonth); } \
  NS_IMETHOD GetAnniversaryDay(PRUnichar * *aAnniversaryDay) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAnniversaryDay(aAnniversaryDay); } \
  NS_IMETHOD SetAnniversaryDay(const PRUnichar * aAnniversaryDay) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAnniversaryDay(aAnniversaryDay); } \
  NS_IMETHOD GetSpouseName(PRUnichar * *aSpouseName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSpouseName(aSpouseName); } \
  NS_IMETHOD SetSpouseName(const PRUnichar * aSpouseName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSpouseName(aSpouseName); } \
  NS_IMETHOD GetFamilyName(PRUnichar * *aFamilyName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFamilyName(aFamilyName); } \
  NS_IMETHOD SetFamilyName(const PRUnichar * aFamilyName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFamilyName(aFamilyName); } \
  NS_IMETHOD GetDefaultAddress(PRUnichar * *aDefaultAddress) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDefaultAddress(aDefaultAddress); } \
  NS_IMETHOD SetDefaultAddress(const PRUnichar * aDefaultAddress) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDefaultAddress(aDefaultAddress); } \
  NS_IMETHOD GetCategory(PRUnichar * *aCategory) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCategory(aCategory); } \
  NS_IMETHOD SetCategory(const PRUnichar * aCategory) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCategory(aCategory); } \
  NS_IMETHOD GetWebPage1(PRUnichar * *aWebPage1) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWebPage1(aWebPage1); } \
  NS_IMETHOD SetWebPage1(const PRUnichar * aWebPage1) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWebPage1(aWebPage1); } \
  NS_IMETHOD GetWebPage2(PRUnichar * *aWebPage2) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetWebPage2(aWebPage2); } \
  NS_IMETHOD SetWebPage2(const PRUnichar * aWebPage2) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetWebPage2(aWebPage2); } \
  NS_IMETHOD GetBirthYear(PRUnichar * *aBirthYear) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBirthYear(aBirthYear); } \
  NS_IMETHOD SetBirthYear(const PRUnichar * aBirthYear) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBirthYear(aBirthYear); } \
  NS_IMETHOD GetBirthMonth(PRUnichar * *aBirthMonth) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBirthMonth(aBirthMonth); } \
  NS_IMETHOD SetBirthMonth(const PRUnichar * aBirthMonth) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBirthMonth(aBirthMonth); } \
  NS_IMETHOD GetBirthDay(PRUnichar * *aBirthDay) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetBirthDay(aBirthDay); } \
  NS_IMETHOD SetBirthDay(const PRUnichar * aBirthDay) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetBirthDay(aBirthDay); } \
  NS_IMETHOD GetCustom1(PRUnichar * *aCustom1) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCustom1(aCustom1); } \
  NS_IMETHOD SetCustom1(const PRUnichar * aCustom1) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCustom1(aCustom1); } \
  NS_IMETHOD GetCustom2(PRUnichar * *aCustom2) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCustom2(aCustom2); } \
  NS_IMETHOD SetCustom2(const PRUnichar * aCustom2) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCustom2(aCustom2); } \
  NS_IMETHOD GetCustom3(PRUnichar * *aCustom3) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCustom3(aCustom3); } \
  NS_IMETHOD SetCustom3(const PRUnichar * aCustom3) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCustom3(aCustom3); } \
  NS_IMETHOD GetCustom4(PRUnichar * *aCustom4) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCustom4(aCustom4); } \
  NS_IMETHOD SetCustom4(const PRUnichar * aCustom4) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCustom4(aCustom4); } \
  NS_IMETHOD GetNotes(PRUnichar * *aNotes) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNotes(aNotes); } \
  NS_IMETHOD SetNotes(const PRUnichar * aNotes) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetNotes(aNotes); } \
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD GetPopularityIndex(PRUint32 *aPopularityIndex) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPopularityIndex(aPopularityIndex); } \
  NS_IMETHOD SetPopularityIndex(PRUint32 aPopularityIndex) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPopularityIndex(aPopularityIndex); } \
  NS_IMETHOD GetPreferMailFormat(PRUint32 *aPreferMailFormat) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPreferMailFormat(aPreferMailFormat); } \
  NS_IMETHOD SetPreferMailFormat(PRUint32 aPreferMailFormat) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPreferMailFormat(aPreferMailFormat); } \
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsMailList(aIsMailList); } \
  NS_IMETHOD SetIsMailList(PRBool aIsMailList) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsMailList(aIsMailList); } \
  NS_IMETHOD GetMailListURI(char * *aMailListURI) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMailListURI(aMailListURI); } \
  NS_IMETHOD SetMailListURI(const char * aMailListURI) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMailListURI(aMailListURI); } \
  NS_IMETHOD GetAllowRemoteContent(PRBool *aAllowRemoteContent) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAllowRemoteContent(aAllowRemoteContent); } \
  NS_IMETHOD SetAllowRemoteContent(PRBool aAllowRemoteContent) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAllowRemoteContent(aAllowRemoteContent); } \
  NS_IMETHOD GetIsANormalCard(PRBool *aIsANormalCard) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsANormalCard(aIsANormalCard); } \
  NS_IMETHOD GetIsASpecialGroup(PRBool *aIsASpecialGroup) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsASpecialGroup(aIsASpecialGroup); } \
  NS_IMETHOD GetIsAnEmailAddress(PRBool *aIsAnEmailAddress) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsAnEmailAddress(aIsAnEmailAddress); } \
  NS_IMETHOD GetCardValue(const char *name, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCardValue(name, _retval); } \
  NS_IMETHOD SetCardValue(const char *attrname, const PRUnichar *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCardValue(attrname, value); } \
  NS_IMETHOD Copy(nsIAbCard *srcCard) { return !_to ? NS_ERROR_NULL_POINTER : _to->Copy(srcCard); } \
  NS_IMETHOD EditCardToDatabase(const char *uri) { return !_to ? NS_ERROR_NULL_POINTER : _to->EditCardToDatabase(uri); } \
  NS_IMETHOD Equals(nsIAbCard *card, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->Equals(card, _retval); } \
  NS_IMETHOD ConvertToBase64EncodedXML(char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ConvertToBase64EncodedXML(_retval); } \
  NS_IMETHOD ConvertToXMLPrintData(PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ConvertToXMLPrintData(_retval); } \
  NS_IMETHOD ConvertToEscapedVCard(char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ConvertToEscapedVCard(_retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbCard : public nsIAbCard
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABCARD

  nsAbCard();

private:
  ~nsAbCard();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbCard, nsIAbCard)

nsAbCard::nsAbCard()
{
  /* member initializers and constructor code */
}

nsAbCard::~nsAbCard()
{
  /* destructor code */
}

/* attribute wstring firstName; */
NS_IMETHODIMP nsAbCard::GetFirstName(PRUnichar * *aFirstName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetFirstName(const PRUnichar * aFirstName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring lastName; */
NS_IMETHODIMP nsAbCard::GetLastName(PRUnichar * *aLastName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetLastName(const PRUnichar * aLastName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring phoneticFirstName; */
NS_IMETHODIMP nsAbCard::GetPhoneticFirstName(PRUnichar * *aPhoneticFirstName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetPhoneticFirstName(const PRUnichar * aPhoneticFirstName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring phoneticLastName; */
NS_IMETHODIMP nsAbCard::GetPhoneticLastName(PRUnichar * *aPhoneticLastName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetPhoneticLastName(const PRUnichar * aPhoneticLastName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring displayName; */
NS_IMETHODIMP nsAbCard::GetDisplayName(PRUnichar * *aDisplayName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetDisplayName(const PRUnichar * aDisplayName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring nickName; */
NS_IMETHODIMP nsAbCard::GetNickName(PRUnichar * *aNickName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetNickName(const PRUnichar * aNickName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring primaryEmail; */
NS_IMETHODIMP nsAbCard::GetPrimaryEmail(PRUnichar * *aPrimaryEmail)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetPrimaryEmail(const PRUnichar * aPrimaryEmail)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring secondEmail; */
NS_IMETHODIMP nsAbCard::GetSecondEmail(PRUnichar * *aSecondEmail)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetSecondEmail(const PRUnichar * aSecondEmail)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring defaultEmail; */
NS_IMETHODIMP nsAbCard::GetDefaultEmail(PRUnichar * *aDefaultEmail)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetDefaultEmail(const PRUnichar * aDefaultEmail)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring cardType; */
NS_IMETHODIMP nsAbCard::GetCardType(PRUnichar * *aCardType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCardType(const PRUnichar * aCardType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workPhone; */
NS_IMETHODIMP nsAbCard::GetWorkPhone(PRUnichar * *aWorkPhone)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkPhone(const PRUnichar * aWorkPhone)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homePhone; */
NS_IMETHODIMP nsAbCard::GetHomePhone(PRUnichar * *aHomePhone)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomePhone(const PRUnichar * aHomePhone)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring faxNumber; */
NS_IMETHODIMP nsAbCard::GetFaxNumber(PRUnichar * *aFaxNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetFaxNumber(const PRUnichar * aFaxNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring pagerNumber; */
NS_IMETHODIMP nsAbCard::GetPagerNumber(PRUnichar * *aPagerNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetPagerNumber(const PRUnichar * aPagerNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring cellularNumber; */
NS_IMETHODIMP nsAbCard::GetCellularNumber(PRUnichar * *aCellularNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCellularNumber(const PRUnichar * aCellularNumber)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workPhoneType; */
NS_IMETHODIMP nsAbCard::GetWorkPhoneType(PRUnichar * *aWorkPhoneType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkPhoneType(const PRUnichar * aWorkPhoneType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homePhoneType; */
NS_IMETHODIMP nsAbCard::GetHomePhoneType(PRUnichar * *aHomePhoneType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomePhoneType(const PRUnichar * aHomePhoneType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring faxNumberType; */
NS_IMETHODIMP nsAbCard::GetFaxNumberType(PRUnichar * *aFaxNumberType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetFaxNumberType(const PRUnichar * aFaxNumberType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring pagerNumberType; */
NS_IMETHODIMP nsAbCard::GetPagerNumberType(PRUnichar * *aPagerNumberType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetPagerNumberType(const PRUnichar * aPagerNumberType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring cellularNumberType; */
NS_IMETHODIMP nsAbCard::GetCellularNumberType(PRUnichar * *aCellularNumberType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCellularNumberType(const PRUnichar * aCellularNumberType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homeAddress; */
NS_IMETHODIMP nsAbCard::GetHomeAddress(PRUnichar * *aHomeAddress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomeAddress(const PRUnichar * aHomeAddress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homeAddress2; */
NS_IMETHODIMP nsAbCard::GetHomeAddress2(PRUnichar * *aHomeAddress2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomeAddress2(const PRUnichar * aHomeAddress2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homeCity; */
NS_IMETHODIMP nsAbCard::GetHomeCity(PRUnichar * *aHomeCity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomeCity(const PRUnichar * aHomeCity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homeState; */
NS_IMETHODIMP nsAbCard::GetHomeState(PRUnichar * *aHomeState)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomeState(const PRUnichar * aHomeState)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homeZipCode; */
NS_IMETHODIMP nsAbCard::GetHomeZipCode(PRUnichar * *aHomeZipCode)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomeZipCode(const PRUnichar * aHomeZipCode)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring homeCountry; */
NS_IMETHODIMP nsAbCard::GetHomeCountry(PRUnichar * *aHomeCountry)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetHomeCountry(const PRUnichar * aHomeCountry)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workAddress; */
NS_IMETHODIMP nsAbCard::GetWorkAddress(PRUnichar * *aWorkAddress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkAddress(const PRUnichar * aWorkAddress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workAddress2; */
NS_IMETHODIMP nsAbCard::GetWorkAddress2(PRUnichar * *aWorkAddress2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkAddress2(const PRUnichar * aWorkAddress2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workCity; */
NS_IMETHODIMP nsAbCard::GetWorkCity(PRUnichar * *aWorkCity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkCity(const PRUnichar * aWorkCity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workState; */
NS_IMETHODIMP nsAbCard::GetWorkState(PRUnichar * *aWorkState)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkState(const PRUnichar * aWorkState)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workZipCode; */
NS_IMETHODIMP nsAbCard::GetWorkZipCode(PRUnichar * *aWorkZipCode)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkZipCode(const PRUnichar * aWorkZipCode)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring workCountry; */
NS_IMETHODIMP nsAbCard::GetWorkCountry(PRUnichar * *aWorkCountry)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWorkCountry(const PRUnichar * aWorkCountry)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring jobTitle; */
NS_IMETHODIMP nsAbCard::GetJobTitle(PRUnichar * *aJobTitle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetJobTitle(const PRUnichar * aJobTitle)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring department; */
NS_IMETHODIMP nsAbCard::GetDepartment(PRUnichar * *aDepartment)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetDepartment(const PRUnichar * aDepartment)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring company; */
NS_IMETHODIMP nsAbCard::GetCompany(PRUnichar * *aCompany)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCompany(const PRUnichar * aCompany)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring aimScreenName; */
NS_IMETHODIMP nsAbCard::GetAimScreenName(PRUnichar * *aAimScreenName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetAimScreenName(const PRUnichar * aAimScreenName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring anniversaryYear; */
NS_IMETHODIMP nsAbCard::GetAnniversaryYear(PRUnichar * *aAnniversaryYear)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetAnniversaryYear(const PRUnichar * aAnniversaryYear)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring anniversaryMonth; */
NS_IMETHODIMP nsAbCard::GetAnniversaryMonth(PRUnichar * *aAnniversaryMonth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetAnniversaryMonth(const PRUnichar * aAnniversaryMonth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring anniversaryDay; */
NS_IMETHODIMP nsAbCard::GetAnniversaryDay(PRUnichar * *aAnniversaryDay)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetAnniversaryDay(const PRUnichar * aAnniversaryDay)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring spouseName; */
NS_IMETHODIMP nsAbCard::GetSpouseName(PRUnichar * *aSpouseName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetSpouseName(const PRUnichar * aSpouseName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring familyName; */
NS_IMETHODIMP nsAbCard::GetFamilyName(PRUnichar * *aFamilyName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetFamilyName(const PRUnichar * aFamilyName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring defaultAddress; */
NS_IMETHODIMP nsAbCard::GetDefaultAddress(PRUnichar * *aDefaultAddress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetDefaultAddress(const PRUnichar * aDefaultAddress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring category; */
NS_IMETHODIMP nsAbCard::GetCategory(PRUnichar * *aCategory)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCategory(const PRUnichar * aCategory)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring webPage1; */
NS_IMETHODIMP nsAbCard::GetWebPage1(PRUnichar * *aWebPage1)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWebPage1(const PRUnichar * aWebPage1)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring webPage2; */
NS_IMETHODIMP nsAbCard::GetWebPage2(PRUnichar * *aWebPage2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetWebPage2(const PRUnichar * aWebPage2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring birthYear; */
NS_IMETHODIMP nsAbCard::GetBirthYear(PRUnichar * *aBirthYear)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetBirthYear(const PRUnichar * aBirthYear)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring birthMonth; */
NS_IMETHODIMP nsAbCard::GetBirthMonth(PRUnichar * *aBirthMonth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetBirthMonth(const PRUnichar * aBirthMonth)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring birthDay; */
NS_IMETHODIMP nsAbCard::GetBirthDay(PRUnichar * *aBirthDay)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetBirthDay(const PRUnichar * aBirthDay)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring custom1; */
NS_IMETHODIMP nsAbCard::GetCustom1(PRUnichar * *aCustom1)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCustom1(const PRUnichar * aCustom1)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring custom2; */
NS_IMETHODIMP nsAbCard::GetCustom2(PRUnichar * *aCustom2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCustom2(const PRUnichar * aCustom2)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring custom3; */
NS_IMETHODIMP nsAbCard::GetCustom3(PRUnichar * *aCustom3)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCustom3(const PRUnichar * aCustom3)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring custom4; */
NS_IMETHODIMP nsAbCard::GetCustom4(PRUnichar * *aCustom4)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetCustom4(const PRUnichar * aCustom4)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring notes; */
NS_IMETHODIMP nsAbCard::GetNotes(PRUnichar * *aNotes)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetNotes(const PRUnichar * aNotes)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long lastModifiedDate; */
NS_IMETHODIMP nsAbCard::GetLastModifiedDate(PRUint32 *aLastModifiedDate)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetLastModifiedDate(PRUint32 aLastModifiedDate)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long popularityIndex; */
NS_IMETHODIMP nsAbCard::GetPopularityIndex(PRUint32 *aPopularityIndex)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetPopularityIndex(PRUint32 aPopularityIndex)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long preferMailFormat; */
NS_IMETHODIMP nsAbCard::GetPreferMailFormat(PRUint32 *aPreferMailFormat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetPreferMailFormat(PRUint32 aPreferMailFormat)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isMailList; */
NS_IMETHODIMP nsAbCard::GetIsMailList(PRBool *aIsMailList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetIsMailList(PRBool aIsMailList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute string mailListURI; */
NS_IMETHODIMP nsAbCard::GetMailListURI(char * *aMailListURI)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetMailListURI(const char * aMailListURI)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean allowRemoteContent; */
NS_IMETHODIMP nsAbCard::GetAllowRemoteContent(PRBool *aAllowRemoteContent)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbCard::SetAllowRemoteContent(PRBool aAllowRemoteContent)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean isANormalCard; */
NS_IMETHODIMP nsAbCard::GetIsANormalCard(PRBool *aIsANormalCard)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean isASpecialGroup; */
NS_IMETHODIMP nsAbCard::GetIsASpecialGroup(PRBool *aIsASpecialGroup)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean isAnEmailAddress; */
NS_IMETHODIMP nsAbCard::GetIsAnEmailAddress(PRBool *aIsAnEmailAddress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring getCardValue (in string name); */
NS_IMETHODIMP nsAbCard::GetCardValue(const char *name, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setCardValue (in string attrname, in wstring value); */
NS_IMETHODIMP nsAbCard::SetCardValue(const char *attrname, const PRUnichar *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copy (in nsIAbCard srcCard); */
NS_IMETHODIMP nsAbCard::Copy(nsIAbCard *srcCard)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void editCardToDatabase (in string uri); */
NS_IMETHODIMP nsAbCard::EditCardToDatabase(const char *uri)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean equals (in nsIAbCard card); */
NS_IMETHODIMP nsAbCard::Equals(nsIAbCard *card, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* string convertToBase64EncodedXML (); */
NS_IMETHODIMP nsAbCard::ConvertToBase64EncodedXML(char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring convertToXMLPrintData (); */
NS_IMETHODIMP nsAbCard::ConvertToXMLPrintData(PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* string convertToEscapedVCard (); */
NS_IMETHODIMP nsAbCard::ConvertToEscapedVCard(char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbCard_h__ */
