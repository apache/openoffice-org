/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/mailnews/addrbook/public/../../../../mailnews/addrbook/public/nsIAbDirFactoryService.idl
 */

#ifndef __gen_nsIAbDirFactoryService_h__
#define __gen_nsIAbDirFactoryService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAbDirFactory; /* forward declaration */


/* starting interface:    nsIAbDirFactoryService */
#define NS_IABDIRFACTORYSERVICE_IID_STR "be2075a8-1dd1-11b2-99ba-bcb9db1d77cc"

#define NS_IABDIRFACTORYSERVICE_IID \
  {0xbe2075a8, 0x1dd1, 0x11b2, \
    { 0x99, 0xba, 0xbc, 0xb9, 0xdb, 0x1d, 0x77, 0xcc }}

class NS_NO_VTABLE nsIAbDirFactoryService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABDIRFACTORYSERVICE_IID)

  /**
     * Obtain a directory factory component
     * given a uri representing an address book
     *
     * The scheme is extracted from the uri and
     * contract id is generated of the form:
     * @mozilla.org/addressbook/directory-factory;1?type=<scheme>
     * 
     * This id is used to instantiate a registered
     * component which implemented the nsIAbDirFactory
     * interface
     *
     * @param uri
     *        The uri which contains the scheme that
     *        defines what directory factory instance
     *        is returned
     */
  /* nsIAbDirFactory getDirFactory (in string uri); */
  NS_IMETHOD GetDirFactory(const char *uri, nsIAbDirFactory **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABDIRFACTORYSERVICE \
  NS_IMETHOD GetDirFactory(const char *uri, nsIAbDirFactory **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABDIRFACTORYSERVICE(_to) \
  NS_IMETHOD GetDirFactory(const char *uri, nsIAbDirFactory **_retval) { return _to GetDirFactory(uri, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABDIRFACTORYSERVICE(_to) \
  NS_IMETHOD GetDirFactory(const char *uri, nsIAbDirFactory **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDirFactory(uri, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbDirFactoryService : public nsIAbDirFactoryService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABDIRFACTORYSERVICE

  nsAbDirFactoryService();

private:
  ~nsAbDirFactoryService();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbDirFactoryService, nsIAbDirFactoryService)

nsAbDirFactoryService::nsAbDirFactoryService()
{
  /* member initializers and constructor code */
}

nsAbDirFactoryService::~nsAbDirFactoryService()
{
  /* destructor code */
}

/* nsIAbDirFactory getDirFactory (in string uri); */
NS_IMETHODIMP nsAbDirFactoryService::GetDirFactory(const char *uri, nsIAbDirFactory **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbDirFactoryService_h__ */
