/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/mailnews/addrbook/public/../../../../mailnews/addrbook/public/nsIAddrDBAnnouncer.idl
 */

#ifndef __gen_nsIAddrDBAnnouncer_h__
#define __gen_nsIAddrDBAnnouncer_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAbCard_h__
#include "nsIAbCard.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAddrDBListener; /* forward declaration */


/* starting interface:    nsIAddrDBAnnouncer */
#define NS_IADDRDBANNOUNCER_IID_STR "0d8fe8e3-ad48-4dbd-b0c2-a1d374e39b93"

#define NS_IADDRDBANNOUNCER_IID \
  {0x0d8fe8e3, 0xad48, 0x4dbd, \
    { 0xb0, 0xc2, 0xa1, 0xd3, 0x74, 0xe3, 0x9b, 0x93 }}

class NS_NO_VTABLE nsIAddrDBAnnouncer : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IADDRDBANNOUNCER_IID)

  /* void addListener (in nsIAddrDBListener listener); */
  NS_IMETHOD AddListener(nsIAddrDBListener *listener) = 0;

  /* void removeListener (in nsIAddrDBListener listener); */
  NS_IMETHOD RemoveListener(nsIAddrDBListener *listener) = 0;

  /* void notifyCardAttribChange (in unsigned long abCode); */
  NS_IMETHOD NotifyCardAttribChange(PRUint32 abCode) = 0;

  /* void notifyCardEntryChange (in unsigned long abCode, in nsIAbCard card); */
  NS_IMETHOD NotifyCardEntryChange(PRUint32 abCode, nsIAbCard *card) = 0;

  /* void notifyAnnouncerGoingAway (); */
  NS_IMETHOD NotifyAnnouncerGoingAway(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIADDRDBANNOUNCER \
  NS_IMETHOD AddListener(nsIAddrDBListener *listener); \
  NS_IMETHOD RemoveListener(nsIAddrDBListener *listener); \
  NS_IMETHOD NotifyCardAttribChange(PRUint32 abCode); \
  NS_IMETHOD NotifyCardEntryChange(PRUint32 abCode, nsIAbCard *card); \
  NS_IMETHOD NotifyAnnouncerGoingAway(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIADDRDBANNOUNCER(_to) \
  NS_IMETHOD AddListener(nsIAddrDBListener *listener) { return _to AddListener(listener); } \
  NS_IMETHOD RemoveListener(nsIAddrDBListener *listener) { return _to RemoveListener(listener); } \
  NS_IMETHOD NotifyCardAttribChange(PRUint32 abCode) { return _to NotifyCardAttribChange(abCode); } \
  NS_IMETHOD NotifyCardEntryChange(PRUint32 abCode, nsIAbCard *card) { return _to NotifyCardEntryChange(abCode, card); } \
  NS_IMETHOD NotifyAnnouncerGoingAway(void) { return _to NotifyAnnouncerGoingAway(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIADDRDBANNOUNCER(_to) \
  NS_IMETHOD AddListener(nsIAddrDBListener *listener) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddListener(listener); } \
  NS_IMETHOD RemoveListener(nsIAddrDBListener *listener) { return !_to ? NS_ERROR_NULL_POINTER : _to->RemoveListener(listener); } \
  NS_IMETHOD NotifyCardAttribChange(PRUint32 abCode) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyCardAttribChange(abCode); } \
  NS_IMETHOD NotifyCardEntryChange(PRUint32 abCode, nsIAbCard *card) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyCardEntryChange(abCode, card); } \
  NS_IMETHOD NotifyAnnouncerGoingAway(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyAnnouncerGoingAway(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAddrDBAnnouncer : public nsIAddrDBAnnouncer
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIADDRDBANNOUNCER

  nsAddrDBAnnouncer();

private:
  ~nsAddrDBAnnouncer();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAddrDBAnnouncer, nsIAddrDBAnnouncer)

nsAddrDBAnnouncer::nsAddrDBAnnouncer()
{
  /* member initializers and constructor code */
}

nsAddrDBAnnouncer::~nsAddrDBAnnouncer()
{
  /* destructor code */
}

/* void addListener (in nsIAddrDBListener listener); */
NS_IMETHODIMP nsAddrDBAnnouncer::AddListener(nsIAddrDBListener *listener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void removeListener (in nsIAddrDBListener listener); */
NS_IMETHODIMP nsAddrDBAnnouncer::RemoveListener(nsIAddrDBListener *listener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void notifyCardAttribChange (in unsigned long abCode); */
NS_IMETHODIMP nsAddrDBAnnouncer::NotifyCardAttribChange(PRUint32 abCode)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void notifyCardEntryChange (in unsigned long abCode, in nsIAbCard card); */
NS_IMETHODIMP nsAddrDBAnnouncer::NotifyCardEntryChange(PRUint32 abCode, nsIAbCard *card)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void notifyAnnouncerGoingAway (); */
NS_IMETHODIMP nsAddrDBAnnouncer::NotifyAnnouncerGoingAway()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAddrDBAnnouncer_h__ */
