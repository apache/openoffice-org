/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/mailnews/addrbook/public/../../../../mailnews/addrbook/public/nsIAbMDBCard.idl
 */

#ifndef __gen_nsIAbMDBCard_h__
#define __gen_nsIAbMDBCard_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAddrDatabase; /* forward declaration */


/* starting interface:    nsIAbMDBCard */
#define NS_IABMDBCARD_IID_STR "5f414a80-1dd2-11b2-aad0-aa4a15d5a1e8"

#define NS_IABMDBCARD_IID \
  {0x5f414a80, 0x1dd2, 0x11b2, \
    { 0xaa, 0xd0, 0xaa, 0x4a, 0x15, 0xd5, 0xa1, 0xe8 }}

class NS_NO_VTABLE nsIAbMDBCard : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABMDBCARD_IID)

  /* attribute unsigned long key; */
  NS_IMETHOD GetKey(PRUint32 *aKey) = 0;
  NS_IMETHOD SetKey(PRUint32 aKey) = 0;

  /* attribute unsigned long dbTableID; */
  NS_IMETHOD GetDbTableID(PRUint32 *aDbTableID) = 0;
  NS_IMETHOD SetDbTableID(PRUint32 aDbTableID) = 0;

  /* attribute unsigned long dbRowID; */
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID) = 0;
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID) = 0;

  /* void setAbDatabase (in nsIAddrDatabase database); */
  NS_IMETHOD SetAbDatabase(nsIAddrDatabase *database) = 0;

  /* void copyCard (in nsIAbMDBCard srcCardDB); */
  NS_IMETHOD CopyCard(nsIAbMDBCard *srcCardDB) = 0;

  /* wstring getStringAttribute (in string name); */
  NS_IMETHOD GetStringAttribute(const char *name, PRUnichar **_retval) = 0;

  /* void setStringAttribute (in string name, in wstring value); */
  NS_IMETHOD SetStringAttribute(const char *name, const PRUnichar *value) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABMDBCARD \
  NS_IMETHOD GetKey(PRUint32 *aKey); \
  NS_IMETHOD SetKey(PRUint32 aKey); \
  NS_IMETHOD GetDbTableID(PRUint32 *aDbTableID); \
  NS_IMETHOD SetDbTableID(PRUint32 aDbTableID); \
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID); \
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID); \
  NS_IMETHOD SetAbDatabase(nsIAddrDatabase *database); \
  NS_IMETHOD CopyCard(nsIAbMDBCard *srcCardDB); \
  NS_IMETHOD GetStringAttribute(const char *name, PRUnichar **_retval); \
  NS_IMETHOD SetStringAttribute(const char *name, const PRUnichar *value); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABMDBCARD(_to) \
  NS_IMETHOD GetKey(PRUint32 *aKey) { return _to GetKey(aKey); } \
  NS_IMETHOD SetKey(PRUint32 aKey) { return _to SetKey(aKey); } \
  NS_IMETHOD GetDbTableID(PRUint32 *aDbTableID) { return _to GetDbTableID(aDbTableID); } \
  NS_IMETHOD SetDbTableID(PRUint32 aDbTableID) { return _to SetDbTableID(aDbTableID); } \
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID) { return _to GetDbRowID(aDbRowID); } \
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID) { return _to SetDbRowID(aDbRowID); } \
  NS_IMETHOD SetAbDatabase(nsIAddrDatabase *database) { return _to SetAbDatabase(database); } \
  NS_IMETHOD CopyCard(nsIAbMDBCard *srcCardDB) { return _to CopyCard(srcCardDB); } \
  NS_IMETHOD GetStringAttribute(const char *name, PRUnichar **_retval) { return _to GetStringAttribute(name, _retval); } \
  NS_IMETHOD SetStringAttribute(const char *name, const PRUnichar *value) { return _to SetStringAttribute(name, value); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABMDBCARD(_to) \
  NS_IMETHOD GetKey(PRUint32 *aKey) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetKey(aKey); } \
  NS_IMETHOD SetKey(PRUint32 aKey) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetKey(aKey); } \
  NS_IMETHOD GetDbTableID(PRUint32 *aDbTableID) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDbTableID(aDbTableID); } \
  NS_IMETHOD SetDbTableID(PRUint32 aDbTableID) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDbTableID(aDbTableID); } \
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDbRowID(aDbRowID); } \
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDbRowID(aDbRowID); } \
  NS_IMETHOD SetAbDatabase(nsIAddrDatabase *database) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAbDatabase(database); } \
  NS_IMETHOD CopyCard(nsIAbMDBCard *srcCardDB) { return !_to ? NS_ERROR_NULL_POINTER : _to->CopyCard(srcCardDB); } \
  NS_IMETHOD GetStringAttribute(const char *name, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetStringAttribute(name, _retval); } \
  NS_IMETHOD SetStringAttribute(const char *name, const PRUnichar *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetStringAttribute(name, value); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbMDBCard : public nsIAbMDBCard
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABMDBCARD

  nsAbMDBCard();

private:
  ~nsAbMDBCard();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbMDBCard, nsIAbMDBCard)

nsAbMDBCard::nsAbMDBCard()
{
  /* member initializers and constructor code */
}

nsAbMDBCard::~nsAbMDBCard()
{
  /* destructor code */
}

/* attribute unsigned long key; */
NS_IMETHODIMP nsAbMDBCard::GetKey(PRUint32 *aKey)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbMDBCard::SetKey(PRUint32 aKey)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long dbTableID; */
NS_IMETHODIMP nsAbMDBCard::GetDbTableID(PRUint32 *aDbTableID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbMDBCard::SetDbTableID(PRUint32 aDbTableID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long dbRowID; */
NS_IMETHODIMP nsAbMDBCard::GetDbRowID(PRUint32 *aDbRowID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbMDBCard::SetDbRowID(PRUint32 aDbRowID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setAbDatabase (in nsIAddrDatabase database); */
NS_IMETHODIMP nsAbMDBCard::SetAbDatabase(nsIAddrDatabase *database)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copyCard (in nsIAbMDBCard srcCardDB); */
NS_IMETHODIMP nsAbMDBCard::CopyCard(nsIAbMDBCard *srcCardDB)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring getStringAttribute (in string name); */
NS_IMETHODIMP nsAbMDBCard::GetStringAttribute(const char *name, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setStringAttribute (in string name, in wstring value); */
NS_IMETHODIMP nsAbMDBCard::SetStringAttribute(const char *name, const PRUnichar *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbMDBCard_h__ */
