/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/mailnews/addrbook/public/../../../../mailnews/addrbook/public/nsIAbMDBDirectory.idl
 */

#ifndef __gen_nsIAbMDBDirectory_h__
#define __gen_nsIAbMDBDirectory_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAbCard_h__
#include "nsIAbCard.h"
#endif

#ifndef __gen_nsIAbDirectory_h__
#include "nsIAbDirectory.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbMDBDirectory */
#define NS_IABMDBDIRECTORY_IID_STR "08669294-66c6-414e-ae2d-69348a62f362"

#define NS_IABMDBDIRECTORY_IID \
  {0x08669294, 0x66c6, 0x414e, \
    { 0xae, 0x2d, 0x69, 0x34, 0x8a, 0x62, 0xf3, 0x62 }}

class NS_NO_VTABLE nsIAbMDBDirectory : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABMDBDIRECTORY_IID)

  /* nsIAbDirectory addDirectory (in string uriName); */
  NS_IMETHOD AddDirectory(const char *uriName, nsIAbDirectory **_retval) = 0;

  /* string getDirUri (); */
  NS_IMETHOD GetDirUri(char **_retval) = 0;

  /* [noscript] void removeElementsFromAddressList (); */
  NS_IMETHOD RemoveElementsFromAddressList(void) = 0;

  /* void addMailListToDirectory (in nsIAbDirectory mailList); */
  NS_IMETHOD AddMailListToDirectory(nsIAbDirectory *mailList) = 0;

  /* void copyDBMailList (in nsIAbMDBDirectory srcListDB); */
  NS_IMETHOD CopyDBMailList(nsIAbMDBDirectory *srcListDB) = 0;

  /* void addAddressToList (in nsIAbCard card); */
  NS_IMETHOD AddAddressToList(nsIAbCard *card) = 0;

  /* void removeEmailAddressAt (in unsigned long aIndex); */
  NS_IMETHOD RemoveEmailAddressAt(PRUint32 aIndex) = 0;

  /* attribute unsigned long dbRowID; */
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID) = 0;
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID) = 0;

  /* [noscript] void notifyDirItemAdded (in nsISupports item); */
  NS_IMETHOD NotifyDirItemAdded(nsISupports *item) = 0;

  /* [noscript] void clearDatabase (); */
  NS_IMETHOD ClearDatabase(void) = 0;

  /* boolean hasCardForEmailAddress (in string emailAddress); */
  NS_IMETHOD HasCardForEmailAddress(const char *emailAddress, PRBool *_retval) = 0;

  /** 
   * returns the address card for the specified email address. Returns NULL if 
   * we were unable to find a card for the specified e-mail address
   */
  /* nsIAbCard cardForEmailAddress (in string emailAddress); */
  NS_IMETHOD CardForEmailAddress(const char *emailAddress, nsIAbCard **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABMDBDIRECTORY \
  NS_IMETHOD AddDirectory(const char *uriName, nsIAbDirectory **_retval); \
  NS_IMETHOD GetDirUri(char **_retval); \
  NS_IMETHOD RemoveElementsFromAddressList(void); \
  NS_IMETHOD AddMailListToDirectory(nsIAbDirectory *mailList); \
  NS_IMETHOD CopyDBMailList(nsIAbMDBDirectory *srcListDB); \
  NS_IMETHOD AddAddressToList(nsIAbCard *card); \
  NS_IMETHOD RemoveEmailAddressAt(PRUint32 aIndex); \
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID); \
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID); \
  NS_IMETHOD NotifyDirItemAdded(nsISupports *item); \
  NS_IMETHOD ClearDatabase(void); \
  NS_IMETHOD HasCardForEmailAddress(const char *emailAddress, PRBool *_retval); \
  NS_IMETHOD CardForEmailAddress(const char *emailAddress, nsIAbCard **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABMDBDIRECTORY(_to) \
  NS_IMETHOD AddDirectory(const char *uriName, nsIAbDirectory **_retval) { return _to AddDirectory(uriName, _retval); } \
  NS_IMETHOD GetDirUri(char **_retval) { return _to GetDirUri(_retval); } \
  NS_IMETHOD RemoveElementsFromAddressList(void) { return _to RemoveElementsFromAddressList(); } \
  NS_IMETHOD AddMailListToDirectory(nsIAbDirectory *mailList) { return _to AddMailListToDirectory(mailList); } \
  NS_IMETHOD CopyDBMailList(nsIAbMDBDirectory *srcListDB) { return _to CopyDBMailList(srcListDB); } \
  NS_IMETHOD AddAddressToList(nsIAbCard *card) { return _to AddAddressToList(card); } \
  NS_IMETHOD RemoveEmailAddressAt(PRUint32 aIndex) { return _to RemoveEmailAddressAt(aIndex); } \
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID) { return _to GetDbRowID(aDbRowID); } \
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID) { return _to SetDbRowID(aDbRowID); } \
  NS_IMETHOD NotifyDirItemAdded(nsISupports *item) { return _to NotifyDirItemAdded(item); } \
  NS_IMETHOD ClearDatabase(void) { return _to ClearDatabase(); } \
  NS_IMETHOD HasCardForEmailAddress(const char *emailAddress, PRBool *_retval) { return _to HasCardForEmailAddress(emailAddress, _retval); } \
  NS_IMETHOD CardForEmailAddress(const char *emailAddress, nsIAbCard **_retval) { return _to CardForEmailAddress(emailAddress, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABMDBDIRECTORY(_to) \
  NS_IMETHOD AddDirectory(const char *uriName, nsIAbDirectory **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddDirectory(uriName, _retval); } \
  NS_IMETHOD GetDirUri(char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDirUri(_retval); } \
  NS_IMETHOD RemoveElementsFromAddressList(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->RemoveElementsFromAddressList(); } \
  NS_IMETHOD AddMailListToDirectory(nsIAbDirectory *mailList) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddMailListToDirectory(mailList); } \
  NS_IMETHOD CopyDBMailList(nsIAbMDBDirectory *srcListDB) { return !_to ? NS_ERROR_NULL_POINTER : _to->CopyDBMailList(srcListDB); } \
  NS_IMETHOD AddAddressToList(nsIAbCard *card) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddAddressToList(card); } \
  NS_IMETHOD RemoveEmailAddressAt(PRUint32 aIndex) { return !_to ? NS_ERROR_NULL_POINTER : _to->RemoveEmailAddressAt(aIndex); } \
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDbRowID(aDbRowID); } \
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDbRowID(aDbRowID); } \
  NS_IMETHOD NotifyDirItemAdded(nsISupports *item) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyDirItemAdded(item); } \
  NS_IMETHOD ClearDatabase(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->ClearDatabase(); } \
  NS_IMETHOD HasCardForEmailAddress(const char *emailAddress, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->HasCardForEmailAddress(emailAddress, _retval); } \
  NS_IMETHOD CardForEmailAddress(const char *emailAddress, nsIAbCard **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CardForEmailAddress(emailAddress, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbMDBDirectory : public nsIAbMDBDirectory
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABMDBDIRECTORY

  nsAbMDBDirectory();

private:
  ~nsAbMDBDirectory();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbMDBDirectory, nsIAbMDBDirectory)

nsAbMDBDirectory::nsAbMDBDirectory()
{
  /* member initializers and constructor code */
}

nsAbMDBDirectory::~nsAbMDBDirectory()
{
  /* destructor code */
}

/* nsIAbDirectory addDirectory (in string uriName); */
NS_IMETHODIMP nsAbMDBDirectory::AddDirectory(const char *uriName, nsIAbDirectory **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* string getDirUri (); */
NS_IMETHODIMP nsAbMDBDirectory::GetDirUri(char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void removeElementsFromAddressList (); */
NS_IMETHODIMP nsAbMDBDirectory::RemoveElementsFromAddressList()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void addMailListToDirectory (in nsIAbDirectory mailList); */
NS_IMETHODIMP nsAbMDBDirectory::AddMailListToDirectory(nsIAbDirectory *mailList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copyDBMailList (in nsIAbMDBDirectory srcListDB); */
NS_IMETHODIMP nsAbMDBDirectory::CopyDBMailList(nsIAbMDBDirectory *srcListDB)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void addAddressToList (in nsIAbCard card); */
NS_IMETHODIMP nsAbMDBDirectory::AddAddressToList(nsIAbCard *card)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void removeEmailAddressAt (in unsigned long aIndex); */
NS_IMETHODIMP nsAbMDBDirectory::RemoveEmailAddressAt(PRUint32 aIndex)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long dbRowID; */
NS_IMETHODIMP nsAbMDBDirectory::GetDbRowID(PRUint32 *aDbRowID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbMDBDirectory::SetDbRowID(PRUint32 aDbRowID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void notifyDirItemAdded (in nsISupports item); */
NS_IMETHODIMP nsAbMDBDirectory::NotifyDirItemAdded(nsISupports *item)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void clearDatabase (); */
NS_IMETHODIMP nsAbMDBDirectory::ClearDatabase()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean hasCardForEmailAddress (in string emailAddress); */
NS_IMETHODIMP nsAbMDBDirectory::HasCardForEmailAddress(const char *emailAddress, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAbCard cardForEmailAddress (in string emailAddress); */
NS_IMETHODIMP nsAbMDBDirectory::CardForEmailAddress(const char *emailAddress, nsIAbCard **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbMDBDirectory_h__ */
