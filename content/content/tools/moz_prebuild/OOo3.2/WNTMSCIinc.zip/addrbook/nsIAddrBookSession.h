/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/mailnews/addrbook/public/../../../../mailnews/addrbook/public/nsIAddrBookSession.idl
 */

#ifndef __gen_nsIAddrBookSession_h__
#define __gen_nsIAddrBookSession_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAbListener_h__
#include "nsIAbListener.h"
#endif

#ifndef __gen_nsIAbDirectory_h__
#include "nsIAbDirectory.h"
#endif

#ifndef __gen_nsIAbCard_h__
#include "nsIAbCard.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsILocalFile; /* forward declaration */


/* starting interface:    nsIAddrBookSession */
#define NS_IADDRBOOKSESSION_IID_STR "90533607-7205-473f-b688-ffb50eeb5d57"

#define NS_IADDRBOOKSESSION_IID \
  {0x90533607, 0x7205, 0x473f, \
    { 0xb6, 0x88, 0xff, 0xb5, 0x0e, 0xeb, 0x5d, 0x57 }}

class NS_NO_VTABLE nsIAddrBookSession : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IADDRBOOKSESSION_IID)

  /**
   * Adds a nsIAbListener to receive notifications of address book updates
   * according to the specified notifyFlags.
   *
   * @param  listener     The listener that is to receive updates.
   *
   * @param  notifyFlags  A bitwise-or of abListenerNotifyFlagValue items
   *                       specifying which notifications to receive.
   *
   */
  /* void addAddressBookListener (in nsIAbListener listener, in abListenerNotifyFlagValue notifyFlags); */
  NS_IMETHOD AddAddressBookListener(nsIAbListener *listener, abListenerNotifyFlagValue notifyFlags) = 0;

  /**
   * These flags specify when to receive notifications of address book updates
   * to be passed to addAddressBookListener.
   */
/**
   * An address book, mailing list or card is added.
   */
  enum { added = 1U };

  /**
   * A mailing list or card is removed from an address book.
   */
  enum { directoryItemRemoved = 2U };

  /**
   * An address book is removed
   */
  enum { directoryRemoved = 4U };

  /**
   * An address book, mailing list or card is changed.
   */
  enum { changed = 8U };

  /**
   * All of the above notifications are to be received.
   */
  enum { all = 4294967295U };

  /**
   * Removes a nsIAbListener from receive notifications of address book
   * updates.
   *
   * @param  listener     The listener that is to no longer receive updates.
   *
   */
  /* void removeAddressBookListener (in nsIAbListener listener); */
  NS_IMETHOD RemoveAddressBookListener(nsIAbListener *listener) = 0;

  /* void notifyItemPropertyChanged (in nsISupports item, in string property, in wstring oldValue, in wstring newValue); */
  NS_IMETHOD NotifyItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue) = 0;

  /* void notifyDirectoryItemAdded (in nsIAbDirectory directory, in nsISupports item); */
  NS_IMETHOD NotifyDirectoryItemAdded(nsIAbDirectory *directory, nsISupports *item) = 0;

  /**
   * when a card is deleted 
   */
  /* void notifyDirectoryItemDeleted (in nsIAbDirectory directory, in nsISupports item); */
  NS_IMETHOD NotifyDirectoryItemDeleted(nsIAbDirectory *directory, nsISupports *item) = 0;

  /**
   * when a directory is deleted 
   */
  /* void notifyDirectoryDeleted (in nsIAbDirectory directory, in nsISupports item); */
  NS_IMETHOD NotifyDirectoryDeleted(nsIAbDirectory *directory, nsISupports *item) = 0;

  /* readonly attribute nsILocalFile userProfileDirectory; */
  NS_IMETHOD GetUserProfileDirectory(nsILocalFile * *aUserProfileDirectory) = 0;

  /** 
   * generate the name from the card, using the firstName and lastName and the displayName
   *
   * format follows the "mail.addr_book.lastnamefirst" pref values
   *
   * 0 = generated name is displayName
   * 1 = lastFirst, formatted following lastFirstFormat (see addressBook.properties)
   * 2 = firstLast, formatted following firstLastFormat (see addressBook.properties)
   *
   * we allow the caller to cache the pref value, so we don't have to go to prefs every time.
   */
  /* wstring generateNameFromCard (in nsIAbCard card, in long generateFormat); */
  NS_IMETHOD GenerateNameFromCard(nsIAbCard *card, PRInt32 generateFormat, PRUnichar **_retval) = 0;

  /** 
   * generate the phonetic name from the card, using the firstName and lastName
   *
   */
  /* wstring generatePhoneticNameFromCard (in nsIAbCard aCard, in boolean aLastNameFirst); */
  NS_IMETHOD GeneratePhoneticNameFromCard(nsIAbCard *aCard, PRBool aLastNameFirst, PRUnichar **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIADDRBOOKSESSION \
  NS_IMETHOD AddAddressBookListener(nsIAbListener *listener, abListenerNotifyFlagValue notifyFlags); \
  NS_IMETHOD RemoveAddressBookListener(nsIAbListener *listener); \
  NS_IMETHOD NotifyItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue); \
  NS_IMETHOD NotifyDirectoryItemAdded(nsIAbDirectory *directory, nsISupports *item); \
  NS_IMETHOD NotifyDirectoryItemDeleted(nsIAbDirectory *directory, nsISupports *item); \
  NS_IMETHOD NotifyDirectoryDeleted(nsIAbDirectory *directory, nsISupports *item); \
  NS_IMETHOD GetUserProfileDirectory(nsILocalFile * *aUserProfileDirectory); \
  NS_IMETHOD GenerateNameFromCard(nsIAbCard *card, PRInt32 generateFormat, PRUnichar **_retval); \
  NS_IMETHOD GeneratePhoneticNameFromCard(nsIAbCard *aCard, PRBool aLastNameFirst, PRUnichar **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIADDRBOOKSESSION(_to) \
  NS_IMETHOD AddAddressBookListener(nsIAbListener *listener, abListenerNotifyFlagValue notifyFlags) { return _to AddAddressBookListener(listener, notifyFlags); } \
  NS_IMETHOD RemoveAddressBookListener(nsIAbListener *listener) { return _to RemoveAddressBookListener(listener); } \
  NS_IMETHOD NotifyItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue) { return _to NotifyItemPropertyChanged(item, property, oldValue, newValue); } \
  NS_IMETHOD NotifyDirectoryItemAdded(nsIAbDirectory *directory, nsISupports *item) { return _to NotifyDirectoryItemAdded(directory, item); } \
  NS_IMETHOD NotifyDirectoryItemDeleted(nsIAbDirectory *directory, nsISupports *item) { return _to NotifyDirectoryItemDeleted(directory, item); } \
  NS_IMETHOD NotifyDirectoryDeleted(nsIAbDirectory *directory, nsISupports *item) { return _to NotifyDirectoryDeleted(directory, item); } \
  NS_IMETHOD GetUserProfileDirectory(nsILocalFile * *aUserProfileDirectory) { return _to GetUserProfileDirectory(aUserProfileDirectory); } \
  NS_IMETHOD GenerateNameFromCard(nsIAbCard *card, PRInt32 generateFormat, PRUnichar **_retval) { return _to GenerateNameFromCard(card, generateFormat, _retval); } \
  NS_IMETHOD GeneratePhoneticNameFromCard(nsIAbCard *aCard, PRBool aLastNameFirst, PRUnichar **_retval) { return _to GeneratePhoneticNameFromCard(aCard, aLastNameFirst, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIADDRBOOKSESSION(_to) \
  NS_IMETHOD AddAddressBookListener(nsIAbListener *listener, abListenerNotifyFlagValue notifyFlags) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddAddressBookListener(listener, notifyFlags); } \
  NS_IMETHOD RemoveAddressBookListener(nsIAbListener *listener) { return !_to ? NS_ERROR_NULL_POINTER : _to->RemoveAddressBookListener(listener); } \
  NS_IMETHOD NotifyItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyItemPropertyChanged(item, property, oldValue, newValue); } \
  NS_IMETHOD NotifyDirectoryItemAdded(nsIAbDirectory *directory, nsISupports *item) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyDirectoryItemAdded(directory, item); } \
  NS_IMETHOD NotifyDirectoryItemDeleted(nsIAbDirectory *directory, nsISupports *item) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyDirectoryItemDeleted(directory, item); } \
  NS_IMETHOD NotifyDirectoryDeleted(nsIAbDirectory *directory, nsISupports *item) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyDirectoryDeleted(directory, item); } \
  NS_IMETHOD GetUserProfileDirectory(nsILocalFile * *aUserProfileDirectory) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetUserProfileDirectory(aUserProfileDirectory); } \
  NS_IMETHOD GenerateNameFromCard(nsIAbCard *card, PRInt32 generateFormat, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GenerateNameFromCard(card, generateFormat, _retval); } \
  NS_IMETHOD GeneratePhoneticNameFromCard(nsIAbCard *aCard, PRBool aLastNameFirst, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GeneratePhoneticNameFromCard(aCard, aLastNameFirst, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAddrBookSession : public nsIAddrBookSession
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIADDRBOOKSESSION

  nsAddrBookSession();

private:
  ~nsAddrBookSession();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAddrBookSession, nsIAddrBookSession)

nsAddrBookSession::nsAddrBookSession()
{
  /* member initializers and constructor code */
}

nsAddrBookSession::~nsAddrBookSession()
{
  /* destructor code */
}

/* void addAddressBookListener (in nsIAbListener listener, in abListenerNotifyFlagValue notifyFlags); */
NS_IMETHODIMP nsAddrBookSession::AddAddressBookListener(nsIAbListener *listener, abListenerNotifyFlagValue notifyFlags)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void removeAddressBookListener (in nsIAbListener listener); */
NS_IMETHODIMP nsAddrBookSession::RemoveAddressBookListener(nsIAbListener *listener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void notifyItemPropertyChanged (in nsISupports item, in string property, in wstring oldValue, in wstring newValue); */
NS_IMETHODIMP nsAddrBookSession::NotifyItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void notifyDirectoryItemAdded (in nsIAbDirectory directory, in nsISupports item); */
NS_IMETHODIMP nsAddrBookSession::NotifyDirectoryItemAdded(nsIAbDirectory *directory, nsISupports *item)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void notifyDirectoryItemDeleted (in nsIAbDirectory directory, in nsISupports item); */
NS_IMETHODIMP nsAddrBookSession::NotifyDirectoryItemDeleted(nsIAbDirectory *directory, nsISupports *item)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void notifyDirectoryDeleted (in nsIAbDirectory directory, in nsISupports item); */
NS_IMETHODIMP nsAddrBookSession::NotifyDirectoryDeleted(nsIAbDirectory *directory, nsISupports *item)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsILocalFile userProfileDirectory; */
NS_IMETHODIMP nsAddrBookSession::GetUserProfileDirectory(nsILocalFile * *aUserProfileDirectory)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring generateNameFromCard (in nsIAbCard card, in long generateFormat); */
NS_IMETHODIMP nsAddrBookSession::GenerateNameFromCard(nsIAbCard *card, PRInt32 generateFormat, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring generatePhoneticNameFromCard (in nsIAbCard aCard, in boolean aLastNameFirst); */
NS_IMETHODIMP nsAddrBookSession::GeneratePhoneticNameFromCard(nsIAbCard *aCard, PRBool aLastNameFirst, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAddrBookSession_h__ */
