/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/mailnews/addrbook/public/../../../../mailnews/addrbook/public/nsIAbView.idl
 */

#ifndef __gen_nsIAbView_h__
#define __gen_nsIAbView_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsISupportsArray_h__
#include "nsISupportsArray.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAbCard; /* forward declaration */

class nsIAbDirectory; /* forward declaration */


/* starting interface:    nsIAbViewListener */
#define NS_IABVIEWLISTENER_IID_STR "79ad5d6e-1dd2-11b2-addd-f547dab50d75"

#define NS_IABVIEWLISTENER_IID \
  {0x79ad5d6e, 0x1dd2, 0x11b2, \
    { 0xad, 0xdd, 0xf5, 0x47, 0xda, 0xb5, 0x0d, 0x75 }}

class NS_NO_VTABLE nsIAbViewListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABVIEWLISTENER_IID)

  /* void onSelectionChanged (); */
  NS_IMETHOD OnSelectionChanged(void) = 0;

  /* void onCountChanged (in long total); */
  NS_IMETHOD OnCountChanged(PRInt32 total) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABVIEWLISTENER \
  NS_IMETHOD OnSelectionChanged(void); \
  NS_IMETHOD OnCountChanged(PRInt32 total); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABVIEWLISTENER(_to) \
  NS_IMETHOD OnSelectionChanged(void) { return _to OnSelectionChanged(); } \
  NS_IMETHOD OnCountChanged(PRInt32 total) { return _to OnCountChanged(total); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABVIEWLISTENER(_to) \
  NS_IMETHOD OnSelectionChanged(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnSelectionChanged(); } \
  NS_IMETHOD OnCountChanged(PRInt32 total) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnCountChanged(total); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbViewListener : public nsIAbViewListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABVIEWLISTENER

  nsAbViewListener();

private:
  ~nsAbViewListener();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbViewListener, nsIAbViewListener)

nsAbViewListener::nsAbViewListener()
{
  /* member initializers and constructor code */
}

nsAbViewListener::~nsAbViewListener()
{
  /* destructor code */
}

/* void onSelectionChanged (); */
NS_IMETHODIMP nsAbViewListener::OnSelectionChanged()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onCountChanged (in long total); */
NS_IMETHODIMP nsAbViewListener::OnCountChanged(PRInt32 total)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbView */
#define NS_IABVIEW_IID_STR "e35c015c-1dd1-11b2-9494-f88326252aae"

#define NS_IABVIEW_IID \
  {0xe35c015c, 0x1dd1, 0x11b2, \
    { 0x94, 0x94, 0xf8, 0x83, 0x26, 0x25, 0x2a, 0xae }}

class NS_NO_VTABLE nsIAbView : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABVIEW_IID)

  /**
     * returns the actual sortColumn.  migration, switching from mozilla 
     * to netscape 6.x, etc, could cause
     * the "persisted" sortColumn to be bogus.
     */
  /* wstring init (in string URI, in boolean aSearchView, in nsIAbViewListener abViewListener, in wstring sortColumn, in wstring sortDirection); */
  NS_IMETHOD Init(const char *URI, PRBool aSearchView, nsIAbViewListener *abViewListener, const PRUnichar *sortColumn, const PRUnichar *sortDirection, PRUnichar **_retval) = 0;

  /* void close (); */
  NS_IMETHOD Close(void) = 0;

  /**
     * sortBy does not optimize for the case when sortColumn and sortDirection
     * is identical since the last call, the caller is responsible optimizing
     * for that case
     */
  /* void sortBy (in wstring sortColumn, in wstring sortDirection); */
  NS_IMETHOD SortBy(const PRUnichar *sortColumn, const PRUnichar *sortDirection) = 0;

  /* readonly attribute string URI; */
  NS_IMETHOD GetURI(char * *aURI) = 0;

  /* readonly attribute AString sortColumn; */
  NS_IMETHOD GetSortColumn(nsAString & aSortColumn) = 0;

  /* readonly attribute AString sortDirection; */
  NS_IMETHOD GetSortDirection(nsAString & aSortDirection) = 0;

  /* readonly attribute nsIAbDirectory directory; */
  NS_IMETHOD GetDirectory(nsIAbDirectory * *aDirectory) = 0;

  /* nsIAbCard getCardFromRow (in long row); */
  NS_IMETHOD GetCardFromRow(PRInt32 row, nsIAbCard **_retval) = 0;

  /* void selectAll (); */
  NS_IMETHOD SelectAll(void) = 0;

  /* void deleteSelectedCards (); */
  NS_IMETHOD DeleteSelectedCards(void) = 0;

  /* void swapFirstNameLastName (); */
  NS_IMETHOD SwapFirstNameLastName(void) = 0;

  /* readonly attribute nsISupportsArray selectedAddresses; */
  NS_IMETHOD GetSelectedAddresses(nsISupportsArray * *aSelectedAddresses) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABVIEW \
  NS_IMETHOD Init(const char *URI, PRBool aSearchView, nsIAbViewListener *abViewListener, const PRUnichar *sortColumn, const PRUnichar *sortDirection, PRUnichar **_retval); \
  NS_IMETHOD Close(void); \
  NS_IMETHOD SortBy(const PRUnichar *sortColumn, const PRUnichar *sortDirection); \
  NS_IMETHOD GetURI(char * *aURI); \
  NS_IMETHOD GetSortColumn(nsAString & aSortColumn); \
  NS_IMETHOD GetSortDirection(nsAString & aSortDirection); \
  NS_IMETHOD GetDirectory(nsIAbDirectory * *aDirectory); \
  NS_IMETHOD GetCardFromRow(PRInt32 row, nsIAbCard **_retval); \
  NS_IMETHOD SelectAll(void); \
  NS_IMETHOD DeleteSelectedCards(void); \
  NS_IMETHOD SwapFirstNameLastName(void); \
  NS_IMETHOD GetSelectedAddresses(nsISupportsArray * *aSelectedAddresses); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABVIEW(_to) \
  NS_IMETHOD Init(const char *URI, PRBool aSearchView, nsIAbViewListener *abViewListener, const PRUnichar *sortColumn, const PRUnichar *sortDirection, PRUnichar **_retval) { return _to Init(URI, aSearchView, abViewListener, sortColumn, sortDirection, _retval); } \
  NS_IMETHOD Close(void) { return _to Close(); } \
  NS_IMETHOD SortBy(const PRUnichar *sortColumn, const PRUnichar *sortDirection) { return _to SortBy(sortColumn, sortDirection); } \
  NS_IMETHOD GetURI(char * *aURI) { return _to GetURI(aURI); } \
  NS_IMETHOD GetSortColumn(nsAString & aSortColumn) { return _to GetSortColumn(aSortColumn); } \
  NS_IMETHOD GetSortDirection(nsAString & aSortDirection) { return _to GetSortDirection(aSortDirection); } \
  NS_IMETHOD GetDirectory(nsIAbDirectory * *aDirectory) { return _to GetDirectory(aDirectory); } \
  NS_IMETHOD GetCardFromRow(PRInt32 row, nsIAbCard **_retval) { return _to GetCardFromRow(row, _retval); } \
  NS_IMETHOD SelectAll(void) { return _to SelectAll(); } \
  NS_IMETHOD DeleteSelectedCards(void) { return _to DeleteSelectedCards(); } \
  NS_IMETHOD SwapFirstNameLastName(void) { return _to SwapFirstNameLastName(); } \
  NS_IMETHOD GetSelectedAddresses(nsISupportsArray * *aSelectedAddresses) { return _to GetSelectedAddresses(aSelectedAddresses); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABVIEW(_to) \
  NS_IMETHOD Init(const char *URI, PRBool aSearchView, nsIAbViewListener *abViewListener, const PRUnichar *sortColumn, const PRUnichar *sortDirection, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->Init(URI, aSearchView, abViewListener, sortColumn, sortDirection, _retval); } \
  NS_IMETHOD Close(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->Close(); } \
  NS_IMETHOD SortBy(const PRUnichar *sortColumn, const PRUnichar *sortDirection) { return !_to ? NS_ERROR_NULL_POINTER : _to->SortBy(sortColumn, sortDirection); } \
  NS_IMETHOD GetURI(char * *aURI) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetURI(aURI); } \
  NS_IMETHOD GetSortColumn(nsAString & aSortColumn) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSortColumn(aSortColumn); } \
  NS_IMETHOD GetSortDirection(nsAString & aSortDirection) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSortDirection(aSortDirection); } \
  NS_IMETHOD GetDirectory(nsIAbDirectory * *aDirectory) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDirectory(aDirectory); } \
  NS_IMETHOD GetCardFromRow(PRInt32 row, nsIAbCard **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCardFromRow(row, _retval); } \
  NS_IMETHOD SelectAll(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectAll(); } \
  NS_IMETHOD DeleteSelectedCards(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeleteSelectedCards(); } \
  NS_IMETHOD SwapFirstNameLastName(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->SwapFirstNameLastName(); } \
  NS_IMETHOD GetSelectedAddresses(nsISupportsArray * *aSelectedAddresses) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSelectedAddresses(aSelectedAddresses); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbView : public nsIAbView
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABVIEW

  nsAbView();

private:
  ~nsAbView();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbView, nsIAbView)

nsAbView::nsAbView()
{
  /* member initializers and constructor code */
}

nsAbView::~nsAbView()
{
  /* destructor code */
}

/* wstring init (in string URI, in boolean aSearchView, in nsIAbViewListener abViewListener, in wstring sortColumn, in wstring sortDirection); */
NS_IMETHODIMP nsAbView::Init(const char *URI, PRBool aSearchView, nsIAbViewListener *abViewListener, const PRUnichar *sortColumn, const PRUnichar *sortDirection, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void close (); */
NS_IMETHODIMP nsAbView::Close()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void sortBy (in wstring sortColumn, in wstring sortDirection); */
NS_IMETHODIMP nsAbView::SortBy(const PRUnichar *sortColumn, const PRUnichar *sortDirection)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute string URI; */
NS_IMETHODIMP nsAbView::GetURI(char * *aURI)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute AString sortColumn; */
NS_IMETHODIMP nsAbView::GetSortColumn(nsAString & aSortColumn)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute AString sortDirection; */
NS_IMETHODIMP nsAbView::GetSortDirection(nsAString & aSortDirection)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsIAbDirectory directory; */
NS_IMETHODIMP nsAbView::GetDirectory(nsIAbDirectory * *aDirectory)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAbCard getCardFromRow (in long row); */
NS_IMETHODIMP nsAbView::GetCardFromRow(PRInt32 row, nsIAbCard **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void selectAll (); */
NS_IMETHODIMP nsAbView::SelectAll()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deleteSelectedCards (); */
NS_IMETHODIMP nsAbView::DeleteSelectedCards()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void swapFirstNameLastName (); */
NS_IMETHODIMP nsAbView::SwapFirstNameLastName()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsISupportsArray selectedAddresses; */
NS_IMETHODIMP nsAbView::GetSelectedAddresses(nsISupportsArray * *aSelectedAddresses)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbView_h__ */
