/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/mailnews/addrbook/public/../../../../mailnews/addrbook/public/nsIMsgVCardService.idl
 */

#ifndef __gen_nsIMsgVCardService_h__
#define __gen_nsIMsgVCardService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
#include "nsVCardObj.h"

/* starting interface:    nsIMsgVCardService */
#define NS_IMSGVCARDSERVICE_IID_STR "45539703-94b4-47fb-afd0-14dfe174899f"

#define NS_IMSGVCARDSERVICE_IID \
  {0x45539703, 0x94b4, 0x47fb, \
    { 0xaf, 0xd0, 0x14, 0xdf, 0xe1, 0x74, 0x89, 0x9f }}

class NS_NO_VTABLE nsIMsgVCardService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IMSGVCARDSERVICE_IID)

  /* [noscript, notxpcom] void cleanVObject (in VObject_ptr o); */
  NS_IMETHOD_(void) CleanVObject(VObject * o) = 0;

  /* [noscript, notxpcom] VObject_ptr nextVObjectInList (in VObject_ptr o); */
  NS_IMETHOD_(VObject *) NextVObjectInList(VObject * o) = 0;

  /* [noscript, notxpcom] VObject_ptr parse_MIME (in string input, in unsigned long len); */
  NS_IMETHOD_(VObject *) Parse_MIME(const char *input, PRUint32 len) = 0;

  /* [noscript, notxpcom] string fakeCString (in VObject_ptr o); */
  NS_IMETHOD_(char *) FakeCString(VObject * o) = 0;

  /* [noscript, notxpcom] VObject_ptr isAPropertyOf (in VObject_ptr o, in string id); */
  NS_IMETHOD_(VObject *) IsAPropertyOf(VObject * o, const char *id) = 0;

  /* [noscript, notxpcom] string writeMemoryVObjects (in string s, out long len, in VObject_ptr list, in boolean expandSpaces); */
  NS_IMETHOD_(char *) WriteMemoryVObjects(const char *s, PRInt32 *len, VObject * list, PRBool expandSpaces) = 0;

  /* [noscript, notxpcom] VObject_ptr nextVObject (in VObjectIterator_ptr i); */
  NS_IMETHOD_(VObject *) NextVObject(VObjectIterator * i) = 0;

  /* [noscript, notxpcom] void initPropIterator (in VObjectIterator_ptr i, in VObject_ptr o); */
  NS_IMETHOD_(void) InitPropIterator(VObjectIterator * i, VObject * o) = 0;

  /* [noscript, notxpcom] long moreIteration (in VObjectIterator_ptr i); */
  NS_IMETHOD_(PRInt32) MoreIteration(VObjectIterator * i) = 0;

  /* [noscript, notxpcom] const_char_ptr vObjectName (in VObject_ptr o); */
  NS_IMETHOD_(const char *) VObjectName(VObject * o) = 0;

  /* [noscript, notxpcom] string vObjectAnyValue (in VObject_ptr o); */
  NS_IMETHOD_(char *) VObjectAnyValue(VObject * o) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIMSGVCARDSERVICE \
  NS_IMETHOD_(void) CleanVObject(VObject * o); \
  NS_IMETHOD_(VObject *) NextVObjectInList(VObject * o); \
  NS_IMETHOD_(VObject *) Parse_MIME(const char *input, PRUint32 len); \
  NS_IMETHOD_(char *) FakeCString(VObject * o); \
  NS_IMETHOD_(VObject *) IsAPropertyOf(VObject * o, const char *id); \
  NS_IMETHOD_(char *) WriteMemoryVObjects(const char *s, PRInt32 *len, VObject * list, PRBool expandSpaces); \
  NS_IMETHOD_(VObject *) NextVObject(VObjectIterator * i); \
  NS_IMETHOD_(void) InitPropIterator(VObjectIterator * i, VObject * o); \
  NS_IMETHOD_(PRInt32) MoreIteration(VObjectIterator * i); \
  NS_IMETHOD_(const char *) VObjectName(VObject * o); \
  NS_IMETHOD_(char *) VObjectAnyValue(VObject * o); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIMSGVCARDSERVICE(_to) \
  NS_IMETHOD_(void) CleanVObject(VObject * o) { return _to CleanVObject(o); } \
  NS_IMETHOD_(VObject *) NextVObjectInList(VObject * o) { return _to NextVObjectInList(o); } \
  NS_IMETHOD_(VObject *) Parse_MIME(const char *input, PRUint32 len) { return _to Parse_MIME(input, len); } \
  NS_IMETHOD_(char *) FakeCString(VObject * o) { return _to FakeCString(o); } \
  NS_IMETHOD_(VObject *) IsAPropertyOf(VObject * o, const char *id) { return _to IsAPropertyOf(o, id); } \
  NS_IMETHOD_(char *) WriteMemoryVObjects(const char *s, PRInt32 *len, VObject * list, PRBool expandSpaces) { return _to WriteMemoryVObjects(s, len, list, expandSpaces); } \
  NS_IMETHOD_(VObject *) NextVObject(VObjectIterator * i) { return _to NextVObject(i); } \
  NS_IMETHOD_(void) InitPropIterator(VObjectIterator * i, VObject * o) { return _to InitPropIterator(i, o); } \
  NS_IMETHOD_(PRInt32) MoreIteration(VObjectIterator * i) { return _to MoreIteration(i); } \
  NS_IMETHOD_(const char *) VObjectName(VObject * o) { return _to VObjectName(o); } \
  NS_IMETHOD_(char *) VObjectAnyValue(VObject * o) { return _to VObjectAnyValue(o); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIMSGVCARDSERVICE(_to) \
  NS_IMETHOD_(void) CleanVObject(VObject * o) { return !_to ? NS_ERROR_NULL_POINTER : _to->CleanVObject(o); } \
  NS_IMETHOD_(VObject *) NextVObjectInList(VObject * o) { return !_to ? NS_ERROR_NULL_POINTER : _to->NextVObjectInList(o); } \
  NS_IMETHOD_(VObject *) Parse_MIME(const char *input, PRUint32 len) { return !_to ? NS_ERROR_NULL_POINTER : _to->Parse_MIME(input, len); } \
  NS_IMETHOD_(char *) FakeCString(VObject * o) { return !_to ? NS_ERROR_NULL_POINTER : _to->FakeCString(o); } \
  NS_IMETHOD_(VObject *) IsAPropertyOf(VObject * o, const char *id) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsAPropertyOf(o, id); } \
  NS_IMETHOD_(char *) WriteMemoryVObjects(const char *s, PRInt32 *len, VObject * list, PRBool expandSpaces) { return !_to ? NS_ERROR_NULL_POINTER : _to->WriteMemoryVObjects(s, len, list, expandSpaces); } \
  NS_IMETHOD_(VObject *) NextVObject(VObjectIterator * i) { return !_to ? NS_ERROR_NULL_POINTER : _to->NextVObject(i); } \
  NS_IMETHOD_(void) InitPropIterator(VObjectIterator * i, VObject * o) { return !_to ? NS_ERROR_NULL_POINTER : _to->InitPropIterator(i, o); } \
  NS_IMETHOD_(PRInt32) MoreIteration(VObjectIterator * i) { return !_to ? NS_ERROR_NULL_POINTER : _to->MoreIteration(i); } \
  NS_IMETHOD_(const char *) VObjectName(VObject * o) { return !_to ? NS_ERROR_NULL_POINTER : _to->VObjectName(o); } \
  NS_IMETHOD_(char *) VObjectAnyValue(VObject * o) { return !_to ? NS_ERROR_NULL_POINTER : _to->VObjectAnyValue(o); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsMsgVCardService : public nsIMsgVCardService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIMSGVCARDSERVICE

  nsMsgVCardService();

private:
  ~nsMsgVCardService();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsMsgVCardService, nsIMsgVCardService)

nsMsgVCardService::nsMsgVCardService()
{
  /* member initializers and constructor code */
}

nsMsgVCardService::~nsMsgVCardService()
{
  /* destructor code */
}

/* [noscript, notxpcom] void cleanVObject (in VObject_ptr o); */
NS_IMETHODIMP_(void) nsMsgVCardService::CleanVObject(VObject * o)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript, notxpcom] VObject_ptr nextVObjectInList (in VObject_ptr o); */
NS_IMETHODIMP_(VObject *) nsMsgVCardService::NextVObjectInList(VObject * o)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript, notxpcom] VObject_ptr parse_MIME (in string input, in unsigned long len); */
NS_IMETHODIMP_(VObject *) nsMsgVCardService::Parse_MIME(const char *input, PRUint32 len)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript, notxpcom] string fakeCString (in VObject_ptr o); */
NS_IMETHODIMP_(char *) nsMsgVCardService::FakeCString(VObject * o)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript, notxpcom] VObject_ptr isAPropertyOf (in VObject_ptr o, in string id); */
NS_IMETHODIMP_(VObject *) nsMsgVCardService::IsAPropertyOf(VObject * o, const char *id)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript, notxpcom] string writeMemoryVObjects (in string s, out long len, in VObject_ptr list, in boolean expandSpaces); */
NS_IMETHODIMP_(char *) nsMsgVCardService::WriteMemoryVObjects(const char *s, PRInt32 *len, VObject * list, PRBool expandSpaces)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript, notxpcom] VObject_ptr nextVObject (in VObjectIterator_ptr i); */
NS_IMETHODIMP_(VObject *) nsMsgVCardService::NextVObject(VObjectIterator * i)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript, notxpcom] void initPropIterator (in VObjectIterator_ptr i, in VObject_ptr o); */
NS_IMETHODIMP_(void) nsMsgVCardService::InitPropIterator(VObjectIterator * i, VObject * o)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript, notxpcom] long moreIteration (in VObjectIterator_ptr i); */
NS_IMETHODIMP_(PRInt32) nsMsgVCardService::MoreIteration(VObjectIterator * i)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript, notxpcom] const_char_ptr vObjectName (in VObject_ptr o); */
NS_IMETHODIMP_(const char *) nsMsgVCardService::VObjectName(VObject * o)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript, notxpcom] string vObjectAnyValue (in VObject_ptr o); */
NS_IMETHODIMP_(char *) nsMsgVCardService::VObjectAnyValue(VObject * o)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIMsgVCardService_h__ */
