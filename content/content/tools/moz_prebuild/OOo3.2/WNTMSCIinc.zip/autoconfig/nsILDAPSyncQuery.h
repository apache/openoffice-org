/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/extensions/pref/autoconfig/public/../../../../../extensions/pref/autoconfig/public/nsILDAPSyncQuery.idl
 */

#ifndef __gen_nsILDAPSyncQuery_h__
#define __gen_nsILDAPSyncQuery_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsILDAPURL; /* forward declaration */


/* starting interface:    nsILDAPSyncQuery */
#define NS_ILDAPSYNCQUERY_IID_STR "0308fb36-1dd2-11b2-b16f-8510e8c5311a"

#define NS_ILDAPSYNCQUERY_IID \
  {0x0308fb36, 0x1dd2, 0x11b2, \
    { 0xb1, 0x6f, 0x85, 0x10, 0xe8, 0xc5, 0x31, 0x1a }}

class NS_NO_VTABLE nsILDAPSyncQuery : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ILDAPSYNCQUERY_IID)

  /**
   * getQueryResults
   *
   * Create a new LDAP connection do a synchronous LDAP search and return 
   * the results.
   * @param aServerURL - LDAP URL with parameters to a LDAP seach 
   *                     ("ldap://host/base?attributes?one/sub?filter")
   * @param aProtocolVersion - LDAP protocol version to use for connection
   *                           (nsILDAPConnection.idl has symbolic constants)
   * @return results
   */
  /* wstring getQueryResults (in nsILDAPURL aServerURL, in unsigned long aProtocolVersion); */
  NS_IMETHOD GetQueryResults(nsILDAPURL *aServerURL, PRUint32 aProtocolVersion, PRUnichar **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSILDAPSYNCQUERY \
  NS_IMETHOD GetQueryResults(nsILDAPURL *aServerURL, PRUint32 aProtocolVersion, PRUnichar **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSILDAPSYNCQUERY(_to) \
  NS_IMETHOD GetQueryResults(nsILDAPURL *aServerURL, PRUint32 aProtocolVersion, PRUnichar **_retval) { return _to GetQueryResults(aServerURL, aProtocolVersion, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSILDAPSYNCQUERY(_to) \
  NS_IMETHOD GetQueryResults(nsILDAPURL *aServerURL, PRUint32 aProtocolVersion, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetQueryResults(aServerURL, aProtocolVersion, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsLDAPSyncQuery : public nsILDAPSyncQuery
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSILDAPSYNCQUERY

  nsLDAPSyncQuery();

private:
  ~nsLDAPSyncQuery();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsLDAPSyncQuery, nsILDAPSyncQuery)

nsLDAPSyncQuery::nsLDAPSyncQuery()
{
  /* member initializers and constructor code */
}

nsLDAPSyncQuery::~nsLDAPSyncQuery()
{
  /* destructor code */
}

/* wstring getQueryResults (in nsILDAPURL aServerURL, in unsigned long aProtocolVersion); */
NS_IMETHODIMP nsLDAPSyncQuery::GetQueryResults(nsILDAPURL *aServerURL, PRUint32 aProtocolVersion, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsILDAPSyncQuery_h__ */
