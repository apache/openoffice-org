/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/rdf/chrome/public/../../../../rdf/chrome/public/nsIChromeRegistrySea.idl
 */

#ifndef __gen_nsIChromeRegistrySea_h__
#define __gen_nsIChromeRegistrySea_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIChromeRegistry_h__
#include "nsIChromeRegistry.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIChromeRegistrySea */
#define NS_ICHROMEREGISTRYSEA_IID_STR "382370d0-a7cd-47ae-aa4e-af74f5edf652"

#define NS_ICHROMEREGISTRYSEA_IID \
  {0x382370d0, 0xa7cd, 0x47ae, \
    { 0xaa, 0x4e, 0xaf, 0x74, 0xf5, 0xed, 0xf6, 0x52 }}

class NS_NO_VTABLE nsIChromeRegistrySea : public nsIXULChromeRegistry {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICHROMEREGISTRYSEA_IID)

  /* void selectSkin (in ACString skinName, in boolean useProfile); */
  NS_IMETHOD SelectSkin(const nsACString & skinName, PRBool useProfile) = 0;

  /* void selectLocale (in ACString localeName, in boolean useProfile); */
  NS_IMETHOD SelectLocale(const nsACString & localeName, PRBool useProfile) = 0;

  /* void deselectSkin (in ACString skinName, in boolean useProfile); */
  NS_IMETHOD DeselectSkin(const nsACString & skinName, PRBool useProfile) = 0;

  /* void deselectLocale (in ACString localeName, in boolean useProfile); */
  NS_IMETHOD DeselectLocale(const nsACString & localeName, PRBool useProfile) = 0;

  /* PRInt32 isSkinSelected (in ACString skinName, in boolean useProfile); */
  NS_IMETHOD IsSkinSelected(const nsACString & skinName, PRBool useProfile, PRInt32 *_retval) = 0;

  /* PRInt32 isLocaleSelected (in ACString localeName, in boolean useProfile); */
  NS_IMETHOD IsLocaleSelected(const nsACString & localeName, PRBool useProfile, PRInt32 *_retval) = 0;

  /* void selectLocaleForProfile (in ACString localeName, in wstring profilePath); */
  NS_IMETHOD SelectLocaleForProfile(const nsACString & localeName, const PRUnichar *profilePath) = 0;

  /* void selectSkinForProfile (in ACString skinName, in wstring profilePath); */
  NS_IMETHOD SelectSkinForProfile(const nsACString & skinName, const PRUnichar *profilePath) = 0;

  /* void setRuntimeProvider (in boolean runtimeProvider); */
  NS_IMETHOD SetRuntimeProvider(PRBool runtimeProvider) = 0;

  /* boolean checkThemeVersion (in ACString skinName); */
  NS_IMETHOD CheckThemeVersion(const nsACString & skinName, PRBool *_retval) = 0;

  /* boolean checkLocaleVersion (in ACString localeName); */
  NS_IMETHOD CheckLocaleVersion(const nsACString & localeName, PRBool *_retval) = 0;

  /* void selectSkinForPackage (in ACString skinName, in wstring packageName, in boolean useProfile); */
  NS_IMETHOD SelectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile) = 0;

  /* void selectLocaleForPackage (in ACString localeName, in wstring packageName, in boolean useProfile); */
  NS_IMETHOD SelectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile) = 0;

  /* void deselectSkinForPackage (in ACString skinName, in wstring packageName, in boolean useProfile); */
  NS_IMETHOD DeselectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile) = 0;

  /* void deselectLocaleForPackage (in ACString localeName, in wstring packageName, in boolean useProfile); */
  NS_IMETHOD DeselectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile) = 0;

  /* boolean isSkinSelectedForPackage (in ACString skinName, in wstring packageName, in boolean useProfile); */
  NS_IMETHOD IsSkinSelectedForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval) = 0;

  /* boolean isLocaleSelectedForPackage (in ACString localeName, in wstring packageName, in boolean useProfile); */
  NS_IMETHOD IsLocaleSelectedForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval) = 0;

  /* ACString getSelectedSkin (in ACString packageName); */
  NS_IMETHOD GetSelectedSkin(const nsACString & packageName, nsACString & _retval) = 0;

  /* void installSkin (in string baseURL, in boolean useProfile, in boolean allowScripts); */
  NS_IMETHOD InstallSkin(const char *baseURL, PRBool useProfile, PRBool allowScripts) = 0;

  /* void uninstallSkin (in ACString skinName, in boolean useProfile); */
  NS_IMETHOD UninstallSkin(const nsACString & skinName, PRBool useProfile) = 0;

  /* void installLocale (in string baseURL, in boolean useProfile); */
  NS_IMETHOD InstallLocale(const char *baseURL, PRBool useProfile) = 0;

  /* void uninstallLocale (in ACString localeName, in boolean useProfile); */
  NS_IMETHOD UninstallLocale(const nsACString & localeName, PRBool useProfile) = 0;

  /* void installPackage (in string baseURL, in boolean useProfile); */
  NS_IMETHOD InstallPackage(const char *baseURL, PRBool useProfile) = 0;

  /* void uninstallPackage (in ACString packageName, in boolean useProfile); */
  NS_IMETHOD UninstallPackage(const nsACString & packageName, PRBool useProfile) = 0;

  /* void setAllowOverlaysForPackage (in wstring packageName, in boolean allowOverlays); */
  NS_IMETHOD SetAllowOverlaysForPackage(const PRUnichar *packageName, PRBool allowOverlays) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICHROMEREGISTRYSEA \
  NS_IMETHOD SelectSkin(const nsACString & skinName, PRBool useProfile); \
  NS_IMETHOD SelectLocale(const nsACString & localeName, PRBool useProfile); \
  NS_IMETHOD DeselectSkin(const nsACString & skinName, PRBool useProfile); \
  NS_IMETHOD DeselectLocale(const nsACString & localeName, PRBool useProfile); \
  NS_IMETHOD IsSkinSelected(const nsACString & skinName, PRBool useProfile, PRInt32 *_retval); \
  NS_IMETHOD IsLocaleSelected(const nsACString & localeName, PRBool useProfile, PRInt32 *_retval); \
  NS_IMETHOD SelectLocaleForProfile(const nsACString & localeName, const PRUnichar *profilePath); \
  NS_IMETHOD SelectSkinForProfile(const nsACString & skinName, const PRUnichar *profilePath); \
  NS_IMETHOD SetRuntimeProvider(PRBool runtimeProvider); \
  NS_IMETHOD CheckThemeVersion(const nsACString & skinName, PRBool *_retval); \
  NS_IMETHOD CheckLocaleVersion(const nsACString & localeName, PRBool *_retval); \
  NS_IMETHOD SelectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile); \
  NS_IMETHOD SelectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile); \
  NS_IMETHOD DeselectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile); \
  NS_IMETHOD DeselectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile); \
  NS_IMETHOD IsSkinSelectedForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval); \
  NS_IMETHOD IsLocaleSelectedForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval); \
  NS_IMETHOD GetSelectedSkin(const nsACString & packageName, nsACString & _retval); \
  NS_IMETHOD InstallSkin(const char *baseURL, PRBool useProfile, PRBool allowScripts); \
  NS_IMETHOD UninstallSkin(const nsACString & skinName, PRBool useProfile); \
  NS_IMETHOD InstallLocale(const char *baseURL, PRBool useProfile); \
  NS_IMETHOD UninstallLocale(const nsACString & localeName, PRBool useProfile); \
  NS_IMETHOD InstallPackage(const char *baseURL, PRBool useProfile); \
  NS_IMETHOD UninstallPackage(const nsACString & packageName, PRBool useProfile); \
  NS_IMETHOD SetAllowOverlaysForPackage(const PRUnichar *packageName, PRBool allowOverlays); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICHROMEREGISTRYSEA(_to) \
  NS_IMETHOD SelectSkin(const nsACString & skinName, PRBool useProfile) { return _to SelectSkin(skinName, useProfile); } \
  NS_IMETHOD SelectLocale(const nsACString & localeName, PRBool useProfile) { return _to SelectLocale(localeName, useProfile); } \
  NS_IMETHOD DeselectSkin(const nsACString & skinName, PRBool useProfile) { return _to DeselectSkin(skinName, useProfile); } \
  NS_IMETHOD DeselectLocale(const nsACString & localeName, PRBool useProfile) { return _to DeselectLocale(localeName, useProfile); } \
  NS_IMETHOD IsSkinSelected(const nsACString & skinName, PRBool useProfile, PRInt32 *_retval) { return _to IsSkinSelected(skinName, useProfile, _retval); } \
  NS_IMETHOD IsLocaleSelected(const nsACString & localeName, PRBool useProfile, PRInt32 *_retval) { return _to IsLocaleSelected(localeName, useProfile, _retval); } \
  NS_IMETHOD SelectLocaleForProfile(const nsACString & localeName, const PRUnichar *profilePath) { return _to SelectLocaleForProfile(localeName, profilePath); } \
  NS_IMETHOD SelectSkinForProfile(const nsACString & skinName, const PRUnichar *profilePath) { return _to SelectSkinForProfile(skinName, profilePath); } \
  NS_IMETHOD SetRuntimeProvider(PRBool runtimeProvider) { return _to SetRuntimeProvider(runtimeProvider); } \
  NS_IMETHOD CheckThemeVersion(const nsACString & skinName, PRBool *_retval) { return _to CheckThemeVersion(skinName, _retval); } \
  NS_IMETHOD CheckLocaleVersion(const nsACString & localeName, PRBool *_retval) { return _to CheckLocaleVersion(localeName, _retval); } \
  NS_IMETHOD SelectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile) { return _to SelectSkinForPackage(skinName, packageName, useProfile); } \
  NS_IMETHOD SelectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile) { return _to SelectLocaleForPackage(localeName, packageName, useProfile); } \
  NS_IMETHOD DeselectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile) { return _to DeselectSkinForPackage(skinName, packageName, useProfile); } \
  NS_IMETHOD DeselectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile) { return _to DeselectLocaleForPackage(localeName, packageName, useProfile); } \
  NS_IMETHOD IsSkinSelectedForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval) { return _to IsSkinSelectedForPackage(skinName, packageName, useProfile, _retval); } \
  NS_IMETHOD IsLocaleSelectedForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval) { return _to IsLocaleSelectedForPackage(localeName, packageName, useProfile, _retval); } \
  NS_IMETHOD GetSelectedSkin(const nsACString & packageName, nsACString & _retval) { return _to GetSelectedSkin(packageName, _retval); } \
  NS_IMETHOD InstallSkin(const char *baseURL, PRBool useProfile, PRBool allowScripts) { return _to InstallSkin(baseURL, useProfile, allowScripts); } \
  NS_IMETHOD UninstallSkin(const nsACString & skinName, PRBool useProfile) { return _to UninstallSkin(skinName, useProfile); } \
  NS_IMETHOD InstallLocale(const char *baseURL, PRBool useProfile) { return _to InstallLocale(baseURL, useProfile); } \
  NS_IMETHOD UninstallLocale(const nsACString & localeName, PRBool useProfile) { return _to UninstallLocale(localeName, useProfile); } \
  NS_IMETHOD InstallPackage(const char *baseURL, PRBool useProfile) { return _to InstallPackage(baseURL, useProfile); } \
  NS_IMETHOD UninstallPackage(const nsACString & packageName, PRBool useProfile) { return _to UninstallPackage(packageName, useProfile); } \
  NS_IMETHOD SetAllowOverlaysForPackage(const PRUnichar *packageName, PRBool allowOverlays) { return _to SetAllowOverlaysForPackage(packageName, allowOverlays); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICHROMEREGISTRYSEA(_to) \
  NS_IMETHOD SelectSkin(const nsACString & skinName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectSkin(skinName, useProfile); } \
  NS_IMETHOD SelectLocale(const nsACString & localeName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectLocale(localeName, useProfile); } \
  NS_IMETHOD DeselectSkin(const nsACString & skinName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeselectSkin(skinName, useProfile); } \
  NS_IMETHOD DeselectLocale(const nsACString & localeName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeselectLocale(localeName, useProfile); } \
  NS_IMETHOD IsSkinSelected(const nsACString & skinName, PRBool useProfile, PRInt32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsSkinSelected(skinName, useProfile, _retval); } \
  NS_IMETHOD IsLocaleSelected(const nsACString & localeName, PRBool useProfile, PRInt32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsLocaleSelected(localeName, useProfile, _retval); } \
  NS_IMETHOD SelectLocaleForProfile(const nsACString & localeName, const PRUnichar *profilePath) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectLocaleForProfile(localeName, profilePath); } \
  NS_IMETHOD SelectSkinForProfile(const nsACString & skinName, const PRUnichar *profilePath) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectSkinForProfile(skinName, profilePath); } \
  NS_IMETHOD SetRuntimeProvider(PRBool runtimeProvider) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetRuntimeProvider(runtimeProvider); } \
  NS_IMETHOD CheckThemeVersion(const nsACString & skinName, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CheckThemeVersion(skinName, _retval); } \
  NS_IMETHOD CheckLocaleVersion(const nsACString & localeName, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CheckLocaleVersion(localeName, _retval); } \
  NS_IMETHOD SelectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectSkinForPackage(skinName, packageName, useProfile); } \
  NS_IMETHOD SelectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectLocaleForPackage(localeName, packageName, useProfile); } \
  NS_IMETHOD DeselectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeselectSkinForPackage(skinName, packageName, useProfile); } \
  NS_IMETHOD DeselectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeselectLocaleForPackage(localeName, packageName, useProfile); } \
  NS_IMETHOD IsSkinSelectedForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsSkinSelectedForPackage(skinName, packageName, useProfile, _retval); } \
  NS_IMETHOD IsLocaleSelectedForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsLocaleSelectedForPackage(localeName, packageName, useProfile, _retval); } \
  NS_IMETHOD GetSelectedSkin(const nsACString & packageName, nsACString & _retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSelectedSkin(packageName, _retval); } \
  NS_IMETHOD InstallSkin(const char *baseURL, PRBool useProfile, PRBool allowScripts) { return !_to ? NS_ERROR_NULL_POINTER : _to->InstallSkin(baseURL, useProfile, allowScripts); } \
  NS_IMETHOD UninstallSkin(const nsACString & skinName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->UninstallSkin(skinName, useProfile); } \
  NS_IMETHOD InstallLocale(const char *baseURL, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->InstallLocale(baseURL, useProfile); } \
  NS_IMETHOD UninstallLocale(const nsACString & localeName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->UninstallLocale(localeName, useProfile); } \
  NS_IMETHOD InstallPackage(const char *baseURL, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->InstallPackage(baseURL, useProfile); } \
  NS_IMETHOD UninstallPackage(const nsACString & packageName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->UninstallPackage(packageName, useProfile); } \
  NS_IMETHOD SetAllowOverlaysForPackage(const PRUnichar *packageName, PRBool allowOverlays) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAllowOverlaysForPackage(packageName, allowOverlays); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsChromeRegistrySea : public nsIChromeRegistrySea
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICHROMEREGISTRYSEA

  nsChromeRegistrySea();

private:
  ~nsChromeRegistrySea();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsChromeRegistrySea, nsIChromeRegistrySea)

nsChromeRegistrySea::nsChromeRegistrySea()
{
  /* member initializers and constructor code */
}

nsChromeRegistrySea::~nsChromeRegistrySea()
{
  /* destructor code */
}

/* void selectSkin (in ACString skinName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::SelectSkin(const nsACString & skinName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void selectLocale (in ACString localeName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::SelectLocale(const nsACString & localeName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deselectSkin (in ACString skinName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::DeselectSkin(const nsACString & skinName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deselectLocale (in ACString localeName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::DeselectLocale(const nsACString & localeName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* PRInt32 isSkinSelected (in ACString skinName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::IsSkinSelected(const nsACString & skinName, PRBool useProfile, PRInt32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* PRInt32 isLocaleSelected (in ACString localeName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::IsLocaleSelected(const nsACString & localeName, PRBool useProfile, PRInt32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void selectLocaleForProfile (in ACString localeName, in wstring profilePath); */
NS_IMETHODIMP nsChromeRegistrySea::SelectLocaleForProfile(const nsACString & localeName, const PRUnichar *profilePath)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void selectSkinForProfile (in ACString skinName, in wstring profilePath); */
NS_IMETHODIMP nsChromeRegistrySea::SelectSkinForProfile(const nsACString & skinName, const PRUnichar *profilePath)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setRuntimeProvider (in boolean runtimeProvider); */
NS_IMETHODIMP nsChromeRegistrySea::SetRuntimeProvider(PRBool runtimeProvider)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean checkThemeVersion (in ACString skinName); */
NS_IMETHODIMP nsChromeRegistrySea::CheckThemeVersion(const nsACString & skinName, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean checkLocaleVersion (in ACString localeName); */
NS_IMETHODIMP nsChromeRegistrySea::CheckLocaleVersion(const nsACString & localeName, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void selectSkinForPackage (in ACString skinName, in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::SelectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void selectLocaleForPackage (in ACString localeName, in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::SelectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deselectSkinForPackage (in ACString skinName, in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::DeselectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deselectLocaleForPackage (in ACString localeName, in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::DeselectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean isSkinSelectedForPackage (in ACString skinName, in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::IsSkinSelectedForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean isLocaleSelectedForPackage (in ACString localeName, in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::IsLocaleSelectedForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* ACString getSelectedSkin (in ACString packageName); */
NS_IMETHODIMP nsChromeRegistrySea::GetSelectedSkin(const nsACString & packageName, nsACString & _retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void installSkin (in string baseURL, in boolean useProfile, in boolean allowScripts); */
NS_IMETHODIMP nsChromeRegistrySea::InstallSkin(const char *baseURL, PRBool useProfile, PRBool allowScripts)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void uninstallSkin (in ACString skinName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::UninstallSkin(const nsACString & skinName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void installLocale (in string baseURL, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::InstallLocale(const char *baseURL, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void uninstallLocale (in ACString localeName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::UninstallLocale(const nsACString & localeName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void installPackage (in string baseURL, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::InstallPackage(const char *baseURL, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void uninstallPackage (in ACString packageName, in boolean useProfile); */
NS_IMETHODIMP nsChromeRegistrySea::UninstallPackage(const nsACString & packageName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setAllowOverlaysForPackage (in wstring packageName, in boolean allowOverlays); */
NS_IMETHODIMP nsChromeRegistrySea::SetAllowOverlaysForPackage(const PRUnichar *packageName, PRBool allowOverlays)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIChromeRegistrySea_h__ */
