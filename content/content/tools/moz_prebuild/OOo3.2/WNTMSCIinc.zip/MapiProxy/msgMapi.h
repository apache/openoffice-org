

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0366 */
/* at Tue Nov 17 01:27:24 2009
 */
/* Compiler settings for ../../../../../mailnews/mapi/mapihook/build/msgMapi.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __msgMapi_h__
#define __msgMapi_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __nsIMapi_FWD_DEFINED__
#define __nsIMapi_FWD_DEFINED__
typedef interface nsIMapi nsIMapi;
#endif 	/* __nsIMapi_FWD_DEFINED__ */


/* header files for imported files */
#include "unknwn.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

/* interface __MIDL_itf_msgMapi_0000 */
/* [local] */ 

typedef wchar_t LOGIN_PW_TYPE[ 256 ];

typedef /* [public] */ struct __MIDL___MIDL_itf_msgMapi_0000_0001
    {
    unsigned long ulReserved;
    unsigned long flFlags;
    unsigned long nPosition_NotUsed;
    LPTSTR lpszPathName;
    LPTSTR lpszFileName;
    unsigned char *lpFileType_NotUsed;
    } 	nsMapiFileDesc;

typedef struct __MIDL___MIDL_itf_msgMapi_0000_0001 *lpnsMapiFileDesc;

typedef /* [public] */ struct __MIDL___MIDL_itf_msgMapi_0000_0002
    {
    unsigned long ulReserved;
    unsigned long ulRecipClass;
    LPSTR lpszName;
    LPSTR lpszAddress;
    unsigned long ulEIDSize_NotUsed;
    unsigned char *lpEntryID_NotUsed;
    } 	nsMapiRecipDesc;

typedef struct __MIDL___MIDL_itf_msgMapi_0000_0002 *lpnsMapiRecipDesc;

typedef /* [public] */ struct __MIDL___MIDL_itf_msgMapi_0000_0003
    {
    unsigned long ulReserved;
    LPSTR lpszSubject;
    LPSTR lpszNoteText;
    LPSTR lpszMessageType;
    LPSTR lpszDateReceived;
    LPSTR lpszConversationID_NotUsed;
    unsigned long flFlags;
    lpnsMapiRecipDesc lpOriginator;
    unsigned long nRecipCount;
    /* [size_is] */ lpnsMapiRecipDesc lpRecips;
    unsigned long nFileCount;
    /* [size_is] */ lpnsMapiFileDesc lpFiles;
    } 	nsMapiMessage;

typedef struct __MIDL___MIDL_itf_msgMapi_0000_0003 *lpnsMapiMessage;



extern RPC_IF_HANDLE __MIDL_itf_msgMapi_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_msgMapi_0000_v0_0_s_ifspec;

#ifndef __nsIMapi_INTERFACE_DEFINED__
#define __nsIMapi_INTERFACE_DEFINED__

/* interface nsIMapi */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_nsIMapi;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6EDCD38E-8861-11d5-A3DD-00B0D0F3BAA7")
    nsIMapi : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Login( 
            unsigned long aUIArg,
            LOGIN_PW_TYPE aLogin,
            LOGIN_PW_TYPE aPassWord,
            unsigned long aFlags,
            /* [out] */ unsigned long *aSessionId) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Initialize( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE IsValid( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE IsValidSession( 
            /* [in] */ unsigned long aSession) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SendMail( 
            /* [in] */ unsigned long aSession,
            /* [in] */ lpnsMapiMessage aMessage,
            /* [in] */ short aRecipCount,
            /* [size_is][in] */ lpnsMapiRecipDesc aRecips,
            /* [in] */ short aFileCount,
            /* [size_is][in] */ lpnsMapiFileDesc aFiles,
            /* [in] */ unsigned long aFlags,
            /* [in] */ unsigned long aReserved) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SendDocuments( 
            /* [in] */ unsigned long aSession,
            /* [in] */ LPTSTR aDelimChar,
            /* [in] */ LPTSTR aFilePaths,
            /* [in] */ LPTSTR aFileNames,
            /* [in] */ ULONG aFlags) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE FindNext( 
            /* [in] */ unsigned long aSession,
            /* [in] */ ULONG ulUIParam,
            /* [in] */ LPTSTR lpszMessageType,
            /* [in] */ LPTSTR lpszSeedMessageID,
            /* [in] */ ULONG flFlags,
            /* [in] */ ULONG ulReserved,
            /* [out][in] */ unsigned char lpszMessageID[ 64 ]) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ReadMail( 
            /* [in] */ unsigned long lhSession,
            /* [in] */ ULONG ulUIParam,
            /* [in] */ LPTSTR lpszMessageID,
            /* [in] */ ULONG flFlags,
            /* [in] */ ULONG ulReserved,
            /* [out] */ lpnsMapiMessage *lppMessage) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE DeleteMail( 
            /* [in] */ unsigned long lhSession,
            /* [in] */ ULONG ulUIParam,
            /* [in] */ LPTSTR lpszMessageID,
            /* [in] */ ULONG flFlags,
            /* [in] */ ULONG ulReserved) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SaveMail( 
            /* [in] */ unsigned long lhSession,
            /* [in] */ ULONG ulUIParam,
            /* [in] */ lpnsMapiMessage lppMessage,
            /* [in] */ ULONG flFlags,
            /* [in] */ ULONG ulReserved,
            /* [in] */ LPTSTR lpszMessageID) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Logoff( 
            unsigned long aSession) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE CleanUp( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct nsIMapiVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            nsIMapi * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            nsIMapi * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            nsIMapi * This);
        
        HRESULT ( STDMETHODCALLTYPE *Login )( 
            nsIMapi * This,
            unsigned long aUIArg,
            LOGIN_PW_TYPE aLogin,
            LOGIN_PW_TYPE aPassWord,
            unsigned long aFlags,
            /* [out] */ unsigned long *aSessionId);
        
        HRESULT ( STDMETHODCALLTYPE *Initialize )( 
            nsIMapi * This);
        
        HRESULT ( STDMETHODCALLTYPE *IsValid )( 
            nsIMapi * This);
        
        HRESULT ( STDMETHODCALLTYPE *IsValidSession )( 
            nsIMapi * This,
            /* [in] */ unsigned long aSession);
        
        HRESULT ( STDMETHODCALLTYPE *SendMail )( 
            nsIMapi * This,
            /* [in] */ unsigned long aSession,
            /* [in] */ lpnsMapiMessage aMessage,
            /* [in] */ short aRecipCount,
            /* [size_is][in] */ lpnsMapiRecipDesc aRecips,
            /* [in] */ short aFileCount,
            /* [size_is][in] */ lpnsMapiFileDesc aFiles,
            /* [in] */ unsigned long aFlags,
            /* [in] */ unsigned long aReserved);
        
        HRESULT ( STDMETHODCALLTYPE *SendDocuments )( 
            nsIMapi * This,
            /* [in] */ unsigned long aSession,
            /* [in] */ LPTSTR aDelimChar,
            /* [in] */ LPTSTR aFilePaths,
            /* [in] */ LPTSTR aFileNames,
            /* [in] */ ULONG aFlags);
        
        HRESULT ( STDMETHODCALLTYPE *FindNext )( 
            nsIMapi * This,
            /* [in] */ unsigned long aSession,
            /* [in] */ ULONG ulUIParam,
            /* [in] */ LPTSTR lpszMessageType,
            /* [in] */ LPTSTR lpszSeedMessageID,
            /* [in] */ ULONG flFlags,
            /* [in] */ ULONG ulReserved,
            /* [out][in] */ unsigned char lpszMessageID[ 64 ]);
        
        HRESULT ( STDMETHODCALLTYPE *ReadMail )( 
            nsIMapi * This,
            /* [in] */ unsigned long lhSession,
            /* [in] */ ULONG ulUIParam,
            /* [in] */ LPTSTR lpszMessageID,
            /* [in] */ ULONG flFlags,
            /* [in] */ ULONG ulReserved,
            /* [out] */ lpnsMapiMessage *lppMessage);
        
        HRESULT ( STDMETHODCALLTYPE *DeleteMail )( 
            nsIMapi * This,
            /* [in] */ unsigned long lhSession,
            /* [in] */ ULONG ulUIParam,
            /* [in] */ LPTSTR lpszMessageID,
            /* [in] */ ULONG flFlags,
            /* [in] */ ULONG ulReserved);
        
        HRESULT ( STDMETHODCALLTYPE *SaveMail )( 
            nsIMapi * This,
            /* [in] */ unsigned long lhSession,
            /* [in] */ ULONG ulUIParam,
            /* [in] */ lpnsMapiMessage lppMessage,
            /* [in] */ ULONG flFlags,
            /* [in] */ ULONG ulReserved,
            /* [in] */ LPTSTR lpszMessageID);
        
        HRESULT ( STDMETHODCALLTYPE *Logoff )( 
            nsIMapi * This,
            unsigned long aSession);
        
        HRESULT ( STDMETHODCALLTYPE *CleanUp )( 
            nsIMapi * This);
        
        END_INTERFACE
    } nsIMapiVtbl;

    interface nsIMapi
    {
        CONST_VTBL struct nsIMapiVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define nsIMapi_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define nsIMapi_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define nsIMapi_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define nsIMapi_Login(This,aUIArg,aLogin,aPassWord,aFlags,aSessionId)	\
    (This)->lpVtbl -> Login(This,aUIArg,aLogin,aPassWord,aFlags,aSessionId)

#define nsIMapi_Initialize(This)	\
    (This)->lpVtbl -> Initialize(This)

#define nsIMapi_IsValid(This)	\
    (This)->lpVtbl -> IsValid(This)

#define nsIMapi_IsValidSession(This,aSession)	\
    (This)->lpVtbl -> IsValidSession(This,aSession)

#define nsIMapi_SendMail(This,aSession,aMessage,aRecipCount,aRecips,aFileCount,aFiles,aFlags,aReserved)	\
    (This)->lpVtbl -> SendMail(This,aSession,aMessage,aRecipCount,aRecips,aFileCount,aFiles,aFlags,aReserved)

#define nsIMapi_SendDocuments(This,aSession,aDelimChar,aFilePaths,aFileNames,aFlags)	\
    (This)->lpVtbl -> SendDocuments(This,aSession,aDelimChar,aFilePaths,aFileNames,aFlags)

#define nsIMapi_FindNext(This,aSession,ulUIParam,lpszMessageType,lpszSeedMessageID,flFlags,ulReserved,lpszMessageID)	\
    (This)->lpVtbl -> FindNext(This,aSession,ulUIParam,lpszMessageType,lpszSeedMessageID,flFlags,ulReserved,lpszMessageID)

#define nsIMapi_ReadMail(This,lhSession,ulUIParam,lpszMessageID,flFlags,ulReserved,lppMessage)	\
    (This)->lpVtbl -> ReadMail(This,lhSession,ulUIParam,lpszMessageID,flFlags,ulReserved,lppMessage)

#define nsIMapi_DeleteMail(This,lhSession,ulUIParam,lpszMessageID,flFlags,ulReserved)	\
    (This)->lpVtbl -> DeleteMail(This,lhSession,ulUIParam,lpszMessageID,flFlags,ulReserved)

#define nsIMapi_SaveMail(This,lhSession,ulUIParam,lppMessage,flFlags,ulReserved,lpszMessageID)	\
    (This)->lpVtbl -> SaveMail(This,lhSession,ulUIParam,lppMessage,flFlags,ulReserved,lpszMessageID)

#define nsIMapi_Logoff(This,aSession)	\
    (This)->lpVtbl -> Logoff(This,aSession)

#define nsIMapi_CleanUp(This)	\
    (This)->lpVtbl -> CleanUp(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE nsIMapi_Login_Proxy( 
    nsIMapi * This,
    unsigned long aUIArg,
    LOGIN_PW_TYPE aLogin,
    LOGIN_PW_TYPE aPassWord,
    unsigned long aFlags,
    /* [out] */ unsigned long *aSessionId);


void __RPC_STUB nsIMapi_Login_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE nsIMapi_Initialize_Proxy( 
    nsIMapi * This);


void __RPC_STUB nsIMapi_Initialize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE nsIMapi_IsValid_Proxy( 
    nsIMapi * This);


void __RPC_STUB nsIMapi_IsValid_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE nsIMapi_IsValidSession_Proxy( 
    nsIMapi * This,
    /* [in] */ unsigned long aSession);


void __RPC_STUB nsIMapi_IsValidSession_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE nsIMapi_SendMail_Proxy( 
    nsIMapi * This,
    /* [in] */ unsigned long aSession,
    /* [in] */ lpnsMapiMessage aMessage,
    /* [in] */ short aRecipCount,
    /* [size_is][in] */ lpnsMapiRecipDesc aRecips,
    /* [in] */ short aFileCount,
    /* [size_is][in] */ lpnsMapiFileDesc aFiles,
    /* [in] */ unsigned long aFlags,
    /* [in] */ unsigned long aReserved);


void __RPC_STUB nsIMapi_SendMail_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE nsIMapi_SendDocuments_Proxy( 
    nsIMapi * This,
    /* [in] */ unsigned long aSession,
    /* [in] */ LPTSTR aDelimChar,
    /* [in] */ LPTSTR aFilePaths,
    /* [in] */ LPTSTR aFileNames,
    /* [in] */ ULONG aFlags);


void __RPC_STUB nsIMapi_SendDocuments_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE nsIMapi_FindNext_Proxy( 
    nsIMapi * This,
    /* [in] */ unsigned long aSession,
    /* [in] */ ULONG ulUIParam,
    /* [in] */ LPTSTR lpszMessageType,
    /* [in] */ LPTSTR lpszSeedMessageID,
    /* [in] */ ULONG flFlags,
    /* [in] */ ULONG ulReserved,
    /* [out][in] */ unsigned char lpszMessageID[ 64 ]);


void __RPC_STUB nsIMapi_FindNext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE nsIMapi_ReadMail_Proxy( 
    nsIMapi * This,
    /* [in] */ unsigned long lhSession,
    /* [in] */ ULONG ulUIParam,
    /* [in] */ LPTSTR lpszMessageID,
    /* [in] */ ULONG flFlags,
    /* [in] */ ULONG ulReserved,
    /* [out] */ lpnsMapiMessage *lppMessage);


void __RPC_STUB nsIMapi_ReadMail_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE nsIMapi_DeleteMail_Proxy( 
    nsIMapi * This,
    /* [in] */ unsigned long lhSession,
    /* [in] */ ULONG ulUIParam,
    /* [in] */ LPTSTR lpszMessageID,
    /* [in] */ ULONG flFlags,
    /* [in] */ ULONG ulReserved);


void __RPC_STUB nsIMapi_DeleteMail_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE nsIMapi_SaveMail_Proxy( 
    nsIMapi * This,
    /* [in] */ unsigned long lhSession,
    /* [in] */ ULONG ulUIParam,
    /* [in] */ lpnsMapiMessage lppMessage,
    /* [in] */ ULONG flFlags,
    /* [in] */ ULONG ulReserved,
    /* [in] */ LPTSTR lpszMessageID);


void __RPC_STUB nsIMapi_SaveMail_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE nsIMapi_Logoff_Proxy( 
    nsIMapi * This,
    unsigned long aSession);


void __RPC_STUB nsIMapi_Logoff_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE nsIMapi_CleanUp_Proxy( 
    nsIMapi * This);


void __RPC_STUB nsIMapi_CleanUp_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __nsIMapi_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


