/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/xpfe/components/urlwidget/../../../../xpfe/components/urlwidget/nsIUrlWidget.idl
 */

#ifndef __gen_nsIUrlWidget_h__
#define __gen_nsIUrlWidget_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIDOMWindowInternal; /* forward declaration */


/* starting interface:    nsIUrlWidget */
#define NS_IURLWIDGET_IID_STR "1802ee81-34a1-11d4-82ee-0050da2da771"

#define NS_IURLWIDGET_IID \
  {0x1802ee81, 0x34a1, 0x11d4, \
    { 0x82, 0xee, 0x00, 0x50, 0xda, 0x2d, 0xa7, 0x71 }}

class NS_NO_VTABLE nsIUrlWidget : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IURLWIDGET_IID)

  /* void SetURLToHiddenControl (in string aURL, in nsIDOMWindowInternal parent); */
  NS_IMETHOD SetURLToHiddenControl(const char *aURL, nsIDOMWindowInternal *parent) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIURLWIDGET \
  NS_IMETHOD SetURLToHiddenControl(const char *aURL, nsIDOMWindowInternal *parent); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIURLWIDGET(_to) \
  NS_IMETHOD SetURLToHiddenControl(const char *aURL, nsIDOMWindowInternal *parent) { return _to SetURLToHiddenControl(aURL, parent); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIURLWIDGET(_to) \
  NS_IMETHOD SetURLToHiddenControl(const char *aURL, nsIDOMWindowInternal *parent) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetURLToHiddenControl(aURL, parent); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsUrlWidget : public nsIUrlWidget
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIURLWIDGET

  nsUrlWidget();

private:
  ~nsUrlWidget();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsUrlWidget, nsIUrlWidget)

nsUrlWidget::nsUrlWidget()
{
  /* member initializers and constructor code */
}

nsUrlWidget::~nsUrlWidget()
{
  /* destructor code */
}

/* void SetURLToHiddenControl (in string aURL, in nsIDOMWindowInternal parent); */
NS_IMETHODIMP nsUrlWidget::SetURLToHiddenControl(const char *aURL, nsIDOMWindowInternal *parent)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

#define NS_IURLWIDGET_CONTRACTID    "@mozilla.org/urlwidget;1"
#define NS_IURLWIDGET_CLASSNAME "nsUrlWidget"

#endif /* __gen_nsIUrlWidget_h__ */
