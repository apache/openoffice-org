/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/xpfe/components/startup/public/../../../../../xpfe/components/startup/public/nsIAppStartup.idl
 */

#ifndef __gen_nsIAppStartup_h__
#define __gen_nsIAppStartup_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsICmdLineService; /* forward declaration */

class nsINativeAppSupport; /* forward declaration */


/* starting interface:    nsIAppStartup */
#define NS_IAPPSTARTUP_IID_STR "0f4ae035-4643-44c5-a596-ff81b8c29f08"

#define NS_IAPPSTARTUP_IID \
  {0x0f4ae035, 0x4643, 0x44c5, \
    { 0xa5, 0x96, 0xff, 0x81, 0xb8, 0xc2, 0x9f, 0x08 }}

class NS_NO_VTABLE nsIAppStartup : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IAPPSTARTUP_IID)

  /**
     * Required initialization routine.
     * @param aNativeAppSupportOrSplashScreen
     *        This is an object that can be QI'd to either an
     *        nsINativeAppSupport or nsISplashScreen; this object will be
     *        used to implement HideSplashScreen.
     */
  /* void initialize (in nsISupports nativeAppSupportOrSplashScreen); */
  NS_IMETHOD Initialize(nsISupports *nativeAppSupportOrSplashScreen) = 0;

  /**
     * Create the hidden window. Only bootstrap code (nsAppRunner.cpp) should call
     * this method.
     */
  /* void createHiddenWindow (); */
  NS_IMETHOD CreateHiddenWindow(void) = 0;

  /**
     * Starts up the profile manager with the given arguments
     * @param aCmdLineService the arguments given to the program
     * @param canInteract If FALSE and UI is needed, will fail
     */
  /* void doProfileStartup (in nsICmdLineService aCmdLineService, in boolean canInteract); */
  NS_IMETHOD DoProfileStartup(nsICmdLineService *aCmdLineService, PRBool canInteract) = 0;

  /**
     * Getter for "native app support."
     */
  /* readonly attribute nsINativeAppSupport nativeAppSupport; */
  NS_IMETHOD GetNativeAppSupport(nsINativeAppSupport * *aNativeAppSupport) = 0;

  /**
     * Runs an application event loop: normally the main event pump which
     * defines the lifetime of the application.
     */
  /* void run (); */
  NS_IMETHOD Run(void) = 0;

  /**
     * During application startup (and at other times!) we may temporarily
     * encounter a situation where all application windows will be closed
     * but we don't want to take this as a signal to quit the app. Bracket
     * the code where the last window could close with these.
     * (And at application startup, on platforms that don't normally quit
     * when the last window has closed, call Enter once, but not Exit)
     */
  /* void enterLastWindowClosingSurvivalArea (); */
  NS_IMETHOD EnterLastWindowClosingSurvivalArea(void) = 0;

  /* void exitLastWindowClosingSurvivalArea (); */
  NS_IMETHOD ExitLastWindowClosingSurvivalArea(void) = 0;

  enum { eConsiderQuit = 1U };

  enum { eAttemptQuit = 2U };

  enum { eForceQuit = 3U };

  /**
     * Exit the event loop, shut down the app
     */
  /* void quit (in PRUint32 aFerocity); */
  NS_IMETHOD Quit(PRUint32 aFerocity) = 0;

  /**
     * Remove the splash screen (if visible).  This need be called
     * only once per application session.
     */
  /* void hideSplashScreen (); */
  NS_IMETHOD HideSplashScreen(void) = 0;

  /**
     * Creates the initial state of the application by launching tasks
     * specfied by "general.startup.*" prefs.
     * @param aWindowWidth	the width to make the initial window(s) opened
     * @param aWindowHeight	the height to make the initial window(s) opened
     * @note SIZE_TO_CONTENT may be used for width or height.
     * @return TRUE if a window was opened
     */
  /* boolean createStartupState (in long aWindowWidth, in long aWindowHeight); */
  NS_IMETHOD CreateStartupState(PRInt32 aWindowWidth, PRInt32 aWindowHeight, PRBool *_retval) = 0;

  /**
     * Ensures that at least one window exists after creating the startup state.
     * If one has not been made, this will create a browser window.
     * @param aCmdLineService  the command line from which startup args can be read.
     */
  /* void ensure1Window (in nsICmdLineService aCmdLineService); */
  NS_IMETHOD Ensure1Window(nsICmdLineService *aCmdLineService) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIAPPSTARTUP \
  NS_IMETHOD Initialize(nsISupports *nativeAppSupportOrSplashScreen); \
  NS_IMETHOD CreateHiddenWindow(void); \
  NS_IMETHOD DoProfileStartup(nsICmdLineService *aCmdLineService, PRBool canInteract); \
  NS_IMETHOD GetNativeAppSupport(nsINativeAppSupport * *aNativeAppSupport); \
  NS_IMETHOD Run(void); \
  NS_IMETHOD EnterLastWindowClosingSurvivalArea(void); \
  NS_IMETHOD ExitLastWindowClosingSurvivalArea(void); \
  NS_IMETHOD Quit(PRUint32 aFerocity); \
  NS_IMETHOD HideSplashScreen(void); \
  NS_IMETHOD CreateStartupState(PRInt32 aWindowWidth, PRInt32 aWindowHeight, PRBool *_retval); \
  NS_IMETHOD Ensure1Window(nsICmdLineService *aCmdLineService); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIAPPSTARTUP(_to) \
  NS_IMETHOD Initialize(nsISupports *nativeAppSupportOrSplashScreen) { return _to Initialize(nativeAppSupportOrSplashScreen); } \
  NS_IMETHOD CreateHiddenWindow(void) { return _to CreateHiddenWindow(); } \
  NS_IMETHOD DoProfileStartup(nsICmdLineService *aCmdLineService, PRBool canInteract) { return _to DoProfileStartup(aCmdLineService, canInteract); } \
  NS_IMETHOD GetNativeAppSupport(nsINativeAppSupport * *aNativeAppSupport) { return _to GetNativeAppSupport(aNativeAppSupport); } \
  NS_IMETHOD Run(void) { return _to Run(); } \
  NS_IMETHOD EnterLastWindowClosingSurvivalArea(void) { return _to EnterLastWindowClosingSurvivalArea(); } \
  NS_IMETHOD ExitLastWindowClosingSurvivalArea(void) { return _to ExitLastWindowClosingSurvivalArea(); } \
  NS_IMETHOD Quit(PRUint32 aFerocity) { return _to Quit(aFerocity); } \
  NS_IMETHOD HideSplashScreen(void) { return _to HideSplashScreen(); } \
  NS_IMETHOD CreateStartupState(PRInt32 aWindowWidth, PRInt32 aWindowHeight, PRBool *_retval) { return _to CreateStartupState(aWindowWidth, aWindowHeight, _retval); } \
  NS_IMETHOD Ensure1Window(nsICmdLineService *aCmdLineService) { return _to Ensure1Window(aCmdLineService); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIAPPSTARTUP(_to) \
  NS_IMETHOD Initialize(nsISupports *nativeAppSupportOrSplashScreen) { return !_to ? NS_ERROR_NULL_POINTER : _to->Initialize(nativeAppSupportOrSplashScreen); } \
  NS_IMETHOD CreateHiddenWindow(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHiddenWindow(); } \
  NS_IMETHOD DoProfileStartup(nsICmdLineService *aCmdLineService, PRBool canInteract) { return !_to ? NS_ERROR_NULL_POINTER : _to->DoProfileStartup(aCmdLineService, canInteract); } \
  NS_IMETHOD GetNativeAppSupport(nsINativeAppSupport * *aNativeAppSupport) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNativeAppSupport(aNativeAppSupport); } \
  NS_IMETHOD Run(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->Run(); } \
  NS_IMETHOD EnterLastWindowClosingSurvivalArea(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->EnterLastWindowClosingSurvivalArea(); } \
  NS_IMETHOD ExitLastWindowClosingSurvivalArea(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->ExitLastWindowClosingSurvivalArea(); } \
  NS_IMETHOD Quit(PRUint32 aFerocity) { return !_to ? NS_ERROR_NULL_POINTER : _to->Quit(aFerocity); } \
  NS_IMETHOD HideSplashScreen(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->HideSplashScreen(); } \
  NS_IMETHOD CreateStartupState(PRInt32 aWindowWidth, PRInt32 aWindowHeight, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateStartupState(aWindowWidth, aWindowHeight, _retval); } \
  NS_IMETHOD Ensure1Window(nsICmdLineService *aCmdLineService) { return !_to ? NS_ERROR_NULL_POINTER : _to->Ensure1Window(aCmdLineService); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAppStartup : public nsIAppStartup
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIAPPSTARTUP

  nsAppStartup();

private:
  ~nsAppStartup();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAppStartup, nsIAppStartup)

nsAppStartup::nsAppStartup()
{
  /* member initializers and constructor code */
}

nsAppStartup::~nsAppStartup()
{
  /* destructor code */
}

/* void initialize (in nsISupports nativeAppSupportOrSplashScreen); */
NS_IMETHODIMP nsAppStartup::Initialize(nsISupports *nativeAppSupportOrSplashScreen)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void createHiddenWindow (); */
NS_IMETHODIMP nsAppStartup::CreateHiddenWindow()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void doProfileStartup (in nsICmdLineService aCmdLineService, in boolean canInteract); */
NS_IMETHODIMP nsAppStartup::DoProfileStartup(nsICmdLineService *aCmdLineService, PRBool canInteract)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsINativeAppSupport nativeAppSupport; */
NS_IMETHODIMP nsAppStartup::GetNativeAppSupport(nsINativeAppSupport * *aNativeAppSupport)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void run (); */
NS_IMETHODIMP nsAppStartup::Run()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void enterLastWindowClosingSurvivalArea (); */
NS_IMETHODIMP nsAppStartup::EnterLastWindowClosingSurvivalArea()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void exitLastWindowClosingSurvivalArea (); */
NS_IMETHODIMP nsAppStartup::ExitLastWindowClosingSurvivalArea()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void quit (in PRUint32 aFerocity); */
NS_IMETHODIMP nsAppStartup::Quit(PRUint32 aFerocity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void hideSplashScreen (); */
NS_IMETHODIMP nsAppStartup::HideSplashScreen()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean createStartupState (in long aWindowWidth, in long aWindowHeight); */
NS_IMETHODIMP nsAppStartup::CreateStartupState(PRInt32 aWindowWidth, PRInt32 aWindowHeight, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void ensure1Window (in nsICmdLineService aCmdLineService); */
NS_IMETHODIMP nsAppStartup::Ensure1Window(nsICmdLineService *aCmdLineService)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAppStartup_h__ */
