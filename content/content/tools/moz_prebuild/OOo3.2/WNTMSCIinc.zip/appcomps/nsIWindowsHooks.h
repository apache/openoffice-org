/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/xpfe/components/winhooks/../../../../xpfe/components/winhooks/nsIWindowsHooks.idl
 */

#ifndef __gen_nsIWindowsHooks_h__
#define __gen_nsIWindowsHooks_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIDOMWindowInternal; /* forward declaration */

class nsIDOMElement; /* forward declaration */


/* starting interface:    nsIWindowsHooksSettings */
#define NS_IWINDOWSHOOKSSETTINGS_IID_STR "4ce9aa90-0a6a-11d4-8076-00600811a9c3"

#define NS_IWINDOWSHOOKSSETTINGS_IID \
  {0x4ce9aa90, 0x0a6a, 0x11d4, \
    { 0x80, 0x76, 0x00, 0x60, 0x08, 0x11, 0xa9, 0xc3 }}

class NS_NO_VTABLE nsIWindowsHooksSettings : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IWINDOWSHOOKSSETTINGS_IID)

  /* attribute boolean isHandlingHTTP; */
  NS_IMETHOD GetIsHandlingHTTP(PRBool *aIsHandlingHTTP) = 0;
  NS_IMETHOD SetIsHandlingHTTP(PRBool aIsHandlingHTTP) = 0;

  /* attribute boolean isHandlingHTTPS; */
  NS_IMETHOD GetIsHandlingHTTPS(PRBool *aIsHandlingHTTPS) = 0;
  NS_IMETHOD SetIsHandlingHTTPS(PRBool aIsHandlingHTTPS) = 0;

  /* attribute boolean isHandlingFTP; */
  NS_IMETHOD GetIsHandlingFTP(PRBool *aIsHandlingFTP) = 0;
  NS_IMETHOD SetIsHandlingFTP(PRBool aIsHandlingFTP) = 0;

  /* attribute boolean isHandlingCHROME; */
  NS_IMETHOD GetIsHandlingCHROME(PRBool *aIsHandlingCHROME) = 0;
  NS_IMETHOD SetIsHandlingCHROME(PRBool aIsHandlingCHROME) = 0;

  /* attribute boolean isHandlingGOPHER; */
  NS_IMETHOD GetIsHandlingGOPHER(PRBool *aIsHandlingGOPHER) = 0;
  NS_IMETHOD SetIsHandlingGOPHER(PRBool aIsHandlingGOPHER) = 0;

  /* attribute boolean isHandlingHTML; */
  NS_IMETHOD GetIsHandlingHTML(PRBool *aIsHandlingHTML) = 0;
  NS_IMETHOD SetIsHandlingHTML(PRBool aIsHandlingHTML) = 0;

  /* attribute boolean isHandlingJPEG; */
  NS_IMETHOD GetIsHandlingJPEG(PRBool *aIsHandlingJPEG) = 0;
  NS_IMETHOD SetIsHandlingJPEG(PRBool aIsHandlingJPEG) = 0;

  /* attribute boolean isHandlingGIF; */
  NS_IMETHOD GetIsHandlingGIF(PRBool *aIsHandlingGIF) = 0;
  NS_IMETHOD SetIsHandlingGIF(PRBool aIsHandlingGIF) = 0;

  /* attribute boolean isHandlingPNG; */
  NS_IMETHOD GetIsHandlingPNG(PRBool *aIsHandlingPNG) = 0;
  NS_IMETHOD SetIsHandlingPNG(PRBool aIsHandlingPNG) = 0;

  /* attribute boolean isHandlingMNG; */
  NS_IMETHOD GetIsHandlingMNG(PRBool *aIsHandlingMNG) = 0;
  NS_IMETHOD SetIsHandlingMNG(PRBool aIsHandlingMNG) = 0;

  /* attribute boolean isHandlingXBM; */
  NS_IMETHOD GetIsHandlingXBM(PRBool *aIsHandlingXBM) = 0;
  NS_IMETHOD SetIsHandlingXBM(PRBool aIsHandlingXBM) = 0;

  /* attribute boolean isHandlingBMP; */
  NS_IMETHOD GetIsHandlingBMP(PRBool *aIsHandlingBMP) = 0;
  NS_IMETHOD SetIsHandlingBMP(PRBool aIsHandlingBMP) = 0;

  /* attribute boolean isHandlingICO; */
  NS_IMETHOD GetIsHandlingICO(PRBool *aIsHandlingICO) = 0;
  NS_IMETHOD SetIsHandlingICO(PRBool aIsHandlingICO) = 0;

  /* attribute boolean isHandlingXML; */
  NS_IMETHOD GetIsHandlingXML(PRBool *aIsHandlingXML) = 0;
  NS_IMETHOD SetIsHandlingXML(PRBool aIsHandlingXML) = 0;

  /* attribute boolean isHandlingXHTML; */
  NS_IMETHOD GetIsHandlingXHTML(PRBool *aIsHandlingXHTML) = 0;
  NS_IMETHOD SetIsHandlingXHTML(PRBool aIsHandlingXHTML) = 0;

  /* attribute boolean isHandlingXUL; */
  NS_IMETHOD GetIsHandlingXUL(PRBool *aIsHandlingXUL) = 0;
  NS_IMETHOD SetIsHandlingXUL(PRBool aIsHandlingXUL) = 0;

  /* attribute boolean showDialog; */
  NS_IMETHOD GetShowDialog(PRBool *aShowDialog) = 0;
  NS_IMETHOD SetShowDialog(PRBool aShowDialog) = 0;

  /* readonly attribute boolean registryMatches; */
  NS_IMETHOD GetRegistryMatches(PRBool *aRegistryMatches) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIWINDOWSHOOKSSETTINGS \
  NS_IMETHOD GetIsHandlingHTTP(PRBool *aIsHandlingHTTP); \
  NS_IMETHOD SetIsHandlingHTTP(PRBool aIsHandlingHTTP); \
  NS_IMETHOD GetIsHandlingHTTPS(PRBool *aIsHandlingHTTPS); \
  NS_IMETHOD SetIsHandlingHTTPS(PRBool aIsHandlingHTTPS); \
  NS_IMETHOD GetIsHandlingFTP(PRBool *aIsHandlingFTP); \
  NS_IMETHOD SetIsHandlingFTP(PRBool aIsHandlingFTP); \
  NS_IMETHOD GetIsHandlingCHROME(PRBool *aIsHandlingCHROME); \
  NS_IMETHOD SetIsHandlingCHROME(PRBool aIsHandlingCHROME); \
  NS_IMETHOD GetIsHandlingGOPHER(PRBool *aIsHandlingGOPHER); \
  NS_IMETHOD SetIsHandlingGOPHER(PRBool aIsHandlingGOPHER); \
  NS_IMETHOD GetIsHandlingHTML(PRBool *aIsHandlingHTML); \
  NS_IMETHOD SetIsHandlingHTML(PRBool aIsHandlingHTML); \
  NS_IMETHOD GetIsHandlingJPEG(PRBool *aIsHandlingJPEG); \
  NS_IMETHOD SetIsHandlingJPEG(PRBool aIsHandlingJPEG); \
  NS_IMETHOD GetIsHandlingGIF(PRBool *aIsHandlingGIF); \
  NS_IMETHOD SetIsHandlingGIF(PRBool aIsHandlingGIF); \
  NS_IMETHOD GetIsHandlingPNG(PRBool *aIsHandlingPNG); \
  NS_IMETHOD SetIsHandlingPNG(PRBool aIsHandlingPNG); \
  NS_IMETHOD GetIsHandlingMNG(PRBool *aIsHandlingMNG); \
  NS_IMETHOD SetIsHandlingMNG(PRBool aIsHandlingMNG); \
  NS_IMETHOD GetIsHandlingXBM(PRBool *aIsHandlingXBM); \
  NS_IMETHOD SetIsHandlingXBM(PRBool aIsHandlingXBM); \
  NS_IMETHOD GetIsHandlingBMP(PRBool *aIsHandlingBMP); \
  NS_IMETHOD SetIsHandlingBMP(PRBool aIsHandlingBMP); \
  NS_IMETHOD GetIsHandlingICO(PRBool *aIsHandlingICO); \
  NS_IMETHOD SetIsHandlingICO(PRBool aIsHandlingICO); \
  NS_IMETHOD GetIsHandlingXML(PRBool *aIsHandlingXML); \
  NS_IMETHOD SetIsHandlingXML(PRBool aIsHandlingXML); \
  NS_IMETHOD GetIsHandlingXHTML(PRBool *aIsHandlingXHTML); \
  NS_IMETHOD SetIsHandlingXHTML(PRBool aIsHandlingXHTML); \
  NS_IMETHOD GetIsHandlingXUL(PRBool *aIsHandlingXUL); \
  NS_IMETHOD SetIsHandlingXUL(PRBool aIsHandlingXUL); \
  NS_IMETHOD GetShowDialog(PRBool *aShowDialog); \
  NS_IMETHOD SetShowDialog(PRBool aShowDialog); \
  NS_IMETHOD GetRegistryMatches(PRBool *aRegistryMatches); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIWINDOWSHOOKSSETTINGS(_to) \
  NS_IMETHOD GetIsHandlingHTTP(PRBool *aIsHandlingHTTP) { return _to GetIsHandlingHTTP(aIsHandlingHTTP); } \
  NS_IMETHOD SetIsHandlingHTTP(PRBool aIsHandlingHTTP) { return _to SetIsHandlingHTTP(aIsHandlingHTTP); } \
  NS_IMETHOD GetIsHandlingHTTPS(PRBool *aIsHandlingHTTPS) { return _to GetIsHandlingHTTPS(aIsHandlingHTTPS); } \
  NS_IMETHOD SetIsHandlingHTTPS(PRBool aIsHandlingHTTPS) { return _to SetIsHandlingHTTPS(aIsHandlingHTTPS); } \
  NS_IMETHOD GetIsHandlingFTP(PRBool *aIsHandlingFTP) { return _to GetIsHandlingFTP(aIsHandlingFTP); } \
  NS_IMETHOD SetIsHandlingFTP(PRBool aIsHandlingFTP) { return _to SetIsHandlingFTP(aIsHandlingFTP); } \
  NS_IMETHOD GetIsHandlingCHROME(PRBool *aIsHandlingCHROME) { return _to GetIsHandlingCHROME(aIsHandlingCHROME); } \
  NS_IMETHOD SetIsHandlingCHROME(PRBool aIsHandlingCHROME) { return _to SetIsHandlingCHROME(aIsHandlingCHROME); } \
  NS_IMETHOD GetIsHandlingGOPHER(PRBool *aIsHandlingGOPHER) { return _to GetIsHandlingGOPHER(aIsHandlingGOPHER); } \
  NS_IMETHOD SetIsHandlingGOPHER(PRBool aIsHandlingGOPHER) { return _to SetIsHandlingGOPHER(aIsHandlingGOPHER); } \
  NS_IMETHOD GetIsHandlingHTML(PRBool *aIsHandlingHTML) { return _to GetIsHandlingHTML(aIsHandlingHTML); } \
  NS_IMETHOD SetIsHandlingHTML(PRBool aIsHandlingHTML) { return _to SetIsHandlingHTML(aIsHandlingHTML); } \
  NS_IMETHOD GetIsHandlingJPEG(PRBool *aIsHandlingJPEG) { return _to GetIsHandlingJPEG(aIsHandlingJPEG); } \
  NS_IMETHOD SetIsHandlingJPEG(PRBool aIsHandlingJPEG) { return _to SetIsHandlingJPEG(aIsHandlingJPEG); } \
  NS_IMETHOD GetIsHandlingGIF(PRBool *aIsHandlingGIF) { return _to GetIsHandlingGIF(aIsHandlingGIF); } \
  NS_IMETHOD SetIsHandlingGIF(PRBool aIsHandlingGIF) { return _to SetIsHandlingGIF(aIsHandlingGIF); } \
  NS_IMETHOD GetIsHandlingPNG(PRBool *aIsHandlingPNG) { return _to GetIsHandlingPNG(aIsHandlingPNG); } \
  NS_IMETHOD SetIsHandlingPNG(PRBool aIsHandlingPNG) { return _to SetIsHandlingPNG(aIsHandlingPNG); } \
  NS_IMETHOD GetIsHandlingMNG(PRBool *aIsHandlingMNG) { return _to GetIsHandlingMNG(aIsHandlingMNG); } \
  NS_IMETHOD SetIsHandlingMNG(PRBool aIsHandlingMNG) { return _to SetIsHandlingMNG(aIsHandlingMNG); } \
  NS_IMETHOD GetIsHandlingXBM(PRBool *aIsHandlingXBM) { return _to GetIsHandlingXBM(aIsHandlingXBM); } \
  NS_IMETHOD SetIsHandlingXBM(PRBool aIsHandlingXBM) { return _to SetIsHandlingXBM(aIsHandlingXBM); } \
  NS_IMETHOD GetIsHandlingBMP(PRBool *aIsHandlingBMP) { return _to GetIsHandlingBMP(aIsHandlingBMP); } \
  NS_IMETHOD SetIsHandlingBMP(PRBool aIsHandlingBMP) { return _to SetIsHandlingBMP(aIsHandlingBMP); } \
  NS_IMETHOD GetIsHandlingICO(PRBool *aIsHandlingICO) { return _to GetIsHandlingICO(aIsHandlingICO); } \
  NS_IMETHOD SetIsHandlingICO(PRBool aIsHandlingICO) { return _to SetIsHandlingICO(aIsHandlingICO); } \
  NS_IMETHOD GetIsHandlingXML(PRBool *aIsHandlingXML) { return _to GetIsHandlingXML(aIsHandlingXML); } \
  NS_IMETHOD SetIsHandlingXML(PRBool aIsHandlingXML) { return _to SetIsHandlingXML(aIsHandlingXML); } \
  NS_IMETHOD GetIsHandlingXHTML(PRBool *aIsHandlingXHTML) { return _to GetIsHandlingXHTML(aIsHandlingXHTML); } \
  NS_IMETHOD SetIsHandlingXHTML(PRBool aIsHandlingXHTML) { return _to SetIsHandlingXHTML(aIsHandlingXHTML); } \
  NS_IMETHOD GetIsHandlingXUL(PRBool *aIsHandlingXUL) { return _to GetIsHandlingXUL(aIsHandlingXUL); } \
  NS_IMETHOD SetIsHandlingXUL(PRBool aIsHandlingXUL) { return _to SetIsHandlingXUL(aIsHandlingXUL); } \
  NS_IMETHOD GetShowDialog(PRBool *aShowDialog) { return _to GetShowDialog(aShowDialog); } \
  NS_IMETHOD SetShowDialog(PRBool aShowDialog) { return _to SetShowDialog(aShowDialog); } \
  NS_IMETHOD GetRegistryMatches(PRBool *aRegistryMatches) { return _to GetRegistryMatches(aRegistryMatches); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIWINDOWSHOOKSSETTINGS(_to) \
  NS_IMETHOD GetIsHandlingHTTP(PRBool *aIsHandlingHTTP) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingHTTP(aIsHandlingHTTP); } \
  NS_IMETHOD SetIsHandlingHTTP(PRBool aIsHandlingHTTP) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingHTTP(aIsHandlingHTTP); } \
  NS_IMETHOD GetIsHandlingHTTPS(PRBool *aIsHandlingHTTPS) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingHTTPS(aIsHandlingHTTPS); } \
  NS_IMETHOD SetIsHandlingHTTPS(PRBool aIsHandlingHTTPS) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingHTTPS(aIsHandlingHTTPS); } \
  NS_IMETHOD GetIsHandlingFTP(PRBool *aIsHandlingFTP) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingFTP(aIsHandlingFTP); } \
  NS_IMETHOD SetIsHandlingFTP(PRBool aIsHandlingFTP) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingFTP(aIsHandlingFTP); } \
  NS_IMETHOD GetIsHandlingCHROME(PRBool *aIsHandlingCHROME) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingCHROME(aIsHandlingCHROME); } \
  NS_IMETHOD SetIsHandlingCHROME(PRBool aIsHandlingCHROME) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingCHROME(aIsHandlingCHROME); } \
  NS_IMETHOD GetIsHandlingGOPHER(PRBool *aIsHandlingGOPHER) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingGOPHER(aIsHandlingGOPHER); } \
  NS_IMETHOD SetIsHandlingGOPHER(PRBool aIsHandlingGOPHER) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingGOPHER(aIsHandlingGOPHER); } \
  NS_IMETHOD GetIsHandlingHTML(PRBool *aIsHandlingHTML) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingHTML(aIsHandlingHTML); } \
  NS_IMETHOD SetIsHandlingHTML(PRBool aIsHandlingHTML) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingHTML(aIsHandlingHTML); } \
  NS_IMETHOD GetIsHandlingJPEG(PRBool *aIsHandlingJPEG) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingJPEG(aIsHandlingJPEG); } \
  NS_IMETHOD SetIsHandlingJPEG(PRBool aIsHandlingJPEG) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingJPEG(aIsHandlingJPEG); } \
  NS_IMETHOD GetIsHandlingGIF(PRBool *aIsHandlingGIF) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingGIF(aIsHandlingGIF); } \
  NS_IMETHOD SetIsHandlingGIF(PRBool aIsHandlingGIF) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingGIF(aIsHandlingGIF); } \
  NS_IMETHOD GetIsHandlingPNG(PRBool *aIsHandlingPNG) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingPNG(aIsHandlingPNG); } \
  NS_IMETHOD SetIsHandlingPNG(PRBool aIsHandlingPNG) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingPNG(aIsHandlingPNG); } \
  NS_IMETHOD GetIsHandlingMNG(PRBool *aIsHandlingMNG) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingMNG(aIsHandlingMNG); } \
  NS_IMETHOD SetIsHandlingMNG(PRBool aIsHandlingMNG) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingMNG(aIsHandlingMNG); } \
  NS_IMETHOD GetIsHandlingXBM(PRBool *aIsHandlingXBM) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingXBM(aIsHandlingXBM); } \
  NS_IMETHOD SetIsHandlingXBM(PRBool aIsHandlingXBM) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingXBM(aIsHandlingXBM); } \
  NS_IMETHOD GetIsHandlingBMP(PRBool *aIsHandlingBMP) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingBMP(aIsHandlingBMP); } \
  NS_IMETHOD SetIsHandlingBMP(PRBool aIsHandlingBMP) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingBMP(aIsHandlingBMP); } \
  NS_IMETHOD GetIsHandlingICO(PRBool *aIsHandlingICO) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingICO(aIsHandlingICO); } \
  NS_IMETHOD SetIsHandlingICO(PRBool aIsHandlingICO) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingICO(aIsHandlingICO); } \
  NS_IMETHOD GetIsHandlingXML(PRBool *aIsHandlingXML) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingXML(aIsHandlingXML); } \
  NS_IMETHOD SetIsHandlingXML(PRBool aIsHandlingXML) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingXML(aIsHandlingXML); } \
  NS_IMETHOD GetIsHandlingXHTML(PRBool *aIsHandlingXHTML) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingXHTML(aIsHandlingXHTML); } \
  NS_IMETHOD SetIsHandlingXHTML(PRBool aIsHandlingXHTML) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingXHTML(aIsHandlingXHTML); } \
  NS_IMETHOD GetIsHandlingXUL(PRBool *aIsHandlingXUL) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsHandlingXUL(aIsHandlingXUL); } \
  NS_IMETHOD SetIsHandlingXUL(PRBool aIsHandlingXUL) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsHandlingXUL(aIsHandlingXUL); } \
  NS_IMETHOD GetShowDialog(PRBool *aShowDialog) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetShowDialog(aShowDialog); } \
  NS_IMETHOD SetShowDialog(PRBool aShowDialog) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetShowDialog(aShowDialog); } \
  NS_IMETHOD GetRegistryMatches(PRBool *aRegistryMatches) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetRegistryMatches(aRegistryMatches); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsWindowsHooksSettings : public nsIWindowsHooksSettings
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIWINDOWSHOOKSSETTINGS

  nsWindowsHooksSettings();

private:
  ~nsWindowsHooksSettings();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsWindowsHooksSettings, nsIWindowsHooksSettings)

nsWindowsHooksSettings::nsWindowsHooksSettings()
{
  /* member initializers and constructor code */
}

nsWindowsHooksSettings::~nsWindowsHooksSettings()
{
  /* destructor code */
}

/* attribute boolean isHandlingHTTP; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingHTTP(PRBool *aIsHandlingHTTP)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingHTTP(PRBool aIsHandlingHTTP)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingHTTPS; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingHTTPS(PRBool *aIsHandlingHTTPS)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingHTTPS(PRBool aIsHandlingHTTPS)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingFTP; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingFTP(PRBool *aIsHandlingFTP)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingFTP(PRBool aIsHandlingFTP)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingCHROME; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingCHROME(PRBool *aIsHandlingCHROME)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingCHROME(PRBool aIsHandlingCHROME)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingGOPHER; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingGOPHER(PRBool *aIsHandlingGOPHER)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingGOPHER(PRBool aIsHandlingGOPHER)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingHTML; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingHTML(PRBool *aIsHandlingHTML)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingHTML(PRBool aIsHandlingHTML)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingJPEG; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingJPEG(PRBool *aIsHandlingJPEG)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingJPEG(PRBool aIsHandlingJPEG)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingGIF; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingGIF(PRBool *aIsHandlingGIF)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingGIF(PRBool aIsHandlingGIF)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingPNG; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingPNG(PRBool *aIsHandlingPNG)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingPNG(PRBool aIsHandlingPNG)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingMNG; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingMNG(PRBool *aIsHandlingMNG)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingMNG(PRBool aIsHandlingMNG)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingXBM; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingXBM(PRBool *aIsHandlingXBM)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingXBM(PRBool aIsHandlingXBM)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingBMP; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingBMP(PRBool *aIsHandlingBMP)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingBMP(PRBool aIsHandlingBMP)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingICO; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingICO(PRBool *aIsHandlingICO)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingICO(PRBool aIsHandlingICO)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingXML; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingXML(PRBool *aIsHandlingXML)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingXML(PRBool aIsHandlingXML)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingXHTML; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingXHTML(PRBool *aIsHandlingXHTML)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingXHTML(PRBool aIsHandlingXHTML)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean isHandlingXUL; */
NS_IMETHODIMP nsWindowsHooksSettings::GetIsHandlingXUL(PRBool *aIsHandlingXUL)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetIsHandlingXUL(PRBool aIsHandlingXUL)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute boolean showDialog; */
NS_IMETHODIMP nsWindowsHooksSettings::GetShowDialog(PRBool *aShowDialog)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooksSettings::SetShowDialog(PRBool aShowDialog)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean registryMatches; */
NS_IMETHODIMP nsWindowsHooksSettings::GetRegistryMatches(PRBool *aRegistryMatches)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIWindowsHooks */
#define NS_IWINDOWSHOOKS_IID_STR "19c9fbb0-06a3-11d4-8076-00600811a9c3"

#define NS_IWINDOWSHOOKS_IID \
  {0x19c9fbb0, 0x06a3, 0x11d4, \
    { 0x80, 0x76, 0x00, 0x60, 0x08, 0x11, 0xa9, 0xc3 }}

class NS_NO_VTABLE nsIWindowsHooks : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IWINDOWSHOOKS_IID)

  /* attribute nsIWindowsHooksSettings settings; */
  NS_IMETHOD GetSettings(nsIWindowsHooksSettings * *aSettings) = 0;
  NS_IMETHOD SetSettings(nsIWindowsHooksSettings * aSettings) = 0;

  /* boolean checkSettings (in nsIDOMWindowInternal aParent); */
  NS_IMETHOD CheckSettings(nsIDOMWindowInternal *aParent, PRBool *_retval) = 0;

  /**
     * Returns true if command is in the "(appname) QuickLaunch" value in the
     * HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run
     * key.
     */
  /* boolean isOptionEnabled (in string option); */
  NS_IMETHOD IsOptionEnabled(const char *option, PRBool *_retval) = 0;

  /**
     * Adds the option to the "(appname) QuickLaunch" value to the key mentioned above,
     * with data "(path\to\app.exe) option", if not done already.
     */
  /* void startupAddOption (in string option); */
  NS_IMETHOD StartupAddOption(const char *option) = 0;

  /**
     * Removes the commnand from the "(appname) QuickLaunch" value from
	 * the key mentioned above, if not done already. And deletes the
	 * "(appname) QuickLaunch" value entirely if there are no options left
     */
  /* void startupRemoveOption (in string option); */
  NS_IMETHOD StartupRemoveOption(const char *option) = 0;

  /**
     * Accepts an element, either an HTML img element or an element with
     * a background image, serializes the image to a bitmap file
     * in the windows directory, and sets it to be the desktop wallpaper.
     */
  /* void setImageAsWallpaper (in nsIDOMElement aImageElement, in boolean useBackground); */
  NS_IMETHOD SetImageAsWallpaper(nsIDOMElement *aImageElement, PRBool useBackground) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIWINDOWSHOOKS \
  NS_IMETHOD GetSettings(nsIWindowsHooksSettings * *aSettings); \
  NS_IMETHOD SetSettings(nsIWindowsHooksSettings * aSettings); \
  NS_IMETHOD CheckSettings(nsIDOMWindowInternal *aParent, PRBool *_retval); \
  NS_IMETHOD IsOptionEnabled(const char *option, PRBool *_retval); \
  NS_IMETHOD StartupAddOption(const char *option); \
  NS_IMETHOD StartupRemoveOption(const char *option); \
  NS_IMETHOD SetImageAsWallpaper(nsIDOMElement *aImageElement, PRBool useBackground); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIWINDOWSHOOKS(_to) \
  NS_IMETHOD GetSettings(nsIWindowsHooksSettings * *aSettings) { return _to GetSettings(aSettings); } \
  NS_IMETHOD SetSettings(nsIWindowsHooksSettings * aSettings) { return _to SetSettings(aSettings); } \
  NS_IMETHOD CheckSettings(nsIDOMWindowInternal *aParent, PRBool *_retval) { return _to CheckSettings(aParent, _retval); } \
  NS_IMETHOD IsOptionEnabled(const char *option, PRBool *_retval) { return _to IsOptionEnabled(option, _retval); } \
  NS_IMETHOD StartupAddOption(const char *option) { return _to StartupAddOption(option); } \
  NS_IMETHOD StartupRemoveOption(const char *option) { return _to StartupRemoveOption(option); } \
  NS_IMETHOD SetImageAsWallpaper(nsIDOMElement *aImageElement, PRBool useBackground) { return _to SetImageAsWallpaper(aImageElement, useBackground); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIWINDOWSHOOKS(_to) \
  NS_IMETHOD GetSettings(nsIWindowsHooksSettings * *aSettings) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSettings(aSettings); } \
  NS_IMETHOD SetSettings(nsIWindowsHooksSettings * aSettings) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSettings(aSettings); } \
  NS_IMETHOD CheckSettings(nsIDOMWindowInternal *aParent, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CheckSettings(aParent, _retval); } \
  NS_IMETHOD IsOptionEnabled(const char *option, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsOptionEnabled(option, _retval); } \
  NS_IMETHOD StartupAddOption(const char *option) { return !_to ? NS_ERROR_NULL_POINTER : _to->StartupAddOption(option); } \
  NS_IMETHOD StartupRemoveOption(const char *option) { return !_to ? NS_ERROR_NULL_POINTER : _to->StartupRemoveOption(option); } \
  NS_IMETHOD SetImageAsWallpaper(nsIDOMElement *aImageElement, PRBool useBackground) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetImageAsWallpaper(aImageElement, useBackground); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsWindowsHooks : public nsIWindowsHooks
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIWINDOWSHOOKS

  nsWindowsHooks();

private:
  ~nsWindowsHooks();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsWindowsHooks, nsIWindowsHooks)

nsWindowsHooks::nsWindowsHooks()
{
  /* member initializers and constructor code */
}

nsWindowsHooks::~nsWindowsHooks()
{
  /* destructor code */
}

/* attribute nsIWindowsHooksSettings settings; */
NS_IMETHODIMP nsWindowsHooks::GetSettings(nsIWindowsHooksSettings * *aSettings)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsWindowsHooks::SetSettings(nsIWindowsHooksSettings * aSettings)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean checkSettings (in nsIDOMWindowInternal aParent); */
NS_IMETHODIMP nsWindowsHooks::CheckSettings(nsIDOMWindowInternal *aParent, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean isOptionEnabled (in string option); */
NS_IMETHODIMP nsWindowsHooks::IsOptionEnabled(const char *option, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void startupAddOption (in string option); */
NS_IMETHODIMP nsWindowsHooks::StartupAddOption(const char *option)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void startupRemoveOption (in string option); */
NS_IMETHODIMP nsWindowsHooks::StartupRemoveOption(const char *option)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setImageAsWallpaper (in nsIDOMElement aImageElement, in boolean useBackground); */
NS_IMETHODIMP nsWindowsHooks::SetImageAsWallpaper(nsIDOMElement *aImageElement, PRBool useBackground)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

#define NS_IWINDOWSHOOKS_CONTRACTID    "@mozilla.org/winhooks;1"
#define NS_IWINDOWSHOOKS_CLASSNAME "Mozilla Windows Integration Hooks"
// The key that is used to write the quick launch appname in the windows registry
#define NS_QUICKLAUNCH_RUN_KEY "Mozilla Quick Launch"

#endif /* __gen_nsIWindowsHooks_h__ */
