/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM g:/src/moz/wntmsci11.pro/misc/build/mozilla/I_objdir/xpfe/components/startup/public/../../../../../xpfe/components/startup/public/nsINativeAppSupportWin.idl
 */

#ifndef __gen_nsINativeAppSupportWin_h__
#define __gen_nsINativeAppSupportWin_h__
/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
// Constants identifying Win32 "native" resources.
#ifdef MOZ_PHOENIX
// Splash screen dialog ID.
#define IDD_SPLASH  100
// Splash screen bitmap ID.
#define IDB_SPLASH  101
// DDE application name
#define ID_DDE_APPLICATION_NAME 102
#define IDI_APPICON 0
#define IDI_DOCUMENT 1
#endif
// String that goes in the WinXP Start Menu.
#define IDS_STARTMENU_APPNAME 103

#endif /* __gen_nsINativeAppSupportWin_h__ */
