/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM ../../../../mailnews/addrbook/public/nsIAbDirectory.idl
 */

#ifndef __gen_nsIAbDirectory_h__
#define __gen_nsIAbDirectory_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAbCard_h__
#include "nsIAbCard.h"
#endif

#ifndef __gen_nsISupportsArray_h__
#include "nsISupportsArray.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
#include "nsFileSpec.h"
#include "nsDirPrefs.h"

/* starting interface:    nsIAbDirectoryProperties */
#define NS_IABDIRECTORYPROPERTIES_IID_STR "f94812de-1dd1-11b2-b0ab-9eb5e055f712"

#define NS_IABDIRECTORYPROPERTIES_IID \
  {0xf94812de, 0x1dd1, 0x11b2, \
    { 0xb0, 0xab, 0x9e, 0xb5, 0xe0, 0x55, 0xf7, 0x12 }}

class NS_NO_VTABLE nsIAbDirectoryProperties : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABDIRECTORYPROPERTIES_IID)

  /* attribute AString description; */
  NS_IMETHOD GetDescription(nsAString & aDescription) = 0;
  NS_IMETHOD SetDescription(const nsAString & aDescription) = 0;

  /* attribute string URI; */
  NS_IMETHOD GetURI(char * *aURI) = 0;
  NS_IMETHOD SetURI(const char * aURI) = 0;

  /* attribute string prefName; */
  NS_IMETHOD GetPrefName(char * *aPrefName) = 0;
  NS_IMETHOD SetPrefName(const char * aPrefName) = 0;

  /* attribute string fileName; */
  NS_IMETHOD GetFileName(char * *aFileName) = 0;
  NS_IMETHOD SetFileName(const char * aFileName) = 0;

  /* attribute unsigned long dirType; */
  NS_IMETHOD GetDirType(PRUint32 *aDirType) = 0;
  NS_IMETHOD SetDirType(PRUint32 aDirType) = 0;

  /* attribute unsigned long maxHits; */
  NS_IMETHOD GetMaxHits(PRUint32 *aMaxHits) = 0;
  NS_IMETHOD SetMaxHits(PRUint32 aMaxHits) = 0;

  /* attribute string authDn; */
  NS_IMETHOD GetAuthDn(char * *aAuthDn) = 0;
  NS_IMETHOD SetAuthDn(const char * aAuthDn) = 0;

  /* attribute unsigned long syncTimeStamp; */
  NS_IMETHOD GetSyncTimeStamp(PRUint32 *aSyncTimeStamp) = 0;
  NS_IMETHOD SetSyncTimeStamp(PRUint32 aSyncTimeStamp) = 0;

  /* attribute long categoryId; */
  NS_IMETHOD GetCategoryId(PRInt32 *aCategoryId) = 0;
  NS_IMETHOD SetCategoryId(PRInt32 aCategoryId) = 0;

  /* attribute long position; */
  NS_IMETHOD GetPosition(PRInt32 *aPosition) = 0;
  NS_IMETHOD SetPosition(PRInt32 aPosition) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABDIRECTORYPROPERTIES \
  NS_IMETHOD GetDescription(nsAString & aDescription); \
  NS_IMETHOD SetDescription(const nsAString & aDescription); \
  NS_IMETHOD GetURI(char * *aURI); \
  NS_IMETHOD SetURI(const char * aURI); \
  NS_IMETHOD GetPrefName(char * *aPrefName); \
  NS_IMETHOD SetPrefName(const char * aPrefName); \
  NS_IMETHOD GetFileName(char * *aFileName); \
  NS_IMETHOD SetFileName(const char * aFileName); \
  NS_IMETHOD GetDirType(PRUint32 *aDirType); \
  NS_IMETHOD SetDirType(PRUint32 aDirType); \
  NS_IMETHOD GetMaxHits(PRUint32 *aMaxHits); \
  NS_IMETHOD SetMaxHits(PRUint32 aMaxHits); \
  NS_IMETHOD GetAuthDn(char * *aAuthDn); \
  NS_IMETHOD SetAuthDn(const char * aAuthDn); \
  NS_IMETHOD GetSyncTimeStamp(PRUint32 *aSyncTimeStamp); \
  NS_IMETHOD SetSyncTimeStamp(PRUint32 aSyncTimeStamp); \
  NS_IMETHOD GetCategoryId(PRInt32 *aCategoryId); \
  NS_IMETHOD SetCategoryId(PRInt32 aCategoryId); \
  NS_IMETHOD GetPosition(PRInt32 *aPosition); \
  NS_IMETHOD SetPosition(PRInt32 aPosition); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABDIRECTORYPROPERTIES(_to) \
  NS_IMETHOD GetDescription(nsAString & aDescription) { return _to GetDescription(aDescription); } \
  NS_IMETHOD SetDescription(const nsAString & aDescription) { return _to SetDescription(aDescription); } \
  NS_IMETHOD GetURI(char * *aURI) { return _to GetURI(aURI); } \
  NS_IMETHOD SetURI(const char * aURI) { return _to SetURI(aURI); } \
  NS_IMETHOD GetPrefName(char * *aPrefName) { return _to GetPrefName(aPrefName); } \
  NS_IMETHOD SetPrefName(const char * aPrefName) { return _to SetPrefName(aPrefName); } \
  NS_IMETHOD GetFileName(char * *aFileName) { return _to GetFileName(aFileName); } \
  NS_IMETHOD SetFileName(const char * aFileName) { return _to SetFileName(aFileName); } \
  NS_IMETHOD GetDirType(PRUint32 *aDirType) { return _to GetDirType(aDirType); } \
  NS_IMETHOD SetDirType(PRUint32 aDirType) { return _to SetDirType(aDirType); } \
  NS_IMETHOD GetMaxHits(PRUint32 *aMaxHits) { return _to GetMaxHits(aMaxHits); } \
  NS_IMETHOD SetMaxHits(PRUint32 aMaxHits) { return _to SetMaxHits(aMaxHits); } \
  NS_IMETHOD GetAuthDn(char * *aAuthDn) { return _to GetAuthDn(aAuthDn); } \
  NS_IMETHOD SetAuthDn(const char * aAuthDn) { return _to SetAuthDn(aAuthDn); } \
  NS_IMETHOD GetSyncTimeStamp(PRUint32 *aSyncTimeStamp) { return _to GetSyncTimeStamp(aSyncTimeStamp); } \
  NS_IMETHOD SetSyncTimeStamp(PRUint32 aSyncTimeStamp) { return _to SetSyncTimeStamp(aSyncTimeStamp); } \
  NS_IMETHOD GetCategoryId(PRInt32 *aCategoryId) { return _to GetCategoryId(aCategoryId); } \
  NS_IMETHOD SetCategoryId(PRInt32 aCategoryId) { return _to SetCategoryId(aCategoryId); } \
  NS_IMETHOD GetPosition(PRInt32 *aPosition) { return _to GetPosition(aPosition); } \
  NS_IMETHOD SetPosition(PRInt32 aPosition) { return _to SetPosition(aPosition); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABDIRECTORYPROPERTIES(_to) \
  NS_IMETHOD GetDescription(nsAString & aDescription) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDescription(aDescription); } \
  NS_IMETHOD SetDescription(const nsAString & aDescription) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDescription(aDescription); } \
  NS_IMETHOD GetURI(char * *aURI) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetURI(aURI); } \
  NS_IMETHOD SetURI(const char * aURI) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetURI(aURI); } \
  NS_IMETHOD GetPrefName(char * *aPrefName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPrefName(aPrefName); } \
  NS_IMETHOD SetPrefName(const char * aPrefName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPrefName(aPrefName); } \
  NS_IMETHOD GetFileName(char * *aFileName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetFileName(aFileName); } \
  NS_IMETHOD SetFileName(const char * aFileName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetFileName(aFileName); } \
  NS_IMETHOD GetDirType(PRUint32 *aDirType) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDirType(aDirType); } \
  NS_IMETHOD SetDirType(PRUint32 aDirType) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDirType(aDirType); } \
  NS_IMETHOD GetMaxHits(PRUint32 *aMaxHits) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMaxHits(aMaxHits); } \
  NS_IMETHOD SetMaxHits(PRUint32 aMaxHits) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetMaxHits(aMaxHits); } \
  NS_IMETHOD GetAuthDn(char * *aAuthDn) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAuthDn(aAuthDn); } \
  NS_IMETHOD SetAuthDn(const char * aAuthDn) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAuthDn(aAuthDn); } \
  NS_IMETHOD GetSyncTimeStamp(PRUint32 *aSyncTimeStamp) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSyncTimeStamp(aSyncTimeStamp); } \
  NS_IMETHOD SetSyncTimeStamp(PRUint32 aSyncTimeStamp) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSyncTimeStamp(aSyncTimeStamp); } \
  NS_IMETHOD GetCategoryId(PRInt32 *aCategoryId) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCategoryId(aCategoryId); } \
  NS_IMETHOD SetCategoryId(PRInt32 aCategoryId) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCategoryId(aCategoryId); } \
  NS_IMETHOD GetPosition(PRInt32 *aPosition) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetPosition(aPosition); } \
  NS_IMETHOD SetPosition(PRInt32 aPosition) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetPosition(aPosition); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbDirectoryProperties : public nsIAbDirectoryProperties
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABDIRECTORYPROPERTIES

  nsAbDirectoryProperties();

private:
  ~nsAbDirectoryProperties();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbDirectoryProperties, nsIAbDirectoryProperties)

nsAbDirectoryProperties::nsAbDirectoryProperties()
{
  /* member initializers and constructor code */
}

nsAbDirectoryProperties::~nsAbDirectoryProperties()
{
  /* destructor code */
}

/* attribute AString description; */
NS_IMETHODIMP nsAbDirectoryProperties::GetDescription(nsAString & aDescription)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectoryProperties::SetDescription(const nsAString & aDescription)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute string URI; */
NS_IMETHODIMP nsAbDirectoryProperties::GetURI(char * *aURI)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectoryProperties::SetURI(const char * aURI)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute string prefName; */
NS_IMETHODIMP nsAbDirectoryProperties::GetPrefName(char * *aPrefName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectoryProperties::SetPrefName(const char * aPrefName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute string fileName; */
NS_IMETHODIMP nsAbDirectoryProperties::GetFileName(char * *aFileName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectoryProperties::SetFileName(const char * aFileName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long dirType; */
NS_IMETHODIMP nsAbDirectoryProperties::GetDirType(PRUint32 *aDirType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectoryProperties::SetDirType(PRUint32 aDirType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long maxHits; */
NS_IMETHODIMP nsAbDirectoryProperties::GetMaxHits(PRUint32 *aMaxHits)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectoryProperties::SetMaxHits(PRUint32 aMaxHits)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute string authDn; */
NS_IMETHODIMP nsAbDirectoryProperties::GetAuthDn(char * *aAuthDn)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectoryProperties::SetAuthDn(const char * aAuthDn)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long syncTimeStamp; */
NS_IMETHODIMP nsAbDirectoryProperties::GetSyncTimeStamp(PRUint32 *aSyncTimeStamp)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectoryProperties::SetSyncTimeStamp(PRUint32 aSyncTimeStamp)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute long categoryId; */
NS_IMETHODIMP nsAbDirectoryProperties::GetCategoryId(PRInt32 *aCategoryId)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectoryProperties::SetCategoryId(PRInt32 aCategoryId)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute long position; */
NS_IMETHODIMP nsAbDirectoryProperties::GetPosition(PRInt32 *aPosition)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectoryProperties::SetPosition(PRInt32 aPosition)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbDirectory */
#define NS_IABDIRECTORY_IID_STR "aa920c90-1dd1-11b2-96d3-aa81268adafc"

#define NS_IABDIRECTORY_IID \
  {0xaa920c90, 0x1dd1, 0x11b2, \
    { 0x96, 0xd3, 0xaa, 0x81, 0x26, 0x8a, 0xda, 0xfc }}

class NS_NO_VTABLE nsIAbDirectory : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABDIRECTORY_IID)

  enum { opRead = 1 };

  enum { opWrite = 2 };

  enum { opSearch = 4 };

  /* readonly attribute long operations; */
  NS_IMETHOD GetOperations(PRInt32 *aOperations) = 0;

  /* attribute wstring dirName; */
  NS_IMETHOD GetDirName(PRUnichar * *aDirName) = 0;
  NS_IMETHOD SetDirName(const PRUnichar * aDirName) = 0;

  /* attribute unsigned long lastModifiedDate; */
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate) = 0;
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate) = 0;

  /* attribute PRBool isMailList; */
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList) = 0;
  NS_IMETHOD SetIsMailList(PRBool aIsMailList) = 0;

  /* readonly attribute nsIAbDirectoryProperties directoryProperties; */
  NS_IMETHOD GetDirectoryProperties(nsIAbDirectoryProperties * *aDirectoryProperties) = 0;

  /* readonly attribute nsISimpleEnumerator childNodes; */
  NS_IMETHOD GetChildNodes(nsISimpleEnumerator * *aChildNodes) = 0;

  /* readonly attribute nsIEnumerator childCards; */
  NS_IMETHOD GetChildCards(nsIEnumerator * *aChildCards) = 0;

  /* void modifyDirectory (in nsIAbDirectory directory, in nsIAbDirectoryProperties aProperties); */
  NS_IMETHOD ModifyDirectory(nsIAbDirectory *directory, nsIAbDirectoryProperties *aProperties) = 0;

  /* void deleteDirectory (in nsIAbDirectory dierctory); */
  NS_IMETHOD DeleteDirectory(nsIAbDirectory *dierctory) = 0;

  /* void deleteCards (in nsISupportsArray cards); */
  NS_IMETHOD DeleteCards(nsISupportsArray *cards) = 0;

  /* boolean hasCard (in nsIAbCard cards); */
  NS_IMETHOD HasCard(nsIAbCard *cards, PRBool *_retval) = 0;

  /* boolean hasDirectory (in nsIAbDirectory dir); */
  NS_IMETHOD HasDirectory(nsIAbDirectory *dir, PRBool *_retval) = 0;

  /**
     * return value is the card that got added
     * we need to do this, as the card we pass in might
     * be an abstract nsIAbCard, and the caller might need
     * the "real" card (the mdbcard) to get / set 
     * non-standard card values
     */
  /* nsIAbCard addCard (in nsIAbCard card); */
  NS_IMETHOD AddCard(nsIAbCard *card, nsIAbCard **_retval) = 0;

  /* void dropCard (in nsIAbCard card, in boolean needToCopyCard); */
  NS_IMETHOD DropCard(nsIAbCard *card, PRBool needToCopyCard) = 0;

  /**
     * directory is local (example, mork based) or remote (example, LDAP)
     */
  /* readonly attribute boolean isRemote; */
  NS_IMETHOD GetIsRemote(PRBool *aIsRemote) = 0;

  /**
     * directory is secure (as in LDAP over SSL)
     */
  /* readonly attribute boolean isSecure; */
  NS_IMETHOD GetIsSecure(PRBool *aIsSecure) = 0;

  /**
     * directory should be searched when doing local autocomplete
     */
  /* readonly attribute boolean searchDuringLocalAutocomplete; */
  NS_IMETHOD GetSearchDuringLocalAutocomplete(PRBool *aSearchDuringLocalAutocomplete) = 0;

  /* readonly attribute boolean supportsMailingLists; */
  NS_IMETHOD GetSupportsMailingLists(PRBool *aSupportsMailingLists) = 0;

  /* attribute nsISupportsArray addressLists; */
  NS_IMETHOD GetAddressLists(nsISupportsArray * *aAddressLists) = 0;
  NS_IMETHOD SetAddressLists(nsISupportsArray * aAddressLists) = 0;

  /* void addMailList (in nsIAbDirectory list); */
  NS_IMETHOD AddMailList(nsIAbDirectory *list) = 0;

  /* void addMailListWithKey (in nsIAbDirectory list, out PRUint32 key); */
  NS_IMETHOD AddMailListWithKey(nsIAbDirectory *list, PRUint32 *key) = 0;

  /* attribute wstring listNickName; */
  NS_IMETHOD GetListNickName(PRUnichar * *aListNickName) = 0;
  NS_IMETHOD SetListNickName(const PRUnichar * aListNickName) = 0;

  /* attribute wstring description; */
  NS_IMETHOD GetDescription(PRUnichar * *aDescription) = 0;
  NS_IMETHOD SetDescription(const PRUnichar * aDescription) = 0;

  /**
     * Edits an existing mailing list (specified as listCard)
	 * into the directory specified by the uri
	 * XXX javadoc me
     */
  /* void editMailListToDatabase (in string uri, in nsIAbCard listCard); */
  NS_IMETHOD EditMailListToDatabase(const char *uri, nsIAbCard *listCard) = 0;

  /* void copyMailList (in nsIAbDirectory srcList); */
  NS_IMETHOD CopyMailList(nsIAbDirectory *srcList) = 0;

  /* void createNewDirectory (in nsIAbDirectoryProperties aProperties); */
  NS_IMETHOD CreateNewDirectory(nsIAbDirectoryProperties *aProperties) = 0;

  /* void createDirectoryByURI (in wstring displayName, in string uri, in boolean migrating); */
  NS_IMETHOD CreateDirectoryByURI(const PRUnichar *displayName, const char *uri, PRBool migrating) = 0;

  /* wstring getValueForCard (in nsIAbCard card, in string name); */
  NS_IMETHOD GetValueForCard(nsIAbCard *card, const char *name, PRUnichar **_retval) = 0;

  /* void setValueForCard (in nsIAbCard card, in string name, in wstring value); */
  NS_IMETHOD SetValueForCard(nsIAbCard *card, const char *name, const PRUnichar *value) = 0;

  /* attribute ACString dirPrefId; */
  NS_IMETHOD GetDirPrefId(nsACString & aDirPrefId) = 0;
  NS_IMETHOD SetDirPrefId(const nsACString & aDirPrefId) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABDIRECTORY \
  NS_IMETHOD GetOperations(PRInt32 *aOperations); \
  NS_IMETHOD GetDirName(PRUnichar * *aDirName); \
  NS_IMETHOD SetDirName(const PRUnichar * aDirName); \
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate); \
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate); \
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList); \
  NS_IMETHOD SetIsMailList(PRBool aIsMailList); \
  NS_IMETHOD GetDirectoryProperties(nsIAbDirectoryProperties * *aDirectoryProperties); \
  NS_IMETHOD GetChildNodes(nsISimpleEnumerator * *aChildNodes); \
  NS_IMETHOD GetChildCards(nsIEnumerator * *aChildCards); \
  NS_IMETHOD ModifyDirectory(nsIAbDirectory *directory, nsIAbDirectoryProperties *aProperties); \
  NS_IMETHOD DeleteDirectory(nsIAbDirectory *dierctory); \
  NS_IMETHOD DeleteCards(nsISupportsArray *cards); \
  NS_IMETHOD HasCard(nsIAbCard *cards, PRBool *_retval); \
  NS_IMETHOD HasDirectory(nsIAbDirectory *dir, PRBool *_retval); \
  NS_IMETHOD AddCard(nsIAbCard *card, nsIAbCard **_retval); \
  NS_IMETHOD DropCard(nsIAbCard *card, PRBool needToCopyCard); \
  NS_IMETHOD GetIsRemote(PRBool *aIsRemote); \
  NS_IMETHOD GetIsSecure(PRBool *aIsSecure); \
  NS_IMETHOD GetSearchDuringLocalAutocomplete(PRBool *aSearchDuringLocalAutocomplete); \
  NS_IMETHOD GetSupportsMailingLists(PRBool *aSupportsMailingLists); \
  NS_IMETHOD GetAddressLists(nsISupportsArray * *aAddressLists); \
  NS_IMETHOD SetAddressLists(nsISupportsArray * aAddressLists); \
  NS_IMETHOD AddMailList(nsIAbDirectory *list); \
  NS_IMETHOD AddMailListWithKey(nsIAbDirectory *list, PRUint32 *key); \
  NS_IMETHOD GetListNickName(PRUnichar * *aListNickName); \
  NS_IMETHOD SetListNickName(const PRUnichar * aListNickName); \
  NS_IMETHOD GetDescription(PRUnichar * *aDescription); \
  NS_IMETHOD SetDescription(const PRUnichar * aDescription); \
  NS_IMETHOD EditMailListToDatabase(const char *uri, nsIAbCard *listCard); \
  NS_IMETHOD CopyMailList(nsIAbDirectory *srcList); \
  NS_IMETHOD CreateNewDirectory(nsIAbDirectoryProperties *aProperties); \
  NS_IMETHOD CreateDirectoryByURI(const PRUnichar *displayName, const char *uri, PRBool migrating); \
  NS_IMETHOD GetValueForCard(nsIAbCard *card, const char *name, PRUnichar **_retval); \
  NS_IMETHOD SetValueForCard(nsIAbCard *card, const char *name, const PRUnichar *value); \
  NS_IMETHOD GetDirPrefId(nsACString & aDirPrefId); \
  NS_IMETHOD SetDirPrefId(const nsACString & aDirPrefId); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABDIRECTORY(_to) \
  NS_IMETHOD GetOperations(PRInt32 *aOperations) { return _to GetOperations(aOperations); } \
  NS_IMETHOD GetDirName(PRUnichar * *aDirName) { return _to GetDirName(aDirName); } \
  NS_IMETHOD SetDirName(const PRUnichar * aDirName) { return _to SetDirName(aDirName); } \
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate) { return _to GetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate) { return _to SetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList) { return _to GetIsMailList(aIsMailList); } \
  NS_IMETHOD SetIsMailList(PRBool aIsMailList) { return _to SetIsMailList(aIsMailList); } \
  NS_IMETHOD GetDirectoryProperties(nsIAbDirectoryProperties * *aDirectoryProperties) { return _to GetDirectoryProperties(aDirectoryProperties); } \
  NS_IMETHOD GetChildNodes(nsISimpleEnumerator * *aChildNodes) { return _to GetChildNodes(aChildNodes); } \
  NS_IMETHOD GetChildCards(nsIEnumerator * *aChildCards) { return _to GetChildCards(aChildCards); } \
  NS_IMETHOD ModifyDirectory(nsIAbDirectory *directory, nsIAbDirectoryProperties *aProperties) { return _to ModifyDirectory(directory, aProperties); } \
  NS_IMETHOD DeleteDirectory(nsIAbDirectory *dierctory) { return _to DeleteDirectory(dierctory); } \
  NS_IMETHOD DeleteCards(nsISupportsArray *cards) { return _to DeleteCards(cards); } \
  NS_IMETHOD HasCard(nsIAbCard *cards, PRBool *_retval) { return _to HasCard(cards, _retval); } \
  NS_IMETHOD HasDirectory(nsIAbDirectory *dir, PRBool *_retval) { return _to HasDirectory(dir, _retval); } \
  NS_IMETHOD AddCard(nsIAbCard *card, nsIAbCard **_retval) { return _to AddCard(card, _retval); } \
  NS_IMETHOD DropCard(nsIAbCard *card, PRBool needToCopyCard) { return _to DropCard(card, needToCopyCard); } \
  NS_IMETHOD GetIsRemote(PRBool *aIsRemote) { return _to GetIsRemote(aIsRemote); } \
  NS_IMETHOD GetIsSecure(PRBool *aIsSecure) { return _to GetIsSecure(aIsSecure); } \
  NS_IMETHOD GetSearchDuringLocalAutocomplete(PRBool *aSearchDuringLocalAutocomplete) { return _to GetSearchDuringLocalAutocomplete(aSearchDuringLocalAutocomplete); } \
  NS_IMETHOD GetSupportsMailingLists(PRBool *aSupportsMailingLists) { return _to GetSupportsMailingLists(aSupportsMailingLists); } \
  NS_IMETHOD GetAddressLists(nsISupportsArray * *aAddressLists) { return _to GetAddressLists(aAddressLists); } \
  NS_IMETHOD SetAddressLists(nsISupportsArray * aAddressLists) { return _to SetAddressLists(aAddressLists); } \
  NS_IMETHOD AddMailList(nsIAbDirectory *list) { return _to AddMailList(list); } \
  NS_IMETHOD AddMailListWithKey(nsIAbDirectory *list, PRUint32 *key) { return _to AddMailListWithKey(list, key); } \
  NS_IMETHOD GetListNickName(PRUnichar * *aListNickName) { return _to GetListNickName(aListNickName); } \
  NS_IMETHOD SetListNickName(const PRUnichar * aListNickName) { return _to SetListNickName(aListNickName); } \
  NS_IMETHOD GetDescription(PRUnichar * *aDescription) { return _to GetDescription(aDescription); } \
  NS_IMETHOD SetDescription(const PRUnichar * aDescription) { return _to SetDescription(aDescription); } \
  NS_IMETHOD EditMailListToDatabase(const char *uri, nsIAbCard *listCard) { return _to EditMailListToDatabase(uri, listCard); } \
  NS_IMETHOD CopyMailList(nsIAbDirectory *srcList) { return _to CopyMailList(srcList); } \
  NS_IMETHOD CreateNewDirectory(nsIAbDirectoryProperties *aProperties) { return _to CreateNewDirectory(aProperties); } \
  NS_IMETHOD CreateDirectoryByURI(const PRUnichar *displayName, const char *uri, PRBool migrating) { return _to CreateDirectoryByURI(displayName, uri, migrating); } \
  NS_IMETHOD GetValueForCard(nsIAbCard *card, const char *name, PRUnichar **_retval) { return _to GetValueForCard(card, name, _retval); } \
  NS_IMETHOD SetValueForCard(nsIAbCard *card, const char *name, const PRUnichar *value) { return _to SetValueForCard(card, name, value); } \
  NS_IMETHOD GetDirPrefId(nsACString & aDirPrefId) { return _to GetDirPrefId(aDirPrefId); } \
  NS_IMETHOD SetDirPrefId(const nsACString & aDirPrefId) { return _to SetDirPrefId(aDirPrefId); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABDIRECTORY(_to) \
  NS_IMETHOD GetOperations(PRInt32 *aOperations) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetOperations(aOperations); } \
  NS_IMETHOD GetDirName(PRUnichar * *aDirName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDirName(aDirName); } \
  NS_IMETHOD SetDirName(const PRUnichar * aDirName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDirName(aDirName); } \
  NS_IMETHOD GetLastModifiedDate(PRUint32 *aLastModifiedDate) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD SetLastModifiedDate(PRUint32 aLastModifiedDate) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetLastModifiedDate(aLastModifiedDate); } \
  NS_IMETHOD GetIsMailList(PRBool *aIsMailList) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsMailList(aIsMailList); } \
  NS_IMETHOD SetIsMailList(PRBool aIsMailList) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetIsMailList(aIsMailList); } \
  NS_IMETHOD GetDirectoryProperties(nsIAbDirectoryProperties * *aDirectoryProperties) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDirectoryProperties(aDirectoryProperties); } \
  NS_IMETHOD GetChildNodes(nsISimpleEnumerator * *aChildNodes) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetChildNodes(aChildNodes); } \
  NS_IMETHOD GetChildCards(nsIEnumerator * *aChildCards) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetChildCards(aChildCards); } \
  NS_IMETHOD ModifyDirectory(nsIAbDirectory *directory, nsIAbDirectoryProperties *aProperties) { return !_to ? NS_ERROR_NULL_POINTER : _to->ModifyDirectory(directory, aProperties); } \
  NS_IMETHOD DeleteDirectory(nsIAbDirectory *dierctory) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeleteDirectory(dierctory); } \
  NS_IMETHOD DeleteCards(nsISupportsArray *cards) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeleteCards(cards); } \
  NS_IMETHOD HasCard(nsIAbCard *cards, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->HasCard(cards, _retval); } \
  NS_IMETHOD HasDirectory(nsIAbDirectory *dir, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->HasDirectory(dir, _retval); } \
  NS_IMETHOD AddCard(nsIAbCard *card, nsIAbCard **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCard(card, _retval); } \
  NS_IMETHOD DropCard(nsIAbCard *card, PRBool needToCopyCard) { return !_to ? NS_ERROR_NULL_POINTER : _to->DropCard(card, needToCopyCard); } \
  NS_IMETHOD GetIsRemote(PRBool *aIsRemote) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsRemote(aIsRemote); } \
  NS_IMETHOD GetIsSecure(PRBool *aIsSecure) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetIsSecure(aIsSecure); } \
  NS_IMETHOD GetSearchDuringLocalAutocomplete(PRBool *aSearchDuringLocalAutocomplete) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSearchDuringLocalAutocomplete(aSearchDuringLocalAutocomplete); } \
  NS_IMETHOD GetSupportsMailingLists(PRBool *aSupportsMailingLists) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSupportsMailingLists(aSupportsMailingLists); } \
  NS_IMETHOD GetAddressLists(nsISupportsArray * *aAddressLists) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAddressLists(aAddressLists); } \
  NS_IMETHOD SetAddressLists(nsISupportsArray * aAddressLists) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAddressLists(aAddressLists); } \
  NS_IMETHOD AddMailList(nsIAbDirectory *list) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddMailList(list); } \
  NS_IMETHOD AddMailListWithKey(nsIAbDirectory *list, PRUint32 *key) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddMailListWithKey(list, key); } \
  NS_IMETHOD GetListNickName(PRUnichar * *aListNickName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetListNickName(aListNickName); } \
  NS_IMETHOD SetListNickName(const PRUnichar * aListNickName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetListNickName(aListNickName); } \
  NS_IMETHOD GetDescription(PRUnichar * *aDescription) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDescription(aDescription); } \
  NS_IMETHOD SetDescription(const PRUnichar * aDescription) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDescription(aDescription); } \
  NS_IMETHOD EditMailListToDatabase(const char *uri, nsIAbCard *listCard) { return !_to ? NS_ERROR_NULL_POINTER : _to->EditMailListToDatabase(uri, listCard); } \
  NS_IMETHOD CopyMailList(nsIAbDirectory *srcList) { return !_to ? NS_ERROR_NULL_POINTER : _to->CopyMailList(srcList); } \
  NS_IMETHOD CreateNewDirectory(nsIAbDirectoryProperties *aProperties) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateNewDirectory(aProperties); } \
  NS_IMETHOD CreateDirectoryByURI(const PRUnichar *displayName, const char *uri, PRBool migrating) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateDirectoryByURI(displayName, uri, migrating); } \
  NS_IMETHOD GetValueForCard(nsIAbCard *card, const char *name, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetValueForCard(card, name, _retval); } \
  NS_IMETHOD SetValueForCard(nsIAbCard *card, const char *name, const PRUnichar *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetValueForCard(card, name, value); } \
  NS_IMETHOD GetDirPrefId(nsACString & aDirPrefId) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDirPrefId(aDirPrefId); } \
  NS_IMETHOD SetDirPrefId(const nsACString & aDirPrefId) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDirPrefId(aDirPrefId); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbDirectory : public nsIAbDirectory
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABDIRECTORY

  nsAbDirectory();

private:
  ~nsAbDirectory();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbDirectory, nsIAbDirectory)

nsAbDirectory::nsAbDirectory()
{
  /* member initializers and constructor code */
}

nsAbDirectory::~nsAbDirectory()
{
  /* destructor code */
}

/* readonly attribute long operations; */
NS_IMETHODIMP nsAbDirectory::GetOperations(PRInt32 *aOperations)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring dirName; */
NS_IMETHODIMP nsAbDirectory::GetDirName(PRUnichar * *aDirName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetDirName(const PRUnichar * aDirName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long lastModifiedDate; */
NS_IMETHODIMP nsAbDirectory::GetLastModifiedDate(PRUint32 *aLastModifiedDate)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetLastModifiedDate(PRUint32 aLastModifiedDate)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute PRBool isMailList; */
NS_IMETHODIMP nsAbDirectory::GetIsMailList(PRBool *aIsMailList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetIsMailList(PRBool aIsMailList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsIAbDirectoryProperties directoryProperties; */
NS_IMETHODIMP nsAbDirectory::GetDirectoryProperties(nsIAbDirectoryProperties * *aDirectoryProperties)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsISimpleEnumerator childNodes; */
NS_IMETHODIMP nsAbDirectory::GetChildNodes(nsISimpleEnumerator * *aChildNodes)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsIEnumerator childCards; */
NS_IMETHODIMP nsAbDirectory::GetChildCards(nsIEnumerator * *aChildCards)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void modifyDirectory (in nsIAbDirectory directory, in nsIAbDirectoryProperties aProperties); */
NS_IMETHODIMP nsAbDirectory::ModifyDirectory(nsIAbDirectory *directory, nsIAbDirectoryProperties *aProperties)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deleteDirectory (in nsIAbDirectory dierctory); */
NS_IMETHODIMP nsAbDirectory::DeleteDirectory(nsIAbDirectory *dierctory)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deleteCards (in nsISupportsArray cards); */
NS_IMETHODIMP nsAbDirectory::DeleteCards(nsISupportsArray *cards)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean hasCard (in nsIAbCard cards); */
NS_IMETHODIMP nsAbDirectory::HasCard(nsIAbCard *cards, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean hasDirectory (in nsIAbDirectory dir); */
NS_IMETHODIMP nsAbDirectory::HasDirectory(nsIAbDirectory *dir, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAbCard addCard (in nsIAbCard card); */
NS_IMETHODIMP nsAbDirectory::AddCard(nsIAbCard *card, nsIAbCard **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void dropCard (in nsIAbCard card, in boolean needToCopyCard); */
NS_IMETHODIMP nsAbDirectory::DropCard(nsIAbCard *card, PRBool needToCopyCard)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean isRemote; */
NS_IMETHODIMP nsAbDirectory::GetIsRemote(PRBool *aIsRemote)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean isSecure; */
NS_IMETHODIMP nsAbDirectory::GetIsSecure(PRBool *aIsSecure)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean searchDuringLocalAutocomplete; */
NS_IMETHODIMP nsAbDirectory::GetSearchDuringLocalAutocomplete(PRBool *aSearchDuringLocalAutocomplete)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute boolean supportsMailingLists; */
NS_IMETHODIMP nsAbDirectory::GetSupportsMailingLists(PRBool *aSupportsMailingLists)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute nsISupportsArray addressLists; */
NS_IMETHODIMP nsAbDirectory::GetAddressLists(nsISupportsArray * *aAddressLists)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetAddressLists(nsISupportsArray * aAddressLists)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void addMailList (in nsIAbDirectory list); */
NS_IMETHODIMP nsAbDirectory::AddMailList(nsIAbDirectory *list)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void addMailListWithKey (in nsIAbDirectory list, out PRUint32 key); */
NS_IMETHODIMP nsAbDirectory::AddMailListWithKey(nsIAbDirectory *list, PRUint32 *key)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring listNickName; */
NS_IMETHODIMP nsAbDirectory::GetListNickName(PRUnichar * *aListNickName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetListNickName(const PRUnichar * aListNickName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring description; */
NS_IMETHODIMP nsAbDirectory::GetDescription(PRUnichar * *aDescription)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetDescription(const PRUnichar * aDescription)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void editMailListToDatabase (in string uri, in nsIAbCard listCard); */
NS_IMETHODIMP nsAbDirectory::EditMailListToDatabase(const char *uri, nsIAbCard *listCard)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copyMailList (in nsIAbDirectory srcList); */
NS_IMETHODIMP nsAbDirectory::CopyMailList(nsIAbDirectory *srcList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void createNewDirectory (in nsIAbDirectoryProperties aProperties); */
NS_IMETHODIMP nsAbDirectory::CreateNewDirectory(nsIAbDirectoryProperties *aProperties)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void createDirectoryByURI (in wstring displayName, in string uri, in boolean migrating); */
NS_IMETHODIMP nsAbDirectory::CreateDirectoryByURI(const PRUnichar *displayName, const char *uri, PRBool migrating)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring getValueForCard (in nsIAbCard card, in string name); */
NS_IMETHODIMP nsAbDirectory::GetValueForCard(nsIAbCard *card, const char *name, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setValueForCard (in nsIAbCard card, in string name, in wstring value); */
NS_IMETHODIMP nsAbDirectory::SetValueForCard(nsIAbCard *card, const char *name, const PRUnichar *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute ACString dirPrefId; */
NS_IMETHODIMP nsAbDirectory::GetDirPrefId(nsACString & aDirPrefId)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbDirectory::SetDirPrefId(const nsACString & aDirPrefId)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbDirectory_h__ */
