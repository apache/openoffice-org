/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM ../../../../mailnews/addrbook/public/nsIAddrDBListener.idl
 */

#ifndef __gen_nsIAddrDBListener_h__
#define __gen_nsIAddrDBListener_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAbCard_h__
#include "nsIAbCard.h"
#endif

#ifndef __gen_nsIAbDirectory_h__
#include "nsIAbDirectory.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAddrDBAnnouncer; /* forward declaration */


/* starting interface:    nsIAddrDBListener */
#define NS_IADDRDBLISTENER_IID_STR "96876e1d-50a8-4264-8cd0-953d75d0e81b"

#define NS_IADDRDBLISTENER_IID \
  {0x96876e1d, 0x50a8, 0x4264, \
    { 0x8c, 0xd0, 0x95, 0x3d, 0x75, 0xd0, 0xe8, 0x1b }}

class NS_NO_VTABLE nsIAddrDBListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IADDRDBLISTENER_IID)

  /* void onCardAttribChange (in unsigned long abCode); */
  NS_IMETHOD OnCardAttribChange(PRUint32 abCode) = 0;

  /* void onCardEntryChange (in unsigned long abCode, in nsIAbCard card); */
  NS_IMETHOD OnCardEntryChange(PRUint32 abCode, nsIAbCard *card) = 0;

  /* void onListEntryChange (in unsigned long abCode, in nsIAbDirectory list); */
  NS_IMETHOD OnListEntryChange(PRUint32 abCode, nsIAbDirectory *list) = 0;

  /* void onAnnouncerGoingAway (); */
  NS_IMETHOD OnAnnouncerGoingAway(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIADDRDBLISTENER \
  NS_IMETHOD OnCardAttribChange(PRUint32 abCode); \
  NS_IMETHOD OnCardEntryChange(PRUint32 abCode, nsIAbCard *card); \
  NS_IMETHOD OnListEntryChange(PRUint32 abCode, nsIAbDirectory *list); \
  NS_IMETHOD OnAnnouncerGoingAway(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIADDRDBLISTENER(_to) \
  NS_IMETHOD OnCardAttribChange(PRUint32 abCode) { return _to OnCardAttribChange(abCode); } \
  NS_IMETHOD OnCardEntryChange(PRUint32 abCode, nsIAbCard *card) { return _to OnCardEntryChange(abCode, card); } \
  NS_IMETHOD OnListEntryChange(PRUint32 abCode, nsIAbDirectory *list) { return _to OnListEntryChange(abCode, list); } \
  NS_IMETHOD OnAnnouncerGoingAway(void) { return _to OnAnnouncerGoingAway(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIADDRDBLISTENER(_to) \
  NS_IMETHOD OnCardAttribChange(PRUint32 abCode) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnCardAttribChange(abCode); } \
  NS_IMETHOD OnCardEntryChange(PRUint32 abCode, nsIAbCard *card) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnCardEntryChange(abCode, card); } \
  NS_IMETHOD OnListEntryChange(PRUint32 abCode, nsIAbDirectory *list) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnListEntryChange(abCode, list); } \
  NS_IMETHOD OnAnnouncerGoingAway(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnAnnouncerGoingAway(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAddrDBListener : public nsIAddrDBListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIADDRDBLISTENER

  nsAddrDBListener();

private:
  ~nsAddrDBListener();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAddrDBListener, nsIAddrDBListener)

nsAddrDBListener::nsAddrDBListener()
{
  /* member initializers and constructor code */
}

nsAddrDBListener::~nsAddrDBListener()
{
  /* destructor code */
}

/* void onCardAttribChange (in unsigned long abCode); */
NS_IMETHODIMP nsAddrDBListener::OnCardAttribChange(PRUint32 abCode)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onCardEntryChange (in unsigned long abCode, in nsIAbCard card); */
NS_IMETHODIMP nsAddrDBListener::OnCardEntryChange(PRUint32 abCode, nsIAbCard *card)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onListEntryChange (in unsigned long abCode, in nsIAbDirectory list); */
NS_IMETHODIMP nsAddrDBListener::OnListEntryChange(PRUint32 abCode, nsIAbDirectory *list)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onAnnouncerGoingAway (); */
NS_IMETHODIMP nsAddrDBListener::OnAnnouncerGoingAway()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAddrDBListener_h__ */
