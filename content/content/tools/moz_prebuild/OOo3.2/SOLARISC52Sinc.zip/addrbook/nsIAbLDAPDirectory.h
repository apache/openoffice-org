/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM ../../../../mailnews/addrbook/public/nsIAbLDAPDirectory.idl
 */

#ifndef __gen_nsIAbLDAPDirectory_h__
#define __gen_nsIAbLDAPDirectory_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIMutableArray; /* forward declaration */


/* starting interface:    nsIAbLDAPDirectory */
#define NS_IABLDAPDIRECTORY_IID_STR "27ef9414-6959-4085-b5e3-bc491c0e6554"

#define NS_IABLDAPDIRECTORY_IID \
  {0x27ef9414, 0x6959, 0x4085, \
    { 0xb5, 0xe3, 0xbc, 0x49, 0x1c, 0x0e, 0x65, 0x54 }}

/**
 * XXX This should really inherit from nsIAbDirectory, and some day it will.
 * But for now, doing that complicates implementation.
 */
class NS_NO_VTABLE nsIAbLDAPDirectory : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABLDAPDIRECTORY_IID)

  /**
     * If set, these arrays of nsILDAPControls are passed through to the
     * nsILDAPOperation that searchExt is called on.
     */
  /* attribute nsIMutableArray searchServerControls; */
  NS_IMETHOD GetSearchServerControls(nsIMutableArray * *aSearchServerControls) = 0;
  NS_IMETHOD SetSearchServerControls(nsIMutableArray * aSearchServerControls) = 0;

  /* attribute nsIMutableArray searchClientControls; */
  NS_IMETHOD GetSearchClientControls(nsIMutableArray * *aSearchClientControls) = 0;
  NS_IMETHOD SetSearchClientControls(nsIMutableArray * aSearchClientControls) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABLDAPDIRECTORY \
  NS_IMETHOD GetSearchServerControls(nsIMutableArray * *aSearchServerControls); \
  NS_IMETHOD SetSearchServerControls(nsIMutableArray * aSearchServerControls); \
  NS_IMETHOD GetSearchClientControls(nsIMutableArray * *aSearchClientControls); \
  NS_IMETHOD SetSearchClientControls(nsIMutableArray * aSearchClientControls); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABLDAPDIRECTORY(_to) \
  NS_IMETHOD GetSearchServerControls(nsIMutableArray * *aSearchServerControls) { return _to GetSearchServerControls(aSearchServerControls); } \
  NS_IMETHOD SetSearchServerControls(nsIMutableArray * aSearchServerControls) { return _to SetSearchServerControls(aSearchServerControls); } \
  NS_IMETHOD GetSearchClientControls(nsIMutableArray * *aSearchClientControls) { return _to GetSearchClientControls(aSearchClientControls); } \
  NS_IMETHOD SetSearchClientControls(nsIMutableArray * aSearchClientControls) { return _to SetSearchClientControls(aSearchClientControls); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABLDAPDIRECTORY(_to) \
  NS_IMETHOD GetSearchServerControls(nsIMutableArray * *aSearchServerControls) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSearchServerControls(aSearchServerControls); } \
  NS_IMETHOD SetSearchServerControls(nsIMutableArray * aSearchServerControls) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSearchServerControls(aSearchServerControls); } \
  NS_IMETHOD GetSearchClientControls(nsIMutableArray * *aSearchClientControls) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSearchClientControls(aSearchClientControls); } \
  NS_IMETHOD SetSearchClientControls(nsIMutableArray * aSearchClientControls) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetSearchClientControls(aSearchClientControls); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbLDAPDirectory : public nsIAbLDAPDirectory
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABLDAPDIRECTORY

  nsAbLDAPDirectory();

private:
  ~nsAbLDAPDirectory();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbLDAPDirectory, nsIAbLDAPDirectory)

nsAbLDAPDirectory::nsAbLDAPDirectory()
{
  /* member initializers and constructor code */
}

nsAbLDAPDirectory::~nsAbLDAPDirectory()
{
  /* destructor code */
}

/* attribute nsIMutableArray searchServerControls; */
NS_IMETHODIMP nsAbLDAPDirectory::GetSearchServerControls(nsIMutableArray * *aSearchServerControls)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbLDAPDirectory::SetSearchServerControls(nsIMutableArray * aSearchServerControls)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute nsIMutableArray searchClientControls; */
NS_IMETHODIMP nsAbLDAPDirectory::GetSearchClientControls(nsIMutableArray * *aSearchClientControls)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbLDAPDirectory::SetSearchClientControls(nsIMutableArray * aSearchClientControls)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbLDAPDirectory_h__ */
