/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM ../../../../mailnews/addrbook/public/nsIAbLDIFService.idl
 */

#ifndef __gen_nsIAbLDIFService_h__
#define __gen_nsIAbLDIFService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIFileSpec; /* forward declaration */

class nsIAddrDatabase; /* forward declaration */


/* starting interface:    nsIAbLDIFService */
#define NS_IABLDIFSERVICE_IID_STR "b594baf1-34d4-48ce-891c-66fc2e8bc59d"

#define NS_IABLDIFSERVICE_IID \
  {0xb594baf1, 0x34d4, 0x48ce, \
    { 0x89, 0x1c, 0x66, 0xfc, 0x2e, 0x8b, 0xc5, 0x9d }}

class NS_NO_VTABLE nsIAbLDIFService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABLDIFSERVICE_IID)

  /**
   * Determine if a file is likely to be an LDIF file based on field
   * names that commonly appear in LDIF files.
   *
   * @param       aSrc   The file to examine
   *    
   * @return      PR_TRUE if the file appears to be of LDIF type,
   *              PR_FALSE otherwise
   */
  /* boolean isLDIFFile (in nsIFileSpec aSrc); */
  NS_IMETHOD IsLDIFFile(nsIFileSpec *aSrc, PRBool *_retval) = 0;

  /**
   * Imports a file into the specified address book.
   *
   * @param       aDb             The address book to import addresses into.
   *
   * @param       aSrc            The file to import addresses from.
   *
   * @param       aStoreLocAsHome Stores the address as a home rather than work
   *                              address.
   *
   * @param       aProgress       May be null, but if a pointer is supplied,
   *                              then it will be updated regularly with the
   *                              current position of reading from the file.
   *
   */
  /* void importLDIFFile (in nsIAddrDatabase aDb, in nsIFileSpec aSrc, in boolean aStoreLocAsHome, inout unsigned long aProgress); */
  NS_IMETHOD ImportLDIFFile(nsIAddrDatabase *aDb, nsIFileSpec *aSrc, PRBool aStoreLocAsHome, PRUint32 *aProgress) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABLDIFSERVICE \
  NS_IMETHOD IsLDIFFile(nsIFileSpec *aSrc, PRBool *_retval); \
  NS_IMETHOD ImportLDIFFile(nsIAddrDatabase *aDb, nsIFileSpec *aSrc, PRBool aStoreLocAsHome, PRUint32 *aProgress); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABLDIFSERVICE(_to) \
  NS_IMETHOD IsLDIFFile(nsIFileSpec *aSrc, PRBool *_retval) { return _to IsLDIFFile(aSrc, _retval); } \
  NS_IMETHOD ImportLDIFFile(nsIAddrDatabase *aDb, nsIFileSpec *aSrc, PRBool aStoreLocAsHome, PRUint32 *aProgress) { return _to ImportLDIFFile(aDb, aSrc, aStoreLocAsHome, aProgress); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABLDIFSERVICE(_to) \
  NS_IMETHOD IsLDIFFile(nsIFileSpec *aSrc, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsLDIFFile(aSrc, _retval); } \
  NS_IMETHOD ImportLDIFFile(nsIAddrDatabase *aDb, nsIFileSpec *aSrc, PRBool aStoreLocAsHome, PRUint32 *aProgress) { return !_to ? NS_ERROR_NULL_POINTER : _to->ImportLDIFFile(aDb, aSrc, aStoreLocAsHome, aProgress); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbLDIFService : public nsIAbLDIFService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABLDIFSERVICE

  nsAbLDIFService();

private:
  ~nsAbLDIFService();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbLDIFService, nsIAbLDIFService)

nsAbLDIFService::nsAbLDIFService()
{
  /* member initializers and constructor code */
}

nsAbLDIFService::~nsAbLDIFService()
{
  /* destructor code */
}

/* boolean isLDIFFile (in nsIFileSpec aSrc); */
NS_IMETHODIMP nsAbLDIFService::IsLDIFFile(nsIFileSpec *aSrc, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void importLDIFFile (in nsIAddrDatabase aDb, in nsIFileSpec aSrc, in boolean aStoreLocAsHome, inout unsigned long aProgress); */
NS_IMETHODIMP nsAbLDIFService::ImportLDIFFile(nsIAddrDatabase *aDb, nsIFileSpec *aSrc, PRBool aStoreLocAsHome, PRUint32 *aProgress)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbLDIFService_h__ */
