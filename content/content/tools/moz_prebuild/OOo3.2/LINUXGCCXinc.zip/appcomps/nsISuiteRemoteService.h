/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM ../../../../../xpfe/components/xremote/public/nsISuiteRemoteService.idl
 */

#ifndef __gen_nsISuiteRemoteService_h__
#define __gen_nsISuiteRemoteService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIDOMWindow; /* forward declaration */


/* starting interface:    nsISuiteRemoteService */
#define NS_ISUITEREMOTESERVICE_IID_STR "52add212-2067-4575-8d26-edd5165179b1"

#define NS_ISUITEREMOTESERVICE_IID \
  {0x52add212, 0x2067, 0x4575, \
    { 0x8d, 0x26, 0xed, 0xd5, 0x16, 0x51, 0x79, 0xb1 }}

/**
 * Responds to incoming xremote requests for the mozilla suite.
 */
class NS_NO_VTABLE nsISuiteRemoteService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ISUITEREMOTESERVICE_IID)

  /**
   * Parse the command given.
   *
   * @param aCommand The command string, e.g. "openURL(http://www.foo.com/)"
   * @param aContext The domwindow to target the command at. May be null, and
   *                 may be ignored.
   */
  /* void parseCommand (in string aCommand, in nsIDOMWindow aContext); */
  NS_IMETHOD ParseCommand(const char *aCommand, nsIDOMWindow *aContext) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSISUITEREMOTESERVICE \
  NS_IMETHOD ParseCommand(const char *aCommand, nsIDOMWindow *aContext); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSISUITEREMOTESERVICE(_to) \
  NS_IMETHOD ParseCommand(const char *aCommand, nsIDOMWindow *aContext) { return _to ParseCommand(aCommand, aContext); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSISUITEREMOTESERVICE(_to) \
  NS_IMETHOD ParseCommand(const char *aCommand, nsIDOMWindow *aContext) { return !_to ? NS_ERROR_NULL_POINTER : _to->ParseCommand(aCommand, aContext); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsSuiteRemoteService : public nsISuiteRemoteService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSISUITEREMOTESERVICE

  nsSuiteRemoteService();

private:
  ~nsSuiteRemoteService();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsSuiteRemoteService, nsISuiteRemoteService)

nsSuiteRemoteService::nsSuiteRemoteService()
{
  /* member initializers and constructor code */
}

nsSuiteRemoteService::~nsSuiteRemoteService()
{
  /* destructor code */
}

/* void parseCommand (in string aCommand, in nsIDOMWindow aContext); */
NS_IMETHODIMP nsSuiteRemoteService::ParseCommand(const char *aCommand, nsIDOMWindow *aContext)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

#define NS_SUITEREMOTESERVICE_CONTRACTID "@mozilla.org/browser/xremoteservice;2"

#endif /* __gen_nsISuiteRemoteService_h__ */
