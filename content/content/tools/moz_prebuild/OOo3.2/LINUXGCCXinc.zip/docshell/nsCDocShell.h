/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM ../../../docshell/base/nsCDocShell.idl
 */

#ifndef __gen_nsCDocShell_h__
#define __gen_nsCDocShell_h__


#ifndef __gen_nsIDocShell_h__
#include "nsIDocShell.h"
#endif

#ifndef __gen_nsIDocShellTreeItem_h__
#include "nsIDocShellTreeItem.h"
#endif

#ifndef __gen_nsIDocShellTreeNode_h__
#include "nsIDocShellTreeNode.h"
#endif

#ifndef __gen_nsIBaseWindow_h__
#include "nsIBaseWindow.h"
#endif

#ifndef __gen_nsIScrollable_h__
#include "nsIScrollable.h"
#endif

#ifndef __gen_nsITextScroll_h__
#include "nsITextScroll.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
//  {F1EAC762-87E9-11d3-AF80-00A024FFC08C} - 
#define NS_DOCSHELL_CID \
{ 0xf1eac762, 0x87e9, 0x11d3, { 0xaf, 0x80, 0x00, 0xa0, 0x24, 0xff, 0xc0, 0x8c } }
#define NS_DOCSHELL_CONTRACTID \
"@mozilla.org/docshell/html;1"

#endif /* __gen_nsCDocShell_h__ */
