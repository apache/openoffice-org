/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIPopupWindowManager.idl
 */

#ifndef __gen_nsIPopupWindowManager_h__
#define __gen_nsIPopupWindowManager_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIObserver; /* forward declaration */

class nsISimpleEnumerator; /* forward declaration */

class nsIURI; /* forward declaration */


/* starting interface:    nsIPopupWindowManager */
#define NS_IPOPUPWINDOWMANAGER_IID_STR "2e14fec9-e8e9-44cc-8c86-c8673c2383cc"

#define NS_IPOPUPWINDOWMANAGER_IID \
  {0x2e14fec9, 0xe8e9, 0x44cc, \
    { 0x8c, 0x86, 0xc8, 0x67, 0x3c, 0x23, 0x83, 0xcc }}

class NS_NO_VTABLE nsIPopupWindowManager : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IPOPUPWINDOWMANAGER_IID)

  /**
   * These values are returned by the testPermission method
   */
  enum { ALLOW_POPUP = 1U };

  enum { DENY_POPUP = 2U };

  enum { ALLOW_POPUP_WITH_PREJUDICE = 3U };

  /**
   * The manager's default permission can be ALLOW_POPUP (a blacklist)
   * or DENY_POPUP (a whitelist).
   */
  /* attribute PRUint32 defaultPermission; */
  NS_IMETHOD GetDefaultPermission(PRUint32 *aDefaultPermission) = 0;
  NS_IMETHOD SetDefaultPermission(PRUint32 aDefaultPermission) = 0;

  /**
   * Test whether a website has permission to show a popup window.
   * @param   uri is the URI to be tested
   * @return  one of the enumerated permission actions defined above
   */
  /* PRUint32 testPermission (in nsIURI uri); */
  NS_IMETHOD TestPermission(nsIURI *uri, PRUint32 *_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIPOPUPWINDOWMANAGER \
  NS_IMETHOD GetDefaultPermission(PRUint32 *aDefaultPermission); \
  NS_IMETHOD SetDefaultPermission(PRUint32 aDefaultPermission); \
  NS_IMETHOD TestPermission(nsIURI *uri, PRUint32 *_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIPOPUPWINDOWMANAGER(_to) \
  NS_IMETHOD GetDefaultPermission(PRUint32 *aDefaultPermission) { return _to GetDefaultPermission(aDefaultPermission); } \
  NS_IMETHOD SetDefaultPermission(PRUint32 aDefaultPermission) { return _to SetDefaultPermission(aDefaultPermission); } \
  NS_IMETHOD TestPermission(nsIURI *uri, PRUint32 *_retval) { return _to TestPermission(uri, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIPOPUPWINDOWMANAGER(_to) \
  NS_IMETHOD GetDefaultPermission(PRUint32 *aDefaultPermission) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDefaultPermission(aDefaultPermission); } \
  NS_IMETHOD SetDefaultPermission(PRUint32 aDefaultPermission) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDefaultPermission(aDefaultPermission); } \
  NS_IMETHOD TestPermission(nsIURI *uri, PRUint32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->TestPermission(uri, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsPopupWindowManager : public nsIPopupWindowManager
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIPOPUPWINDOWMANAGER

  nsPopupWindowManager();

private:
  ~nsPopupWindowManager();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsPopupWindowManager, nsIPopupWindowManager)

nsPopupWindowManager::nsPopupWindowManager()
{
  /* member initializers and constructor code */
}

nsPopupWindowManager::~nsPopupWindowManager()
{
  /* destructor code */
}

/* attribute PRUint32 defaultPermission; */
NS_IMETHODIMP nsPopupWindowManager::GetDefaultPermission(PRUint32 *aDefaultPermission)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsPopupWindowManager::SetDefaultPermission(PRUint32 aDefaultPermission)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* PRUint32 testPermission (in nsIURI uri); */
NS_IMETHODIMP nsPopupWindowManager::TestPermission(nsIURI *uri, PRUint32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

// {2e14fec9-e8e9-44cc-8c86-c8673c2383cc}
#define NS_POPUPWINDOWMANAGER_IID \
{ 0x2e14fec9, 0xe8e9, 0x44cc, { 0x8c, 0x86, 0xc8, 0x67, 0x3c, 0x23, 0x83,0xcc }}
#define NS_POPUPWINDOWMANAGER_CONTRACTID "@mozilla.org/PopupWindowManager;1"
#define PPM_CHANGE_NOTIFICATION "popup-perm-change"

#endif /* __gen_nsIPopupWindowManager_h__ */
