/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbLDAPReplicationData.idl
 */

#ifndef __gen_nsIAbLDAPReplicationData_h__
#define __gen_nsIAbLDAPReplicationData_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsILDAPMessageListener_h__
#include "nsILDAPMessageListener.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAbLDAPReplicationQuery; /* forward declaration */

class nsIWebProgressListener; /* forward declaration */


/* starting interface:    nsIAbLDAPProcessReplicationData */
#define NS_IABLDAPPROCESSREPLICATIONDATA_IID_STR "00d568a2-3c3b-11d6-b7b9-00b0d06e5f27"

#define NS_IABLDAPPROCESSREPLICATIONDATA_IID \
  {0x00d568a2, 0x3c3b, 0x11d6, \
    { 0xb7, 0xb9, 0x00, 0xb0, 0xd0, 0x6e, 0x5f, 0x27 }}

/**
 * this service does replication of an LDAP directory to a local Mork AB Database.
 */
class NS_NO_VTABLE nsIAbLDAPProcessReplicationData : public nsILDAPMessageListener {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABLDAPPROCESSREPLICATIONDATA_IID)

  /**
     * readonly attribute giving the current replication state
     */
  /* readonly attribute PRInt32 replicationState; */
  NS_IMETHOD GetReplicationState(PRInt32 *aReplicationState) = 0;

  /**
     * replication states
     */
  enum { kIdle = 0 };

  enum { kAnonymousBinding = 1 };

  enum { kAuthenticatedBinding = 2 };

  enum { kSyncServerBinding = 3 };

  enum { kSearchingAuthDN = 4 };

  enum { kDecidingProtocol = 5 };

  enum { kAuthenticating = 6 };

  enum { kReplicatingAll = 7 };

  enum { kSearchingRootDSE = 8 };

  enum { kFindingChanges = 9 };

  enum { kReplicatingChanges = 10 };

  enum { kReplicationDone = 11 };

  /**
     * readonly attribute giving the current protocol used
     */
  /* readonly attribute PRInt32 protocolUsed; */
  NS_IMETHOD GetProtocolUsed(PRInt32 *aProtocolUsed) = 0;

  /**
     * replication protocols
     */
  enum { kDefaultDownloadAll = 0 };

  enum { kChangeLogProtocol = 1 };

  enum { kLCUPProtocol = 2 };

  enum { kLastUpdatedTimeStampMethod = 3 };

  /**
     * this method initializes the implementation
     */
  /* void init (in nsIAbLDAPReplicationQuery query, in nsIWebProgressListener progressListener); */
  NS_IMETHOD Init(nsIAbLDAPReplicationQuery *query, nsIWebProgressListener *progressListener) = 0;

  /**
     * this method a aborts the ongoing processing
     */
  /* void abort (); */
  NS_IMETHOD Abort(void) = 0;

  /**
     * this utility method populates authentication data from Dir Server
     */
  /* void populateAuthData (); */
  NS_IMETHOD PopulateAuthData(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABLDAPPROCESSREPLICATIONDATA \
  NS_IMETHOD GetReplicationState(PRInt32 *aReplicationState); \
  NS_IMETHOD GetProtocolUsed(PRInt32 *aProtocolUsed); \
  NS_IMETHOD Init(nsIAbLDAPReplicationQuery *query, nsIWebProgressListener *progressListener); \
  NS_IMETHOD Abort(void); \
  NS_IMETHOD PopulateAuthData(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABLDAPPROCESSREPLICATIONDATA(_to) \
  NS_IMETHOD GetReplicationState(PRInt32 *aReplicationState) { return _to GetReplicationState(aReplicationState); } \
  NS_IMETHOD GetProtocolUsed(PRInt32 *aProtocolUsed) { return _to GetProtocolUsed(aProtocolUsed); } \
  NS_IMETHOD Init(nsIAbLDAPReplicationQuery *query, nsIWebProgressListener *progressListener) { return _to Init(query, progressListener); } \
  NS_IMETHOD Abort(void) { return _to Abort(); } \
  NS_IMETHOD PopulateAuthData(void) { return _to PopulateAuthData(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABLDAPPROCESSREPLICATIONDATA(_to) \
  NS_IMETHOD GetReplicationState(PRInt32 *aReplicationState) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetReplicationState(aReplicationState); } \
  NS_IMETHOD GetProtocolUsed(PRInt32 *aProtocolUsed) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetProtocolUsed(aProtocolUsed); } \
  NS_IMETHOD Init(nsIAbLDAPReplicationQuery *query, nsIWebProgressListener *progressListener) { return !_to ? NS_ERROR_NULL_POINTER : _to->Init(query, progressListener); } \
  NS_IMETHOD Abort(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->Abort(); } \
  NS_IMETHOD PopulateAuthData(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->PopulateAuthData(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbLDAPProcessReplicationData : public nsIAbLDAPProcessReplicationData
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABLDAPPROCESSREPLICATIONDATA

  nsAbLDAPProcessReplicationData();

private:
  ~nsAbLDAPProcessReplicationData();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbLDAPProcessReplicationData, nsIAbLDAPProcessReplicationData)

nsAbLDAPProcessReplicationData::nsAbLDAPProcessReplicationData()
{
  /* member initializers and constructor code */
}

nsAbLDAPProcessReplicationData::~nsAbLDAPProcessReplicationData()
{
  /* destructor code */
}

/* readonly attribute PRInt32 replicationState; */
NS_IMETHODIMP nsAbLDAPProcessReplicationData::GetReplicationState(PRInt32 *aReplicationState)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute PRInt32 protocolUsed; */
NS_IMETHODIMP nsAbLDAPProcessReplicationData::GetProtocolUsed(PRInt32 *aProtocolUsed)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void init (in nsIAbLDAPReplicationQuery query, in nsIWebProgressListener progressListener); */
NS_IMETHODIMP nsAbLDAPProcessReplicationData::Init(nsIAbLDAPReplicationQuery *query, nsIWebProgressListener *progressListener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void abort (); */
NS_IMETHODIMP nsAbLDAPProcessReplicationData::Abort()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void populateAuthData (); */
NS_IMETHODIMP nsAbLDAPProcessReplicationData::PopulateAuthData()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbLDAPReplicationData_h__ */
