/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAddrDatabase.idl
 */

#ifndef __gen_nsIAddrDatabase_h__
#define __gen_nsIAddrDatabase_h__


#ifndef __gen_nsIAddrDBAnnouncer_h__
#include "nsIAddrDBAnnouncer.h"
#endif

#ifndef __gen_nsIAbCard_h__
#include "nsIAbCard.h"
#endif

#ifndef __gen_nsIAbDirectory_h__
#include "nsIAbDirectory.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIMdbTableRowCursor; /* forward declaration */

class nsIMdbEnv; /* forward declaration */

class nsIMdbRow; /* forward declaration */

// this is the prefix we for attributes that are specific
// to the mozilla addressbook, and weren't in 4.x and aren't specified in
// RFC 2789.  used when exporting and import LDIF
// see nsTextAddress.cpp, nsAddressBook.cpp
#define MOZ_AB_LDIF_PREFIX "mozilla"
// note, GeneratedName is not a real column
// if you change any of this, make sure to change 
// Get / Set CardValue in nsAbCardProperty.cpp
#define kFirstNameColumn          "FirstName"
#define kLastNameColumn           "LastName"
#define kPhoneticFirstNameColumn  "PhoneticFirstName"
#define kPhoneticLastNameColumn   "PhoneticLastName"
#define kPhoneticNameColumn       "_PhoneticName"
#define kDisplayNameColumn        "DisplayName"
#define kNicknameColumn           "NickName"
#define kPriEmailColumn           "PrimaryEmail"
#define k2ndEmailColumn           "SecondEmail"
#define kDefaultEmailColumn       "DefaultEmail"
#define kCardTypeColumn           "CardType"
#define kPreferMailFormatColumn   "PreferMailFormat"
#define kWorkPhoneColumn          "WorkPhone"
#define kHomePhoneColumn          "HomePhone"
#define kFaxColumn                "FaxNumber"
#define kPagerColumn              "PagerNumber"
#define kCellularColumn           "CellularNumber"
#define kWorkPhoneTypeColumn      "WorkPhoneType"
#define kHomePhoneTypeColumn      "HomePhoneType"
#define kFaxTypeColumn            "FaxNumberType"
#define kPagerTypeColumn          "PagerNumberType"
#define kCellularTypeColumn       "CellularNumberType"
#define kHomeAddressColumn        "HomeAddress"
#define kHomeAddress2Column       "HomeAddress2"
#define kHomeCityColumn           "HomeCity"
#define kHomeStateColumn          "HomeState"
#define kHomeZipCodeColumn        "HomeZipCode"
#define kHomeCountryColumn        "HomeCountry"
#define kWorkAddressColumn        "WorkAddress"
#define kWorkAddress2Column       "WorkAddress2"
#define kWorkCityColumn           "WorkCity"
#define kWorkStateColumn          "WorkState"
#define kWorkZipCodeColumn        "WorkZipCode"
#define kWorkCountryColumn        "WorkCountry"
#define kJobTitleColumn           "JobTitle"
#define kDepartmentColumn         "Department"
#define kCompanyColumn            "Company"
#define kAimScreenNameColumn      "_AimScreenName"
#define kAnniversaryYearColumn    "AnniversaryYear"
#define kAnniversaryMonthColumn   "AnniversaryMonth"
#define kAnniversaryDayColumn     "AnniversaryDay"
#define kSpouseNameColumn         "SpouseName"
#define kFamilyNameColumn         "FamilyName"
#define kDefaultAddressColumn     "DefaultAddress"
#define kCategoryColumn           "Category"
// webPage1 is work web page
#define kWebPage1Column           "WebPage1"
// webPage2 is home web page
#define kWebPage2Column           "WebPage2"
#define kBirthYearColumn          "BirthYear"
#define kBirthMonthColumn         "BirthMonth"
#define kBirthDayColumn           "BirthDay"
#define kCustom1Column            "Custom1"
#define kCustom2Column            "Custom2"
#define kCustom3Column            "Custom3"
#define kCustom4Column            "Custom4"
#define kNotesColumn              "Notes"
#define kLastModifiedDateColumn   "LastModifiedDate"
#define kAddressCharSetColumn     "AddrCharSet"
#define kMailListName             "ListName"
#define kMailListNickName         "ListNickName"
#define kMailListDescription      "ListDescription"
#define kMailListTotalAddresses   "ListTotalAddresses"
// not shown in the UI
#define kLowerPriEmailColumn      "LowercasePrimaryEmail"

/* starting interface:    nsAddrDBCommitType */
#define NS_ADDRDBCOMMITTYPE_IID_STR "ca536e0e-1dd1-11b2-951a-e02b86e4f60e"

#define NS_ADDRDBCOMMITTYPE_IID \
  {0xca536e0e, 0x1dd1, 0x11b2, \
    { 0x95, 0x1a, 0xe0, 0x2b, 0x86, 0xe4, 0xf6, 0x0e }}

class NS_NO_VTABLE nsAddrDBCommitType {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ADDRDBCOMMITTYPE_IID)

  enum { kSmallCommit = 0 };

  enum { kLargeCommit = 1 };

  enum { kSessionCommit = 2 };

  enum { kCompressCommit = 3 };

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSADDRDBCOMMITTYPE \

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSADDRDBCOMMITTYPE(_to) \

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSADDRDBCOMMITTYPE(_to) \

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public nsAddrDBCommitType
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSADDRDBCOMMITTYPE

  _MYCLASS_();

private:
  ~_MYCLASS_();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, nsAddrDBCommitType)

_MYCLASS_::_MYCLASS_()
{
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAddrDatabase */
#define NS_IADDRDATABASE_IID_STR "a4186d8b-1dd0-11d3-a303-001083003d0c"

#define NS_IADDRDATABASE_IID \
  {0xa4186d8b, 0x1dd0, 0x11d3, \
    { 0xa3, 0x03, 0x00, 0x10, 0x83, 0x00, 0x3d, 0x0c }}

class NS_NO_VTABLE nsIAddrDatabase : public nsIAddrDBAnnouncer {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IADDRDATABASE_IID)

  /* [noscript] attribute nsFileSpec dbPath; */
  NS_IMETHOD GetDbPath(nsFileSpec * *aDbPath) = 0;
  NS_IMETHOD SetDbPath(nsFileSpec * aDbPath) = 0;

  /* [noscript] void open (in nsFileSpec folderName, in boolean create, out nsIAddrDatabase pCardDB, in boolean upgrading); */
  NS_IMETHOD Open(nsFileSpec * folderName, PRBool create, nsIAddrDatabase **pCardDB, PRBool upgrading) = 0;

  /* void close (in boolean forceCommit); */
  NS_IMETHOD Close(PRBool forceCommit) = 0;

  /* [noscript] void openMDB (in nsFileSpec dbName, in boolean create); */
  NS_IMETHOD OpenMDB(nsFileSpec * dbName, PRBool create) = 0;

  /* void closeMDB (in boolean commit); */
  NS_IMETHOD CloseMDB(PRBool commit) = 0;

  /* void commit (in unsigned long commitType); */
  NS_IMETHOD Commit(PRUint32 commitType) = 0;

  /* void forceClosed (); */
  NS_IMETHOD ForceClosed(void) = 0;

  /* void createNewCardAndAddToDB (in nsIAbCard newCard, in boolean aNotify); */
  NS_IMETHOD CreateNewCardAndAddToDB(nsIAbCard *newCard, PRBool aNotify) = 0;

  /* void createNewCardAndAddToDBWithKey (in nsIAbCard newCard, in boolean aNotify, out unsigned long key); */
  NS_IMETHOD CreateNewCardAndAddToDBWithKey(nsIAbCard *newCard, PRBool aNotify, PRUint32 *key) = 0;

  /* void createNewListCardAndAddToDB (in nsIAbDirectory list, in unsigned long listRowID, in nsIAbCard newCard, in boolean aNotify); */
  NS_IMETHOD CreateNewListCardAndAddToDB(nsIAbDirectory *list, PRUint32 listRowID, nsIAbCard *newCard, PRBool aNotify) = 0;

  /* void createMailListAndAddToDB (in nsIAbDirectory newList, in boolean aNotify); */
  NS_IMETHOD CreateMailListAndAddToDB(nsIAbDirectory *newList, PRBool aNotify) = 0;

  /* void createMailListAndAddToDBWithKey (in nsIAbDirectory newList, in boolean aNotify, out PRUint32 key); */
  NS_IMETHOD CreateMailListAndAddToDBWithKey(nsIAbDirectory *newList, PRBool aNotify, PRUint32 *key) = 0;

  /* nsIEnumerator enumerateCards (in nsIAbDirectory directory); */
  NS_IMETHOD EnumerateCards(nsIAbDirectory *directory, nsIEnumerator **_retval) = 0;

  /* nsIEnumerator enumerateListAddresses (in nsIAbDirectory directory); */
  NS_IMETHOD EnumerateListAddresses(nsIAbDirectory *directory, nsIEnumerator **_retval) = 0;

  /* void getMailingListsFromDB (in nsIAbDirectory parentDir); */
  NS_IMETHOD GetMailingListsFromDB(nsIAbDirectory *parentDir) = 0;

  /* void deleteCard (in nsIAbCard card, in boolean aNotify); */
  NS_IMETHOD DeleteCard(nsIAbCard *card, PRBool aNotify) = 0;

  /* void editCard (in nsIAbCard card, in boolean aNotify); */
  NS_IMETHOD EditCard(nsIAbCard *card, PRBool aNotify) = 0;

  /* boolean containsCard (in nsIAbCard card); */
  NS_IMETHOD ContainsCard(nsIAbCard *card, PRBool *_retval) = 0;

  /* void deleteMailList (in nsIAbDirectory mailList, in boolean aNotify); */
  NS_IMETHOD DeleteMailList(nsIAbDirectory *mailList, PRBool aNotify) = 0;

  /* void editMailList (in nsIAbDirectory mailList, in nsIAbCard listCard, in boolean aNotify); */
  NS_IMETHOD EditMailList(nsIAbDirectory *mailList, nsIAbCard *listCard, PRBool aNotify) = 0;

  /* boolean containsMailList (in nsIAbDirectory mailList); */
  NS_IMETHOD ContainsMailList(nsIAbDirectory *mailList, PRBool *_retval) = 0;

  /* void deleteCardFromMailList (in nsIAbDirectory mailList, in nsIAbCard card, in boolean aNotify); */
  NS_IMETHOD DeleteCardFromMailList(nsIAbDirectory *mailList, nsIAbCard *card, PRBool aNotify) = 0;

  /* readonly attribute wstring directoryName; */
  NS_IMETHOD GetDirectoryName(PRUnichar * *aDirectoryName) = 0;

  /**
	 * aUTF8Value needs to be in UTF-8
	 */
  /* nsIAbCard getCardFromAttribute (in nsIAbDirectory directory, in string aName, in string aUTF8Value, in boolean caseInsensitive); */
  NS_IMETHOD GetCardFromAttribute(nsIAbDirectory *directory, const char *aName, const char *aUTF8Value, PRBool caseInsensitive, nsIAbCard **_retval) = 0;

  /* PRBool findMailListbyUnicodeName (in wstring listName); */
  NS_IMETHOD FindMailListbyUnicodeName(const PRUnichar *listName, PRBool *_retval) = 0;

  /* void getCardCount (out PRUint32 count); */
  NS_IMETHOD GetCardCount(PRUint32 *count) = 0;

  /* [noscript] readonly attribute nsIMdbRow newRow; */
  NS_IMETHOD GetNewRow(nsIMdbRow * *aNewRow) = 0;

  /* [noscript] readonly attribute nsIMdbRow newListRow; */
  NS_IMETHOD GetNewListRow(nsIMdbRow * *aNewListRow) = 0;

  /* [noscript] void addCardRowToDB (in nsIMdbRow newRow); */
  NS_IMETHOD AddCardRowToDB(nsIMdbRow *newRow) = 0;

  /* [noscript] void addLdifListMember (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddLdifListMember(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addFirstName (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddFirstName(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addLastName (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddLastName(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addPhoneticFirstName (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddPhoneticFirstName(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addPhoneticLastName (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddPhoneticLastName(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addDisplayName (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddDisplayName(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addNickName (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddNickName(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addPrimaryEmail (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddPrimaryEmail(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void add2ndEmail (in nsIMdbRow row, in string value); */
  NS_IMETHOD Add2ndEmail(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addDefaultEmail (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddDefaultEmail(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addCardType (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddCardType(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addWorkPhone (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddWorkPhone(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addHomePhone (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddHomePhone(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addFaxNumber (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddFaxNumber(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addPagerNumber (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddPagerNumber(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addCellularNumber (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddCellularNumber(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addWorkPhoneType (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddWorkPhoneType(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addHomePhoneType (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddHomePhoneType(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addFaxNumberType (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddFaxNumberType(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addPagerNumberType (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddPagerNumberType(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addCellularNumberType (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddCellularNumberType(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addHomeAddress (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddHomeAddress(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addHomeAddress2 (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddHomeAddress2(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addHomeCity (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddHomeCity(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addHomeState (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddHomeState(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addHomeZipCode (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddHomeZipCode(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addHomeCountry (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddHomeCountry(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addWorkAddress (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddWorkAddress(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addWorkAddress2 (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddWorkAddress2(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addWorkCity (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddWorkCity(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addWorkState (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddWorkState(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addWorkZipCode (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddWorkZipCode(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addWorkCountry (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddWorkCountry(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addJobTitle (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddJobTitle(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addDepartment (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddDepartment(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addCompany (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddCompany(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addAimScreenName (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddAimScreenName(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addAnniversaryYear (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddAnniversaryYear(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addAnniversaryMonth (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddAnniversaryMonth(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addAnniversaryDay (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddAnniversaryDay(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addSpouseName (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddSpouseName(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addFamilyName (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddFamilyName(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addDefaultAddress (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddDefaultAddress(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addCategory (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddCategory(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addWebPage1 (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddWebPage1(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addWebPage2 (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddWebPage2(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addBirthYear (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddBirthYear(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addBirthMonth (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddBirthMonth(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addBirthDay (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddBirthDay(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addCustom1 (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddCustom1(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addCustom2 (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddCustom2(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addCustom3 (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddCustom3(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addCustom4 (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddCustom4(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addNotes (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddNotes(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addPreferMailFormat (in nsIMdbRow row, in unsigned long value); */
  NS_IMETHOD AddPreferMailFormat(nsIMdbRow *row, PRUint32 value) = 0;

  /* [noscript] void addListName (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddListName(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addListNickName (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddListNickName(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addListDescription (in nsIMdbRow row, in string value); */
  NS_IMETHOD AddListDescription(nsIMdbRow *row, const char *value) = 0;

  /* [noscript] void addListDirNode (in nsIMdbRow listRow); */
  NS_IMETHOD AddListDirNode(nsIMdbRow *listRow) = 0;

  /**
     * use for getting and setting generic string attributes
     * like _AimScreenName
     */
  /* void setCardValue (in nsIAbCard card, in string name, in wstring value, in boolean notify); */
  NS_IMETHOD SetCardValue(nsIAbCard *card, const char *name, const PRUnichar *value, PRBool notify) = 0;

  /* wstring getCardValue (in nsIAbCard card, in string name); */
  NS_IMETHOD GetCardValue(nsIAbCard *card, const char *name, PRUnichar **_retval) = 0;

  /* void getDeletedCardList (out unsigned long aCount, out nsISupportsArray aDeletedList); */
  NS_IMETHOD GetDeletedCardList(PRUint32 *aCount, nsISupportsArray **aDeletedList) = 0;

  /* void getDeletedCardCount (out unsigned long count); */
  NS_IMETHOD GetDeletedCardCount(PRUint32 *count) = 0;

  /**
     * used for adding a string attributes to a row.
     * used during LDIF and addressbook import.
     *
     * @param aRow
     *        The row we're adding the column to
     * @param aLDIFAttributeName
     *        The column name  (examples: mozillaCategory, 
     *                                    mozilla_AimScreenName)
     * @param aColValue
     *        The column value (example: jabroni316)
     */
  /* [noscript] void addRowValue (in nsIMdbRow aRow, in ACString aLDIFAttributeName, in AString aColValue); */
  NS_IMETHOD AddRowValue(nsIMdbRow *aRow, const nsACString & aLDIFAttributeName, const nsAString & aColValue) = 0;

  /* void AddListCardColumnsToRow (in nsIAbCard aPCard, in nsIMdbRow aPListRow, in unsigned long aPos, out nsIAbCard aPNewCard, in boolean aInMailingList); */
  NS_IMETHOD AddListCardColumnsToRow(nsIAbCard *aPCard, nsIMdbRow *aPListRow, PRUint32 aPos, nsIAbCard **aPNewCard, PRBool aInMailingList) = 0;

  /* void InitCardFromRow (in nsIAbCard aNewCard, in nsIMdbRow aCardRow); */
  NS_IMETHOD InitCardFromRow(nsIAbCard *aNewCard, nsIMdbRow *aCardRow) = 0;

  /* void SetListAddressTotal (in nsIMdbRow aListRow, in PRUint32 aTotal); */
  NS_IMETHOD SetListAddressTotal(nsIMdbRow *aListRow, PRUint32 aTotal) = 0;

  /* nsIMdbRow FindRowByCard (in nsIAbCard aCard); */
  NS_IMETHOD FindRowByCard(nsIAbCard *aCard, nsIMdbRow **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIADDRDATABASE \
  NS_IMETHOD GetDbPath(nsFileSpec * *aDbPath); \
  NS_IMETHOD SetDbPath(nsFileSpec * aDbPath); \
  NS_IMETHOD Open(nsFileSpec * folderName, PRBool create, nsIAddrDatabase **pCardDB, PRBool upgrading); \
  NS_IMETHOD Close(PRBool forceCommit); \
  NS_IMETHOD OpenMDB(nsFileSpec * dbName, PRBool create); \
  NS_IMETHOD CloseMDB(PRBool commit); \
  NS_IMETHOD Commit(PRUint32 commitType); \
  NS_IMETHOD ForceClosed(void); \
  NS_IMETHOD CreateNewCardAndAddToDB(nsIAbCard *newCard, PRBool aNotify); \
  NS_IMETHOD CreateNewCardAndAddToDBWithKey(nsIAbCard *newCard, PRBool aNotify, PRUint32 *key); \
  NS_IMETHOD CreateNewListCardAndAddToDB(nsIAbDirectory *list, PRUint32 listRowID, nsIAbCard *newCard, PRBool aNotify); \
  NS_IMETHOD CreateMailListAndAddToDB(nsIAbDirectory *newList, PRBool aNotify); \
  NS_IMETHOD CreateMailListAndAddToDBWithKey(nsIAbDirectory *newList, PRBool aNotify, PRUint32 *key); \
  NS_IMETHOD EnumerateCards(nsIAbDirectory *directory, nsIEnumerator **_retval); \
  NS_IMETHOD EnumerateListAddresses(nsIAbDirectory *directory, nsIEnumerator **_retval); \
  NS_IMETHOD GetMailingListsFromDB(nsIAbDirectory *parentDir); \
  NS_IMETHOD DeleteCard(nsIAbCard *card, PRBool aNotify); \
  NS_IMETHOD EditCard(nsIAbCard *card, PRBool aNotify); \
  NS_IMETHOD ContainsCard(nsIAbCard *card, PRBool *_retval); \
  NS_IMETHOD DeleteMailList(nsIAbDirectory *mailList, PRBool aNotify); \
  NS_IMETHOD EditMailList(nsIAbDirectory *mailList, nsIAbCard *listCard, PRBool aNotify); \
  NS_IMETHOD ContainsMailList(nsIAbDirectory *mailList, PRBool *_retval); \
  NS_IMETHOD DeleteCardFromMailList(nsIAbDirectory *mailList, nsIAbCard *card, PRBool aNotify); \
  NS_IMETHOD GetDirectoryName(PRUnichar * *aDirectoryName); \
  NS_IMETHOD GetCardFromAttribute(nsIAbDirectory *directory, const char *aName, const char *aUTF8Value, PRBool caseInsensitive, nsIAbCard **_retval); \
  NS_IMETHOD FindMailListbyUnicodeName(const PRUnichar *listName, PRBool *_retval); \
  NS_IMETHOD GetCardCount(PRUint32 *count); \
  NS_IMETHOD GetNewRow(nsIMdbRow * *aNewRow); \
  NS_IMETHOD GetNewListRow(nsIMdbRow * *aNewListRow); \
  NS_IMETHOD AddCardRowToDB(nsIMdbRow *newRow); \
  NS_IMETHOD AddLdifListMember(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddFirstName(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddLastName(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddPhoneticFirstName(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddPhoneticLastName(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddDisplayName(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddNickName(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddPrimaryEmail(nsIMdbRow *row, const char *value); \
  NS_IMETHOD Add2ndEmail(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddDefaultEmail(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddCardType(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddWorkPhone(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddHomePhone(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddFaxNumber(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddPagerNumber(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddCellularNumber(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddWorkPhoneType(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddHomePhoneType(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddFaxNumberType(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddPagerNumberType(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddCellularNumberType(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddHomeAddress(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddHomeAddress2(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddHomeCity(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddHomeState(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddHomeZipCode(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddHomeCountry(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddWorkAddress(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddWorkAddress2(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddWorkCity(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddWorkState(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddWorkZipCode(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddWorkCountry(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddJobTitle(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddDepartment(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddCompany(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddAimScreenName(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddAnniversaryYear(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddAnniversaryMonth(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddAnniversaryDay(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddSpouseName(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddFamilyName(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddDefaultAddress(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddCategory(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddWebPage1(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddWebPage2(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddBirthYear(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddBirthMonth(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddBirthDay(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddCustom1(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddCustom2(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddCustom3(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddCustom4(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddNotes(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddPreferMailFormat(nsIMdbRow *row, PRUint32 value); \
  NS_IMETHOD AddListName(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddListNickName(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddListDescription(nsIMdbRow *row, const char *value); \
  NS_IMETHOD AddListDirNode(nsIMdbRow *listRow); \
  NS_IMETHOD SetCardValue(nsIAbCard *card, const char *name, const PRUnichar *value, PRBool notify); \
  NS_IMETHOD GetCardValue(nsIAbCard *card, const char *name, PRUnichar **_retval); \
  NS_IMETHOD GetDeletedCardList(PRUint32 *aCount, nsISupportsArray **aDeletedList); \
  NS_IMETHOD GetDeletedCardCount(PRUint32 *count); \
  NS_IMETHOD AddRowValue(nsIMdbRow *aRow, const nsACString & aLDIFAttributeName, const nsAString & aColValue); \
  NS_IMETHOD AddListCardColumnsToRow(nsIAbCard *aPCard, nsIMdbRow *aPListRow, PRUint32 aPos, nsIAbCard **aPNewCard, PRBool aInMailingList); \
  NS_IMETHOD InitCardFromRow(nsIAbCard *aNewCard, nsIMdbRow *aCardRow); \
  NS_IMETHOD SetListAddressTotal(nsIMdbRow *aListRow, PRUint32 aTotal); \
  NS_IMETHOD FindRowByCard(nsIAbCard *aCard, nsIMdbRow **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIADDRDATABASE(_to) \
  NS_IMETHOD GetDbPath(nsFileSpec * *aDbPath) { return _to GetDbPath(aDbPath); } \
  NS_IMETHOD SetDbPath(nsFileSpec * aDbPath) { return _to SetDbPath(aDbPath); } \
  NS_IMETHOD Open(nsFileSpec * folderName, PRBool create, nsIAddrDatabase **pCardDB, PRBool upgrading) { return _to Open(folderName, create, pCardDB, upgrading); } \
  NS_IMETHOD Close(PRBool forceCommit) { return _to Close(forceCommit); } \
  NS_IMETHOD OpenMDB(nsFileSpec * dbName, PRBool create) { return _to OpenMDB(dbName, create); } \
  NS_IMETHOD CloseMDB(PRBool commit) { return _to CloseMDB(commit); } \
  NS_IMETHOD Commit(PRUint32 commitType) { return _to Commit(commitType); } \
  NS_IMETHOD ForceClosed(void) { return _to ForceClosed(); } \
  NS_IMETHOD CreateNewCardAndAddToDB(nsIAbCard *newCard, PRBool aNotify) { return _to CreateNewCardAndAddToDB(newCard, aNotify); } \
  NS_IMETHOD CreateNewCardAndAddToDBWithKey(nsIAbCard *newCard, PRBool aNotify, PRUint32 *key) { return _to CreateNewCardAndAddToDBWithKey(newCard, aNotify, key); } \
  NS_IMETHOD CreateNewListCardAndAddToDB(nsIAbDirectory *list, PRUint32 listRowID, nsIAbCard *newCard, PRBool aNotify) { return _to CreateNewListCardAndAddToDB(list, listRowID, newCard, aNotify); } \
  NS_IMETHOD CreateMailListAndAddToDB(nsIAbDirectory *newList, PRBool aNotify) { return _to CreateMailListAndAddToDB(newList, aNotify); } \
  NS_IMETHOD CreateMailListAndAddToDBWithKey(nsIAbDirectory *newList, PRBool aNotify, PRUint32 *key) { return _to CreateMailListAndAddToDBWithKey(newList, aNotify, key); } \
  NS_IMETHOD EnumerateCards(nsIAbDirectory *directory, nsIEnumerator **_retval) { return _to EnumerateCards(directory, _retval); } \
  NS_IMETHOD EnumerateListAddresses(nsIAbDirectory *directory, nsIEnumerator **_retval) { return _to EnumerateListAddresses(directory, _retval); } \
  NS_IMETHOD GetMailingListsFromDB(nsIAbDirectory *parentDir) { return _to GetMailingListsFromDB(parentDir); } \
  NS_IMETHOD DeleteCard(nsIAbCard *card, PRBool aNotify) { return _to DeleteCard(card, aNotify); } \
  NS_IMETHOD EditCard(nsIAbCard *card, PRBool aNotify) { return _to EditCard(card, aNotify); } \
  NS_IMETHOD ContainsCard(nsIAbCard *card, PRBool *_retval) { return _to ContainsCard(card, _retval); } \
  NS_IMETHOD DeleteMailList(nsIAbDirectory *mailList, PRBool aNotify) { return _to DeleteMailList(mailList, aNotify); } \
  NS_IMETHOD EditMailList(nsIAbDirectory *mailList, nsIAbCard *listCard, PRBool aNotify) { return _to EditMailList(mailList, listCard, aNotify); } \
  NS_IMETHOD ContainsMailList(nsIAbDirectory *mailList, PRBool *_retval) { return _to ContainsMailList(mailList, _retval); } \
  NS_IMETHOD DeleteCardFromMailList(nsIAbDirectory *mailList, nsIAbCard *card, PRBool aNotify) { return _to DeleteCardFromMailList(mailList, card, aNotify); } \
  NS_IMETHOD GetDirectoryName(PRUnichar * *aDirectoryName) { return _to GetDirectoryName(aDirectoryName); } \
  NS_IMETHOD GetCardFromAttribute(nsIAbDirectory *directory, const char *aName, const char *aUTF8Value, PRBool caseInsensitive, nsIAbCard **_retval) { return _to GetCardFromAttribute(directory, aName, aUTF8Value, caseInsensitive, _retval); } \
  NS_IMETHOD FindMailListbyUnicodeName(const PRUnichar *listName, PRBool *_retval) { return _to FindMailListbyUnicodeName(listName, _retval); } \
  NS_IMETHOD GetCardCount(PRUint32 *count) { return _to GetCardCount(count); } \
  NS_IMETHOD GetNewRow(nsIMdbRow * *aNewRow) { return _to GetNewRow(aNewRow); } \
  NS_IMETHOD GetNewListRow(nsIMdbRow * *aNewListRow) { return _to GetNewListRow(aNewListRow); } \
  NS_IMETHOD AddCardRowToDB(nsIMdbRow *newRow) { return _to AddCardRowToDB(newRow); } \
  NS_IMETHOD AddLdifListMember(nsIMdbRow *row, const char *value) { return _to AddLdifListMember(row, value); } \
  NS_IMETHOD AddFirstName(nsIMdbRow *row, const char *value) { return _to AddFirstName(row, value); } \
  NS_IMETHOD AddLastName(nsIMdbRow *row, const char *value) { return _to AddLastName(row, value); } \
  NS_IMETHOD AddPhoneticFirstName(nsIMdbRow *row, const char *value) { return _to AddPhoneticFirstName(row, value); } \
  NS_IMETHOD AddPhoneticLastName(nsIMdbRow *row, const char *value) { return _to AddPhoneticLastName(row, value); } \
  NS_IMETHOD AddDisplayName(nsIMdbRow *row, const char *value) { return _to AddDisplayName(row, value); } \
  NS_IMETHOD AddNickName(nsIMdbRow *row, const char *value) { return _to AddNickName(row, value); } \
  NS_IMETHOD AddPrimaryEmail(nsIMdbRow *row, const char *value) { return _to AddPrimaryEmail(row, value); } \
  NS_IMETHOD Add2ndEmail(nsIMdbRow *row, const char *value) { return _to Add2ndEmail(row, value); } \
  NS_IMETHOD AddDefaultEmail(nsIMdbRow *row, const char *value) { return _to AddDefaultEmail(row, value); } \
  NS_IMETHOD AddCardType(nsIMdbRow *row, const char *value) { return _to AddCardType(row, value); } \
  NS_IMETHOD AddWorkPhone(nsIMdbRow *row, const char *value) { return _to AddWorkPhone(row, value); } \
  NS_IMETHOD AddHomePhone(nsIMdbRow *row, const char *value) { return _to AddHomePhone(row, value); } \
  NS_IMETHOD AddFaxNumber(nsIMdbRow *row, const char *value) { return _to AddFaxNumber(row, value); } \
  NS_IMETHOD AddPagerNumber(nsIMdbRow *row, const char *value) { return _to AddPagerNumber(row, value); } \
  NS_IMETHOD AddCellularNumber(nsIMdbRow *row, const char *value) { return _to AddCellularNumber(row, value); } \
  NS_IMETHOD AddWorkPhoneType(nsIMdbRow *row, const char *value) { return _to AddWorkPhoneType(row, value); } \
  NS_IMETHOD AddHomePhoneType(nsIMdbRow *row, const char *value) { return _to AddHomePhoneType(row, value); } \
  NS_IMETHOD AddFaxNumberType(nsIMdbRow *row, const char *value) { return _to AddFaxNumberType(row, value); } \
  NS_IMETHOD AddPagerNumberType(nsIMdbRow *row, const char *value) { return _to AddPagerNumberType(row, value); } \
  NS_IMETHOD AddCellularNumberType(nsIMdbRow *row, const char *value) { return _to AddCellularNumberType(row, value); } \
  NS_IMETHOD AddHomeAddress(nsIMdbRow *row, const char *value) { return _to AddHomeAddress(row, value); } \
  NS_IMETHOD AddHomeAddress2(nsIMdbRow *row, const char *value) { return _to AddHomeAddress2(row, value); } \
  NS_IMETHOD AddHomeCity(nsIMdbRow *row, const char *value) { return _to AddHomeCity(row, value); } \
  NS_IMETHOD AddHomeState(nsIMdbRow *row, const char *value) { return _to AddHomeState(row, value); } \
  NS_IMETHOD AddHomeZipCode(nsIMdbRow *row, const char *value) { return _to AddHomeZipCode(row, value); } \
  NS_IMETHOD AddHomeCountry(nsIMdbRow *row, const char *value) { return _to AddHomeCountry(row, value); } \
  NS_IMETHOD AddWorkAddress(nsIMdbRow *row, const char *value) { return _to AddWorkAddress(row, value); } \
  NS_IMETHOD AddWorkAddress2(nsIMdbRow *row, const char *value) { return _to AddWorkAddress2(row, value); } \
  NS_IMETHOD AddWorkCity(nsIMdbRow *row, const char *value) { return _to AddWorkCity(row, value); } \
  NS_IMETHOD AddWorkState(nsIMdbRow *row, const char *value) { return _to AddWorkState(row, value); } \
  NS_IMETHOD AddWorkZipCode(nsIMdbRow *row, const char *value) { return _to AddWorkZipCode(row, value); } \
  NS_IMETHOD AddWorkCountry(nsIMdbRow *row, const char *value) { return _to AddWorkCountry(row, value); } \
  NS_IMETHOD AddJobTitle(nsIMdbRow *row, const char *value) { return _to AddJobTitle(row, value); } \
  NS_IMETHOD AddDepartment(nsIMdbRow *row, const char *value) { return _to AddDepartment(row, value); } \
  NS_IMETHOD AddCompany(nsIMdbRow *row, const char *value) { return _to AddCompany(row, value); } \
  NS_IMETHOD AddAimScreenName(nsIMdbRow *row, const char *value) { return _to AddAimScreenName(row, value); } \
  NS_IMETHOD AddAnniversaryYear(nsIMdbRow *row, const char *value) { return _to AddAnniversaryYear(row, value); } \
  NS_IMETHOD AddAnniversaryMonth(nsIMdbRow *row, const char *value) { return _to AddAnniversaryMonth(row, value); } \
  NS_IMETHOD AddAnniversaryDay(nsIMdbRow *row, const char *value) { return _to AddAnniversaryDay(row, value); } \
  NS_IMETHOD AddSpouseName(nsIMdbRow *row, const char *value) { return _to AddSpouseName(row, value); } \
  NS_IMETHOD AddFamilyName(nsIMdbRow *row, const char *value) { return _to AddFamilyName(row, value); } \
  NS_IMETHOD AddDefaultAddress(nsIMdbRow *row, const char *value) { return _to AddDefaultAddress(row, value); } \
  NS_IMETHOD AddCategory(nsIMdbRow *row, const char *value) { return _to AddCategory(row, value); } \
  NS_IMETHOD AddWebPage1(nsIMdbRow *row, const char *value) { return _to AddWebPage1(row, value); } \
  NS_IMETHOD AddWebPage2(nsIMdbRow *row, const char *value) { return _to AddWebPage2(row, value); } \
  NS_IMETHOD AddBirthYear(nsIMdbRow *row, const char *value) { return _to AddBirthYear(row, value); } \
  NS_IMETHOD AddBirthMonth(nsIMdbRow *row, const char *value) { return _to AddBirthMonth(row, value); } \
  NS_IMETHOD AddBirthDay(nsIMdbRow *row, const char *value) { return _to AddBirthDay(row, value); } \
  NS_IMETHOD AddCustom1(nsIMdbRow *row, const char *value) { return _to AddCustom1(row, value); } \
  NS_IMETHOD AddCustom2(nsIMdbRow *row, const char *value) { return _to AddCustom2(row, value); } \
  NS_IMETHOD AddCustom3(nsIMdbRow *row, const char *value) { return _to AddCustom3(row, value); } \
  NS_IMETHOD AddCustom4(nsIMdbRow *row, const char *value) { return _to AddCustom4(row, value); } \
  NS_IMETHOD AddNotes(nsIMdbRow *row, const char *value) { return _to AddNotes(row, value); } \
  NS_IMETHOD AddPreferMailFormat(nsIMdbRow *row, PRUint32 value) { return _to AddPreferMailFormat(row, value); } \
  NS_IMETHOD AddListName(nsIMdbRow *row, const char *value) { return _to AddListName(row, value); } \
  NS_IMETHOD AddListNickName(nsIMdbRow *row, const char *value) { return _to AddListNickName(row, value); } \
  NS_IMETHOD AddListDescription(nsIMdbRow *row, const char *value) { return _to AddListDescription(row, value); } \
  NS_IMETHOD AddListDirNode(nsIMdbRow *listRow) { return _to AddListDirNode(listRow); } \
  NS_IMETHOD SetCardValue(nsIAbCard *card, const char *name, const PRUnichar *value, PRBool notify) { return _to SetCardValue(card, name, value, notify); } \
  NS_IMETHOD GetCardValue(nsIAbCard *card, const char *name, PRUnichar **_retval) { return _to GetCardValue(card, name, _retval); } \
  NS_IMETHOD GetDeletedCardList(PRUint32 *aCount, nsISupportsArray **aDeletedList) { return _to GetDeletedCardList(aCount, aDeletedList); } \
  NS_IMETHOD GetDeletedCardCount(PRUint32 *count) { return _to GetDeletedCardCount(count); } \
  NS_IMETHOD AddRowValue(nsIMdbRow *aRow, const nsACString & aLDIFAttributeName, const nsAString & aColValue) { return _to AddRowValue(aRow, aLDIFAttributeName, aColValue); } \
  NS_IMETHOD AddListCardColumnsToRow(nsIAbCard *aPCard, nsIMdbRow *aPListRow, PRUint32 aPos, nsIAbCard **aPNewCard, PRBool aInMailingList) { return _to AddListCardColumnsToRow(aPCard, aPListRow, aPos, aPNewCard, aInMailingList); } \
  NS_IMETHOD InitCardFromRow(nsIAbCard *aNewCard, nsIMdbRow *aCardRow) { return _to InitCardFromRow(aNewCard, aCardRow); } \
  NS_IMETHOD SetListAddressTotal(nsIMdbRow *aListRow, PRUint32 aTotal) { return _to SetListAddressTotal(aListRow, aTotal); } \
  NS_IMETHOD FindRowByCard(nsIAbCard *aCard, nsIMdbRow **_retval) { return _to FindRowByCard(aCard, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIADDRDATABASE(_to) \
  NS_IMETHOD GetDbPath(nsFileSpec * *aDbPath) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDbPath(aDbPath); } \
  NS_IMETHOD SetDbPath(nsFileSpec * aDbPath) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDbPath(aDbPath); } \
  NS_IMETHOD Open(nsFileSpec * folderName, PRBool create, nsIAddrDatabase **pCardDB, PRBool upgrading) { return !_to ? NS_ERROR_NULL_POINTER : _to->Open(folderName, create, pCardDB, upgrading); } \
  NS_IMETHOD Close(PRBool forceCommit) { return !_to ? NS_ERROR_NULL_POINTER : _to->Close(forceCommit); } \
  NS_IMETHOD OpenMDB(nsFileSpec * dbName, PRBool create) { return !_to ? NS_ERROR_NULL_POINTER : _to->OpenMDB(dbName, create); } \
  NS_IMETHOD CloseMDB(PRBool commit) { return !_to ? NS_ERROR_NULL_POINTER : _to->CloseMDB(commit); } \
  NS_IMETHOD Commit(PRUint32 commitType) { return !_to ? NS_ERROR_NULL_POINTER : _to->Commit(commitType); } \
  NS_IMETHOD ForceClosed(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->ForceClosed(); } \
  NS_IMETHOD CreateNewCardAndAddToDB(nsIAbCard *newCard, PRBool aNotify) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateNewCardAndAddToDB(newCard, aNotify); } \
  NS_IMETHOD CreateNewCardAndAddToDBWithKey(nsIAbCard *newCard, PRBool aNotify, PRUint32 *key) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateNewCardAndAddToDBWithKey(newCard, aNotify, key); } \
  NS_IMETHOD CreateNewListCardAndAddToDB(nsIAbDirectory *list, PRUint32 listRowID, nsIAbCard *newCard, PRBool aNotify) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateNewListCardAndAddToDB(list, listRowID, newCard, aNotify); } \
  NS_IMETHOD CreateMailListAndAddToDB(nsIAbDirectory *newList, PRBool aNotify) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateMailListAndAddToDB(newList, aNotify); } \
  NS_IMETHOD CreateMailListAndAddToDBWithKey(nsIAbDirectory *newList, PRBool aNotify, PRUint32 *key) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateMailListAndAddToDBWithKey(newList, aNotify, key); } \
  NS_IMETHOD EnumerateCards(nsIAbDirectory *directory, nsIEnumerator **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->EnumerateCards(directory, _retval); } \
  NS_IMETHOD EnumerateListAddresses(nsIAbDirectory *directory, nsIEnumerator **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->EnumerateListAddresses(directory, _retval); } \
  NS_IMETHOD GetMailingListsFromDB(nsIAbDirectory *parentDir) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetMailingListsFromDB(parentDir); } \
  NS_IMETHOD DeleteCard(nsIAbCard *card, PRBool aNotify) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeleteCard(card, aNotify); } \
  NS_IMETHOD EditCard(nsIAbCard *card, PRBool aNotify) { return !_to ? NS_ERROR_NULL_POINTER : _to->EditCard(card, aNotify); } \
  NS_IMETHOD ContainsCard(nsIAbCard *card, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ContainsCard(card, _retval); } \
  NS_IMETHOD DeleteMailList(nsIAbDirectory *mailList, PRBool aNotify) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeleteMailList(mailList, aNotify); } \
  NS_IMETHOD EditMailList(nsIAbDirectory *mailList, nsIAbCard *listCard, PRBool aNotify) { return !_to ? NS_ERROR_NULL_POINTER : _to->EditMailList(mailList, listCard, aNotify); } \
  NS_IMETHOD ContainsMailList(nsIAbDirectory *mailList, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ContainsMailList(mailList, _retval); } \
  NS_IMETHOD DeleteCardFromMailList(nsIAbDirectory *mailList, nsIAbCard *card, PRBool aNotify) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeleteCardFromMailList(mailList, card, aNotify); } \
  NS_IMETHOD GetDirectoryName(PRUnichar * *aDirectoryName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDirectoryName(aDirectoryName); } \
  NS_IMETHOD GetCardFromAttribute(nsIAbDirectory *directory, const char *aName, const char *aUTF8Value, PRBool caseInsensitive, nsIAbCard **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCardFromAttribute(directory, aName, aUTF8Value, caseInsensitive, _retval); } \
  NS_IMETHOD FindMailListbyUnicodeName(const PRUnichar *listName, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->FindMailListbyUnicodeName(listName, _retval); } \
  NS_IMETHOD GetCardCount(PRUint32 *count) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCardCount(count); } \
  NS_IMETHOD GetNewRow(nsIMdbRow * *aNewRow) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNewRow(aNewRow); } \
  NS_IMETHOD GetNewListRow(nsIMdbRow * *aNewListRow) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNewListRow(aNewListRow); } \
  NS_IMETHOD AddCardRowToDB(nsIMdbRow *newRow) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCardRowToDB(newRow); } \
  NS_IMETHOD AddLdifListMember(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddLdifListMember(row, value); } \
  NS_IMETHOD AddFirstName(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddFirstName(row, value); } \
  NS_IMETHOD AddLastName(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddLastName(row, value); } \
  NS_IMETHOD AddPhoneticFirstName(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddPhoneticFirstName(row, value); } \
  NS_IMETHOD AddPhoneticLastName(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddPhoneticLastName(row, value); } \
  NS_IMETHOD AddDisplayName(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddDisplayName(row, value); } \
  NS_IMETHOD AddNickName(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddNickName(row, value); } \
  NS_IMETHOD AddPrimaryEmail(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddPrimaryEmail(row, value); } \
  NS_IMETHOD Add2ndEmail(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->Add2ndEmail(row, value); } \
  NS_IMETHOD AddDefaultEmail(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddDefaultEmail(row, value); } \
  NS_IMETHOD AddCardType(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCardType(row, value); } \
  NS_IMETHOD AddWorkPhone(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddWorkPhone(row, value); } \
  NS_IMETHOD AddHomePhone(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddHomePhone(row, value); } \
  NS_IMETHOD AddFaxNumber(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddFaxNumber(row, value); } \
  NS_IMETHOD AddPagerNumber(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddPagerNumber(row, value); } \
  NS_IMETHOD AddCellularNumber(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCellularNumber(row, value); } \
  NS_IMETHOD AddWorkPhoneType(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddWorkPhoneType(row, value); } \
  NS_IMETHOD AddHomePhoneType(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddHomePhoneType(row, value); } \
  NS_IMETHOD AddFaxNumberType(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddFaxNumberType(row, value); } \
  NS_IMETHOD AddPagerNumberType(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddPagerNumberType(row, value); } \
  NS_IMETHOD AddCellularNumberType(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCellularNumberType(row, value); } \
  NS_IMETHOD AddHomeAddress(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddHomeAddress(row, value); } \
  NS_IMETHOD AddHomeAddress2(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddHomeAddress2(row, value); } \
  NS_IMETHOD AddHomeCity(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddHomeCity(row, value); } \
  NS_IMETHOD AddHomeState(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddHomeState(row, value); } \
  NS_IMETHOD AddHomeZipCode(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddHomeZipCode(row, value); } \
  NS_IMETHOD AddHomeCountry(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddHomeCountry(row, value); } \
  NS_IMETHOD AddWorkAddress(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddWorkAddress(row, value); } \
  NS_IMETHOD AddWorkAddress2(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddWorkAddress2(row, value); } \
  NS_IMETHOD AddWorkCity(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddWorkCity(row, value); } \
  NS_IMETHOD AddWorkState(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddWorkState(row, value); } \
  NS_IMETHOD AddWorkZipCode(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddWorkZipCode(row, value); } \
  NS_IMETHOD AddWorkCountry(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddWorkCountry(row, value); } \
  NS_IMETHOD AddJobTitle(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddJobTitle(row, value); } \
  NS_IMETHOD AddDepartment(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddDepartment(row, value); } \
  NS_IMETHOD AddCompany(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCompany(row, value); } \
  NS_IMETHOD AddAimScreenName(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddAimScreenName(row, value); } \
  NS_IMETHOD AddAnniversaryYear(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddAnniversaryYear(row, value); } \
  NS_IMETHOD AddAnniversaryMonth(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddAnniversaryMonth(row, value); } \
  NS_IMETHOD AddAnniversaryDay(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddAnniversaryDay(row, value); } \
  NS_IMETHOD AddSpouseName(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddSpouseName(row, value); } \
  NS_IMETHOD AddFamilyName(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddFamilyName(row, value); } \
  NS_IMETHOD AddDefaultAddress(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddDefaultAddress(row, value); } \
  NS_IMETHOD AddCategory(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCategory(row, value); } \
  NS_IMETHOD AddWebPage1(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddWebPage1(row, value); } \
  NS_IMETHOD AddWebPage2(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddWebPage2(row, value); } \
  NS_IMETHOD AddBirthYear(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddBirthYear(row, value); } \
  NS_IMETHOD AddBirthMonth(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddBirthMonth(row, value); } \
  NS_IMETHOD AddBirthDay(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddBirthDay(row, value); } \
  NS_IMETHOD AddCustom1(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCustom1(row, value); } \
  NS_IMETHOD AddCustom2(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCustom2(row, value); } \
  NS_IMETHOD AddCustom3(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCustom3(row, value); } \
  NS_IMETHOD AddCustom4(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddCustom4(row, value); } \
  NS_IMETHOD AddNotes(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddNotes(row, value); } \
  NS_IMETHOD AddPreferMailFormat(nsIMdbRow *row, PRUint32 value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddPreferMailFormat(row, value); } \
  NS_IMETHOD AddListName(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddListName(row, value); } \
  NS_IMETHOD AddListNickName(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddListNickName(row, value); } \
  NS_IMETHOD AddListDescription(nsIMdbRow *row, const char *value) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddListDescription(row, value); } \
  NS_IMETHOD AddListDirNode(nsIMdbRow *listRow) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddListDirNode(listRow); } \
  NS_IMETHOD SetCardValue(nsIAbCard *card, const char *name, const PRUnichar *value, PRBool notify) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCardValue(card, name, value, notify); } \
  NS_IMETHOD GetCardValue(nsIAbCard *card, const char *name, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCardValue(card, name, _retval); } \
  NS_IMETHOD GetDeletedCardList(PRUint32 *aCount, nsISupportsArray **aDeletedList) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDeletedCardList(aCount, aDeletedList); } \
  NS_IMETHOD GetDeletedCardCount(PRUint32 *count) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDeletedCardCount(count); } \
  NS_IMETHOD AddRowValue(nsIMdbRow *aRow, const nsACString & aLDIFAttributeName, const nsAString & aColValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddRowValue(aRow, aLDIFAttributeName, aColValue); } \
  NS_IMETHOD AddListCardColumnsToRow(nsIAbCard *aPCard, nsIMdbRow *aPListRow, PRUint32 aPos, nsIAbCard **aPNewCard, PRBool aInMailingList) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddListCardColumnsToRow(aPCard, aPListRow, aPos, aPNewCard, aInMailingList); } \
  NS_IMETHOD InitCardFromRow(nsIAbCard *aNewCard, nsIMdbRow *aCardRow) { return !_to ? NS_ERROR_NULL_POINTER : _to->InitCardFromRow(aNewCard, aCardRow); } \
  NS_IMETHOD SetListAddressTotal(nsIMdbRow *aListRow, PRUint32 aTotal) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetListAddressTotal(aListRow, aTotal); } \
  NS_IMETHOD FindRowByCard(nsIAbCard *aCard, nsIMdbRow **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->FindRowByCard(aCard, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAddrDatabase : public nsIAddrDatabase
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIADDRDATABASE

  nsAddrDatabase();

private:
  ~nsAddrDatabase();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAddrDatabase, nsIAddrDatabase)

nsAddrDatabase::nsAddrDatabase()
{
  /* member initializers and constructor code */
}

nsAddrDatabase::~nsAddrDatabase()
{
  /* destructor code */
}

/* [noscript] attribute nsFileSpec dbPath; */
NS_IMETHODIMP nsAddrDatabase::GetDbPath(nsFileSpec * *aDbPath)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAddrDatabase::SetDbPath(nsFileSpec * aDbPath)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void open (in nsFileSpec folderName, in boolean create, out nsIAddrDatabase pCardDB, in boolean upgrading); */
NS_IMETHODIMP nsAddrDatabase::Open(nsFileSpec * folderName, PRBool create, nsIAddrDatabase **pCardDB, PRBool upgrading)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void close (in boolean forceCommit); */
NS_IMETHODIMP nsAddrDatabase::Close(PRBool forceCommit)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void openMDB (in nsFileSpec dbName, in boolean create); */
NS_IMETHODIMP nsAddrDatabase::OpenMDB(nsFileSpec * dbName, PRBool create)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void closeMDB (in boolean commit); */
NS_IMETHODIMP nsAddrDatabase::CloseMDB(PRBool commit)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void commit (in unsigned long commitType); */
NS_IMETHODIMP nsAddrDatabase::Commit(PRUint32 commitType)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void forceClosed (); */
NS_IMETHODIMP nsAddrDatabase::ForceClosed()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void createNewCardAndAddToDB (in nsIAbCard newCard, in boolean aNotify); */
NS_IMETHODIMP nsAddrDatabase::CreateNewCardAndAddToDB(nsIAbCard *newCard, PRBool aNotify)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void createNewCardAndAddToDBWithKey (in nsIAbCard newCard, in boolean aNotify, out unsigned long key); */
NS_IMETHODIMP nsAddrDatabase::CreateNewCardAndAddToDBWithKey(nsIAbCard *newCard, PRBool aNotify, PRUint32 *key)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void createNewListCardAndAddToDB (in nsIAbDirectory list, in unsigned long listRowID, in nsIAbCard newCard, in boolean aNotify); */
NS_IMETHODIMP nsAddrDatabase::CreateNewListCardAndAddToDB(nsIAbDirectory *list, PRUint32 listRowID, nsIAbCard *newCard, PRBool aNotify)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void createMailListAndAddToDB (in nsIAbDirectory newList, in boolean aNotify); */
NS_IMETHODIMP nsAddrDatabase::CreateMailListAndAddToDB(nsIAbDirectory *newList, PRBool aNotify)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void createMailListAndAddToDBWithKey (in nsIAbDirectory newList, in boolean aNotify, out PRUint32 key); */
NS_IMETHODIMP nsAddrDatabase::CreateMailListAndAddToDBWithKey(nsIAbDirectory *newList, PRBool aNotify, PRUint32 *key)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIEnumerator enumerateCards (in nsIAbDirectory directory); */
NS_IMETHODIMP nsAddrDatabase::EnumerateCards(nsIAbDirectory *directory, nsIEnumerator **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIEnumerator enumerateListAddresses (in nsIAbDirectory directory); */
NS_IMETHODIMP nsAddrDatabase::EnumerateListAddresses(nsIAbDirectory *directory, nsIEnumerator **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void getMailingListsFromDB (in nsIAbDirectory parentDir); */
NS_IMETHODIMP nsAddrDatabase::GetMailingListsFromDB(nsIAbDirectory *parentDir)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deleteCard (in nsIAbCard card, in boolean aNotify); */
NS_IMETHODIMP nsAddrDatabase::DeleteCard(nsIAbCard *card, PRBool aNotify)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void editCard (in nsIAbCard card, in boolean aNotify); */
NS_IMETHODIMP nsAddrDatabase::EditCard(nsIAbCard *card, PRBool aNotify)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean containsCard (in nsIAbCard card); */
NS_IMETHODIMP nsAddrDatabase::ContainsCard(nsIAbCard *card, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deleteMailList (in nsIAbDirectory mailList, in boolean aNotify); */
NS_IMETHODIMP nsAddrDatabase::DeleteMailList(nsIAbDirectory *mailList, PRBool aNotify)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void editMailList (in nsIAbDirectory mailList, in nsIAbCard listCard, in boolean aNotify); */
NS_IMETHODIMP nsAddrDatabase::EditMailList(nsIAbDirectory *mailList, nsIAbCard *listCard, PRBool aNotify)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean containsMailList (in nsIAbDirectory mailList); */
NS_IMETHODIMP nsAddrDatabase::ContainsMailList(nsIAbDirectory *mailList, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deleteCardFromMailList (in nsIAbDirectory mailList, in nsIAbCard card, in boolean aNotify); */
NS_IMETHODIMP nsAddrDatabase::DeleteCardFromMailList(nsIAbDirectory *mailList, nsIAbCard *card, PRBool aNotify)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute wstring directoryName; */
NS_IMETHODIMP nsAddrDatabase::GetDirectoryName(PRUnichar * *aDirectoryName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAbCard getCardFromAttribute (in nsIAbDirectory directory, in string aName, in string aUTF8Value, in boolean caseInsensitive); */
NS_IMETHODIMP nsAddrDatabase::GetCardFromAttribute(nsIAbDirectory *directory, const char *aName, const char *aUTF8Value, PRBool caseInsensitive, nsIAbCard **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* PRBool findMailListbyUnicodeName (in wstring listName); */
NS_IMETHODIMP nsAddrDatabase::FindMailListbyUnicodeName(const PRUnichar *listName, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void getCardCount (out PRUint32 count); */
NS_IMETHODIMP nsAddrDatabase::GetCardCount(PRUint32 *count)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] readonly attribute nsIMdbRow newRow; */
NS_IMETHODIMP nsAddrDatabase::GetNewRow(nsIMdbRow * *aNewRow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] readonly attribute nsIMdbRow newListRow; */
NS_IMETHODIMP nsAddrDatabase::GetNewListRow(nsIMdbRow * *aNewListRow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addCardRowToDB (in nsIMdbRow newRow); */
NS_IMETHODIMP nsAddrDatabase::AddCardRowToDB(nsIMdbRow *newRow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addLdifListMember (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddLdifListMember(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addFirstName (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddFirstName(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addLastName (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddLastName(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addPhoneticFirstName (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddPhoneticFirstName(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addPhoneticLastName (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddPhoneticLastName(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addDisplayName (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddDisplayName(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addNickName (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddNickName(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addPrimaryEmail (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddPrimaryEmail(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void add2ndEmail (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::Add2ndEmail(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addDefaultEmail (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddDefaultEmail(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addCardType (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddCardType(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addWorkPhone (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddWorkPhone(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addHomePhone (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddHomePhone(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addFaxNumber (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddFaxNumber(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addPagerNumber (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddPagerNumber(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addCellularNumber (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddCellularNumber(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addWorkPhoneType (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddWorkPhoneType(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addHomePhoneType (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddHomePhoneType(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addFaxNumberType (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddFaxNumberType(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addPagerNumberType (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddPagerNumberType(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addCellularNumberType (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddCellularNumberType(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addHomeAddress (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddHomeAddress(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addHomeAddress2 (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddHomeAddress2(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addHomeCity (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddHomeCity(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addHomeState (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddHomeState(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addHomeZipCode (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddHomeZipCode(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addHomeCountry (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddHomeCountry(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addWorkAddress (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddWorkAddress(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addWorkAddress2 (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddWorkAddress2(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addWorkCity (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddWorkCity(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addWorkState (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddWorkState(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addWorkZipCode (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddWorkZipCode(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addWorkCountry (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddWorkCountry(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addJobTitle (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddJobTitle(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addDepartment (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddDepartment(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addCompany (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddCompany(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addAimScreenName (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddAimScreenName(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addAnniversaryYear (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddAnniversaryYear(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addAnniversaryMonth (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddAnniversaryMonth(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addAnniversaryDay (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddAnniversaryDay(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addSpouseName (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddSpouseName(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addFamilyName (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddFamilyName(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addDefaultAddress (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddDefaultAddress(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addCategory (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddCategory(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addWebPage1 (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddWebPage1(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addWebPage2 (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddWebPage2(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addBirthYear (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddBirthYear(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addBirthMonth (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddBirthMonth(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addBirthDay (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddBirthDay(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addCustom1 (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddCustom1(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addCustom2 (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddCustom2(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addCustom3 (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddCustom3(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addCustom4 (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddCustom4(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addNotes (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddNotes(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addPreferMailFormat (in nsIMdbRow row, in unsigned long value); */
NS_IMETHODIMP nsAddrDatabase::AddPreferMailFormat(nsIMdbRow *row, PRUint32 value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addListName (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddListName(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addListNickName (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddListNickName(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addListDescription (in nsIMdbRow row, in string value); */
NS_IMETHODIMP nsAddrDatabase::AddListDescription(nsIMdbRow *row, const char *value)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addListDirNode (in nsIMdbRow listRow); */
NS_IMETHODIMP nsAddrDatabase::AddListDirNode(nsIMdbRow *listRow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setCardValue (in nsIAbCard card, in string name, in wstring value, in boolean notify); */
NS_IMETHODIMP nsAddrDatabase::SetCardValue(nsIAbCard *card, const char *name, const PRUnichar *value, PRBool notify)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring getCardValue (in nsIAbCard card, in string name); */
NS_IMETHODIMP nsAddrDatabase::GetCardValue(nsIAbCard *card, const char *name, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void getDeletedCardList (out unsigned long aCount, out nsISupportsArray aDeletedList); */
NS_IMETHODIMP nsAddrDatabase::GetDeletedCardList(PRUint32 *aCount, nsISupportsArray **aDeletedList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void getDeletedCardCount (out unsigned long count); */
NS_IMETHODIMP nsAddrDatabase::GetDeletedCardCount(PRUint32 *count)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void addRowValue (in nsIMdbRow aRow, in ACString aLDIFAttributeName, in AString aColValue); */
NS_IMETHODIMP nsAddrDatabase::AddRowValue(nsIMdbRow *aRow, const nsACString & aLDIFAttributeName, const nsAString & aColValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void AddListCardColumnsToRow (in nsIAbCard aPCard, in nsIMdbRow aPListRow, in unsigned long aPos, out nsIAbCard aPNewCard, in boolean aInMailingList); */
NS_IMETHODIMP nsAddrDatabase::AddListCardColumnsToRow(nsIAbCard *aPCard, nsIMdbRow *aPListRow, PRUint32 aPos, nsIAbCard **aPNewCard, PRBool aInMailingList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void InitCardFromRow (in nsIAbCard aNewCard, in nsIMdbRow aCardRow); */
NS_IMETHODIMP nsAddrDatabase::InitCardFromRow(nsIAbCard *aNewCard, nsIMdbRow *aCardRow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void SetListAddressTotal (in nsIMdbRow aListRow, in PRUint32 aTotal); */
NS_IMETHODIMP nsAddrDatabase::SetListAddressTotal(nsIMdbRow *aListRow, PRUint32 aTotal)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIMdbRow FindRowByCard (in nsIAbCard aCard); */
NS_IMETHODIMP nsAddrDatabase::FindRowByCard(nsIAbCard *aCard, nsIMdbRow **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAddrDatabase_h__ */
