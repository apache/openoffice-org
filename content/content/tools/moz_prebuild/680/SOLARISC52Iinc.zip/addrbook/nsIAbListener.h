/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbListener.idl
 */

#ifndef __gen_nsIAbListener_h__
#define __gen_nsIAbListener_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIEnumerator_h__
#include "nsIEnumerator.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
typedef PRUint32 abListenerNotifyFlagValue;


/* starting interface:    nsIAbListener */
#define NS_IABLISTENER_IID_STR "1920e484-0709-11d3-a2ec-001083003d0c"

#define NS_IABLISTENER_IID \
  {0x1920e484, 0x0709, 0x11d3, \
    { 0xa2, 0xec, 0x00, 0x10, 0x83, 0x00, 0x3d, 0x0c }}

class NS_NO_VTABLE nsIAbListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABLISTENER_IID)

  enum { added = 1U };

  /* void onItemAdded (in nsISupports parentDir, in nsISupports item); */
  NS_IMETHOD OnItemAdded(nsISupports *parentDir, nsISupports *item) = 0;

  enum { directoryItemRemoved = 2U };

  enum { directoryRemoved = 4U };

  /* void onItemRemoved (in nsISupports parentDir, in nsISupports item); */
  NS_IMETHOD OnItemRemoved(nsISupports *parentDir, nsISupports *item) = 0;

  enum { changed = 8U };

  /* void onItemPropertyChanged (in nsISupports item, in string property, in wstring oldValue, in wstring newValue); */
  NS_IMETHOD OnItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue) = 0;

  enum { all = 4294967295U };

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABLISTENER \
  NS_IMETHOD OnItemAdded(nsISupports *parentDir, nsISupports *item); \
  NS_IMETHOD OnItemRemoved(nsISupports *parentDir, nsISupports *item); \
  NS_IMETHOD OnItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue); \

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABLISTENER(_to) \
  NS_IMETHOD OnItemAdded(nsISupports *parentDir, nsISupports *item) { return _to OnItemAdded(parentDir, item); } \
  NS_IMETHOD OnItemRemoved(nsISupports *parentDir, nsISupports *item) { return _to OnItemRemoved(parentDir, item); } \
  NS_IMETHOD OnItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue) { return _to OnItemPropertyChanged(item, property, oldValue, newValue); } \

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABLISTENER(_to) \
  NS_IMETHOD OnItemAdded(nsISupports *parentDir, nsISupports *item) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnItemAdded(parentDir, item); } \
  NS_IMETHOD OnItemRemoved(nsISupports *parentDir, nsISupports *item) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnItemRemoved(parentDir, item); } \
  NS_IMETHOD OnItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnItemPropertyChanged(item, property, oldValue, newValue); } \

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbListener : public nsIAbListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABLISTENER

  nsAbListener();

private:
  ~nsAbListener();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbListener, nsIAbListener)

nsAbListener::nsAbListener()
{
  /* member initializers and constructor code */
}

nsAbListener::~nsAbListener()
{
  /* destructor code */
}

/* void onItemAdded (in nsISupports parentDir, in nsISupports item); */
NS_IMETHODIMP nsAbListener::OnItemAdded(nsISupports *parentDir, nsISupports *item)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onItemRemoved (in nsISupports parentDir, in nsISupports item); */
NS_IMETHODIMP nsAbListener::OnItemRemoved(nsISupports *parentDir, nsISupports *item)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onItemPropertyChanged (in nsISupports item, in string property, in wstring oldValue, in wstring newValue); */
NS_IMETHODIMP nsAbListener::OnItemPropertyChanged(nsISupports *item, const char *property, const PRUnichar *oldValue, const PRUnichar *newValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbListener_h__ */
