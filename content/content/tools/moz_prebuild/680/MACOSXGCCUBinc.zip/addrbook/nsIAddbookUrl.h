/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAddbookUrl.idl
 */

#ifndef __gen_nsIAddbookUrl_h__
#define __gen_nsIAddbookUrl_h__


#ifndef __gen_nsIURI_h__
#include "nsIURI.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAddbookUrlOperation */
#define NS_IADDBOOKURLOPERATION_IID_STR "6eb9d874-01aa-11d4-8fbe-000064657374"

#define NS_IADDBOOKURLOPERATION_IID \
  {0x6eb9d874, 0x01aa, 0x11d4, \
    { 0x8f, 0xbe, 0x00, 0x00, 0x64, 0x65, 0x73, 0x74 }}

class NS_NO_VTABLE nsIAddbookUrlOperation {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IADDBOOKURLOPERATION_IID)

  enum { InvalidUrl = 0 };

  enum { PrintAddressBook = 1 };

  enum { AddVCard = 2 };

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIADDBOOKURLOPERATION \

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIADDBOOKURLOPERATION(_to) \

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIADDBOOKURLOPERATION(_to) \

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAddbookUrlOperation : public nsIAddbookUrlOperation
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIADDBOOKURLOPERATION

  nsAddbookUrlOperation();

private:
  ~nsAddbookUrlOperation();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAddbookUrlOperation, nsIAddbookUrlOperation)

nsAddbookUrlOperation::nsAddbookUrlOperation()
{
  /* member initializers and constructor code */
}

nsAddbookUrlOperation::~nsAddbookUrlOperation()
{
  /* destructor code */
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAddbookUrl */
#define NS_IADDBOOKURL_IID_STR "ee1d5cc3-5f8c-43f3-b1b8-8d2ea67ce2d8"

#define NS_IADDBOOKURL_IID \
  {0xee1d5cc3, 0x5f8c, 0x43f3, \
    { 0xb1, 0xb8, 0x8d, 0x2e, 0xa6, 0x7c, 0xe2, 0xd8 }}

class NS_NO_VTABLE nsIAddbookUrl : public nsIURI {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IADDBOOKURL_IID)

  /* readonly attribute long addbookOperation; */
  NS_IMETHOD GetAddbookOperation(PRInt32 *aAddbookOperation) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIADDBOOKURL \
  NS_IMETHOD GetAddbookOperation(PRInt32 *aAddbookOperation); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIADDBOOKURL(_to) \
  NS_IMETHOD GetAddbookOperation(PRInt32 *aAddbookOperation) { return _to GetAddbookOperation(aAddbookOperation); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIADDBOOKURL(_to) \
  NS_IMETHOD GetAddbookOperation(PRInt32 *aAddbookOperation) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAddbookOperation(aAddbookOperation); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAddbookUrl : public nsIAddbookUrl
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIADDBOOKURL

  nsAddbookUrl();

private:
  ~nsAddbookUrl();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAddbookUrl, nsIAddbookUrl)

nsAddbookUrl::nsAddbookUrl()
{
  /* member initializers and constructor code */
}

nsAddbookUrl::~nsAddbookUrl()
{
  /* destructor code */
}

/* readonly attribute long addbookOperation; */
NS_IMETHODIMP nsAddbookUrl::GetAddbookOperation(PRInt32 *aAddbookOperation)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAddbookUrl_h__ */
