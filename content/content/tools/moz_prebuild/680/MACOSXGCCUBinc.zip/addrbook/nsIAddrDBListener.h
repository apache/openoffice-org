/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAddrDBListener.idl
 */

#ifndef __gen_nsIAddrDBListener_h__
#define __gen_nsIAddrDBListener_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAbCard_h__
#include "nsIAbCard.h"
#endif

#ifndef __gen_nsIAbDirectory_h__
#include "nsIAbDirectory.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIAddrDBAnnouncer; /* forward declaration */


/* starting interface:    nsIAddrDBListener */
#define NS_IADDRDBLISTENER_IID_STR "a4186d89-1dd0-11d3-a303-001083003d0c"

#define NS_IADDRDBLISTENER_IID \
  {0xa4186d89, 0x1dd0, 0x11d3, \
    { 0xa3, 0x03, 0x00, 0x10, 0x83, 0x00, 0x3d, 0x0c }}

class NS_NO_VTABLE nsIAddrDBListener : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IADDRDBLISTENER_IID)

  /* void onCardAttribChange (in unsigned long abCode, in nsIAddrDBListener instigator); */
  NS_IMETHOD OnCardAttribChange(PRUint32 abCode, nsIAddrDBListener *instigator) = 0;

  /* void onCardEntryChange (in unsigned long abCode, in nsIAbCard card, in nsIAddrDBListener instigator); */
  NS_IMETHOD OnCardEntryChange(PRUint32 abCode, nsIAbCard *card, nsIAddrDBListener *instigator) = 0;

  /* void onListEntryChange (in unsigned long abCode, in nsIAbDirectory list, in nsIAddrDBListener instigator); */
  NS_IMETHOD OnListEntryChange(PRUint32 abCode, nsIAbDirectory *list, nsIAddrDBListener *instigator) = 0;

  /* void onAnnouncerGoingAway (in nsIAddrDBAnnouncer instigator); */
  NS_IMETHOD OnAnnouncerGoingAway(nsIAddrDBAnnouncer *instigator) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIADDRDBLISTENER \
  NS_IMETHOD OnCardAttribChange(PRUint32 abCode, nsIAddrDBListener *instigator); \
  NS_IMETHOD OnCardEntryChange(PRUint32 abCode, nsIAbCard *card, nsIAddrDBListener *instigator); \
  NS_IMETHOD OnListEntryChange(PRUint32 abCode, nsIAbDirectory *list, nsIAddrDBListener *instigator); \
  NS_IMETHOD OnAnnouncerGoingAway(nsIAddrDBAnnouncer *instigator); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIADDRDBLISTENER(_to) \
  NS_IMETHOD OnCardAttribChange(PRUint32 abCode, nsIAddrDBListener *instigator) { return _to OnCardAttribChange(abCode, instigator); } \
  NS_IMETHOD OnCardEntryChange(PRUint32 abCode, nsIAbCard *card, nsIAddrDBListener *instigator) { return _to OnCardEntryChange(abCode, card, instigator); } \
  NS_IMETHOD OnListEntryChange(PRUint32 abCode, nsIAbDirectory *list, nsIAddrDBListener *instigator) { return _to OnListEntryChange(abCode, list, instigator); } \
  NS_IMETHOD OnAnnouncerGoingAway(nsIAddrDBAnnouncer *instigator) { return _to OnAnnouncerGoingAway(instigator); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIADDRDBLISTENER(_to) \
  NS_IMETHOD OnCardAttribChange(PRUint32 abCode, nsIAddrDBListener *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnCardAttribChange(abCode, instigator); } \
  NS_IMETHOD OnCardEntryChange(PRUint32 abCode, nsIAbCard *card, nsIAddrDBListener *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnCardEntryChange(abCode, card, instigator); } \
  NS_IMETHOD OnListEntryChange(PRUint32 abCode, nsIAbDirectory *list, nsIAddrDBListener *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnListEntryChange(abCode, list, instigator); } \
  NS_IMETHOD OnAnnouncerGoingAway(nsIAddrDBAnnouncer *instigator) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnAnnouncerGoingAway(instigator); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAddrDBListener : public nsIAddrDBListener
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIADDRDBLISTENER

  nsAddrDBListener();

private:
  ~nsAddrDBListener();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAddrDBListener, nsIAddrDBListener)

nsAddrDBListener::nsAddrDBListener()
{
  /* member initializers and constructor code */
}

nsAddrDBListener::~nsAddrDBListener()
{
  /* destructor code */
}

/* void onCardAttribChange (in unsigned long abCode, in nsIAddrDBListener instigator); */
NS_IMETHODIMP nsAddrDBListener::OnCardAttribChange(PRUint32 abCode, nsIAddrDBListener *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onCardEntryChange (in unsigned long abCode, in nsIAbCard card, in nsIAddrDBListener instigator); */
NS_IMETHODIMP nsAddrDBListener::OnCardEntryChange(PRUint32 abCode, nsIAbCard *card, nsIAddrDBListener *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onListEntryChange (in unsigned long abCode, in nsIAbDirectory list, in nsIAddrDBListener instigator); */
NS_IMETHODIMP nsAddrDBListener::OnListEntryChange(PRUint32 abCode, nsIAbDirectory *list, nsIAddrDBListener *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void onAnnouncerGoingAway (in nsIAddrDBAnnouncer instigator); */
NS_IMETHODIMP nsAddrDBListener::OnAnnouncerGoingAway(nsIAddrDBAnnouncer *instigator)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAddrDBListener_h__ */
