/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIImgManager.idl
 */

#ifndef __gen_nsIImgManager_h__
#define __gen_nsIImgManager_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIURI; /* forward declaration */


/* starting interface:    nsIImgManager */
#define NS_IIMGMANAGER_IID_STR "d60b3710-166d-11d5-a542-0010a401eb10"

#define NS_IIMGMANAGER_IID \
  {0xd60b3710, 0x166d, 0x11d5, \
    { 0xa5, 0x42, 0x00, 0x10, 0xa4, 0x01, 0xeb, 0x10 }}

class NS_NO_VTABLE nsIImgManager : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IIMGMANAGER_IID)

  /**
   * Test if the given image from URI can be loaded
   * @param uri      the uri of the image which wants to be loaded
   * @param firstUri the uri of the document which tried to load the image
   * @return         whether the image has permission to be loaded
   */
  /* boolean testPermission (in nsIURI uri, in nsIURI firstUri); */
  NS_IMETHOD TestPermission(nsIURI *uri, nsIURI *firstUri, PRBool *_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIIMGMANAGER \
  NS_IMETHOD TestPermission(nsIURI *uri, nsIURI *firstUri, PRBool *_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIIMGMANAGER(_to) \
  NS_IMETHOD TestPermission(nsIURI *uri, nsIURI *firstUri, PRBool *_retval) { return _to TestPermission(uri, firstUri, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIIMGMANAGER(_to) \
  NS_IMETHOD TestPermission(nsIURI *uri, nsIURI *firstUri, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->TestPermission(uri, firstUri, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsImgManager : public nsIImgManager
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIIMGMANAGER

  nsImgManager();

private:
  ~nsImgManager();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsImgManager, nsIImgManager)

nsImgManager::nsImgManager()
{
  /* member initializers and constructor code */
}

nsImgManager::~nsImgManager()
{
  /* destructor code */
}

/* boolean testPermission (in nsIURI uri, in nsIURI firstUri); */
NS_IMETHODIMP nsImgManager::TestPermission(nsIURI *uri, nsIURI *firstUri, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

#define NS_IMGMANAGER_CONTRACTID "@mozilla.org/imgmanager;1"

#endif /* __gen_nsIImgManager_h__ */
