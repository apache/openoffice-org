/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAppShellService.idl
 */

#ifndef __gen_nsIAppShellService_h__
#define __gen_nsIAppShellService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIXULWindow; /* forward declaration */

class nsIURI; /* forward declaration */

class nsICmdLineService; /* forward declaration */

class nsINativeAppSupport; /* forward declaration */

class nsIDOMWindowInternal; /* forward declaration */

struct JSContext;

/* starting interface:    nsIAppShellService */
#define NS_IAPPSHELLSERVICE_IID_STR "e5e5af70-8a38-11d2-9938-0080c7cb1080"

#define NS_IAPPSHELLSERVICE_IID \
  {0xe5e5af70, 0x8a38, 0x11d2, \
    { 0x99, 0x38, 0x00, 0x80, 0xc7, 0xcb, 0x10, 0x80 }}

class NS_NO_VTABLE nsIAppShellService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IAPPSHELLSERVICE_IID)

  enum { eConsiderQuit = 1U };

  enum { eAttemptQuit = 2U };

  enum { eForceQuit = 3U };

  /**
   * Required initialization routine.
   * @param aCmdLineService is stored and passed to appshell components as
   *                        they are initialized.
   * @param aNativeAppSupportOrSplashScreen is an object that can be
   *                        QI'd to either an nsINativeAppSupport or
   *                        nsISplashScreen; this object will be used to
   *                        implement HideSplashScreen.
   */
  /* void initialize (in nsICmdLineService aCmdLineService, in nsISupports nativeAppSupportOrSplashScreen); */
  NS_IMETHOD Initialize(nsICmdLineService *aCmdLineService, nsISupports *nativeAppSupportOrSplashScreen) = 0;

  /**
   * Starts up the profile manager with the given arguments
   * @param aCmdLineService the arguments given to the program
   * @param canInteract If FALSE and UI is needed, will fail
   */
  /* void doProfileStartup (in nsICmdLineService aCmdLineService, in boolean canInteract); */
  NS_IMETHOD DoProfileStartup(nsICmdLineService *aCmdLineService, PRBool canInteract) = 0;

  /**
   * Getter for "native app support."
   */
  /* readonly attribute nsINativeAppSupport nativeAppSupport; */
  NS_IMETHOD GetNativeAppSupport(nsINativeAppSupport * *aNativeAppSupport) = 0;

  /**
   * Runs an application event loop: normally the main event pump which
   * defines the lifetime of the application.
   */
  /* void run (); */
  NS_IMETHOD Run(void) = 0;

  /**
   * Exit the event loop, shut down the app
   */
  /* void quit (in PRUint32 aFerocity); */
  NS_IMETHOD Quit(PRUint32 aFerocity) = 0;

  /**
   * Create a window.
   * @param aParent the parent window.  Can be null.
   * @param aUrl the contents of the new window.
   * @param aShowWindow the window remains invisible if PR_FALSE.
   * @param aLoadDefaultPage controls whether the window should try to
   *                         load a default content page on its own.
   * @param aChromeMask chrome flags affecting the kind of OS border
   *                    given to the window. see nsIBrowserWindow for
   *                    bit/flag definitions.
   * @param aCallbacks interface providing C++ hooks for window initialization
   *                   before the window is made visible.  Can be null.
   *                   Deprecated.
   * @param aInitialWidth width, in pixels, of the window.  Width of window
   *                      at creation.  Can be overridden by the "width"
   *                      tag in the XUL.  Set to NS_SIZETOCONTENT to force
   *                      the window to wrap to its contents.
   * @param aInitialHeight like aInitialWidth, but subtly different.
   * @param aResult the newly created window is returned here.
   */
  enum { SIZE_TO_CONTENT = -1 };

  /* nsIXULWindow createTopLevelWindow (in nsIXULWindow aParent, in nsIURI aUrl, in boolean aShowWindow, in boolean aLoadDefaultPage, in PRUint32 aChromeMask, in long aInitialWidth, in long aInitialHeight); */
  NS_IMETHOD CreateTopLevelWindow(nsIXULWindow *aParent, nsIURI *aUrl, PRBool aShowWindow, PRBool aLoadDefaultPage, PRUint32 aChromeMask, PRInt32 aInitialWidth, PRInt32 aInitialHeight, nsIXULWindow **_retval) = 0;

  /**
   * Close a window.
   * @param aWindow a window.
   */
  /* void closeTopLevelWindow (in nsIXULWindow aWindow); */
  NS_IMETHOD CloseTopLevelWindow(nsIXULWindow *aWindow) = 0;

  /* [noscript] void createHiddenWindow (); */
  NS_IMETHOD CreateHiddenWindow(void) = 0;

  /**
   * Return the (singleton) application hidden window, automatically created
   * and maintained by this AppShellService.
   * @param aResult the hidden window.  Do not unhide hidden window.
   *                Do not taunt hidden window.
   */
  /* readonly attribute nsIXULWindow hiddenWindow; */
  NS_IMETHOD GetHiddenWindow(nsIXULWindow * *aHiddenWindow) = 0;

  /**
   * Return the (singleton) application hidden window, automatically created
   * and maintained by this AppShellService.
   * @param aResult the hidden window.  Do not unhide hidden window.
   *                Do not taunt hidden window.
   */
  /* readonly attribute nsIDOMWindowInternal hiddenDOMWindow; */
  NS_IMETHOD GetHiddenDOMWindow(nsIDOMWindowInternal * *aHiddenDOMWindow) = 0;

  /**
   * Return the (singleton) application hidden window as an nsIDOMWindowInternal,
   * and, the corresponding JavaScript context pointer.  This is useful
   * if you'd like to subsequently call OpenDialog on the hidden window.
   * @aHiddenDOMWindow the hidden window QI'd to type nsIDOMWindowInternal
   * @aJSContext       the corresponding JavaScript context
   */
  /* [noscript] void getHiddenWindowAndJSContext (out nsIDOMWindowInternal aHiddenDOMWindow, out JSContext aJSContext); */
  NS_IMETHOD GetHiddenWindowAndJSContext(nsIDOMWindowInternal **aHiddenDOMWindow, JSContext * *aJSContext) = 0;

  /**
   * Add a window to the application's registry of windows.  These windows
   * are generally shown in the Windows taskbar, and the application
   * knows it can't quit until it's out of registered windows.
   * @param aWindow yes
   */
  /* void registerTopLevelWindow (in nsIXULWindow aWindow); */
  NS_IMETHOD RegisterTopLevelWindow(nsIXULWindow *aWindow) = 0;

  /**
   * Remove a window from the application's window registry. Note that
   * this method won't automatically attempt to quit the app when
   * the last window is unregistered. For that, see Quit().
   * @param aWindow you see the pattern
   */
  /* void unregisterTopLevelWindow (in nsIXULWindow aWindow); */
  NS_IMETHOD UnregisterTopLevelWindow(nsIXULWindow *aWindow) = 0;

  /**
   * The appshell service needs to be informed of modal XUL windows currently
   * open. Call this method as a window becomes modal or as it becomes
   * nonmodal.
   * @param aWindow no surprises here
   * @param aModal true if aWindow is becoming modal
   *               false if aWindow is becoming nonmodal (or being closed)
   */
  /* void topLevelWindowIsModal (in nsIXULWindow aWindow, in boolean aModal); */
  NS_IMETHOD TopLevelWindowIsModal(nsIXULWindow *aWindow, PRBool aModal) = 0;

  /**
   * Remove the splash screen (if visible).  This need be called
   * only once per application session.
   */
  /* void hideSplashScreen (); */
  NS_IMETHOD HideSplashScreen(void) = 0;

  /**
   * During application startup (and at other times!) we may temporarily
   * encounter a situation where all application windows will be closed
   * but we don't want to take this as a signal to quit the app. Bracket
   * the code where the last window could close with these.
   * (And at application startup, on platforms that don't normally quit
   * when the last window has closed, call Enter once, but not Exit)
   */
  /* void enterLastWindowClosingSurvivalArea (); */
  NS_IMETHOD EnterLastWindowClosingSurvivalArea(void) = 0;

  /* void exitLastWindowClosingSurvivalArea (); */
  NS_IMETHOD ExitLastWindowClosingSurvivalArea(void) = 0;

  /**
   * Creates the initial state of the application by launching tasks
   * specfied by "general.startup.*" prefs.
   * @param aWindowWidth	the width to make the initial window(s) opened
   * @param aWindowHeight	the height to make the initial window(s) opened
   * @note SIZE_TO_CONTENT may be used for width or height.
   * @return TRUE if a window was opened
   */
  /* boolean createStartupState (in long aWindowWidth, in long aWindowHeight); */
  NS_IMETHOD CreateStartupState(PRInt32 aWindowWidth, PRInt32 aWindowHeight, PRBool *_retval) = 0;

  /**
   * Ensures that at least one window exists after creating the startup state.
   * If one has not been made, this will create a browser window.
   * @param aCmdLineService  the command line from which startup args can be read.
   */
  /* void ensure1Window (in nsICmdLineService aCmdLineService); */
  NS_IMETHOD Ensure1Window(nsICmdLineService *aCmdLineService) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIAPPSHELLSERVICE \
  NS_IMETHOD Initialize(nsICmdLineService *aCmdLineService, nsISupports *nativeAppSupportOrSplashScreen); \
  NS_IMETHOD DoProfileStartup(nsICmdLineService *aCmdLineService, PRBool canInteract); \
  NS_IMETHOD GetNativeAppSupport(nsINativeAppSupport * *aNativeAppSupport); \
  NS_IMETHOD Run(void); \
  NS_IMETHOD Quit(PRUint32 aFerocity); \
  NS_IMETHOD CreateTopLevelWindow(nsIXULWindow *aParent, nsIURI *aUrl, PRBool aShowWindow, PRBool aLoadDefaultPage, PRUint32 aChromeMask, PRInt32 aInitialWidth, PRInt32 aInitialHeight, nsIXULWindow **_retval); \
  NS_IMETHOD CloseTopLevelWindow(nsIXULWindow *aWindow); \
  NS_IMETHOD CreateHiddenWindow(void); \
  NS_IMETHOD GetHiddenWindow(nsIXULWindow * *aHiddenWindow); \
  NS_IMETHOD GetHiddenDOMWindow(nsIDOMWindowInternal * *aHiddenDOMWindow); \
  NS_IMETHOD GetHiddenWindowAndJSContext(nsIDOMWindowInternal **aHiddenDOMWindow, JSContext * *aJSContext); \
  NS_IMETHOD RegisterTopLevelWindow(nsIXULWindow *aWindow); \
  NS_IMETHOD UnregisterTopLevelWindow(nsIXULWindow *aWindow); \
  NS_IMETHOD TopLevelWindowIsModal(nsIXULWindow *aWindow, PRBool aModal); \
  NS_IMETHOD HideSplashScreen(void); \
  NS_IMETHOD EnterLastWindowClosingSurvivalArea(void); \
  NS_IMETHOD ExitLastWindowClosingSurvivalArea(void); \
  NS_IMETHOD CreateStartupState(PRInt32 aWindowWidth, PRInt32 aWindowHeight, PRBool *_retval); \
  NS_IMETHOD Ensure1Window(nsICmdLineService *aCmdLineService); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIAPPSHELLSERVICE(_to) \
  NS_IMETHOD Initialize(nsICmdLineService *aCmdLineService, nsISupports *nativeAppSupportOrSplashScreen) { return _to Initialize(aCmdLineService, nativeAppSupportOrSplashScreen); } \
  NS_IMETHOD DoProfileStartup(nsICmdLineService *aCmdLineService, PRBool canInteract) { return _to DoProfileStartup(aCmdLineService, canInteract); } \
  NS_IMETHOD GetNativeAppSupport(nsINativeAppSupport * *aNativeAppSupport) { return _to GetNativeAppSupport(aNativeAppSupport); } \
  NS_IMETHOD Run(void) { return _to Run(); } \
  NS_IMETHOD Quit(PRUint32 aFerocity) { return _to Quit(aFerocity); } \
  NS_IMETHOD CreateTopLevelWindow(nsIXULWindow *aParent, nsIURI *aUrl, PRBool aShowWindow, PRBool aLoadDefaultPage, PRUint32 aChromeMask, PRInt32 aInitialWidth, PRInt32 aInitialHeight, nsIXULWindow **_retval) { return _to CreateTopLevelWindow(aParent, aUrl, aShowWindow, aLoadDefaultPage, aChromeMask, aInitialWidth, aInitialHeight, _retval); } \
  NS_IMETHOD CloseTopLevelWindow(nsIXULWindow *aWindow) { return _to CloseTopLevelWindow(aWindow); } \
  NS_IMETHOD CreateHiddenWindow(void) { return _to CreateHiddenWindow(); } \
  NS_IMETHOD GetHiddenWindow(nsIXULWindow * *aHiddenWindow) { return _to GetHiddenWindow(aHiddenWindow); } \
  NS_IMETHOD GetHiddenDOMWindow(nsIDOMWindowInternal * *aHiddenDOMWindow) { return _to GetHiddenDOMWindow(aHiddenDOMWindow); } \
  NS_IMETHOD GetHiddenWindowAndJSContext(nsIDOMWindowInternal **aHiddenDOMWindow, JSContext * *aJSContext) { return _to GetHiddenWindowAndJSContext(aHiddenDOMWindow, aJSContext); } \
  NS_IMETHOD RegisterTopLevelWindow(nsIXULWindow *aWindow) { return _to RegisterTopLevelWindow(aWindow); } \
  NS_IMETHOD UnregisterTopLevelWindow(nsIXULWindow *aWindow) { return _to UnregisterTopLevelWindow(aWindow); } \
  NS_IMETHOD TopLevelWindowIsModal(nsIXULWindow *aWindow, PRBool aModal) { return _to TopLevelWindowIsModal(aWindow, aModal); } \
  NS_IMETHOD HideSplashScreen(void) { return _to HideSplashScreen(); } \
  NS_IMETHOD EnterLastWindowClosingSurvivalArea(void) { return _to EnterLastWindowClosingSurvivalArea(); } \
  NS_IMETHOD ExitLastWindowClosingSurvivalArea(void) { return _to ExitLastWindowClosingSurvivalArea(); } \
  NS_IMETHOD CreateStartupState(PRInt32 aWindowWidth, PRInt32 aWindowHeight, PRBool *_retval) { return _to CreateStartupState(aWindowWidth, aWindowHeight, _retval); } \
  NS_IMETHOD Ensure1Window(nsICmdLineService *aCmdLineService) { return _to Ensure1Window(aCmdLineService); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIAPPSHELLSERVICE(_to) \
  NS_IMETHOD Initialize(nsICmdLineService *aCmdLineService, nsISupports *nativeAppSupportOrSplashScreen) { return !_to ? NS_ERROR_NULL_POINTER : _to->Initialize(aCmdLineService, nativeAppSupportOrSplashScreen); } \
  NS_IMETHOD DoProfileStartup(nsICmdLineService *aCmdLineService, PRBool canInteract) { return !_to ? NS_ERROR_NULL_POINTER : _to->DoProfileStartup(aCmdLineService, canInteract); } \
  NS_IMETHOD GetNativeAppSupport(nsINativeAppSupport * *aNativeAppSupport) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNativeAppSupport(aNativeAppSupport); } \
  NS_IMETHOD Run(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->Run(); } \
  NS_IMETHOD Quit(PRUint32 aFerocity) { return !_to ? NS_ERROR_NULL_POINTER : _to->Quit(aFerocity); } \
  NS_IMETHOD CreateTopLevelWindow(nsIXULWindow *aParent, nsIURI *aUrl, PRBool aShowWindow, PRBool aLoadDefaultPage, PRUint32 aChromeMask, PRInt32 aInitialWidth, PRInt32 aInitialHeight, nsIXULWindow **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateTopLevelWindow(aParent, aUrl, aShowWindow, aLoadDefaultPage, aChromeMask, aInitialWidth, aInitialHeight, _retval); } \
  NS_IMETHOD CloseTopLevelWindow(nsIXULWindow *aWindow) { return !_to ? NS_ERROR_NULL_POINTER : _to->CloseTopLevelWindow(aWindow); } \
  NS_IMETHOD CreateHiddenWindow(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateHiddenWindow(); } \
  NS_IMETHOD GetHiddenWindow(nsIXULWindow * *aHiddenWindow) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHiddenWindow(aHiddenWindow); } \
  NS_IMETHOD GetHiddenDOMWindow(nsIDOMWindowInternal * *aHiddenDOMWindow) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHiddenDOMWindow(aHiddenDOMWindow); } \
  NS_IMETHOD GetHiddenWindowAndJSContext(nsIDOMWindowInternal **aHiddenDOMWindow, JSContext * *aJSContext) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetHiddenWindowAndJSContext(aHiddenDOMWindow, aJSContext); } \
  NS_IMETHOD RegisterTopLevelWindow(nsIXULWindow *aWindow) { return !_to ? NS_ERROR_NULL_POINTER : _to->RegisterTopLevelWindow(aWindow); } \
  NS_IMETHOD UnregisterTopLevelWindow(nsIXULWindow *aWindow) { return !_to ? NS_ERROR_NULL_POINTER : _to->UnregisterTopLevelWindow(aWindow); } \
  NS_IMETHOD TopLevelWindowIsModal(nsIXULWindow *aWindow, PRBool aModal) { return !_to ? NS_ERROR_NULL_POINTER : _to->TopLevelWindowIsModal(aWindow, aModal); } \
  NS_IMETHOD HideSplashScreen(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->HideSplashScreen(); } \
  NS_IMETHOD EnterLastWindowClosingSurvivalArea(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->EnterLastWindowClosingSurvivalArea(); } \
  NS_IMETHOD ExitLastWindowClosingSurvivalArea(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->ExitLastWindowClosingSurvivalArea(); } \
  NS_IMETHOD CreateStartupState(PRInt32 aWindowWidth, PRInt32 aWindowHeight, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CreateStartupState(aWindowWidth, aWindowHeight, _retval); } \
  NS_IMETHOD Ensure1Window(nsICmdLineService *aCmdLineService) { return !_to ? NS_ERROR_NULL_POINTER : _to->Ensure1Window(aCmdLineService); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAppShellService : public nsIAppShellService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIAPPSHELLSERVICE

  nsAppShellService();

private:
  ~nsAppShellService();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAppShellService, nsIAppShellService)

nsAppShellService::nsAppShellService()
{
  /* member initializers and constructor code */
}

nsAppShellService::~nsAppShellService()
{
  /* destructor code */
}

/* void initialize (in nsICmdLineService aCmdLineService, in nsISupports nativeAppSupportOrSplashScreen); */
NS_IMETHODIMP nsAppShellService::Initialize(nsICmdLineService *aCmdLineService, nsISupports *nativeAppSupportOrSplashScreen)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void doProfileStartup (in nsICmdLineService aCmdLineService, in boolean canInteract); */
NS_IMETHODIMP nsAppShellService::DoProfileStartup(nsICmdLineService *aCmdLineService, PRBool canInteract)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsINativeAppSupport nativeAppSupport; */
NS_IMETHODIMP nsAppShellService::GetNativeAppSupport(nsINativeAppSupport * *aNativeAppSupport)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void run (); */
NS_IMETHODIMP nsAppShellService::Run()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void quit (in PRUint32 aFerocity); */
NS_IMETHODIMP nsAppShellService::Quit(PRUint32 aFerocity)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIXULWindow createTopLevelWindow (in nsIXULWindow aParent, in nsIURI aUrl, in boolean aShowWindow, in boolean aLoadDefaultPage, in PRUint32 aChromeMask, in long aInitialWidth, in long aInitialHeight); */
NS_IMETHODIMP nsAppShellService::CreateTopLevelWindow(nsIXULWindow *aParent, nsIURI *aUrl, PRBool aShowWindow, PRBool aLoadDefaultPage, PRUint32 aChromeMask, PRInt32 aInitialWidth, PRInt32 aInitialHeight, nsIXULWindow **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void closeTopLevelWindow (in nsIXULWindow aWindow); */
NS_IMETHODIMP nsAppShellService::CloseTopLevelWindow(nsIXULWindow *aWindow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void createHiddenWindow (); */
NS_IMETHODIMP nsAppShellService::CreateHiddenWindow()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsIXULWindow hiddenWindow; */
NS_IMETHODIMP nsAppShellService::GetHiddenWindow(nsIXULWindow * *aHiddenWindow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsIDOMWindowInternal hiddenDOMWindow; */
NS_IMETHODIMP nsAppShellService::GetHiddenDOMWindow(nsIDOMWindowInternal * *aHiddenDOMWindow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void getHiddenWindowAndJSContext (out nsIDOMWindowInternal aHiddenDOMWindow, out JSContext aJSContext); */
NS_IMETHODIMP nsAppShellService::GetHiddenWindowAndJSContext(nsIDOMWindowInternal **aHiddenDOMWindow, JSContext * *aJSContext)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void registerTopLevelWindow (in nsIXULWindow aWindow); */
NS_IMETHODIMP nsAppShellService::RegisterTopLevelWindow(nsIXULWindow *aWindow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void unregisterTopLevelWindow (in nsIXULWindow aWindow); */
NS_IMETHODIMP nsAppShellService::UnregisterTopLevelWindow(nsIXULWindow *aWindow)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void topLevelWindowIsModal (in nsIXULWindow aWindow, in boolean aModal); */
NS_IMETHODIMP nsAppShellService::TopLevelWindowIsModal(nsIXULWindow *aWindow, PRBool aModal)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void hideSplashScreen (); */
NS_IMETHODIMP nsAppShellService::HideSplashScreen()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void enterLastWindowClosingSurvivalArea (); */
NS_IMETHODIMP nsAppShellService::EnterLastWindowClosingSurvivalArea()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void exitLastWindowClosingSurvivalArea (); */
NS_IMETHODIMP nsAppShellService::ExitLastWindowClosingSurvivalArea()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean createStartupState (in long aWindowWidth, in long aWindowHeight); */
NS_IMETHODIMP nsAppShellService::CreateStartupState(PRInt32 aWindowWidth, PRInt32 aWindowHeight, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void ensure1Window (in nsICmdLineService aCmdLineService); */
NS_IMETHODIMP nsAppShellService::Ensure1Window(nsICmdLineService *aCmdLineService)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAppShellService_h__ */
