/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIChromeRegistry.idl
 */

#ifndef __gen_nsIChromeRegistry_h__
#define __gen_nsIChromeRegistry_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIURL_h__
#include "nsIURL.h"
#endif

#ifndef __gen_nsISimpleEnumerator_h__
#include "nsISimpleEnumerator.h"
#endif

#ifndef __gen_nsISupportsArray_h__
#include "nsISupportsArray.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIDocShell; /* forward declaration */


/* starting interface:    nsIChromeRegistry */
#define NS_ICHROMEREGISTRY_IID_STR "68389281-f6d0-4533-841d-344a2018140c"

#define NS_ICHROMEREGISTRY_IID \
  {0x68389281, 0xf6d0, 0x4533, \
    { 0x84, 0x1d, 0x34, 0x4a, 0x20, 0x18, 0x14, 0x0c }}

class NS_NO_VTABLE nsIChromeRegistry : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ICHROMEREGISTRY_IID)

  enum { NONE = 0 };

  enum { PARTIAL = 1 };

  enum { FULL = 2 };

  /**
   * Convert a chrome URL into a canonical representation; specifically,
   *
   *   chrome://package/provider/file
   *
   * Chrome URLs are allowed to be specified in "shorthand", leaving the
   * "file" portion off. In that case, the URL is expanded to:
   *
   *   chrome://package/provider/package.ext
   *
   * where "ext" is:
   *
   *   "xul" for a "content" package,
   *   "css" for a "skin" package, and
   *   "dtd" for a "locale" package.
   *
   * @param aChromeURL the URL that is to be canonified.
   */
  /* void canonify (in nsIURI aChromeURL); */
  NS_IMETHOD Canonify(nsIURI *aChromeURL) = 0;

  /**
   * Convert a chrome URL to a "real" using the information in the registry.
   * Does not modify aChromeURL.
   *
   * @param aChromeURL the URL that is to be converted.
   */
  /* AUTF8String convertChromeURL (in nsIURI aChromeURL); */
  NS_IMETHOD ConvertChromeURL(nsIURI *aChromeURL, nsACString & _retval) = 0;

  /**
   * refresh the chrome list at runtime, looking for new packages/etc
   */
  /* void checkForNewChrome (); */
  NS_IMETHOD CheckForNewChrome(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICHROMEREGISTRY \
  NS_IMETHOD Canonify(nsIURI *aChromeURL); \
  NS_IMETHOD ConvertChromeURL(nsIURI *aChromeURL, nsACString & _retval); \
  NS_IMETHOD CheckForNewChrome(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICHROMEREGISTRY(_to) \
  NS_IMETHOD Canonify(nsIURI *aChromeURL) { return _to Canonify(aChromeURL); } \
  NS_IMETHOD ConvertChromeURL(nsIURI *aChromeURL, nsACString & _retval) { return _to ConvertChromeURL(aChromeURL, _retval); } \
  NS_IMETHOD CheckForNewChrome(void) { return _to CheckForNewChrome(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICHROMEREGISTRY(_to) \
  NS_IMETHOD Canonify(nsIURI *aChromeURL) { return !_to ? NS_ERROR_NULL_POINTER : _to->Canonify(aChromeURL); } \
  NS_IMETHOD ConvertChromeURL(nsIURI *aChromeURL, nsACString & _retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ConvertChromeURL(aChromeURL, _retval); } \
  NS_IMETHOD CheckForNewChrome(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->CheckForNewChrome(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsChromeRegistry : public nsIChromeRegistry
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICHROMEREGISTRY

  nsChromeRegistry();

private:
  ~nsChromeRegistry();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsChromeRegistry, nsIChromeRegistry)

nsChromeRegistry::nsChromeRegistry()
{
  /* member initializers and constructor code */
}

nsChromeRegistry::~nsChromeRegistry()
{
  /* destructor code */
}

/* void canonify (in nsIURI aChromeURL); */
NS_IMETHODIMP nsChromeRegistry::Canonify(nsIURI *aChromeURL)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* AUTF8String convertChromeURL (in nsIURI aChromeURL); */
NS_IMETHODIMP nsChromeRegistry::ConvertChromeURL(nsIURI *aChromeURL, nsACString & _retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void checkForNewChrome (); */
NS_IMETHODIMP nsChromeRegistry::CheckForNewChrome()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIXULChromeRegistry */
#define NS_IXULCHROMEREGISTRY_IID_STR "a9f92623-5982-4afe-9d90-619cf5b0c39f"

#define NS_IXULCHROMEREGISTRY_IID \
  {0xa9f92623, 0x5982, 0x4afe, \
    { 0x9d, 0x90, 0x61, 0x9c, 0xf5, 0xb0, 0xc3, 0x9f }}

class NS_NO_VTABLE nsIXULChromeRegistry : public nsIChromeRegistry {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IXULCHROMEREGISTRY_IID)

  /* void selectSkin (in ACString skinName, in boolean useProfile); */
  NS_IMETHOD SelectSkin(const nsACString & skinName, PRBool useProfile) = 0;

  /* void selectLocale (in ACString localeName, in boolean useProfile); */
  NS_IMETHOD SelectLocale(const nsACString & localeName, PRBool useProfile) = 0;

  /* void deselectSkin (in ACString skinName, in boolean useProfile); */
  NS_IMETHOD DeselectSkin(const nsACString & skinName, PRBool useProfile) = 0;

  /* void deselectLocale (in ACString localeName, in boolean useProfile); */
  NS_IMETHOD DeselectLocale(const nsACString & localeName, PRBool useProfile) = 0;

  /* PRInt32 isSkinSelected (in ACString skinName, in boolean useProfile); */
  NS_IMETHOD IsSkinSelected(const nsACString & skinName, PRBool useProfile, PRInt32 *_retval) = 0;

  /* PRInt32 isLocaleSelected (in ACString localeName, in boolean useProfile); */
  NS_IMETHOD IsLocaleSelected(const nsACString & localeName, PRBool useProfile, PRInt32 *_retval) = 0;

  /* void selectLocaleForProfile (in ACString localeName, in wstring profilePath); */
  NS_IMETHOD SelectLocaleForProfile(const nsACString & localeName, const PRUnichar *profilePath) = 0;

  /* void reloadChrome (); */
  NS_IMETHOD ReloadChrome(void) = 0;

  /* void setRuntimeProvider (in boolean runtimeProvider); */
  NS_IMETHOD SetRuntimeProvider(PRBool runtimeProvider) = 0;

  /* boolean checkThemeVersion (in ACString skinName); */
  NS_IMETHOD CheckThemeVersion(const nsACString & skinName, PRBool *_retval) = 0;

  /* boolean checkLocaleVersion (in ACString localeName); */
  NS_IMETHOD CheckLocaleVersion(const nsACString & localeName, PRBool *_retval) = 0;

  /* void selectSkinForPackage (in ACString skinName, in wstring packageName, in boolean useProfile); */
  NS_IMETHOD SelectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile) = 0;

  /* void selectLocaleForPackage (in ACString localeName, in wstring packageName, in boolean useProfile); */
  NS_IMETHOD SelectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile) = 0;

  /* void deselectSkinForPackage (in ACString skinName, in wstring packageName, in boolean useProfile); */
  NS_IMETHOD DeselectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile) = 0;

  /* void deselectLocaleForPackage (in ACString localeName, in wstring packageName, in boolean useProfile); */
  NS_IMETHOD DeselectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile) = 0;

  /* boolean isSkinSelectedForPackage (in ACString skinName, in wstring packageName, in boolean useProfile); */
  NS_IMETHOD IsSkinSelectedForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval) = 0;

  /* boolean isLocaleSelectedForPackage (in ACString localeName, in wstring packageName, in boolean useProfile); */
  NS_IMETHOD IsLocaleSelectedForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval) = 0;

  /* ACString getSelectedLocale (in ACString packageName); */
  NS_IMETHOD GetSelectedLocale(const nsACString & packageName, nsACString & _retval) = 0;

  /* ACString getSelectedSkin (in ACString packageName); */
  NS_IMETHOD GetSelectedSkin(const nsACString & packageName, nsACString & _retval) = 0;

  /* void refreshSkins (); */
  NS_IMETHOD RefreshSkins(void) = 0;

  /* boolean allowScriptsForSkin (in nsIURI url); */
  NS_IMETHOD AllowScriptsForSkin(nsIURI *url, PRBool *_retval) = 0;

  /* void setAllowOverlaysForPackage (in wstring packageName, in boolean allowOverlays); */
  NS_IMETHOD SetAllowOverlaysForPackage(const PRUnichar *packageName, PRBool allowOverlays) = 0;

  /* void installSkin (in string baseURL, in boolean useProfile, in boolean allowScripts); */
  NS_IMETHOD InstallSkin(const char *baseURL, PRBool useProfile, PRBool allowScripts) = 0;

  /* void uninstallSkin (in ACString skinName, in boolean useProfile); */
  NS_IMETHOD UninstallSkin(const nsACString & skinName, PRBool useProfile) = 0;

  /* void installLocale (in string baseURL, in boolean useProfile); */
  NS_IMETHOD InstallLocale(const char *baseURL, PRBool useProfile) = 0;

  /* void uninstallLocale (in ACString localeName, in boolean useProfile); */
  NS_IMETHOD UninstallLocale(const nsACString & localeName, PRBool useProfile) = 0;

  /* void installPackage (in string baseURL, in boolean useProfile); */
  NS_IMETHOD InstallPackage(const char *baseURL, PRBool useProfile) = 0;

  /* void uninstallPackage (in wstring packageName, in boolean useProfile); */
  NS_IMETHOD UninstallPackage(const PRUnichar *packageName, PRBool useProfile) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIXULCHROMEREGISTRY \
  NS_IMETHOD SelectSkin(const nsACString & skinName, PRBool useProfile); \
  NS_IMETHOD SelectLocale(const nsACString & localeName, PRBool useProfile); \
  NS_IMETHOD DeselectSkin(const nsACString & skinName, PRBool useProfile); \
  NS_IMETHOD DeselectLocale(const nsACString & localeName, PRBool useProfile); \
  NS_IMETHOD IsSkinSelected(const nsACString & skinName, PRBool useProfile, PRInt32 *_retval); \
  NS_IMETHOD IsLocaleSelected(const nsACString & localeName, PRBool useProfile, PRInt32 *_retval); \
  NS_IMETHOD SelectLocaleForProfile(const nsACString & localeName, const PRUnichar *profilePath); \
  NS_IMETHOD ReloadChrome(void); \
  NS_IMETHOD SetRuntimeProvider(PRBool runtimeProvider); \
  NS_IMETHOD CheckThemeVersion(const nsACString & skinName, PRBool *_retval); \
  NS_IMETHOD CheckLocaleVersion(const nsACString & localeName, PRBool *_retval); \
  NS_IMETHOD SelectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile); \
  NS_IMETHOD SelectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile); \
  NS_IMETHOD DeselectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile); \
  NS_IMETHOD DeselectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile); \
  NS_IMETHOD IsSkinSelectedForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval); \
  NS_IMETHOD IsLocaleSelectedForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval); \
  NS_IMETHOD GetSelectedLocale(const nsACString & packageName, nsACString & _retval); \
  NS_IMETHOD GetSelectedSkin(const nsACString & packageName, nsACString & _retval); \
  NS_IMETHOD RefreshSkins(void); \
  NS_IMETHOD AllowScriptsForSkin(nsIURI *url, PRBool *_retval); \
  NS_IMETHOD SetAllowOverlaysForPackage(const PRUnichar *packageName, PRBool allowOverlays); \
  NS_IMETHOD InstallSkin(const char *baseURL, PRBool useProfile, PRBool allowScripts); \
  NS_IMETHOD UninstallSkin(const nsACString & skinName, PRBool useProfile); \
  NS_IMETHOD InstallLocale(const char *baseURL, PRBool useProfile); \
  NS_IMETHOD UninstallLocale(const nsACString & localeName, PRBool useProfile); \
  NS_IMETHOD InstallPackage(const char *baseURL, PRBool useProfile); \
  NS_IMETHOD UninstallPackage(const PRUnichar *packageName, PRBool useProfile); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIXULCHROMEREGISTRY(_to) \
  NS_IMETHOD SelectSkin(const nsACString & skinName, PRBool useProfile) { return _to SelectSkin(skinName, useProfile); } \
  NS_IMETHOD SelectLocale(const nsACString & localeName, PRBool useProfile) { return _to SelectLocale(localeName, useProfile); } \
  NS_IMETHOD DeselectSkin(const nsACString & skinName, PRBool useProfile) { return _to DeselectSkin(skinName, useProfile); } \
  NS_IMETHOD DeselectLocale(const nsACString & localeName, PRBool useProfile) { return _to DeselectLocale(localeName, useProfile); } \
  NS_IMETHOD IsSkinSelected(const nsACString & skinName, PRBool useProfile, PRInt32 *_retval) { return _to IsSkinSelected(skinName, useProfile, _retval); } \
  NS_IMETHOD IsLocaleSelected(const nsACString & localeName, PRBool useProfile, PRInt32 *_retval) { return _to IsLocaleSelected(localeName, useProfile, _retval); } \
  NS_IMETHOD SelectLocaleForProfile(const nsACString & localeName, const PRUnichar *profilePath) { return _to SelectLocaleForProfile(localeName, profilePath); } \
  NS_IMETHOD ReloadChrome(void) { return _to ReloadChrome(); } \
  NS_IMETHOD SetRuntimeProvider(PRBool runtimeProvider) { return _to SetRuntimeProvider(runtimeProvider); } \
  NS_IMETHOD CheckThemeVersion(const nsACString & skinName, PRBool *_retval) { return _to CheckThemeVersion(skinName, _retval); } \
  NS_IMETHOD CheckLocaleVersion(const nsACString & localeName, PRBool *_retval) { return _to CheckLocaleVersion(localeName, _retval); } \
  NS_IMETHOD SelectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile) { return _to SelectSkinForPackage(skinName, packageName, useProfile); } \
  NS_IMETHOD SelectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile) { return _to SelectLocaleForPackage(localeName, packageName, useProfile); } \
  NS_IMETHOD DeselectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile) { return _to DeselectSkinForPackage(skinName, packageName, useProfile); } \
  NS_IMETHOD DeselectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile) { return _to DeselectLocaleForPackage(localeName, packageName, useProfile); } \
  NS_IMETHOD IsSkinSelectedForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval) { return _to IsSkinSelectedForPackage(skinName, packageName, useProfile, _retval); } \
  NS_IMETHOD IsLocaleSelectedForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval) { return _to IsLocaleSelectedForPackage(localeName, packageName, useProfile, _retval); } \
  NS_IMETHOD GetSelectedLocale(const nsACString & packageName, nsACString & _retval) { return _to GetSelectedLocale(packageName, _retval); } \
  NS_IMETHOD GetSelectedSkin(const nsACString & packageName, nsACString & _retval) { return _to GetSelectedSkin(packageName, _retval); } \
  NS_IMETHOD RefreshSkins(void) { return _to RefreshSkins(); } \
  NS_IMETHOD AllowScriptsForSkin(nsIURI *url, PRBool *_retval) { return _to AllowScriptsForSkin(url, _retval); } \
  NS_IMETHOD SetAllowOverlaysForPackage(const PRUnichar *packageName, PRBool allowOverlays) { return _to SetAllowOverlaysForPackage(packageName, allowOverlays); } \
  NS_IMETHOD InstallSkin(const char *baseURL, PRBool useProfile, PRBool allowScripts) { return _to InstallSkin(baseURL, useProfile, allowScripts); } \
  NS_IMETHOD UninstallSkin(const nsACString & skinName, PRBool useProfile) { return _to UninstallSkin(skinName, useProfile); } \
  NS_IMETHOD InstallLocale(const char *baseURL, PRBool useProfile) { return _to InstallLocale(baseURL, useProfile); } \
  NS_IMETHOD UninstallLocale(const nsACString & localeName, PRBool useProfile) { return _to UninstallLocale(localeName, useProfile); } \
  NS_IMETHOD InstallPackage(const char *baseURL, PRBool useProfile) { return _to InstallPackage(baseURL, useProfile); } \
  NS_IMETHOD UninstallPackage(const PRUnichar *packageName, PRBool useProfile) { return _to UninstallPackage(packageName, useProfile); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIXULCHROMEREGISTRY(_to) \
  NS_IMETHOD SelectSkin(const nsACString & skinName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectSkin(skinName, useProfile); } \
  NS_IMETHOD SelectLocale(const nsACString & localeName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectLocale(localeName, useProfile); } \
  NS_IMETHOD DeselectSkin(const nsACString & skinName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeselectSkin(skinName, useProfile); } \
  NS_IMETHOD DeselectLocale(const nsACString & localeName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeselectLocale(localeName, useProfile); } \
  NS_IMETHOD IsSkinSelected(const nsACString & skinName, PRBool useProfile, PRInt32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsSkinSelected(skinName, useProfile, _retval); } \
  NS_IMETHOD IsLocaleSelected(const nsACString & localeName, PRBool useProfile, PRInt32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsLocaleSelected(localeName, useProfile, _retval); } \
  NS_IMETHOD SelectLocaleForProfile(const nsACString & localeName, const PRUnichar *profilePath) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectLocaleForProfile(localeName, profilePath); } \
  NS_IMETHOD ReloadChrome(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->ReloadChrome(); } \
  NS_IMETHOD SetRuntimeProvider(PRBool runtimeProvider) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetRuntimeProvider(runtimeProvider); } \
  NS_IMETHOD CheckThemeVersion(const nsACString & skinName, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CheckThemeVersion(skinName, _retval); } \
  NS_IMETHOD CheckLocaleVersion(const nsACString & localeName, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->CheckLocaleVersion(localeName, _retval); } \
  NS_IMETHOD SelectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectSkinForPackage(skinName, packageName, useProfile); } \
  NS_IMETHOD SelectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->SelectLocaleForPackage(localeName, packageName, useProfile); } \
  NS_IMETHOD DeselectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeselectSkinForPackage(skinName, packageName, useProfile); } \
  NS_IMETHOD DeselectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeselectLocaleForPackage(localeName, packageName, useProfile); } \
  NS_IMETHOD IsSkinSelectedForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsSkinSelectedForPackage(skinName, packageName, useProfile, _retval); } \
  NS_IMETHOD IsLocaleSelectedForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->IsLocaleSelectedForPackage(localeName, packageName, useProfile, _retval); } \
  NS_IMETHOD GetSelectedLocale(const nsACString & packageName, nsACString & _retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSelectedLocale(packageName, _retval); } \
  NS_IMETHOD GetSelectedSkin(const nsACString & packageName, nsACString & _retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetSelectedSkin(packageName, _retval); } \
  NS_IMETHOD RefreshSkins(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->RefreshSkins(); } \
  NS_IMETHOD AllowScriptsForSkin(nsIURI *url, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->AllowScriptsForSkin(url, _retval); } \
  NS_IMETHOD SetAllowOverlaysForPackage(const PRUnichar *packageName, PRBool allowOverlays) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetAllowOverlaysForPackage(packageName, allowOverlays); } \
  NS_IMETHOD InstallSkin(const char *baseURL, PRBool useProfile, PRBool allowScripts) { return !_to ? NS_ERROR_NULL_POINTER : _to->InstallSkin(baseURL, useProfile, allowScripts); } \
  NS_IMETHOD UninstallSkin(const nsACString & skinName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->UninstallSkin(skinName, useProfile); } \
  NS_IMETHOD InstallLocale(const char *baseURL, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->InstallLocale(baseURL, useProfile); } \
  NS_IMETHOD UninstallLocale(const nsACString & localeName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->UninstallLocale(localeName, useProfile); } \
  NS_IMETHOD InstallPackage(const char *baseURL, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->InstallPackage(baseURL, useProfile); } \
  NS_IMETHOD UninstallPackage(const PRUnichar *packageName, PRBool useProfile) { return !_to ? NS_ERROR_NULL_POINTER : _to->UninstallPackage(packageName, useProfile); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsXULChromeRegistry : public nsIXULChromeRegistry
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIXULCHROMEREGISTRY

  nsXULChromeRegistry();

private:
  ~nsXULChromeRegistry();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsXULChromeRegistry, nsIXULChromeRegistry)

nsXULChromeRegistry::nsXULChromeRegistry()
{
  /* member initializers and constructor code */
}

nsXULChromeRegistry::~nsXULChromeRegistry()
{
  /* destructor code */
}

/* void selectSkin (in ACString skinName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::SelectSkin(const nsACString & skinName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void selectLocale (in ACString localeName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::SelectLocale(const nsACString & localeName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deselectSkin (in ACString skinName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::DeselectSkin(const nsACString & skinName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deselectLocale (in ACString localeName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::DeselectLocale(const nsACString & localeName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* PRInt32 isSkinSelected (in ACString skinName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::IsSkinSelected(const nsACString & skinName, PRBool useProfile, PRInt32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* PRInt32 isLocaleSelected (in ACString localeName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::IsLocaleSelected(const nsACString & localeName, PRBool useProfile, PRInt32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void selectLocaleForProfile (in ACString localeName, in wstring profilePath); */
NS_IMETHODIMP nsXULChromeRegistry::SelectLocaleForProfile(const nsACString & localeName, const PRUnichar *profilePath)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void reloadChrome (); */
NS_IMETHODIMP nsXULChromeRegistry::ReloadChrome()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setRuntimeProvider (in boolean runtimeProvider); */
NS_IMETHODIMP nsXULChromeRegistry::SetRuntimeProvider(PRBool runtimeProvider)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean checkThemeVersion (in ACString skinName); */
NS_IMETHODIMP nsXULChromeRegistry::CheckThemeVersion(const nsACString & skinName, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean checkLocaleVersion (in ACString localeName); */
NS_IMETHODIMP nsXULChromeRegistry::CheckLocaleVersion(const nsACString & localeName, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void selectSkinForPackage (in ACString skinName, in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::SelectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void selectLocaleForPackage (in ACString localeName, in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::SelectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deselectSkinForPackage (in ACString skinName, in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::DeselectSkinForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deselectLocaleForPackage (in ACString localeName, in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::DeselectLocaleForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean isSkinSelectedForPackage (in ACString skinName, in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::IsSkinSelectedForPackage(const nsACString & skinName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean isLocaleSelectedForPackage (in ACString localeName, in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::IsLocaleSelectedForPackage(const nsACString & localeName, const PRUnichar *packageName, PRBool useProfile, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* ACString getSelectedLocale (in ACString packageName); */
NS_IMETHODIMP nsXULChromeRegistry::GetSelectedLocale(const nsACString & packageName, nsACString & _retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* ACString getSelectedSkin (in ACString packageName); */
NS_IMETHODIMP nsXULChromeRegistry::GetSelectedSkin(const nsACString & packageName, nsACString & _retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void refreshSkins (); */
NS_IMETHODIMP nsXULChromeRegistry::RefreshSkins()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean allowScriptsForSkin (in nsIURI url); */
NS_IMETHODIMP nsXULChromeRegistry::AllowScriptsForSkin(nsIURI *url, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setAllowOverlaysForPackage (in wstring packageName, in boolean allowOverlays); */
NS_IMETHODIMP nsXULChromeRegistry::SetAllowOverlaysForPackage(const PRUnichar *packageName, PRBool allowOverlays)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void installSkin (in string baseURL, in boolean useProfile, in boolean allowScripts); */
NS_IMETHODIMP nsXULChromeRegistry::InstallSkin(const char *baseURL, PRBool useProfile, PRBool allowScripts)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void uninstallSkin (in ACString skinName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::UninstallSkin(const nsACString & skinName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void installLocale (in string baseURL, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::InstallLocale(const char *baseURL, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void uninstallLocale (in ACString localeName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::UninstallLocale(const nsACString & localeName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void installPackage (in string baseURL, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::InstallPackage(const char *baseURL, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void uninstallPackage (in wstring packageName, in boolean useProfile); */
NS_IMETHODIMP nsXULChromeRegistry::UninstallPackage(const PRUnichar *packageName, PRBool useProfile)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif

#define NS_CHROMEREGISTRY_CONTRACTID \
  "@mozilla.org/chrome/chrome-registry;1"
/**
 * Chrome registry will notify various caches that all chrome files need
 * flushing.
 */
#define NS_CHROME_FLUSH_TOPIC \
  "chrome-flush-caches"
/**
 * Chrome registry will notify various caches that skin files need flushing.
 * If "chrome-flush-caches" is notified, this topic will *not* be notified.
 */
#define NS_CHROME_FLUSH_SKINS_TOPIC \
  "chrome-flush-skin-caches"

#endif /* __gen_nsIChromeRegistry_h__ */
