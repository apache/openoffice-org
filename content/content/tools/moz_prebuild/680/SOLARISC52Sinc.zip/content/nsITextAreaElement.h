/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsITextAreaElement.idl
 */

#ifndef __gen_nsITextAreaElement_h__
#define __gen_nsITextAreaElement_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsITextAreaElement */
#define NS_ITEXTAREAELEMENT_IID_STR "36878df2-1dd2-11b2-99a0-ea9fab347485"

#define NS_ITEXTAREAELEMENT_IID \
  {0x36878df2, 0x1dd2, 0x11b2, \
    { 0x99, 0xa0, 0xea, 0x9f, 0xab, 0x34, 0x74, 0x85 }}

/**
 * This interface is used so that the parser can notify the textarea when
 * it has finished loading content.
 */
class NS_NO_VTABLE nsITextAreaElement : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ITEXTAREAELEMENT_IID)

  /**
   * Called when the parser is done adding child content
   * to the select during document loading.
   */
  /* void doneAddingChildren (); */
  NS_IMETHOD DoneAddingChildren(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSITEXTAREAELEMENT \
  NS_IMETHOD DoneAddingChildren(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSITEXTAREAELEMENT(_to) \
  NS_IMETHOD DoneAddingChildren(void) { return _to DoneAddingChildren(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSITEXTAREAELEMENT(_to) \
  NS_IMETHOD DoneAddingChildren(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->DoneAddingChildren(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsTextAreaElement : public nsITextAreaElement
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSITEXTAREAELEMENT

  nsTextAreaElement();

private:
  ~nsTextAreaElement();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsTextAreaElement, nsITextAreaElement)

nsTextAreaElement::nsTextAreaElement()
{
  /* member initializers and constructor code */
}

nsTextAreaElement::~nsTextAreaElement()
{
  /* destructor code */
}

/* void doneAddingChildren (); */
NS_IMETHODIMP nsTextAreaElement::DoneAddingChildren()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsITextAreaElement_h__ */
