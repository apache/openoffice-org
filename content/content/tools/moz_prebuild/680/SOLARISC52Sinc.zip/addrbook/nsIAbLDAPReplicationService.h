/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbLDAPReplicationService.idl
 */

#ifndef __gen_nsIAbLDAPReplicationService_h__
#define __gen_nsIAbLDAPReplicationService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIWebProgressListener; /* forward declaration */


/* starting interface:    nsIAbLDAPReplicationService */
#define NS_IABLDAPREPLICATIONSERVICE_IID_STR "00d568a0-3c3b-11d6-b7b9-00b0d06e5f27"

#define NS_IABLDAPREPLICATIONSERVICE_IID \
  {0x00d568a0, 0x3c3b, 0x11d6, \
    { 0xb7, 0xb9, 0x00, 0xb0, 0xd0, 0x6e, 0x5f, 0x27 }}

/**
 * this service does replication of an LDAP directory to a local Mork AB Database.
 */
class NS_NO_VTABLE nsIAbLDAPReplicationService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABLDAPREPLICATIONSERVICE_IID)

  /**
     * Start Replication of given LDAP directory represented by the URI
     */
  /* void startReplication (in ACString aPrefName, in nsIWebProgressListener progressListener); */
  NS_IMETHOD StartReplication(const nsACString & aPrefName, nsIWebProgressListener *progressListener) = 0;

  /**
     * Cancel Replication of given LDAP directory represented by the URI
     */
  /* void cancelReplication (in ACString aPrefName); */
  NS_IMETHOD CancelReplication(const nsACString & aPrefName) = 0;

  /**
     * callback when replication is done, failure or success
     */
  /* void done (in boolean aSuccess); */
  NS_IMETHOD Done(PRBool aSuccess) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABLDAPREPLICATIONSERVICE \
  NS_IMETHOD StartReplication(const nsACString & aPrefName, nsIWebProgressListener *progressListener); \
  NS_IMETHOD CancelReplication(const nsACString & aPrefName); \
  NS_IMETHOD Done(PRBool aSuccess); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABLDAPREPLICATIONSERVICE(_to) \
  NS_IMETHOD StartReplication(const nsACString & aPrefName, nsIWebProgressListener *progressListener) { return _to StartReplication(aPrefName, progressListener); } \
  NS_IMETHOD CancelReplication(const nsACString & aPrefName) { return _to CancelReplication(aPrefName); } \
  NS_IMETHOD Done(PRBool aSuccess) { return _to Done(aSuccess); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABLDAPREPLICATIONSERVICE(_to) \
  NS_IMETHOD StartReplication(const nsACString & aPrefName, nsIWebProgressListener *progressListener) { return !_to ? NS_ERROR_NULL_POINTER : _to->StartReplication(aPrefName, progressListener); } \
  NS_IMETHOD CancelReplication(const nsACString & aPrefName) { return !_to ? NS_ERROR_NULL_POINTER : _to->CancelReplication(aPrefName); } \
  NS_IMETHOD Done(PRBool aSuccess) { return !_to ? NS_ERROR_NULL_POINTER : _to->Done(aSuccess); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbLDAPReplicationService : public nsIAbLDAPReplicationService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABLDAPREPLICATIONSERVICE

  nsAbLDAPReplicationService();

private:
  ~nsAbLDAPReplicationService();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbLDAPReplicationService, nsIAbLDAPReplicationService)

nsAbLDAPReplicationService::nsAbLDAPReplicationService()
{
  /* member initializers and constructor code */
}

nsAbLDAPReplicationService::~nsAbLDAPReplicationService()
{
  /* destructor code */
}

/* void startReplication (in ACString aPrefName, in nsIWebProgressListener progressListener); */
NS_IMETHODIMP nsAbLDAPReplicationService::StartReplication(const nsACString & aPrefName, nsIWebProgressListener *progressListener)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void cancelReplication (in ACString aPrefName); */
NS_IMETHODIMP nsAbLDAPReplicationService::CancelReplication(const nsACString & aPrefName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void done (in boolean aSuccess); */
NS_IMETHODIMP nsAbLDAPReplicationService::Done(PRBool aSuccess)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbLDAPReplicationService_h__ */
