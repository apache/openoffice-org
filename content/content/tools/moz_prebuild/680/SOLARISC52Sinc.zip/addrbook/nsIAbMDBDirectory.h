/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbMDBDirectory.idl
 */

#ifndef __gen_nsIAbMDBDirectory_h__
#define __gen_nsIAbMDBDirectory_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAbCard_h__
#include "nsIAbCard.h"
#endif

#ifndef __gen_nsIAbDirectory_h__
#include "nsIAbDirectory.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIAbMDBDirectory */
#define NS_IABMDBDIRECTORY_IID_STR "c6bcf232-1dd1-11b2-a108-b41bfeced134"

#define NS_IABMDBDIRECTORY_IID \
  {0xc6bcf232, 0x1dd1, 0x11b2, \
    { 0xa1, 0x08, 0xb4, 0x1b, 0xfe, 0xce, 0xd1, 0x34 }}

class NS_NO_VTABLE nsIAbMDBDirectory : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABMDBDIRECTORY_IID)

  /* nsIAbDirectory addDirectory (in string uriName); */
  NS_IMETHOD AddDirectory(const char *uriName, nsIAbDirectory **_retval) = 0;

  /* string getDirUri (); */
  NS_IMETHOD GetDirUri(char **_retval) = 0;

  /* [noscript] void removeElementsFromAddressList (); */
  NS_IMETHOD RemoveElementsFromAddressList(void) = 0;

  /* void addMailListToDirectory (in nsIAbDirectory mailList); */
  NS_IMETHOD AddMailListToDirectory(nsIAbDirectory *mailList) = 0;

  /* void copyDBMailList (in nsIAbMDBDirectory srcListDB); */
  NS_IMETHOD CopyDBMailList(nsIAbMDBDirectory *srcListDB) = 0;

  /* void addAddressToList (in nsIAbCard card); */
  NS_IMETHOD AddAddressToList(nsIAbCard *card) = 0;

  /* void removeEmailAddressAt (in unsigned long aIndex); */
  NS_IMETHOD RemoveEmailAddressAt(PRUint32 aIndex) = 0;

  /* attribute unsigned long dbRowID; */
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID) = 0;
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID) = 0;

  /* [noscript] void notifyDirItemAdded (in nsISupports item); */
  NS_IMETHOD NotifyDirItemAdded(nsISupports *item) = 0;

  /* [noscript] void clearDatabase (); */
  NS_IMETHOD ClearDatabase(void) = 0;

  /* boolean hasCardForEmailAddress (in string emailAddress); */
  NS_IMETHOD HasCardForEmailAddress(const char *emailAddress, PRBool *_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABMDBDIRECTORY \
  NS_IMETHOD AddDirectory(const char *uriName, nsIAbDirectory **_retval); \
  NS_IMETHOD GetDirUri(char **_retval); \
  NS_IMETHOD RemoveElementsFromAddressList(void); \
  NS_IMETHOD AddMailListToDirectory(nsIAbDirectory *mailList); \
  NS_IMETHOD CopyDBMailList(nsIAbMDBDirectory *srcListDB); \
  NS_IMETHOD AddAddressToList(nsIAbCard *card); \
  NS_IMETHOD RemoveEmailAddressAt(PRUint32 aIndex); \
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID); \
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID); \
  NS_IMETHOD NotifyDirItemAdded(nsISupports *item); \
  NS_IMETHOD ClearDatabase(void); \
  NS_IMETHOD HasCardForEmailAddress(const char *emailAddress, PRBool *_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABMDBDIRECTORY(_to) \
  NS_IMETHOD AddDirectory(const char *uriName, nsIAbDirectory **_retval) { return _to AddDirectory(uriName, _retval); } \
  NS_IMETHOD GetDirUri(char **_retval) { return _to GetDirUri(_retval); } \
  NS_IMETHOD RemoveElementsFromAddressList(void) { return _to RemoveElementsFromAddressList(); } \
  NS_IMETHOD AddMailListToDirectory(nsIAbDirectory *mailList) { return _to AddMailListToDirectory(mailList); } \
  NS_IMETHOD CopyDBMailList(nsIAbMDBDirectory *srcListDB) { return _to CopyDBMailList(srcListDB); } \
  NS_IMETHOD AddAddressToList(nsIAbCard *card) { return _to AddAddressToList(card); } \
  NS_IMETHOD RemoveEmailAddressAt(PRUint32 aIndex) { return _to RemoveEmailAddressAt(aIndex); } \
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID) { return _to GetDbRowID(aDbRowID); } \
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID) { return _to SetDbRowID(aDbRowID); } \
  NS_IMETHOD NotifyDirItemAdded(nsISupports *item) { return _to NotifyDirItemAdded(item); } \
  NS_IMETHOD ClearDatabase(void) { return _to ClearDatabase(); } \
  NS_IMETHOD HasCardForEmailAddress(const char *emailAddress, PRBool *_retval) { return _to HasCardForEmailAddress(emailAddress, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABMDBDIRECTORY(_to) \
  NS_IMETHOD AddDirectory(const char *uriName, nsIAbDirectory **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddDirectory(uriName, _retval); } \
  NS_IMETHOD GetDirUri(char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDirUri(_retval); } \
  NS_IMETHOD RemoveElementsFromAddressList(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->RemoveElementsFromAddressList(); } \
  NS_IMETHOD AddMailListToDirectory(nsIAbDirectory *mailList) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddMailListToDirectory(mailList); } \
  NS_IMETHOD CopyDBMailList(nsIAbMDBDirectory *srcListDB) { return !_to ? NS_ERROR_NULL_POINTER : _to->CopyDBMailList(srcListDB); } \
  NS_IMETHOD AddAddressToList(nsIAbCard *card) { return !_to ? NS_ERROR_NULL_POINTER : _to->AddAddressToList(card); } \
  NS_IMETHOD RemoveEmailAddressAt(PRUint32 aIndex) { return !_to ? NS_ERROR_NULL_POINTER : _to->RemoveEmailAddressAt(aIndex); } \
  NS_IMETHOD GetDbRowID(PRUint32 *aDbRowID) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetDbRowID(aDbRowID); } \
  NS_IMETHOD SetDbRowID(PRUint32 aDbRowID) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDbRowID(aDbRowID); } \
  NS_IMETHOD NotifyDirItemAdded(nsISupports *item) { return !_to ? NS_ERROR_NULL_POINTER : _to->NotifyDirItemAdded(item); } \
  NS_IMETHOD ClearDatabase(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->ClearDatabase(); } \
  NS_IMETHOD HasCardForEmailAddress(const char *emailAddress, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->HasCardForEmailAddress(emailAddress, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbMDBDirectory : public nsIAbMDBDirectory
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABMDBDIRECTORY

  nsAbMDBDirectory();

private:
  ~nsAbMDBDirectory();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbMDBDirectory, nsIAbMDBDirectory)

nsAbMDBDirectory::nsAbMDBDirectory()
{
  /* member initializers and constructor code */
}

nsAbMDBDirectory::~nsAbMDBDirectory()
{
  /* destructor code */
}

/* nsIAbDirectory addDirectory (in string uriName); */
NS_IMETHODIMP nsAbMDBDirectory::AddDirectory(const char *uriName, nsIAbDirectory **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* string getDirUri (); */
NS_IMETHODIMP nsAbMDBDirectory::GetDirUri(char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void removeElementsFromAddressList (); */
NS_IMETHODIMP nsAbMDBDirectory::RemoveElementsFromAddressList()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void addMailListToDirectory (in nsIAbDirectory mailList); */
NS_IMETHODIMP nsAbMDBDirectory::AddMailListToDirectory(nsIAbDirectory *mailList)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void copyDBMailList (in nsIAbMDBDirectory srcListDB); */
NS_IMETHODIMP nsAbMDBDirectory::CopyDBMailList(nsIAbMDBDirectory *srcListDB)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void addAddressToList (in nsIAbCard card); */
NS_IMETHODIMP nsAbMDBDirectory::AddAddressToList(nsIAbCard *card)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void removeEmailAddressAt (in unsigned long aIndex); */
NS_IMETHODIMP nsAbMDBDirectory::RemoveEmailAddressAt(PRUint32 aIndex)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute unsigned long dbRowID; */
NS_IMETHODIMP nsAbMDBDirectory::GetDbRowID(PRUint32 *aDbRowID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbMDBDirectory::SetDbRowID(PRUint32 aDbRowID)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void notifyDirItemAdded (in nsISupports item); */
NS_IMETHODIMP nsAbMDBDirectory::NotifyDirItemAdded(nsISupports *item)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript] void clearDatabase (); */
NS_IMETHODIMP nsAbMDBDirectory::ClearDatabase()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean hasCardForEmailAddress (in string emailAddress); */
NS_IMETHODIMP nsAbMDBDirectory::HasCardForEmailAddress(const char *emailAddress, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbMDBDirectory_h__ */
