/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAbBooleanExpression.idl
 */

#ifndef __gen_nsIAbBooleanExpression_h__
#define __gen_nsIAbBooleanExpression_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsISupportsArray_h__
#include "nsISupportsArray.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
typedef PRInt32 nsAbBooleanConditionType;


/* starting interface:    nsIAbBooleanConditionTypes */
#define NS_IABBOOLEANCONDITIONTYPES_IID_STR "f51387b1-5aef-4a1c-830e-7cd3b02366ce"

#define NS_IABBOOLEANCONDITIONTYPES_IID \
  {0xf51387b1, 0x5aef, 0x4a1c, \
    { 0x83, 0x0e, 0x7c, 0xd3, 0xb0, 0x23, 0x66, 0xce }}

/**
 * Condition types
 *
 * Constants defining the types of condition
 * to obtain a boolean result of TRUE or FALSE
 *
 */
class NS_NO_VTABLE nsIAbBooleanConditionTypes {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABBOOLEANCONDITIONTYPES_IID)

  enum { Exists = 0 };

  enum { DoesNotExist = 1 };

  enum { Contains = 2 };

  enum { DoesNotContain = 3 };

  enum { Is = 4 };

  enum { IsNot = 5 };

  enum { BeginsWith = 6 };

  enum { EndsWith = 7 };

  enum { LessThan = 8 };

  enum { GreaterThan = 9 };

  enum { SoundsLike = 10 };

  enum { RegExp = 11 };

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABBOOLEANCONDITIONTYPES \

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABBOOLEANCONDITIONTYPES(_to) \

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABBOOLEANCONDITIONTYPES(_to) \

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbBooleanConditionTypes : public nsIAbBooleanConditionTypes
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABBOOLEANCONDITIONTYPES

  nsAbBooleanConditionTypes();

private:
  ~nsAbBooleanConditionTypes();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbBooleanConditionTypes, nsIAbBooleanConditionTypes)

nsAbBooleanConditionTypes::nsAbBooleanConditionTypes()
{
  /* member initializers and constructor code */
}

nsAbBooleanConditionTypes::~nsAbBooleanConditionTypes()
{
  /* destructor code */
}

/* End of implementation class template. */
#endif

typedef PRInt32 nsAbBooleanOperationType;


/* starting interface:    nsIAbBooleanOperationTypes */
#define NS_IABBOOLEANOPERATIONTYPES_IID_STR "9bdd2e51-2be4-49a4-a558-36d1a812231a"

#define NS_IABBOOLEANOPERATIONTYPES_IID \
  {0x9bdd2e51, 0x2be4, 0x49a4, \
    { 0xa5, 0x58, 0x36, 0xd1, 0xa8, 0x12, 0x23, 0x1a }}

class NS_NO_VTABLE nsIAbBooleanOperationTypes {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABBOOLEANOPERATIONTYPES_IID)

  enum { AND = 0 };

  enum { OR = 1 };

  enum { NOT = 2 };

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABBOOLEANOPERATIONTYPES \

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABBOOLEANOPERATIONTYPES(_to) \

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABBOOLEANOPERATIONTYPES(_to) \

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbBooleanOperationTypes : public nsIAbBooleanOperationTypes
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABBOOLEANOPERATIONTYPES

  nsAbBooleanOperationTypes();

private:
  ~nsAbBooleanOperationTypes();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbBooleanOperationTypes, nsIAbBooleanOperationTypes)

nsAbBooleanOperationTypes::nsAbBooleanOperationTypes()
{
  /* member initializers and constructor code */
}

nsAbBooleanOperationTypes::~nsAbBooleanOperationTypes()
{
  /* destructor code */
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbBooleanConditionString */
#define NS_IABBOOLEANCONDITIONSTRING_IID_STR "c3869d72-cfd0-45f0-a0ec-3f67d83c7110"

#define NS_IABBOOLEANCONDITIONSTRING_IID \
  {0xc3869d72, 0xcfd0, 0x45f0, \
    { 0xa0, 0xec, 0x3f, 0x67, 0xd8, 0x3c, 0x71, 0x10 }}

/**
 * String condition
 *
 * A string condition represents a leaf node in a
 * boolean expression tree and represents
 * test which will return TRUE or FALSE
 *
 * Condition is an expression which is a
 * leaf node in a boolean expression tree
 *
 */
class NS_NO_VTABLE nsIAbBooleanConditionString : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABBOOLEANCONDITIONSTRING_IID)

  /**
     * The condition for how the a value
     * should be compared
     *
     */
  /* attribute nsAbBooleanConditionType condition; */
  NS_IMETHOD GetCondition(nsAbBooleanConditionType *aCondition) = 0;
  NS_IMETHOD SetCondition(nsAbBooleanConditionType aCondition) = 0;

  /**
     * The lhs of the condition
     *
     * Represents a property name which
     * should be evaluated to obtain the
     * lhs.
     *
     */
  /* attribute string name; */
  NS_IMETHOD GetName(char * *aName) = 0;
  NS_IMETHOD SetName(const char * aName) = 0;

  /**
     * The rhs of the condition
     *
     * <name> [condition] value
     *
     */
  /* attribute wstring value; */
  NS_IMETHOD GetValue(PRUnichar * *aValue) = 0;
  NS_IMETHOD SetValue(const PRUnichar * aValue) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABBOOLEANCONDITIONSTRING \
  NS_IMETHOD GetCondition(nsAbBooleanConditionType *aCondition); \
  NS_IMETHOD SetCondition(nsAbBooleanConditionType aCondition); \
  NS_IMETHOD GetName(char * *aName); \
  NS_IMETHOD SetName(const char * aName); \
  NS_IMETHOD GetValue(PRUnichar * *aValue); \
  NS_IMETHOD SetValue(const PRUnichar * aValue); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABBOOLEANCONDITIONSTRING(_to) \
  NS_IMETHOD GetCondition(nsAbBooleanConditionType *aCondition) { return _to GetCondition(aCondition); } \
  NS_IMETHOD SetCondition(nsAbBooleanConditionType aCondition) { return _to SetCondition(aCondition); } \
  NS_IMETHOD GetName(char * *aName) { return _to GetName(aName); } \
  NS_IMETHOD SetName(const char * aName) { return _to SetName(aName); } \
  NS_IMETHOD GetValue(PRUnichar * *aValue) { return _to GetValue(aValue); } \
  NS_IMETHOD SetValue(const PRUnichar * aValue) { return _to SetValue(aValue); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABBOOLEANCONDITIONSTRING(_to) \
  NS_IMETHOD GetCondition(nsAbBooleanConditionType *aCondition) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCondition(aCondition); } \
  NS_IMETHOD SetCondition(nsAbBooleanConditionType aCondition) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCondition(aCondition); } \
  NS_IMETHOD GetName(char * *aName) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetName(aName); } \
  NS_IMETHOD SetName(const char * aName) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetName(aName); } \
  NS_IMETHOD GetValue(PRUnichar * *aValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetValue(aValue); } \
  NS_IMETHOD SetValue(const PRUnichar * aValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetValue(aValue); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbBooleanConditionString : public nsIAbBooleanConditionString
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABBOOLEANCONDITIONSTRING

  nsAbBooleanConditionString();

private:
  ~nsAbBooleanConditionString();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbBooleanConditionString, nsIAbBooleanConditionString)

nsAbBooleanConditionString::nsAbBooleanConditionString()
{
  /* member initializers and constructor code */
}

nsAbBooleanConditionString::~nsAbBooleanConditionString()
{
  /* destructor code */
}

/* attribute nsAbBooleanConditionType condition; */
NS_IMETHODIMP nsAbBooleanConditionString::GetCondition(nsAbBooleanConditionType *aCondition)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbBooleanConditionString::SetCondition(nsAbBooleanConditionType aCondition)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute string name; */
NS_IMETHODIMP nsAbBooleanConditionString::GetName(char * *aName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbBooleanConditionString::SetName(const char * aName)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute wstring value; */
NS_IMETHODIMP nsAbBooleanConditionString::GetValue(PRUnichar * *aValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbBooleanConditionString::SetValue(const PRUnichar * aValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


/* starting interface:    nsIAbBooleanExpression */
#define NS_IABBOOLEANEXPRESSION_IID_STR "67f87c44-2c63-41a2-9545-aff1d9f09623"

#define NS_IABBOOLEANEXPRESSION_IID \
  {0x67f87c44, 0x2c63, 0x41a2, \
    { 0x95, 0x45, 0xaf, 0xf1, 0xd9, 0xf0, 0x96, 0x23 }}

/**
 * N Boolean expression type
 *
 * Supports Unary Binary and N boolean expressions
 *
 * An operation represents a node in a boolean
 * expression tree which may contain one or more
 * child conditions or expressions
 *
 */
class NS_NO_VTABLE nsIAbBooleanExpression : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IABBOOLEANEXPRESSION_IID)

  /**
     * The boolean operation to be applied to
     * results of all evaluated expressions
     *
     */
  /* attribute nsAbBooleanOperationType operation; */
  NS_IMETHOD GetOperation(nsAbBooleanOperationType *aOperation) = 0;
  NS_IMETHOD SetOperation(nsAbBooleanOperationType aOperation) = 0;

  /**
     * List of peer expressions
     *
     * e1 [op] e2 [op] .... en
     *
     */
  /* attribute nsISupportsArray expressions; */
  NS_IMETHOD GetExpressions(nsISupportsArray * *aExpressions) = 0;
  NS_IMETHOD SetExpressions(nsISupportsArray * aExpressions) = 0;

  /**
     * expressions attribute defined explicitly as an
     * array of nsISupports
     *
     */
  /* void asetExpressions (in unsigned long aExpressionsSize, [array, size_is (aExpressionsSize)] in nsISupports aExpressionsArray); */
  NS_IMETHOD AsetExpressions(PRUint32 aExpressionsSize, nsISupports **aExpressionsArray) = 0;

  /* void agetExpressions (out unsigned long aExpressionsSize, [array, size_is (aExpressionsSize), retval] out nsISupports aExpressionsArray); */
  NS_IMETHOD AgetExpressions(PRUint32 *aExpressionsSize, nsISupports ***aExpressionsArray) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIABBOOLEANEXPRESSION \
  NS_IMETHOD GetOperation(nsAbBooleanOperationType *aOperation); \
  NS_IMETHOD SetOperation(nsAbBooleanOperationType aOperation); \
  NS_IMETHOD GetExpressions(nsISupportsArray * *aExpressions); \
  NS_IMETHOD SetExpressions(nsISupportsArray * aExpressions); \
  NS_IMETHOD AsetExpressions(PRUint32 aExpressionsSize, nsISupports **aExpressionsArray); \
  NS_IMETHOD AgetExpressions(PRUint32 *aExpressionsSize, nsISupports ***aExpressionsArray); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIABBOOLEANEXPRESSION(_to) \
  NS_IMETHOD GetOperation(nsAbBooleanOperationType *aOperation) { return _to GetOperation(aOperation); } \
  NS_IMETHOD SetOperation(nsAbBooleanOperationType aOperation) { return _to SetOperation(aOperation); } \
  NS_IMETHOD GetExpressions(nsISupportsArray * *aExpressions) { return _to GetExpressions(aExpressions); } \
  NS_IMETHOD SetExpressions(nsISupportsArray * aExpressions) { return _to SetExpressions(aExpressions); } \
  NS_IMETHOD AsetExpressions(PRUint32 aExpressionsSize, nsISupports **aExpressionsArray) { return _to AsetExpressions(aExpressionsSize, aExpressionsArray); } \
  NS_IMETHOD AgetExpressions(PRUint32 *aExpressionsSize, nsISupports ***aExpressionsArray) { return _to AgetExpressions(aExpressionsSize, aExpressionsArray); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIABBOOLEANEXPRESSION(_to) \
  NS_IMETHOD GetOperation(nsAbBooleanOperationType *aOperation) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetOperation(aOperation); } \
  NS_IMETHOD SetOperation(nsAbBooleanOperationType aOperation) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetOperation(aOperation); } \
  NS_IMETHOD GetExpressions(nsISupportsArray * *aExpressions) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetExpressions(aExpressions); } \
  NS_IMETHOD SetExpressions(nsISupportsArray * aExpressions) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetExpressions(aExpressions); } \
  NS_IMETHOD AsetExpressions(PRUint32 aExpressionsSize, nsISupports **aExpressionsArray) { return !_to ? NS_ERROR_NULL_POINTER : _to->AsetExpressions(aExpressionsSize, aExpressionsArray); } \
  NS_IMETHOD AgetExpressions(PRUint32 *aExpressionsSize, nsISupports ***aExpressionsArray) { return !_to ? NS_ERROR_NULL_POINTER : _to->AgetExpressions(aExpressionsSize, aExpressionsArray); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAbBooleanExpression : public nsIAbBooleanExpression
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIABBOOLEANEXPRESSION

  nsAbBooleanExpression();

private:
  ~nsAbBooleanExpression();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAbBooleanExpression, nsIAbBooleanExpression)

nsAbBooleanExpression::nsAbBooleanExpression()
{
  /* member initializers and constructor code */
}

nsAbBooleanExpression::~nsAbBooleanExpression()
{
  /* destructor code */
}

/* attribute nsAbBooleanOperationType operation; */
NS_IMETHODIMP nsAbBooleanExpression::GetOperation(nsAbBooleanOperationType *aOperation)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbBooleanExpression::SetOperation(nsAbBooleanOperationType aOperation)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* attribute nsISupportsArray expressions; */
NS_IMETHODIMP nsAbBooleanExpression::GetExpressions(nsISupportsArray * *aExpressions)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsAbBooleanExpression::SetExpressions(nsISupportsArray * aExpressions)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void asetExpressions (in unsigned long aExpressionsSize, [array, size_is (aExpressionsSize)] in nsISupports aExpressionsArray); */
NS_IMETHODIMP nsAbBooleanExpression::AsetExpressions(PRUint32 aExpressionsSize, nsISupports **aExpressionsArray)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void agetExpressions (out unsigned long aExpressionsSize, [array, size_is (aExpressionsSize), retval] out nsISupports aExpressionsArray); */
NS_IMETHODIMP nsAbBooleanExpression::AgetExpressions(PRUint32 *aExpressionsSize, nsISupports ***aExpressionsArray)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAbBooleanExpression_h__ */
