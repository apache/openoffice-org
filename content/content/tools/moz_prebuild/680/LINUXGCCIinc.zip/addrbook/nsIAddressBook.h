/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIAddressBook.idl
 */

#ifndef __gen_nsIAddressBook_h__
#define __gen_nsIAddressBook_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIRDFCompositeDataSource_h__
#include "nsIRDFCompositeDataSource.h"
#endif

#ifndef __gen_nsIAddrDatabase_h__
#include "nsIAddrDatabase.h"
#endif

#ifndef __gen_nsISupportsArray_h__
#include "nsISupportsArray.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIDOMWindowInternal; /* forward declaration */

class nsIFileSpec; /* forward declaration */

class nsIAbDirectory; /* forward declaration */

class nsIAbCard; /* forward declaration */


/* starting interface:    nsIAddressBook */
#define NS_IADDRESSBOOK_IID_STR "d60b84f1-2a8c-11d3-9e07-00a0c92b5f0d"

#define NS_IADDRESSBOOK_IID \
  {0xd60b84f1, 0x2a8c, 0x11d3, \
    { 0x9e, 0x07, 0x00, 0xa0, 0xc9, 0x2b, 0x5f, 0x0d }}

class NS_NO_VTABLE nsIAddressBook : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IADDRESSBOOK_IID)

  /* void newAddressBook (in nsIAbDirectoryProperties aProperties); */
  NS_IMETHOD NewAddressBook(nsIAbDirectoryProperties *aProperties) = 0;

  /* void modifyAddressBook (in nsIRDFDataSource aDS, in nsIAbDirectory aParentDir, in nsIAbDirectory aDirectory, in nsIAbDirectoryProperties aProperties); */
  NS_IMETHOD ModifyAddressBook(nsIRDFDataSource *aDS, nsIAbDirectory *aParentDir, nsIAbDirectory *aDirectory, nsIAbDirectoryProperties *aProperties) = 0;

  /* void deleteAddressBooks (in nsIRDFDataSource aDS, in nsISupportsArray aParentDir, in nsISupportsArray aResourceArray); */
  NS_IMETHOD DeleteAddressBooks(nsIRDFDataSource *aDS, nsISupportsArray *aParentDir, nsISupportsArray *aResourceArray) = 0;

  /* void setDocShellWindow (in nsIDOMWindowInternal win); */
  NS_IMETHOD SetDocShellWindow(nsIDOMWindowInternal *win) = 0;

  /* void exportAddressBook (in nsIAbDirectory aDirectory); */
  NS_IMETHOD ExportAddressBook(nsIAbDirectory *aDirectory) = 0;

  /* void convertLDIFtoMAB (in nsIFileSpec fileSpec, in boolean migrating, in nsIAddrDatabase db, in boolean bStoreLocAsHome, in boolean bImportingComm4x); */
  NS_IMETHOD ConvertLDIFtoMAB(nsIFileSpec *fileSpec, PRBool migrating, nsIAddrDatabase *db, PRBool bStoreLocAsHome, PRBool bImportingComm4x) = 0;

  /* void convertNA2toLDIF (in nsIFileSpec srcFileSpec, in nsIFileSpec dstFileSpec); */
  NS_IMETHOD ConvertNA2toLDIF(nsIFileSpec *srcFileSpec, nsIFileSpec *dstFileSpec) = 0;

  /* nsIAddrDatabase getAbDatabaseFromURI (in string URI); */
  NS_IMETHOD GetAbDatabaseFromURI(const char *URI, nsIAddrDatabase **_retval) = 0;

  /* boolean mailListNameExists (in wstring name); */
  NS_IMETHOD MailListNameExists(const PRUnichar *name, PRBool *_retval) = 0;

  /* nsIAbCard escapedVCardToAbCard (in string escapedVCardStr); */
  NS_IMETHOD EscapedVCardToAbCard(const char *escapedVCardStr, nsIAbCard **_retval) = 0;

  /* string abCardToEscapedVCard (in nsIAbCard aCard); */
  NS_IMETHOD AbCardToEscapedVCard(nsIAbCard *aCard, char **_retval) = 0;

  /* void convert4xVCardPrefs (in string prefRoot, out string escapedVCardStr); */
  NS_IMETHOD Convert4xVCardPrefs(const char *prefRoot, char **escapedVCardStr) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIADDRESSBOOK \
  NS_IMETHOD NewAddressBook(nsIAbDirectoryProperties *aProperties); \
  NS_IMETHOD ModifyAddressBook(nsIRDFDataSource *aDS, nsIAbDirectory *aParentDir, nsIAbDirectory *aDirectory, nsIAbDirectoryProperties *aProperties); \
  NS_IMETHOD DeleteAddressBooks(nsIRDFDataSource *aDS, nsISupportsArray *aParentDir, nsISupportsArray *aResourceArray); \
  NS_IMETHOD SetDocShellWindow(nsIDOMWindowInternal *win); \
  NS_IMETHOD ExportAddressBook(nsIAbDirectory *aDirectory); \
  NS_IMETHOD ConvertLDIFtoMAB(nsIFileSpec *fileSpec, PRBool migrating, nsIAddrDatabase *db, PRBool bStoreLocAsHome, PRBool bImportingComm4x); \
  NS_IMETHOD ConvertNA2toLDIF(nsIFileSpec *srcFileSpec, nsIFileSpec *dstFileSpec); \
  NS_IMETHOD GetAbDatabaseFromURI(const char *URI, nsIAddrDatabase **_retval); \
  NS_IMETHOD MailListNameExists(const PRUnichar *name, PRBool *_retval); \
  NS_IMETHOD EscapedVCardToAbCard(const char *escapedVCardStr, nsIAbCard **_retval); \
  NS_IMETHOD AbCardToEscapedVCard(nsIAbCard *aCard, char **_retval); \
  NS_IMETHOD Convert4xVCardPrefs(const char *prefRoot, char **escapedVCardStr); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIADDRESSBOOK(_to) \
  NS_IMETHOD NewAddressBook(nsIAbDirectoryProperties *aProperties) { return _to NewAddressBook(aProperties); } \
  NS_IMETHOD ModifyAddressBook(nsIRDFDataSource *aDS, nsIAbDirectory *aParentDir, nsIAbDirectory *aDirectory, nsIAbDirectoryProperties *aProperties) { return _to ModifyAddressBook(aDS, aParentDir, aDirectory, aProperties); } \
  NS_IMETHOD DeleteAddressBooks(nsIRDFDataSource *aDS, nsISupportsArray *aParentDir, nsISupportsArray *aResourceArray) { return _to DeleteAddressBooks(aDS, aParentDir, aResourceArray); } \
  NS_IMETHOD SetDocShellWindow(nsIDOMWindowInternal *win) { return _to SetDocShellWindow(win); } \
  NS_IMETHOD ExportAddressBook(nsIAbDirectory *aDirectory) { return _to ExportAddressBook(aDirectory); } \
  NS_IMETHOD ConvertLDIFtoMAB(nsIFileSpec *fileSpec, PRBool migrating, nsIAddrDatabase *db, PRBool bStoreLocAsHome, PRBool bImportingComm4x) { return _to ConvertLDIFtoMAB(fileSpec, migrating, db, bStoreLocAsHome, bImportingComm4x); } \
  NS_IMETHOD ConvertNA2toLDIF(nsIFileSpec *srcFileSpec, nsIFileSpec *dstFileSpec) { return _to ConvertNA2toLDIF(srcFileSpec, dstFileSpec); } \
  NS_IMETHOD GetAbDatabaseFromURI(const char *URI, nsIAddrDatabase **_retval) { return _to GetAbDatabaseFromURI(URI, _retval); } \
  NS_IMETHOD MailListNameExists(const PRUnichar *name, PRBool *_retval) { return _to MailListNameExists(name, _retval); } \
  NS_IMETHOD EscapedVCardToAbCard(const char *escapedVCardStr, nsIAbCard **_retval) { return _to EscapedVCardToAbCard(escapedVCardStr, _retval); } \
  NS_IMETHOD AbCardToEscapedVCard(nsIAbCard *aCard, char **_retval) { return _to AbCardToEscapedVCard(aCard, _retval); } \
  NS_IMETHOD Convert4xVCardPrefs(const char *prefRoot, char **escapedVCardStr) { return _to Convert4xVCardPrefs(prefRoot, escapedVCardStr); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIADDRESSBOOK(_to) \
  NS_IMETHOD NewAddressBook(nsIAbDirectoryProperties *aProperties) { return !_to ? NS_ERROR_NULL_POINTER : _to->NewAddressBook(aProperties); } \
  NS_IMETHOD ModifyAddressBook(nsIRDFDataSource *aDS, nsIAbDirectory *aParentDir, nsIAbDirectory *aDirectory, nsIAbDirectoryProperties *aProperties) { return !_to ? NS_ERROR_NULL_POINTER : _to->ModifyAddressBook(aDS, aParentDir, aDirectory, aProperties); } \
  NS_IMETHOD DeleteAddressBooks(nsIRDFDataSource *aDS, nsISupportsArray *aParentDir, nsISupportsArray *aResourceArray) { return !_to ? NS_ERROR_NULL_POINTER : _to->DeleteAddressBooks(aDS, aParentDir, aResourceArray); } \
  NS_IMETHOD SetDocShellWindow(nsIDOMWindowInternal *win) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDocShellWindow(win); } \
  NS_IMETHOD ExportAddressBook(nsIAbDirectory *aDirectory) { return !_to ? NS_ERROR_NULL_POINTER : _to->ExportAddressBook(aDirectory); } \
  NS_IMETHOD ConvertLDIFtoMAB(nsIFileSpec *fileSpec, PRBool migrating, nsIAddrDatabase *db, PRBool bStoreLocAsHome, PRBool bImportingComm4x) { return !_to ? NS_ERROR_NULL_POINTER : _to->ConvertLDIFtoMAB(fileSpec, migrating, db, bStoreLocAsHome, bImportingComm4x); } \
  NS_IMETHOD ConvertNA2toLDIF(nsIFileSpec *srcFileSpec, nsIFileSpec *dstFileSpec) { return !_to ? NS_ERROR_NULL_POINTER : _to->ConvertNA2toLDIF(srcFileSpec, dstFileSpec); } \
  NS_IMETHOD GetAbDatabaseFromURI(const char *URI, nsIAddrDatabase **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAbDatabaseFromURI(URI, _retval); } \
  NS_IMETHOD MailListNameExists(const PRUnichar *name, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->MailListNameExists(name, _retval); } \
  NS_IMETHOD EscapedVCardToAbCard(const char *escapedVCardStr, nsIAbCard **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->EscapedVCardToAbCard(escapedVCardStr, _retval); } \
  NS_IMETHOD AbCardToEscapedVCard(nsIAbCard *aCard, char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->AbCardToEscapedVCard(aCard, _retval); } \
  NS_IMETHOD Convert4xVCardPrefs(const char *prefRoot, char **escapedVCardStr) { return !_to ? NS_ERROR_NULL_POINTER : _to->Convert4xVCardPrefs(prefRoot, escapedVCardStr); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsAddressBook : public nsIAddressBook
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIADDRESSBOOK

  nsAddressBook();

private:
  ~nsAddressBook();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsAddressBook, nsIAddressBook)

nsAddressBook::nsAddressBook()
{
  /* member initializers and constructor code */
}

nsAddressBook::~nsAddressBook()
{
  /* destructor code */
}

/* void newAddressBook (in nsIAbDirectoryProperties aProperties); */
NS_IMETHODIMP nsAddressBook::NewAddressBook(nsIAbDirectoryProperties *aProperties)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void modifyAddressBook (in nsIRDFDataSource aDS, in nsIAbDirectory aParentDir, in nsIAbDirectory aDirectory, in nsIAbDirectoryProperties aProperties); */
NS_IMETHODIMP nsAddressBook::ModifyAddressBook(nsIRDFDataSource *aDS, nsIAbDirectory *aParentDir, nsIAbDirectory *aDirectory, nsIAbDirectoryProperties *aProperties)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void deleteAddressBooks (in nsIRDFDataSource aDS, in nsISupportsArray aParentDir, in nsISupportsArray aResourceArray); */
NS_IMETHODIMP nsAddressBook::DeleteAddressBooks(nsIRDFDataSource *aDS, nsISupportsArray *aParentDir, nsISupportsArray *aResourceArray)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void setDocShellWindow (in nsIDOMWindowInternal win); */
NS_IMETHODIMP nsAddressBook::SetDocShellWindow(nsIDOMWindowInternal *win)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void exportAddressBook (in nsIAbDirectory aDirectory); */
NS_IMETHODIMP nsAddressBook::ExportAddressBook(nsIAbDirectory *aDirectory)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void convertLDIFtoMAB (in nsIFileSpec fileSpec, in boolean migrating, in nsIAddrDatabase db, in boolean bStoreLocAsHome, in boolean bImportingComm4x); */
NS_IMETHODIMP nsAddressBook::ConvertLDIFtoMAB(nsIFileSpec *fileSpec, PRBool migrating, nsIAddrDatabase *db, PRBool bStoreLocAsHome, PRBool bImportingComm4x)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void convertNA2toLDIF (in nsIFileSpec srcFileSpec, in nsIFileSpec dstFileSpec); */
NS_IMETHODIMP nsAddressBook::ConvertNA2toLDIF(nsIFileSpec *srcFileSpec, nsIFileSpec *dstFileSpec)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAddrDatabase getAbDatabaseFromURI (in string URI); */
NS_IMETHODIMP nsAddressBook::GetAbDatabaseFromURI(const char *URI, nsIAddrDatabase **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean mailListNameExists (in wstring name); */
NS_IMETHODIMP nsAddressBook::MailListNameExists(const PRUnichar *name, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* nsIAbCard escapedVCardToAbCard (in string escapedVCardStr); */
NS_IMETHODIMP nsAddressBook::EscapedVCardToAbCard(const char *escapedVCardStr, nsIAbCard **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* string abCardToEscapedVCard (in nsIAbCard aCard); */
NS_IMETHODIMP nsAddressBook::AbCardToEscapedVCard(nsIAbCard *aCard, char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void convert4xVCardPrefs (in string prefRoot, out string escapedVCardStr); */
NS_IMETHODIMP nsAddressBook::Convert4xVCardPrefs(const char *prefRoot, char **escapedVCardStr)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIAddressBook_h__ */
