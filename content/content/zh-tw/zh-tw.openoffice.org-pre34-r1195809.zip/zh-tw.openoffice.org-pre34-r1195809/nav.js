//<SCRIPT language=JavaScript>
//document.write('js導航') ;
//document.write('<br>');
var text=' \
<table class="zh_menu">\
<tr><th>概覽</th></tr>\
  <tr><td><a href="index.html">簡介</a><br />\
  <a href="http://marketing.openoffice.org/ooocon2008/programme.html">北京OOo2008年會</a><br />\
  <a href="about-features.html">重要特性</a><br />\
  <a href="about-odf.html">ODF</a><br />\
  <a href="about-licenses.html">授權聲明</a><br />\
  <a href="about-ooo.html">關於我們</a>\
  </td></tr>\
<tr><th>下載</th></tr>\
  <tr><td><a href="downloads.html">最新版本</a><br />\
  <a href="downloads_ago.html">歷史版本</a><br />\
  <a href="downloads-addons.html">功能強化套件</a><br />\
  <a href="downloads-cdrom.html">光碟</a><br />\
  <a href="downloads-businesses.html">商品化版本</a>\
  </td></tr>\
<tr><th>幫助</th></tr>\
  <tr><td><a href="http://zh.openoffice.org/nonav/servlets/HelpTOC">站點幫助</a><br />\
  <a href="help-faq.html">常見問題</a> <br />\
  <a href="help-doc.html">說明文件</a> <br />\
  <a href="help-mailinglist.html">社區</a>\
  </td></tr>\
<tr><th>開發</th></tr>\
  <tr><td><a href="dev-ooo-zh.html">參與開發</a><br />\
  <a href="dev-zh_tasks.html">工作一覽表</a><br />\
  <a href="http://www.openoffice.org/project_issues.html" target="_new">報告錯誤(英)</a>\
  </td></tr>\
</table>\
';
document.write(text) ;
// </SCRIPT>
