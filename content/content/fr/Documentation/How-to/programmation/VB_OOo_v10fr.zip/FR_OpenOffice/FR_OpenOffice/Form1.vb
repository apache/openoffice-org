Option Explicit On

Public Class Form1

    Private Sub OOoBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OOoBtn.Click

        ConnectOpenOffice()
        MsgBox(OOoMess001)

        HelloWorldExample()

        DisconnectOpenOffice()
        MsgBox(OOoMess002)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Close()
    End Sub
End Class
