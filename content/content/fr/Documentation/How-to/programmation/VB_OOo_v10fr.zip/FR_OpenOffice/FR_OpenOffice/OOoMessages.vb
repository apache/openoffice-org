﻿Module OOoMessages
    '  OOoMessages : tous les textes de messages utilisés par la boîte à outils

    ' OOoTools module
    Public Const OOo_serviceKO = "Impossible de créer le service : "
    Public Const OOo_connectKO = "Connexion OpenOffice impossible"
    Public Const OOo_structureKO = "Nom de structure inconnu : "
    Public Const OOo_inspectionKO = "Cet objet ne peut pas être inspecté"
    Public Const OOo_nbrArgsKO = "Nombre d'arguments incorrect"
    Public Const OOo_argRank = "L'argument de rang "
    Public Const OOo_notString = " (démarrant à 0) devrait être une chaîne de caractères"
    Public Const OOo_convertToURLKO = "ConvertToURL impossible"
    Public Const OOo_convertFromURLKO = "ConvertFromURL impossible"



    ' OOo_Example module 
    Public Const OOoMess001 = "Connecté à OpenOffice"
    Public Const OOoMess002 = "Déconnecté d'OpenOffice"
    Public Const OOoMess105 = "Le document va fermer"
    Public Const OOoMess107 = "La table n'est pas triée"
    Public Const OOoMess108 = "La table est maintenant triée !"
    Public Const OOoMess109 = "Veuillez mettre quelque chose dans la zone B2:C5"
    Public Const OOoMess111 = "Bonjour à tous"
    Public Const OOoMess112 = "écrit avec "
    Public Const OOoMess113 = "OpenOffice.org "

End Module
