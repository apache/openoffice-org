<?php
//*******************************************************
//** Programme cr��    le 03/03/04 par Tony GALMICHE   **
//**           modifi� le 11/03/04 par Jean-Fran�ois   ** Remplacement du "Short Tag" par un "Full Tag"
//**                                                   ** -> Mettre en place un programme fonctionnel multi-plateforme
//**           modifi� le 12/03/04 par Tony GALMICHE   ** Simplification de l'exemple
//**           modifi� le 12/03/04 par Tony GALMICHE   ** Possibilit� fichier Calc complet ou seul
//*******************************************************

//Activation de tous les messages d'erreur pour d�bugguer le programme
//Si le programme ne marche pas, essayer d�j� de d�sactiver cette ligne
error_reporting(E_ALL);

// ** Appel des fonctions enregistrees ***************************************
require ('../SQL_HTML_OOo/Fonctions.php');
require ('../SQL_HTML_OOo/SQL_HTML_OOo.php');
// ***************************************************************************

// Configuration de la connection MySQL
// Cette partie pourrait �tre incluse dans un fichier de config
$Serveur="localhost";
$DataBase="mysql";
$User="root";
$Password="";

echo "<HTML> \n";
echo "<HEAD> \n";
require ('../SQL_HTML_OOo/Styles.css');
echo "</HEAD> \n";
echo "<BODY BGCOLOR=#F5F5F5> \n";

echo "<DIV CLASS=GrandTitre>Exemple 1 -> Requete SQL sur table User de mysql</DIV> \n";
echo "<HR COLOR=#0000CD SIZE=3> \n";


// Assurons nous que toutes nos variables globales et celles du formulaire
// soient d�finies m�me lorsque le formulaire n'a pas �t� sollicit�.
// REMARQUES: Ce code ne fonctionne qu'� partir de PHP version 4.1.0 !!
// (il faudrait v�rifier si la fonction getenv() est plus ancienne ...)
// La variable $HTTP_GET_VARS existe depuis PHP 4.0.3 mais peut �tre d�sactiv�e sur certaine config.

// Variables du formulaire utilent uniquement pour l'exemple
$SCRIPT_NAME = $_SERVER['PHP_SELF'];
if(isset($HTTP_GET_VARS['xHost']))    $xHost    =$HTTP_GET_VARS['xHost'];    else $xHost="";
if(isset($HTTP_GET_VARS['xUser']))    $xUser    =$HTTP_GET_VARS['xUser'];    else $xUser="";
if(isset($HTTP_GET_VARS['NbLigMax'])) $NbLigMax =$HTTP_GET_VARS['NbLigMax']; else $NbLigMax="10";
if(isset($HTTP_GET_VARS['zzOOo']))    $zzOOo    =$HTTP_GET_VARS['zzOOo'];    else $zzOOo=0;

//** Ce formulaire est donn� � titre d'exemple, il doit �tre adapt� � la requ�t� SQL � traiter.
echo "<FORM ACTION=$SCRIPT_NAME METHOD=GET> \n";
	echo "<TABLE WIDTH=600><TR> \n";

		echo "<TD CLASS=Commentaire>Host (Partiel) </BR><INPUT SIZE=12 NAME=xHost VALUE=$xHost></TD> \n";
		echo "<TD CLASS=Commentaire>User (Partiel) </BR><INPUT SIZE=12 NAME=xUser VALUE=$xUser></TD> \n";

		echo "<TD CLASS=Commentaire>Nb Lignes/Page</BR> \n";
		echo "<SELECT STYLE='WIDTH: 7em;' SIZE=1 NAME=NbLigMax> \n";
					$Tab=array(1,2,5,10,50,100,200,300,400,500,1000,2000);
					SelectOption($Tab,$Tab,$NbLigMax);
		echo "</SELECT></TD> \n";

		echo "<TD CLASS=Commentaire>Fichier OpenOffice Calc</BR> \n";
		echo "<SELECT STYLE='WIDTH: 15em;' SIZE=1 NAME=zzOOo> \n";
					$Tab1=array(0,1,2,3);
					$Tab2=array("Non","Page affich�e","Toute les pages", "Seulement Calc");
					SelectOption($Tab1,$Tab2,$zzOOo);
		echo "</SELECT></TD> \n";

		//** Autre variante avec un CHECKBOX *************************************
		//if ($zzOOo>0) $Check="CHECKED"; else $Check="";
		//echo "<TD CLASS=Commentaire>Calc</BR><INPUT TYPE=CHECKBOX $Check NAME=zzOOo VALUE=3></TD> \n";

		echo "<TD CLASS=Commentaire>                      <INPUT TYPE=SUBMIT VALUE=OK></TD> \n";
echo "</TR></TABLE> \n";

//** S�parer chaque champ du SELECT par une virgule et un espace sans retour a la ligne
//** Ne pas utiliser d'alias (AS), car le programme va les cr�er automatiquement
//** Ne pas mettre d'espace dans les fonctions (SUM, SUBSTRING...)
//** Il est possible d'ajouter une clause GROUP BY et HAVING
$SQL="SELECT Host, User, Password
      FROM user
      WHERE User<>' ' ";
if ($xHost!="") $SQL="$SQL AND Host LIKE '%$xHost%' ";
if ($xUser!="") $SQL="$SQL AND User LIKE '%$xUser%' ";

//** Chaque champ du Order By doit correspondre exactement a un champ du Select
//** -> Si le select utilise une fonction, il faut remettre la fonction avec la m�me syntaxe
//** -> Ne pas utiliser d'alias (AS)
//** S�parer chaque champ par une virgule et un espace.
$SQL="$SQL ORDER BY Host, User DESC ";

$sho=new SQLtoHTML(); // Creation de l'object

//** ATTENTION : Il est indispensable que tous les tableaux comporte le m�me nombre d'�lements
//**   que la clause SELECT de la requete SQL
$sho->TabNomCol =array("Host"    , "User"    , "Password");
$sho->TabStyle  =array("NormalCN", "NormalLN", "NormalLN" );
$sho->TabFormat =array("TEXT"    , "TEXT"    , "TEXT"    );
$sho->TabTotal  =array(0         , 0         , 0         );
//** Cet exemple de lien permet de filtrer automatiquement les User
$sho->TabLien   =array("","$SCRIPT_NAME?ACTION=DETAIL&xUser=XX01","");

$sho->OOo=$zzOOo;   // Indicateur de creation de Fichier

//** Nom du fichier qui sera cr��.
//** Il est possible d'indiquer un nom en dur ou d'utiliser des variables.
//** J'ai choisi de prendre l'adresse IP du demandeur comme nom de fichier OOo
//**   pour �viter les probl�me en cas de cr�ation de fichier par deux personnes
//**   en m�me temps.
$sho->OOoFichier=$_SERVER['REMOTE_ADDR']; // Nom du fichier OOo a creer

$sho->Largeur=600;             // Largeur de la table HTML
$sho->NbLigMax=$NbLigMax;      // Nombre de ligne par page
$sho->SQL=$SQL;                // Affectation Requete SQL

//** Les deux lignes ci-dessous sont indispensable au fonctionnement du tri de la table HTML
if(isset($HTTP_GET_VARS['OrderBy'])) $sho->SQLOrderBy =$HTTP_GET_VARS['OrderBy'];
if(isset($HTTP_GET_VARS['Tri']))     $sho->SQLTri     =$HTTP_GET_VARS['Tri'];

//** Les deux lignes ci-dessous sont indispensable au fonctionnement de la pagination dans la table HTML
if(isset($HTTP_GET_VARS['NumPage']))     $sho->NumPage    =$HTTP_GET_VARS['NumPage'];
if(isset($HTTP_GET_VARS['NumPageTot']))  $sho->NumPageTot =$HTTP_GET_VARS['NumPageTot'];

//** Param�trage de la connexion � la base de donn�es
$sho->Serveur=$Serveur;   // Nom du serveur (Defaut=localhost)
$sho->Base=$DataBase;     // Nom de la base de donnees (Defaut=mysql)
$sho->User=$User;       	// Nom de l'utilisateur (Defaut=root)
$sho->Password=$Password; // Mot de passe de l'utilisateur (Defaut="")

//** Affichage de la table HTML avec la pagination, la ligne de tri et la ligne de total
$sho->SqlToHtmlComplet();

echo "</HTML>";
?>
