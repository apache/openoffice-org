<?
//****************************************************************************
//** Programme cr��     le 01/03/04 par Tony GALMICHE                       **
//**           modifi�  le __/__/__ par Tony GALMICHE                       **
//****************************************************************************

//****************************************************************************
//** Ce programme contient l'ent�te commun � tous les programmes ainsi que  **
//**   les param�tres de connexion � la base de donn�es                     **
//****************************************************************************



// ** Appel des fonctions enregistr�es ***************************************
//require ('../SQL_HTML_OOo/SaveCookies.php');
require ('../SQL_HTML_OOo/Fonctions.php');
require ('../SQL_HTML_OOo/SQL_HTML_OOo.php');
// ***************************************************************************
//EnregistreStatistiques("$SCRIPT_NAME",$REMOTE_ADDR);

echo "<HTML>";
echo "<HEAD>";
require ('../SQL_HTML_OOo/Styles.css');
echo "</HEAD>";
echo "<BODY BGCOLOR=#F5F5F5>";

$Serveur="localhost";
$DataBase="Plastigray";
$User="pg";
$Password="pg";





?>
