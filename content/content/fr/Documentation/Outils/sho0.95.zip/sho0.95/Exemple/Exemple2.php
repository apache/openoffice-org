<?
//****************************************************************************
//** Programme cr��     le 17/03/04 par Tony GALMICHE                       **
//**           modifi�  le __/__/__ par Tony GALMICHE                       **
//****************************************************************************

//Activation de tous les messages d'erreur pour d�bugguer le programme
//Si le programme ne marche pas, essayer d�j� de d�sactiver cette ligne
error_reporting(E_ALL);

require ('Entete.php');

echo "<DIV CLASS=GrandTitre>Exemple 2 -> Utilisation d'un tableau de donn�es</DIV> \n";
echo "<HR COLOR=#0000CD SIZE=3> \n";

$SCRIPT_NAME = $_SERVER['PHP_SELF'];
if(isset($HTTP_GET_VARS['NbLigMax'])) $NbLigMax =$HTTP_GET_VARS['NbLigMax']; else $NbLigMax="10";
if(isset($HTTP_GET_VARS['zzOOo']))    $zzOOo    =$HTTP_GET_VARS['zzOOo'];    else $zzOOo=0;

echo "<FORM ACTION=$SCRIPT_NAME METHOD=GET>";
	echo "<TABLE WIDTH=400><TR>";
		echo "<INPUT TYPE=HIDDEN NAME=ACTION     VALUE=OK>";
  	
		echo "<TD CLASS=Commentaire>Nb Lignes/Page</BR>";
		echo "<SELECT STYLE='WIDTH: 7em;' SIZE=1 NAME=NbLigMax>";
					$Tab=array(1,2,5,10,50);
					SelectOption($Tab,$Tab,$NbLigMax);
		echo "</SELECT></TD>";

		echo "<TD CLASS=Commentaire>Fichier OpenOffice Calc</BR> \n";
		echo "<SELECT STYLE='WIDTH: 15em;' SIZE=1 NAME=zzOOo> \n";
					$Tab1=array(0,1,2,3);
					$Tab2=array("Non","Page affich�e","Toute les pages", "Seulement Calc");
					SelectOption($Tab1,$Tab2,$zzOOo);
		echo "</SELECT></TD> \n";

		echo "<TD CLASS=Commentaire>                      <INPUT TYPE=SUBMIT VALUE=OK></TD>";
echo "</TR></TABLE>";

//** Cr�ation d'un tableau quelconque ***************************************
$Tab=array();
for ($i=0;$i<500;$i++)
{
	$Tab[0][$i]="Ref $i";
	$Tab[1][$i]="D�signation $i";
	$Tab[2][$i]=100*$i;
}
//***************************************************************************

$OrderBy="1002|0001"; // Tri d�croissant sur la deuxi�me colonne et croissant sur la premi�re

$sho=new SQLtoHTML(); // Cr�ation de l'object
$sho->Tab=$Tab;       // Envoie du tableau dans la class

//** Les deux lignes ci-dessous sont indispensable au fonctionnement du tri de la table HTML
if(isset($HTTP_GET_VARS['OrderBy'])) $sho->SQLOrderBy =$HTTP_GET_VARS['OrderBy']; else $sho->SQLOrderBy=$OrderBy;
if(isset($HTTP_GET_VARS['Tri']))     $sho->SQLTri     =$HTTP_GET_VARS['Tri'];

//** Les deux lignes ci-dessous sont indispensable au fonctionnement de la pagination dans la table HTML
if(isset($HTTP_GET_VARS['NumPage']))     $sho->NumPage    =$HTTP_GET_VARS['NumPage'];
if(isset($HTTP_GET_VARS['NumPageTot']))  $sho->NumPageTot =$HTTP_GET_VARS['NumPageTot'];

$sho->TabNomCol =array("Ref"     , "D�signation" , "Qt"       );
$sho->TabStyle  =array("NormalLN", "NormalLN"    , "NormalRN" );
$sho->TabFormat =array("TEXT"    , "TEXT"        , "DEC0"     );
$sho->TabTotal  =array(0         , 0             , 1          );

$sho->OOo=$zzOOo;                         // Indicateur de creation de Fichier
$sho->OOoFichier=$_SERVER['REMOTE_ADDR']; // Nom du fichier OOo a creer
$sho->Largeur=400;             // Largeur de la table HTML
$sho->NbLigMax=$NbLigMax;      // Nombre de ligne par page
$sho->SqlToHtmlComplet();      // Affichage de la table HTML compl�te

echo "</HTML>";

?>


