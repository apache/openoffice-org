<?
/*############################################################################
# This library is free software; you can redistribute it and/or              #
# modify it under the terms of the GNU Lesser General Public                 #
# License as published by the Free Software Foundation; either               #
# version 2.1 of the License, or (at your option) any later version.         #
#                                                                            #
# This library is distributed in the hope that it will be useful,            #
# but WITHOUT ANY WARRANTY; without even the implied warranty of             #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU           #
# Lesser General Public License for more details.                            #
# http://www.opensource.org/licenses/lgpl-license.php                        #
#                                                                            #
# You should have received a copy of the GNU Lesser General Public           #
# License along with this library; if not, write to the Free Software        #
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA    #
##############################################################################*/

// ***************************************************************************
// ** SQL_HTML_OOo Version 0.95 (sho0.95)                                   **
// ** Cette Class permet de cr�er une table HTML format� et un fichier      **
// **   OpenOffice � partir d'une requete SQL ou d'un tableau               **
// ** -> Si la requete SQL n'est pas donn�e, le syst�me prendra le tableau  **
// ** - Il est possible de naviguer dans les pages du r�sultat grace � une  **
// **   ligne de pagination                                                 **
// ** - Il est possible de  faire des tris croissants et d�croissant sur    **
// **   les colonnes                                                        **
// ***************************************************************************

// ** L'historique des modifications est disponible dans la documentation

require("phpzip.inc.php"); // Class permettant de Zipper des dossiers

class SQLtoHTML
{
	var $Serveur;    // Serveur de la base de donn�es
	var $User;       // Utilisateur de la base de donn�es
	var $Password;   // Mot de passe de la base de donn�es
	var $Base;       // Nom de la base de donn�es
	var $Connexion;  // Variable contenant la connexion

	var $SQL;        // Contenu de la requ�te SQL cr�er par la fonction CreerCodeSQL
	var $SQLTri;     // N� de la 1iere cl� de tri � ajouter aux autres
	var $SQLOrderBy; // Chaine des N� des champs � trier s�par�s par des |
	
	var $Tab;        // Contient le tableau des donn�es si la requete SQL n'est pas d�finie

	var $Resultat;   // Contient le r�sultat de la requ�te

	var $Largeur;    // Largeur de la table HTML
	var $TabNomCol;  // Tableau contenant le titre des colonnes
	var $TabStyle;	 // Tableau contenant le style des colonnes
	var $TabLien;	   // Tableau des liens des colonnes
	var $TabTotal;   // Tableau indiquant s'il faut faire la somme des colonnes
	var $TabTotalCol;// Tableau contenant la somme des colonnes
	var $NbLigMax;   // Nombre de ligne par page
	var $NbLig;      // Nombre de lignes sur la page en cours (Interne)
	var $NbLigTot;   // Nombre de lignes total de la requ�te (Interne)
	var $NbCol;      // Nombre de colonnes ou champs de la requete (Interne)
	var $NumPage;    // N� de la page active
	var $NumPageTot; // Nombre de page totale

	var $OOo;        // Indicateur de cr�ation de fichier
									 // 0 -> Pas de fichier OOo (Valeur par d�faut)
									 // 1 -> Fichier OOo de la table HTML affich�e 
									 // 2 -> Fichier OOo contenant tout le r�sultat de la requete
									 // 3 -> Fichier OOo complet sans la table HTML
	var $OOofp;      // Pointeur pour �crire le fichier content.xml (Interne)
	var $OOoFichier; // Nom du fichier OOo � cr�er
	var $OOoNbLigMax;// Nombre de lignes maximums autoris� pour le fichier OOo

	// ***************************************************************************
	// ** Cette fonction permet de creer la requete SQL                         **
	// ***************************************************************************
	function ValeurParDefaut()
	{
		if ($this->Serveur=="")  $this->Serveur="localhost";
		if ($this->User=="")     $this->User="root";
		if ($this->Password=="") $this->Password="";
		if ($this->Base=="")     $this->Base="mysql";
		if ($this->OOo=="") $this->OOo=0;
		if ($this->OOoNbLigMax=="") $this->OOoNbLigMax=32000; // Nombre de lignes maximum dans OOo
		if ($this->Largeur=="")  $this->Largeur=980;
		if ($this->NbLigMax=="") $this->NbLigMax=10;
		if ($this->SQL=="")
		{
			if (isset($this->Tab)==FALSE) 
			{
				echo "<DIV CLASS=MsgErr>Si la requete SQL n'est pas d�finie, il faut fournir un tableau dans Tab !</DIV>";
				exit;		
			}
		}	
	}
	

	// ***************************************************************************
	// ** Cette fonction ajoute la nouvelle cl� de tri � $this->SQLOrderBy      **
	// ** Cette fonction v�rife si la cl� n'est pas en double                   **
	// ** Cette focntion est utilis�e en mode Requete et Tableau                **
	// ** - $this->SQLTri -> Nouvelle cl� de tri � ajouter                      **
	// ** - $this->SQLOrderBy -> Clause OrderBy � traiter                       **
	// ***************************************************************************
	function AjoutCleTri()
	{
		if ($this->SQLTri!="") {
			// ** Suppresion des anciennes cl�s sur le m�me champ
			$LeTri=$this->SQLTri/1;
			$this->SQLOrderBy=str_replace("|".substr("0000".$LeTri,-4),"",$this->SQLOrderBy);
			$this->SQLOrderBy=str_replace(substr("0000".$LeTri,-4)."|","",$this->SQLOrderBy);
			$this->SQLOrderBy=str_replace(substr("0000".$LeTri,-4),"",$this->SQLOrderBy);

			// ** Suppresion des anciennes cl�s sur le m�me champ dans l'ordre inverse
			if ($LeTri>=1000) $LeTri=$LeTri-1000; else $LeTri=$LeTri+1000;
			$this->SQLOrderBy=str_replace("|".substr("0000".$LeTri,-4),"",$this->SQLOrderBy);
			$this->SQLOrderBy=str_replace(substr("0000".$LeTri,-4)."|","",$this->SQLOrderBy);
			$this->SQLOrderBy=str_replace(substr("0000".$LeTri,-4),"",$this->SQLOrderBy);

			// ** Ajout de la nouvelle cl� de tri
			$this->SQLOrderBy=trim($this->SQLOrderBy);
			if ($this->SQLOrderBy!="") {
				$this->SQLOrderBy=$this->SQLTri."|".$this->SQLOrderBy; }
			else {
				$this->SQLOrderBy=$this->SQLTri;
			}
		}
	}

	
	
	
	
	// ***************************************************************************
	// ** Cette fonction permet de creer la requete SQL                         **
	// ** ATENTION : Pour que ce programme fontionne, il faut imp�rtivement :   **
	// ** -> Que chaque champ du SELECT soient s�par�s par une virgule          **
	// **    et un espace                                                       **
	// ** -> Si le SELECT comporte des focntions, il faut imp�rativement ne     **
	// **    pas mettre d'espace pour s�parer les arguments                     **
	// ** - $SQL;        Contenu de la requ�te SQL cr�er par cette fonction     **
	// ** - $SQLOrderBy; Tableau des N� des champs � trier                      **
	// ***************************************************************************
	function CreerRequeteSQL()
	{
		$ORDERBY = ""; //$this->SQLOrderBy;
		// ** Cr�ation d'un tableau contenant tous les champs du Select ************
		$FinSelect=strpos($this->SQL,"FROM ");
		$Select=trim(substr($this->SQL,6,$FinSelect-6));
		$ResteSQL=trim(substr($this->SQL,$FinSelect,1000));
		$TabSelect=explode(", ",$Select);
		// *************************************************************************

		// ** Ajout des clauses AS � chaque champ du SELECT pour pr�parer le tri ***
		$Select="SELECT ";
		for ($i=0;$i<count($TabSelect);$i++) {
			$Select=$Select.$TabSelect[$i]." AS C".substr("000".($i+1),-3).", ";
		}
		$Select=substr($Select,0,strlen($Select)-2);
		$NewSQL=$Select." ".$ResteSQL;
		$this->SQL=$NewSQL;
		// *************************************************************************

		// ** Cr�ation de la chaine SQLOrderBY si n'existe pas *********************
		if ($this->SQLOrderBy=="")
		{
			$DebutOrderBy=strpos($this->SQL,"ORDER BY ")+8;
			$OrderBy=trim(substr($this->SQL,$DebutOrderBy,1000));
			$TabOrderBy=explode(", ",$OrderBy);
			$OrderBy="";
			for ($i=0;$i<count($TabOrderBy);$i++)
			{
				// ** Test si tri descendant et recherche de N� de champ � trier *******
				if (array_search("DESC", explode(" ",trim($TabOrderBy[$i])), TRUE)==FALSE)
				{
					$Index=array_search(trim($TabOrderBy[$i]),$TabSelect, TRUE)+1;
					$OrderBy="$OrderBy|".substr("0000".$Index,-4);
				}
				else
				{
					$OrderBySansDesc=trim(substr($TabOrderBy[$i],0,count($TabOrderBy[$i])-5));
					$Index=array_search($OrderBySansDesc,$TabSelect, TRUE)+1;
					$OrderBy="$OrderBy|".($Index+1000);
				}
				// *********************************************************************
			}
			$this->SQLOrderBy=substr($OrderBy,1,1000);
		}
		// *************************************************************************

		// Ajoute la nouvelle cl� de tri et supprime les doublons
		$this->AjoutCleTri();
		 
		// ** Suprresion de la clause Order By de la requete ***********************
		$DebutOrderBy=strpos($this->SQL,"ORDER BY ");
		if ($DebutOrderBy>0) $this->SQL=substr($this->SQL,0,$DebutOrderBy);
		// *************************************************************************

		// ** Ajout de la nouvelle clause OrderBy dans la requete ******************
		if ($this->SQLOrderBy!="")
		{
			$TabOrderBy=explode("|",$this->SQLOrderBy);
			for ($i=0;$i<count($TabOrderBy);$i++)
			{
				$NumChamp=$TabOrderBy[$i];
				if ($NumChamp>1000)
				{
					$Champ="C".substr("000".($NumChamp-1000),-3)." DESC " ;
				}
				else
				{
					$Champ="C".substr("000".$NumChamp,-3)." " ;
				}

				$ORDERBY="$ORDERBY $Champ, ";
			}
			$ORDERBY=substr($ORDERBY,0,strlen($ORDERBY)-2);
			$this->SQL=$this->SQL." ORDER BY ".$ORDERBY." ";
		}
		
		//** Calcul des limites de la requete ************************************
		if ($this->NumPage)
		{
			$LIMITE = "LIMIT " . ($this->NumPage-1)*$this->NbLigMax . ", " . $this->NbLigMax;
			$this->SQL = $this->SQL." ".$LIMITE." ";
		}
		//************************************************************************	
	}
	

	// ***************************************************************************
	// ** Cette fonction permet de trier le Tableau Tab                         **
	// ** - $this->Tab = Tableau conteant toute les donn�es                     **
	// **   (Si la requete SQL n'est pas foruni en param�tre, il faut fournir   **
	// **    un tableau)                                                        **
	// ***************************************************************************
	function TriTableau()
	{
		// Ajoute la nouvelle cl� de tri et supprime les doublons
		$this->AjoutCleTri();
    //** Ajoute dans OrderBy les colonnes qui manquent pour trier tous le tableau **
    for ($i=0;$i<$this->NbCol;$i++)
    {
    	$TabOrderBy=explode("|",$this->SQLOrderBy);
    	$NumChamp=trim(substr("0000".($i+1),-4));
    	if (in_array($NumChamp, $TabOrderBy)==FALSE)
    	{
    		$NumChamp=trim(substr("0000".($i+1001),-4));
    		if (in_array($NumChamp, $TabOrderBy)==FALSE)
    		{
    			$this->SQLOrderBy=$this->SQLOrderBy."|".substr("0000".($i+1),-4);
    		}
    	}
    }
    //echo "<BR>$OrderBy <BR>";
    //******************************************************************************
    
    $TabOrderBy=explode("|",$this->SQLOrderBy);
    for ($i=0;$i<count($TabOrderBy);$i++)
    {
    	if ($TabOrderBy[$i]>1000)
    	{
    		$TabOrdre[$i]=$TabOrderBy[$i]-1000-1;
    		$TabSens[$i]=3; // 3 = SORT_DESC
    	}
    	else
    	{
    		$TabOrdre[$i]=$TabOrderBy[$i]-1;
    		$TabSens[$i]=4; // 4 = SORT_ASC
    	}
    }
    
    //** Ajoute les tableaux pass� en cl� de tri *********************************
    for ($i=0;$i<count($TabOrderBy);$i++)
    {
    	$TabTab[]= $this->Tab[$TabOrdre[$i]];
    	$TabTab[]= $TabSens[0];
    	$TabTab[]= SORT_REGULAR;
    }
    //****************************************************************************
    
    //** Permet d'appeler une fonction en placant tous les param�tres dans un tableau
    call_user_func_array("array_multisort",$TabTab);
    //***************************************************************************
	}
	
	

	// ***************************************************************************
	// ** Cette fonction permet de ce connecter � la base de donn�es mysql      **
	// ** - $Base = Nom de la base donn�es ou ce connecter                      **
	// ***************************************************************************
	function SqlToHtmlConnexion()
	{
		//** Le signe @ permet de masquer les messages d'erreures enventuels *******
		$this->Connexion=@mysql_connect($this->Serveur, $this->User, $this->Password);
		if (!$this->Connexion)
		{
			echo "<DIV CLASS=MsgErr>Connexion au serveur ".$this->Serveur." (user=".$this->User.") Impossible  !</DIV>";
			exit;
		}
		if (!mysql_select_db($this->Base, $this->Connexion))
		{
			echo "<DIV CLASS=MsgErr>Connexion � la base de donn�es <".$this->Base."> Impossible !</DIV>";
			exit;
		}
	}

	// ***************************************************************************
	// ** Cette fonction permet d'excuter une requete SQL                       **
	// ** - $Connexion = Identifiant de la Connexion mysql                      **
	// ** - $SQL       = Contenu de la requ�te SQL                              **
	// ***************************************************************************
	function SqlToHtmlRequete()
	{
		$this->Resultat = mysql_query($this->SQL, $this->Connexion);
		if (!$this->Resultat)
		{
			echo "<DIV CLASS=MsgErr>Erreur dans l'execution de la requete : <BR>".$this->SQL."</DIV>";
			exit;
		}
	}

	// ***************************************************************************
	// ** Cette fonction initialise la table HTML                               **
	// ** - Largeur  = Largeur de la table HTML                                 **
	// ***************************************************************************
	function SqlToHtmlTableDebut()
	{
		echo "<TABLE WIDTH=".$this->Largeur." BORDER=1 CELLSPACING=0 BACKGROUND=../Images/FondTab.gif>";
	}

	// ***************************************************************************
	// ** Cette fonction termine la table HTML                                  **
	// ** - Largeur  = Largeur de la table HTML                                 **
	// ***************************************************************************
	function SqlToHtmlTableFin()
	{
		echo "</TABLE>";
	}

	// ***************************************************************************
	// ** Cette fonction permet d'afficher la ligne de tri du tableau           **
	// ** ATTENTION : la table html doit �tre initialis�e                       **
	// ** un Tableau HTML                                                       **
	// ** - $Resultat  = Identifiant du resultat d'une requete sql de mysql     **
	// ** - $SQLOrderBy = Chaine s�par�e par | conteant les N� de champs � trier**
	// **      -> Si le N� de champ est > 1000 -> Tri d�croissant               **
	// ***************************************************************************
	function SqlToHtmlTableTri()
	{
		$SCRIPT_URI = $_SERVER['PHP_SELF'];
		echo "<TR>";
			for($i=0; $i<$this->NbCol; $i++)
			{
					echo "<TD CLASS=NormalCN>";
					$Image="tri_asc_gris.png";
					$Pos=$this->ChercheOrderBy($i+1);
					if ($Pos>0) $Image="tri_asc_rouge.png";
					echo "<A HREF=$SCRIPT_URI?ACTION=SUIVANT&NbLigMax=".$this->NbLigMax."&zzOOo=".$this->OOo."&OrderBy=".$this->SQLOrderBy."&Tri=".substr("0000".($i+1),-4)."&NumPageTot=".$this->NumPageTot."><IMG BORDER=0 SRC='../Images/$Image'></A>";
					if ($Pos>0) echo $Pos; else echo "&nbsp";

					$Image="tri_des_gris.png";
					$Pos=$this->ChercheOrderBy($i+1001);
					if ($Pos>0) $Image="tri_des_rouge.png";
					echo "<A HREF=$SCRIPT_URI?ACTION=SUIVANT&NbLigMax=".$this->NbLigMax."&zzOOo=".$this->OOo."&OrderBy=".$this->SQLOrderBy."&Tri=".($i+1000+1)."&NumPageTot=".$this->NumPageTot."><IMG BORDER=0 SRC='../Images/$Image'></A>";
					if ($Pos>0) echo $Pos;
				echo "</TD>";
			}
		echo "</TR>";
	}

	function ChercheOrderBy($Val)
	{
		$Tab=explode("|",$this->SQLOrderBy);
		for ($i=0; $i<count($Tab); $i++)
		{
			if ($Val==$Tab[$i])
			{
				return $i+1;
				exit;
			}
		}
		return 0;
	}





	// ***************************************************************************
	// ** Cette fonction permet d'afficher le titre des colonnes d'une requ�te  **
	// ** - $Resultat  = Identifiant du resultat d'une requete sql de mysql     **
	// ** - $TabNomCol = Tableua contenant le nom des colonnes                  **
	// ***************************************************************************
	function SqlToHtmlTableTitre()
	{
		echo "<TR>";
			for($i=0; $i<$this->NbCol; $i++)
			{
				if (isset($this->TabNomCol[$i])) $Titre=$this->TabNomCol[$i]; else $Titre="Col".($i+1);
				echo "<TD CLASS=TitreTabC>$Titre</TD>";
				//** Initialisation des totaux
				$this->TabTotalCol[$i]=0;
			}
		echo "</TR>";
	}



	// ***************************************************************************
	// ** Cette fonction permet de naviguer dans les pages du r�sultat          **
	// ** - $Connexion = Identifiant de connexion mysql                         **
	// ** - $SQL       = requ�te SQL sans clause LIMIT                          **
	// ** - $NbLigMax  = Nombre de lignes maximum par page                      **
	// ** - $NumPage   = N� de la page actuelle                                 **
	// ** - $NumPageTot= Nombre total de page                                   **
	// ***************************************************************************
	function SqlToHtmlTableNavig()
	{
		$SCRIPT_URI = $_SERVER['PHP_SELF'];
		$MaxPage=20;

		if (!$this->NumPageTot) 
		{
			if ($this->SQL)  $this->NumPageTot=ceil(mysql_num_rows($this->Resultat)/$this->NbLigMax); 
			if (!$this->SQL) $this->NumPageTot=ceil(count($this->Tab[0])/$this->NbLigMax); 
		} 

		if ($this->NbLig>0)
		{
			echo "<DIV CLASS=NormalLN>";
				echo "Pages de r�sultats : ";

				// ** Affichage des MaxPage-5 premieres pages *******************************
				for ($i=1;$i<=$this->NumPageTot;$i++)
				{
					if ($this->NumPage!=$i)
						{echo "&nbsp<A HREF=$SCRIPT_URI?ACTION=SUIVANT&zzOOo=".$this->OOo."&NbLigMax=".$this->NbLigMax."&NumPage=$i&NumPageTot=".$this->NumPageTot."&OrderBy=".$this->SQLOrderBy."&Tri=>$i</A>&nbsp";}
					else
						{echo "&nbsp<SPAN CLASS=TitreTabL>$i</SPAN>&nbsp";}
					if ($i>=$MaxPage-5) break;
				}
				
				// ** Affichage des 5 derni�res pages *******************************
				if ($this->NumPageTot>$MaxPage-5)
				{
					if ($this->NumPageTot>$MaxPage) echo "&nbsp.........&nbsp";
					if ($this->NumPageTot>=$MaxPage) $Debut=$this->NumPageTot-4; else $Debut=$MaxPage-4;
					for ($i=$Debut;$i<=$this->NumPageTot;$i++)
					{
						if ($this->NumPage!=$i)
							{echo "&nbsp<A HREF=$SCRIPT_URI?ACTION=SUIVANT&zzOOo=".$this->OOo."&NbLigMax=".$this->NbLigMax."&NumPage=$i&NumPageTot=".$this->NumPageTot."&OrderBy=".$this->SQLOrderBy."&Tri=>$i</A>&nbsp";}
						else
							{echo "&nbsp<SPAN CLASS=TitreTabL>$i</SPAN>&nbsp";}
					}
				}

 				// ** Page Suivante **************************************************
				if ($this->NumPage<$this->NumPageTot)
				{
					echo "&nbsp<A HREF=$SCRIPT_URI?ACTION=SUIVANT&zzOOo=".$this->OOo."&NbLigMax=".$this->NbLigMax."&NumPage=".($this->NumPage+1)."&NumPageTot=".$this->NumPageTot."&OrderBy=".$this->SQLOrderBy."&Tri=>Suivante</A>";
				}
				// ** Page Pr�c�dente ************************************************
				if ($this->NumPage>1 and $this->NumPageTot>1)
				{
					echo "&nbsp<A HREF=$SCRIPT_URI?ACTION=SUIVANT&zzOOo=".$this->OOo."&NbLigMax=".$this->NbLigMax."&NumPage=".($this->NumPage-1)."&NumPageTot=".$this->NumPageTot."&OrderBy=".$this->SQLOrderBy."&Tri=>Pr�c�dente</A>";
				}
				echo "&nbsp&nbsp(Page ".$this->NumPage."/".$this->NumPageTot." - ";
				if ($this->NbLig<$this->NbLigMax)  echo $this->NbLig." lignes sur cette page)";
				if ($this->NbLig>=$this->NbLigMax) echo $this->NbLigMax." lignes par page)";
			echo "</DIV>";
		}
	}



	// ***************************************************************************
	// ** Cette fonction permet d'afficher les donn�es d'une requete SQL dans   **
	// ** un Tableau HTML                                                       **
	// ** ATTENTION : la table html doit �tre initialis�e                       **
	// ** - $Resultat  = Identifiant du resultat d'une requete sql de mysql     **
	// ** - $NbLigMax  = Nombre de lignes maximum � afficher                    **
	// ** - $TabStyle  = Tableau contenant le style d'affichage des donn�es     **
	// ** - $TabFormat = Tableau contenant les formats d'affichage des donn�es  **
	// **				- DEC0 � DEC9 -> Nombre D�cimale                                **
	// **       - TEXT        -> Texte                                          **
	// **       - DATEP       -> Date Prodstar                                  **
	// ***************************************************************************
	function SqlToHtmlTableDonn�es()
	{
		$i=0;
	
		if ($this->NbLig>=1)
		{
			$NumLigOOo=0;
			for ($lig=0;$lig<$this->NbLig;$lig++)
			{
				if ($this->SQL)
				{
					$row = mysql_fetch_array($this->Resultat);
				}
				else
				{
					$row=array(); //Tableau contenant une ligne du tableau
					$NumLig=$lig+($this->NumPage-1)*$this->NbLigMax;
					if ($NumLig<$this->NbLigTot)
					{
						for ($col=0;$col<count($this->Tab);$col++)
						{
								$row[]=$this->Tab[$col][$NumLig];
						}
					}
				}		
				if (!$row) break;
				if ($this->OOo==1 and $NumLigOOo<$this->OOoNbLigMax)
				{
					$NumLigOOo++;
					$this->OOoDonnees($row); // Donn�es dans le fichier OOo
				}
				echo "<TR onmouseover=style.backgroundColor=\"yellow\" onmouseout=style.backgroundColor=\"\">";

				for($i=0; $i<$this->NbCol; $i++)
				{
					$Donn�e=$row[$i];
					//** Si le tableau des formats est mal renseign�, affectation d'une valeur par d�faut -> TEXT
					if (isset($this->TabFormat[$i])) $LeFormat=$this->TabFormat[$i]; else $LeFormat="TEXT";
					if ($LeFormat=="TEXT") $Donn�e=$row[$i]."&nbsp";
					if ($LeFormat=="DATEM")
					{
						if ($row[$i]==0)
						{
							$Donn�e="&nbsp";
						}
						else
						{
							$year   = substr($row[$i], 0, 4);
							$month  = substr($row[$i], 5, 2);
							$day    = substr($row[$i], 8, 2);
							$Donn�e=date("d.m.y",mktime(0, 0, 0, $month, $day, $year));
						}
					}
					if ($LeFormat=="DATEP")
					{
						if ($row[$i]==0)
						{
							$Donn�e="&nbsp";
						}
						else
						{
							$day    = substr($row[$i], 6, 2);
							$month  = substr($row[$i], 4, 2);
							$year   = substr($row[$i], 0, 4);
							$Donn�e=date("d.m.y",mktime(0, 0, 0, $month, $day, $year));
						}
					}
					
					//** Si le tableau des styles est mal renseign�, affectation d'une valeur par d�faut ->NormalLN
					if (isset($this->TabStyle[$i])) $StyleTmp=$this->TabStyle[$i]; else $StyleTmp="NormalLN";
					//** Pour les nombres n�gatif utilisation d'un style Rouge -> Nom termin� par R
					if (substr($LeFormat,0,3)=="DEC" And $Donn�e<0) {
						$LeStyle=substr($StyleTmp,0,strlen($StyleTmp)-1) ."R"; }			
					else {
						$LeStyle=$StyleTmp;
					}
					if (substr($LeFormat,0,3)=="DEC")  $Donn�e=number_format($row[$i]/1,substr($LeFormat,3,1),'.',' ');


					//** Si le tableau des liens est mal renseign�, affectation d'une valeur par d�faut -> Pas de lien
					if (isset($this->TabLien[$i])) $LeLien=$this->TabLien[$i]; else $LeLien="";

					if ($LeLien=="")
					{
						if ($LeFormat=="TEXT")
							{echo "<TD        CLASS=$LeStyle>$Donn�e</TD>";}
						else
							{echo "<TD NOWRAP CLASS=$LeStyle>$Donn�e</TD>";}
					}
					else
					{
						// ** Permet de remplacer les XX01 � XX99 par la valeur des champs correpondants *******
						for($j=0; $j<$this->NbCol; $j++)
						{
							$XX= "XX".substr("00$j",-2);
							$LeLien=str_replace($XX,$row[$j],$LeLien);
						}

						$LeLien=$LeLien."&zzOOo=".$this->OOo."&NbLigMax=".$this->NbLigMax."&OrderBy=".$this->SQLOrderBy;
						echo "<TD NOWRAP CLASS=$LeStyle><A HREF=\"$LeLien\">$Donn�e</A></TD>";
						// *************************************************************************************
					}
					$this->TabTotalCol[$i]=$this->TabTotalCol[$i]+$row[$i];
				}
				echo "</TR>";
			}
		}
 	}

	// ***************************************************************************
	// ** Cette fonction permet d'afficher les totaux d'une requete SQL dans    **
	// ** un Tableau HTML                                                       **
	// ** - $Resultat  = Identifiant du resultat d'une requete sql de mysql     **
	// ** - $TabTotal  = Tableau utilis� pour faire les totaux des colonnes     **
	// ** - $TabTotal  = Tableau contenant la somme de chaque colonne           **
	// ** - $TabFormat = Tableau contenant les formats d'affichage des donn�es  **
	// ***************************************************************************
	function SqlToHtmlTableTotal()
	{
		echo "<TR>";
			for($i=0; $i<$this->NbCol; $i++)
			{
				//** Si le tableau des formats est mal renseign�, affectation d'une valeur par d�faut -> DEC0
				if (isset($this->TabFormat[$i])) $LeFormat=$this->TabFormat[$i]; else $LeFormat="DEC0";
				//** Si le tableau des Totaux est mal renseign�, affectation d'une valeur par d�faut
				//** -> Total si Format = DECxx et TotalCol!=0
				$LeTotal=0;
				if (substr($LeFormat,0,3)=="DEC" and $this->TabTotalCol[$i]!=0) $LeTotal=1;				
				if (isset($this->TabTotal[$i])) $LeTotal=$this->TabTotal[$i]; 
				if ($LeTotal==0) echo "<TD NOWRAP CLASS=TitreTabR>&nbsp</TD>";
				if ($LeTotal==1) echo "<TD NOWRAP CLASS=TitreTabR>".number_format($this->TabTotalCol[$i],substr($LeFormat,3,1),'.',' ')."</TD>";
			}
		echo "</TR>";
	}










	//##############################################################################
	//##############################################################################
	//## CREATION FICHIER OPEN OFFICE A LA VOLEE                                  ##
	//##############################################################################
	//##############################################################################


	// ***************************************************************************
	// ** Cette fonction encode les caract�res sp�ciaux en UTF8 + Adaptation OOo**
	// ***************************************************************************
	function utf8_OOo($Txt)
	{
		$Txt=utf8_encode($Txt);               // Encodage UTF8

		$Txt=str_replace("&", "&amp;", $Txt); // Encode uniquement le &

		$Tab1=array("<",">","\""); //"
		$Tab2=array("&lt;","&gt;","&quot;");
		$Txt=str_replace($Tab1, $Tab2, $Txt); // Encode les autres carat�res sauf le &

		return $Txt;
	}

	// ***************************************************************************
	// ** Initialisation du fichier OOo                                         **
	// ***************************************************************************
	function OOoDebut($NbLig)
	{
		$Result=$this->Resultat;

		//** Cr�ation du dossier de Travail ******************************************
		$Fichier=$this->OOoFichier;

		$this->CopierDossier("OOo", "../OOoTemp/$Fichier");

		//`cp -Ruv OOo/OOo OOo/$Fichier`;
		$fp=fopen("../OOoTemp/$Fichier/content.xml","w");
		//****************************************************************************

		//** Ent�te du document ******************************************************
		fwrite($fp,"<?xml version=\"1.0\" encoding=\"UTF-8\"?> \n");
		fwrite($fp,"<!DOCTYPE office:document-content PUBLIC \"-//OpenOffice.org//DTD OfficeDocument 1.0//EN\" \"office.dtd\"> \n");
		fwrite($fp,"<office:document-content xmlns:office=\"http://openoffice.org/2000/office\" xmlns:style=\"http://openoffice.org/2000/style\" xmlns:text=\"http://openoffice.org/2000/text\" xmlns:table=\"http://openoffice.org/2000/table\" office:class=\"spreadsheet\" office:version=\"1.0\"> \n");
		// ***************************************************************************

		//** Styles permettant de fixer la largeur des colonnes **********************
		fwrite($fp,"<office:script/> \n");
		fwrite($fp,"<office:automatic-styles> \n");
			for($j=0; $j<$this->NbCol; $j++)
			{
				fwrite($fp,"<style:style style:name=\"co$j\" style:family=\"table-column\"> \n");
					fwrite($fp,"<style:properties style:column-width=\"5cm\"/> \n");
				fwrite($fp,"</style:style> \n");
			}
		fwrite($fp,"</office:automatic-styles> \n");
		//****************************************************************************

		fwrite($fp,"<office:body> \n");

		//** D�finition de la zone d'impression **************************************
		$ColName=chr(65+$this->NbCol-1);
		$ZoneImp="Base.A1:Base.$ColName".($NbLig+3);
		fwrite($fp,"<table:table table:name=\"Base\" table:style-name=\"ta1\" table:print-ranges=\"$ZoneImp\"> \n");
		//****************************************************************************

		//** Affectation des styles des colonnes *************************************
			for($j=1; $j<$this->NbCol; $j++)	{
				fwrite($fp,"<table:table-column table:style-name=\"co$j\" table:default-cell-style-name=\"Default\"/> \n");
			}
		//****************************************************************************

		//** Ligne de titre **********************************************************
		fwrite($fp,"<table:table-header-rows> \n");
			fwrite($fp,"<table:table-row table:style-name=\"ro1\"> \n");
			for($j=0; $j<$this->NbCol; $j++)
			{
				if (isset($this->TabNomCol[$j])) $Titre=$this->TabNomCol[$j]; else $Titre="Col".($j+1);
				$x=str_replace("<BR>", " ", $Titre);
				$x=$this->utf8_OOo($x);

				fwrite($fp,"<table:table-cell table:style-name=\"Heading1\"> \n");
					fwrite($fp,"<text:p>$x</text:p> \n");
				fwrite($fp,"</table:table-cell> \n");
			}
			fwrite($fp,"</table:table-row> \n");
		fwrite($fp,"</table:table-header-rows> \n");
		//****************************************************************************
		
		$this->OOofp=$fp; // M�morisation du pointeur de fichier
	}

	// ***************************************************************************
	// ** Donn�es du fichier OOo                                                **
	// ***************************************************************************
	function OOoDonnees($row)
	{
		$fp=$this->OOofp;
		fwrite($fp,"\n");
		fwrite($fp,"<table:table-row table:style-name=\"ro1\"> \n");
		for($j=0; $j<$this->NbCol; $j++)
		{
			//** Si le tableau des formats est mal renseign�, affectation d'une valeur par d�faut -> TEXT
			if (isset($this->TabFormat[$j])) $FormatTmp=$this->TabFormat[$j]; else $FormatTmp="TEXT";
			$LeFormat="table:style-name=\"".$FormatTmp."\"";
			if ($FormatTmp=="TEXT")            $LeFormat="table:style-name=\"".$FormatTmp."\"";
			if (substr($FormatTmp,0,3)=="DEC") $LeFormat="table:style-name=\"".$FormatTmp."\" table:value-type=\"float\"";
			if ($FormatTmp=="DATEM")
			{
				$LeFormat="table:style-name=\"".$FormatTmp."\"";
				if ($row[$j]==0)
				{
					$Donn�e="";
				}
				else
				{
					$day    = substr($row[$j], 8, 2);
					$month  = substr($row[$j], 5, 2);
					$year   = substr($row[$j], 0, 4);
					$Donn�e=date("d.m.y",mktime(0, 0, 0, $month, $day, $year));
				}
				$row[$j]=$Donn�e;
			}
			if ($FormatTmp=="DATEP")
			{
				$LeFormat="table:style-name=\"".$FormatTmp."\"";
				if ($row[$j]==0)
				{
					$Donn�e="";
				}
				else
				{
					$day    = substr($row[$j], 6, 2);
					$month  = substr($row[$j], 4, 2);
					$year   = substr($row[$j], 0, 4);
					$Donn�e=date("d.m.y",mktime(0, 0, 0, $month, $day, $year));
				}
				$row[$j]=$Donn�e;
			}
			$x=$this->utf8_OOo($row[$j]);
			fwrite($fp,"  <table:table-cell $LeFormat table:value=\"$x\"> \n");
			fwrite($fp,"    <text:p>$x</text:p> \n");
			fwrite($fp,"  </table:table-cell> \n");
		}
		fwrite($fp,"</table:table-row> \n");
	}

	// ***************************************************************************
	// ** Fin du fichier OOo                                                    **
	// ***************************************************************************
	function OOoFin($NbLig)
	{
		$fp=$this->OOofp;
		//** Ligne vide pour s�parer le Total ****************************************
		fwrite($fp,"\n");
		fwrite($fp,"<table:table-row> \n");
		for($j=0; $j<$this->NbCol; $j++)
		{
			fwrite($fp,"  <table:table-cell table:style-name=\"Vide\"> \n");
				fwrite($fp,"    <text:p></text:p> \n");
			fwrite($fp,"  </table:table-cell> \n");
		}
		fwrite($fp,"</table:table-row> \n");
		fwrite($fp,"\n");
		//****************************************************************************

		//** Ligne de total **********************************************************
		fwrite($fp,"\n");
		fwrite($fp,"<table:table-row> \n");
//		fwrite($fp,"  <table:table-cell table:style-name=\"Total\"> \n");
//		fwrite($fp,"    <text:p>Total</text:p> \n");
//		fwrite($fp,"  </table:table-cell> \n");

		for($j=0; $j<$this->NbCol; $j++)
		{
			$LaFonction="";
			$LeTotal=0;
			if ($this->TabTotalCol[$j]!=0) $LeTotal=1;				
			if (isset($this->TabTotal[$j])) $LeTotal=$this->TabTotal[$j]; 
			if ($LeTotal==1) {
				$ColName=chr(65+$j);
				$LaFonction="table:formula=\"=SUM([.".$ColName."2:.$ColName".($NbLig+1)."])\"";
			}
			fwrite($fp,"  <table:table-cell table:style-name=\"Total\" $LaFonction table:value-type=\"float\"> \n");
				fwrite($fp,"    <text:p>0</text:p> \n");
			fwrite($fp,"  </table:table-cell> \n");
		}
		fwrite($fp,"</table:table-row> \n");
		fwrite($fp,"</table:table> \n");
		//****************************************************************************

		//** Activation de l'AutoFiltre **********************************************
		$ColName=chr(65+$this->NbCol-1);
		fwrite($fp,"\n");
		fwrite($fp,"<table:database-ranges> \n");
  		fwrite($fp,"<table:database-range table:target-range-address=\"Base.A1:Base.$ColName".($NbLig+1)."\" table:display-filter-buttons=\"true\"/> \n");
		fwrite($fp,"</table:database-ranges> \n");
		//****************************************************************************

		fwrite($fp,"</office:body> \n");
		fwrite($fp,"</office:document-content> \n");
		fclose($fp);
	}

	// ***************************************************************************
	// ** Cette fonction copie un dossier et tous ces sous-dossiers             **
	// ***************************************************************************
	function CopierDossier($Origine, $Destination)
	{
		@mkdir($Destination);
		$Fichiers=array();
		$Dir=opendir($Origine);
		while ($Fichier=readdir($Dir))
		{
			if ($Fichier!='.' and $Fichier!='..')
			{
				if (is_file("$Origine/$Fichier"))
				{
					copy("$Origine/$Fichier", "$Destination/$Fichier");
				}
				else
				{
					//** Appel r�cursif de la fonction pour traiter les sous-dossiers
					$this->CopierDossier("$Origine/$Fichier", "$Destination/$Fichier");
				}
			}
		}
		closedir($Dir);
	}

	// ***************************************************************************
	// ** Cette fonction Zip le dossier de OOo � l'aide de la class phpzip      **
	// ***************************************************************************
	function OOoZip()
	{
		$Fichier=$this->OOoFichier;
		$LeZip = new PHPZip();
		/* on dirai qu'il y a une coquille dans la classe PHPZip 
		  (comme le but n'est pas de d�buguer PHPZip, on contourne le pb)
		*/
		error_reporting(E_ALL & ~E_NOTICE);
		$LeZip -> Zip("../OOoTemp/$Fichier", "../OOoTemp/$Fichier.sxc");
		error_reporting(E_ALL); /* Puis comme d'hab, on remet en l'�tat  :-) */
	}







	// ***************************************************************************
	// ** Cette fonction cr�e le tableau HTML en entier                         **
	// ***************************************************************************
	function SqlToHtmlComplet()
	{
	 	//** Initialisation des valeurs par d�faut *********************************
		$this->ValeurParDefaut();      
				
		if ($this->SQL)	
		{
			$this->SqlToHtmlConnexion();  // Connexion � la base de donn�es
			$this->CreerRequeteSQL();     // Creation de la requete SQL en focntion des param�tres
			if (!$this->Resultat) $this->SqlToHtmlRequete(); // Execution de la requete
		}
		
		//** Calcul du nombre de lignes et du nombre de colonnes ****************
		if ($this->SQL)	$NbLig=mysql_num_rows($this->Resultat); else $NbLig=count($this->Tab[0]);
		$this->NbLigTot=$NbLig;
		if ($NbLig>$this->NbLigMax) $NbLig=$this->NbLigMax;
		$this->NbLig=$NbLig;
		if ($this->SQL)	$this->NbCol=mysql_num_fields($this->Resultat); else $this->NbCol=count($this->Tab);
		//************************************************************************
		
		if ($this->NumPage=="")  $this->NumPage=1;
		
		// Tri le tableau si pas de requete SQL
		if (!$this->SQL)	$this->TriTableau();

		//** D�termine le nombre de lignes du fichier Calc en fonction de l'option choisie
		if ($this->OOo==1) $NbLig=$this->NbLig; else $NbLig=$this->NbLigTot;
		
		//Initialisation du fichier OOo
		if ($this->OOo==1 or ($this->OOo>1 and $this->NumPage==1))
		{
			$this->OOoDebut($NbLig);   // Initialisation du fichier OOo
			$fp=$this->OOofp;
		}

		//Creation du fichier OOo conteant toute les lignes de la requete ********
		if ($this->OOo>1 and $this->NumPage==1)
		{
    	for ($lig=0;$lig<$this->NbLigTot;$lig++)
			{
				if ($lig<$this->OOoNbLigMax)
				{
    			if ($this->SQL)
    			{
    				$row = mysql_fetch_array($this->Resultat);
    			}
    			else
    			{
    				$row=array(); //Tableau contenant une ligne du tableau
    				$NumLig=$lig+($this->NumPage-1)*$this->NbLigMax;
    				if ($NumLig<$this->NbLigTot)
    				{
    					for ($col=0;$col<count($this->Tab);$col++)
    					{
    							$row[]=$this->Tab[$col][$NumLig];
    					}
    				}
    			}		
    			if (!$row) break;
					$this->OOoDonnees($row); // Donn�es dans le fichier OOo
 				}
			}
			if ($this->SQL) mysql_data_seek($this->Resultat,0);			
		}
		//************************************************************************

		//Affichage de la table HTML si OOo<=2 ***********************************
		if ($this->OOo<=2)
		{
			$this->SqlToHtmlTableNavig();   // Barre de navigation -> Execute �galement la requ�te
			$this->SqlToHtmlTableDebut();   // Ent�te de la table HTML
			$this->SqlToHtmlTableTri();     // Affiche la ligne de tri
			$this->SqlToHtmlTableTitre();   // Affiche le titre des colonnes
			$this->SqlToHtmlTableDonn�es(); // Affiche la table HTML
			$this->SqlToHtmlTableTotal();   // Affiche la ligne de total
			$this->SqlToHtmlTableFin();     // Fin de la table HTML
 			$this->SqlToHtmlTableNavig();   // Barre de navigation -> Execute �galement la requ�te
		}
		//************************************************************************
		
		//** Fin du fichier OOo **************************************************
		if ($this->OOo==1 or ($this->OOo>1 and $this->NumPage==1))
		{
			$this->OOoFin($NbLig); //** Fin du fichier OOo
			$this->OOoZip();
		}
		//************************************************************************
		
		//** Lien pour t�l�charger le fichier OOo ********************************
		if ($this->OOo>0)
		{
			echo "<A CLASS=Commentaire href=../OOoTemp/".$this->OOoFichier.".sxc>Cliquez ici pour ouvrir le fichier OpenOffice Calc correspondant</A>";
		}
		//************************************************************************	
	}   
}
    


?>
