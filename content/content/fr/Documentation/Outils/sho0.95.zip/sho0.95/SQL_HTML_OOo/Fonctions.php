<?
//****************************************************************************
//** Programme cr��     le __/__/02 par Tony GALMICHE                       **
//**           modifi�  le 26/02/04 par Tony GALMICHE                       ** Regroupement de toute les fonctions
//**           modifi�  le 16/03/04 par Tony GALMICHE                       ** Correction bug dans SelectOption
//**           modifi�  le 17/03/04 par Tony GALMICHE                       ** S�paration Fonctions et FonctionsPG
//****************************************************************************

// **************************************************************************************************
// ** Cette fonction format une date du type 20020615 en 15.06.02                                  **
// **************************************************************************************************
function FormatDate($LaDate)
{
  return substr($LaDate,6,2) . "." . substr($LaDate,4,2) ."." . substr($LaDate,2,2);
}

function FormatDateProdstar($LaDate)
{
	$Tab=explode("/", $LaDate);
	$JJ=substr("00" . $Tab[0],-2);
	$MM=substr("00" . $Tab[1],-2);
	$AAAA="2" . substr("000" . $Tab[2],-3);
	return "$AAAA$MM$JJ";
}

function FormatDateMySQL($LaDate)
{
	$Tab=explode("/", $LaDate);
	$JJ=substr("00" . $Tab[0],-2);
	$MM=substr("00" . $Tab[1],-2);
	$AAAA="2" . substr("000" . $Tab[2],-3);
	return "$AAAA-$MM-$JJ";
}


// *****************************************************************************
// ** Cette fonction transforme un timestamp MySQL en timestamp PHP.          **
// ** Il suffit alors de le passer a date() pour le formater.                 **
// *****************************************************************************
function prodstar_mktime($timestamp)
{
 	$hour   = 0;
  $minute = 0;
  $second = 0;
 	$day    = substr($timestamp, 6, 2);
  $month  = substr($timestamp, 4, 2);
  $year   = substr($timestamp, 0, 4);
  return mktime($hour, $minute, $second, $month, $day, $year);
}

// *****************************************************************************
// ** Cette fonction transforme un timestamp MySQL en timestamp PHP.          **
// ** Il suffit alors de le passer a date() pour le formater.                 **
// *****************************************************************************
function mysql_mktime($timestamp)
{
 	$hour   = substr($timestamp, 11, 2);
  $minute = substr($timestamp, 14, 2);
  $second = substr($timestamp, 17, 2);
  $month  = substr($timestamp, 5, 2);
  $day    = substr($timestamp, 8, 2);
  $year   = substr($timestamp, 0, 4);
  return mktime($hour, $minute, $second, $month, $day, $year);
}




// **************************************************************************************************
// ** Cette fonction permet de cr�er les lignes HTML <OPTION VALUE> dans un <SELECT> � partir      **
// ** de 2 tableaux                                                                                **
// ** $Tab1 contient le tableau contenant les valeurs r��les du <OPTION VALUE>                     **
// ** $Tab2 contient le tableau contenant les valeurs affich�es du <OPTION VALUE>                  **
// ** $TabSelect contient la valeur s�lectionn�e par d�faut                                        **
// **************************************************************************************************
function SelectOption($Tab1, $Tab2, $TabSelect)
{
	for($i=0;$i<sizeof($Tab1);$i++)
	{
//		if ($TabSelect!=$Tab2[$i])
		if ($TabSelect!=$Tab1[$i])
		{
			echo "<OPTION VALUE=\"" . $Tab1[$i] . "\">" . $Tab2[$i] . "</OPTION>";
		}
		else
		{
			echo "<OPTION SELECTED VALUE=\"" . $Tab1[$i] . "\">" . $Tab2[$i] . "</OPTION>";
		}
	}
}









?>
