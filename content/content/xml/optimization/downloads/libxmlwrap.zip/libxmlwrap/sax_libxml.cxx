/*************************************************************************
 *
 *  OpenOffice.org - a multi-platform office productivity suite
 *
 *  $RCSfile: sax_expat.cxx,v $
 *
 *  $Revision: 1.14 $
 *
 *  last change: $Author: obo $ $Date: 200:16 13:10:10 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.
 *
 *
 *    GNU Lesser General Public License Version 2.1
 *    =============================================
 *    Copyright 2005 by Sun Microsystems, Inc.
 *    901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License version 2.1, as published by the Free Software Foundation.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *    MA  02111-1307  USA
 *
 ************************************************************************/

#include <assert.h>
#include <stdlib.h>
#include <sal/alloca.h>
#include <vector>

#include <osl/diagnose.h>

#include <com/sun/star/lang/XServiceInfo.hpp>
#include <com/sun/star/lang/XInitialization.hpp>
#include <com/sun/star/util/XCloneable.hpp>
#include <com/sun/star/xml/sax/XExtendedDocumentHandler.hpp>
#include <com/sun/star/xml/sax/XParser.hpp>
#include <com/sun/star/xml/sax/SAXParseException.hpp>

#include <cppuhelper/factory.hxx>
#include <cppuhelper/weak.hxx>
#include <cppuhelper/implbase1.hxx>
#include <cppuhelper/implbase2.hxx>
#include <cppuhelper/implbase3.hxx>

#include <libxml/SAX2.h>
#include <vcl/threadex.hxx>

using namespace ::rtl;
using namespace ::std;
using namespace ::osl;
using namespace ::cppu;
using namespace ::com::sun::star::uno;
using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::registry;
using namespace ::com::sun::star::xml::sax;
using namespace ::com::sun::star::util;
using namespace ::com::sun::star::io;

#define X2S(s) OUString((sal_Char*)s , strlen((sal_Char*)s), RTL_TEXTENCODING_UTF8)
#define XN2S(s,l) OUString((sal_Char*)s , l, RTL_TEXTENCODING_UTF8)

namespace sax_libxmlwrap {

struct AttributeListImpl_impl;

class AttributeListImpl :
	public WeakImplHelper2<	XAttributeList,	XCloneable >
{
public:
	AttributeListImpl();
	AttributeListImpl( const AttributeListImpl & );
	~AttributeListImpl();	

public:
    virtual sal_Int16 SAL_CALL getLength(void) throw(RuntimeException);
    virtual OUString SAL_CALL getNameByIndex(sal_Int16 i) throw(RuntimeException);
    virtual OUString SAL_CALL getTypeByIndex(sal_Int16 i) throw(RuntimeException);
    virtual OUString SAL_CALL getTypeByName(const OUString& aName) throw(RuntimeException);
    virtual OUString SAL_CALL getValueByIndex(sal_Int16 i) throw(RuntimeException);
    virtual OUString SAL_CALL getValueByName(const OUString& aName) throw( RuntimeException);

public:
	virtual Reference< XCloneable >  SAL_CALL createClone()	throw(RuntimeException);
	
public:
	void addAttribute( const OUString &sName , const OUString &sType , const OUString &sValue );
	void clear();
	void removeAttribute( const OUString &sName );
	void setAttributeList( const Reference<  XAttributeList > & );

private:
	struct AttributeListImpl_impl *m_pImpl;
};

struct TagAttribute
{
	TagAttribute()
		{}
	TagAttribute( const OUString &sName, const OUString &sType , const OUString &sValue )
	{
		this->sName 	= sName;
		this->sType 	= sType;
		this->sValue 	= sValue;
	}

	OUString sName;
	OUString sType;
	OUString sValue;
};

struct AttributeListImpl_impl
{
	AttributeListImpl_impl()
	{
		// performance improvement during adding
		vecAttribute.reserve(20);
	}
	vector<struct TagAttribute> vecAttribute;
};



sal_Int16 AttributeListImpl::getLength(void) throw (RuntimeException)
{
	return m_pImpl->vecAttribute.size();
}


AttributeListImpl::AttributeListImpl( const AttributeListImpl &r )
{
	m_pImpl = new AttributeListImpl_impl;
	*m_pImpl = *(r.m_pImpl);
}

OUString AttributeListImpl::getNameByIndex(sal_Int16 i) throw (RuntimeException)
{
	if( i < (sal_Int16)m_pImpl->vecAttribute.size() ) {
		return m_pImpl->vecAttribute[i].sName;
	}
	return OUString();
}


OUString AttributeListImpl::getTypeByIndex(sal_Int16 i) throw (RuntimeException)
{
	if( i < (sal_Int16)m_pImpl->vecAttribute.size() ) {
		return m_pImpl->vecAttribute[i].sType;
	}
	return OUString();
}

OUString AttributeListImpl::getValueByIndex(sal_Int16 i) throw (RuntimeException)
{
	if( i < (sal_Int16)m_pImpl->vecAttribute.size() ) {
		return m_pImpl->vecAttribute[i].sValue;
	}
	return OUString();

}

OUString AttributeListImpl::getTypeByName( const OUString& sName ) throw (RuntimeException)
{
	vector<struct TagAttribute>::iterator ii = m_pImpl->vecAttribute.begin();

	for( ; ii != m_pImpl->vecAttribute.end() ; ii ++ ) {
		if( (*ii).sName == sName ) {
			return (*ii).sType;
		}
	}
	return OUString();
}

OUString AttributeListImpl::getValueByName(const OUString& sName) throw (RuntimeException)
{
	vector<struct TagAttribute>::iterator ii = m_pImpl->vecAttribute.begin();

	for( ; ii != m_pImpl->vecAttribute.end() ; ii ++ ) {
		if( (*ii).sName == sName ) {
			return (*ii).sValue;
		}
	}
	return OUString();
}


Reference< XCloneable > AttributeListImpl::createClone() throw (RuntimeException)
{
	AttributeListImpl *p = new AttributeListImpl( *this );
	return Reference< XCloneable > ( (XCloneable * ) p );
}



AttributeListImpl::AttributeListImpl()
{
	m_pImpl = new AttributeListImpl_impl;
}



AttributeListImpl::~AttributeListImpl()
{
	delete m_pImpl;
}


void AttributeListImpl::addAttribute( 	const OUString &sName ,
										const OUString &sType ,
										const OUString &sValue )
{
	m_pImpl->vecAttribute.push_back( TagAttribute( sName , sType , sValue ) );
}

void AttributeListImpl::clear()
{
	m_pImpl->vecAttribute.clear();
}

void AttributeListImpl::removeAttribute( const OUString &sName )
{
	vector<struct TagAttribute>::iterator ii = m_pImpl->vecAttribute.begin();

	for( ; ii != m_pImpl->vecAttribute.end() ; ii ++ ) {
		if( (*ii).sName == sName ) {
			m_pImpl->vecAttribute.erase( ii );
			break;
		}
	}
}


void AttributeListImpl::setAttributeList( const Reference<  XAttributeList >  &r )
{
	assert( r.is() );

	sal_Int16 nMax = r->getLength();
	clear();
	m_pImpl->vecAttribute.reserve( nMax );

	for( int i = 0 ; i < nMax ; i ++ ) {
		m_pImpl->vecAttribute.push_back( TagAttribute( 	r->getNameByIndex( i ) ,
														r->getTypeByIndex( i ) ,
														r->getValueByIndex( i ) ) );
	}

	assert( nMax == getLength() );
}

/*
* The following macro encapsulates any call to an event handler. 
* It ensures, that exceptions thrown by the event handler are
* treated properly. 
*/
#define CALL_ELEMENT_HANDLER_AND_CARE_FOR_EXCEPTIONS(pThis,call) \
	if( ! pThis->bExceptionWasThrown ) { \
		try {\
			pThis->call;\
		}\
		catch( SAXParseException &e ) {\
			pThis->callErrorHandler( pThis ,  e );\
	 	}\
		catch( SAXException &e ) {\
			pThis->callErrorHandler( pThis , SAXParseException(\
											e.Message, \
											e.Context, \
											e.WrappedException,\
											pThis->rDocumentLocator->getPublicId(),\
											pThis->rDocumentLocator->getSystemId(),\
											pThis->rDocumentLocator->getLineNumber(),\
											pThis->rDocumentLocator->getColumnNumber()\
									 ) );\
		}\
	}\
	((void)0)

#define IMPLEMENTATION_NAME	"com.sun.star.comp.extensions.xml.sax.ParserLibXML2"
#define SERVICE_NAME		"com.sun.star.xml.sax.Parser"

class SaxLibXML2Parser_Impl;


// This class implements the external Parser interface
class SaxLibXML2Parser :
	public WeakImplHelper3<
				XParser,
				XServiceInfo,
				XInitialization
                          >
{
	
public:	
	SaxLibXML2Parser();
	~SaxLibXML2Parser();
	
public:

	// The implementation details
    static Sequence< OUString > 	getSupportedServiceNames_Static(void) throw ();
	static OUString 				getImplementationName_Static() throw ();

public:
	// The SAX-Parser-Interface
    virtual void SAL_CALL parseStream(	const InputSource& structSource)
		throw (	SAXException, 
				IOException, 
				RuntimeException);
    virtual void SAL_CALL setDocumentHandler(const Reference< XDocumentHandler > & xHandler) 
		throw (RuntimeException);
	
    virtual void SAL_CALL setErrorHandler(const Reference< XErrorHandler > & xHandler)
		throw (RuntimeException);
    virtual void SAL_CALL setDTDHandler(const Reference < XDTDHandler > & xHandler)
		throw (RuntimeException);
    virtual void SAL_CALL setEntityResolver(const Reference<  XEntityResolver >& xResolver)
		throw (RuntimeException);

	virtual void SAL_CALL setLocale( const Locale &locale ) 					throw (RuntimeException);
	
public: // XServiceInfo
    OUString                     SAL_CALL getImplementationName() throw ();
    Sequence< OUString >         SAL_CALL getSupportedServiceNames(void) throw ();
    sal_Bool                     SAL_CALL supportsService(const OUString& ServiceName) throw ();

	// XInitialization
    virtual void SAL_CALL initialize( const Sequence< Any >& aArguments ) throw (Exception, RuntimeException);

private:

	SaxLibXML2Parser_Impl 		*m_pImpl;
	
};

//--------------------------------------
// the extern interface 
//---------------------------------------
Reference< XInterface > SAL_CALL SaxLibXML2Parser_CreateInstance(
	const Reference< XMultiServiceFactory  >  & rSMgr ) throw(Exception)
{	
	SaxLibXML2Parser *p = new SaxLibXML2Parser;

	return Reference< XInterface > ( (OWeakObject * ) p );
}



Sequence< OUString > 	SaxLibXML2Parser::getSupportedServiceNames_Static(void) throw ()
{
	Sequence<OUString> aRet(1);
	aRet.getArray()[0] = ::rtl::OUString( RTL_CONSTASCII_USTRINGPARAM(SERVICE_NAME) );
	return aRet;
}


//---------------------------------------------
// the implementation part
//---------------------------------------------


// Entity binds all information neede for a single file
struct Entity
{
	InputSource			structSource;
	xmlParserCtxtPtr	pParser;	
};


class SaxLibXML2Parser_Impl
{
public: // module scope
	SaxLibXML2Parser_Impl();

	Mutex				aMutex;

	Reference< XDocumentHandler >	rDocumentHandler;
	Reference< XExtendedDocumentHandler > rExtendedDocumentHandler;
	
	Reference< XErrorHandler > 	rErrorHandler;
	Reference< XDTDHandler > 	rDTDHandler;
	Reference< XEntityResolver > rEntityResolver;
	Reference < XLocator >		rDocumentLocator;


	Reference < XAttributeList >	rAttrList;
	AttributeListImpl	*pAttrList;

	// External entity stack 
	vector<struct Entity> 	vecEntity;
	void pushEntity( const struct Entity &entity )
		{ vecEntity.push_back( entity ); }
	void popEntity()
		{ vecEntity.pop_back( ); }
	struct Entity &getEntity()
		{ return vecEntity.back(); }


	// Exception cannot be thrown through the C-XmlParser (possible resource leaks), 
	// therefor the exception must be saved somewhere.
	SAXParseException 	exception;
	sal_Bool 				bExceptionWasThrown;

	Locale				locale;

public:	
	// the C-Callbacks for the expat parser
	void static callbackStartElement(void *userData, const xmlChar *name , const xmlChar **atts);
	void static callbackEndElement(void *userData, const xmlChar *name);

	void static callbackCharacters( void *userData , const xmlChar *ch , int nLen );
	void static callbackProcessingInstruction( 	void *userData , 
												const xmlChar *sTarget , 
												const xmlChar *sData );

	void static callbackUnparsedEntityDecl(	void *userData , 
						  					const xmlChar *entityName,
					      					const xmlChar *publicId,
					      					const xmlChar *systemId,
					      					const xmlChar *notationName);
					      					
	void static callbackNotationDecl(	void *userData,
										const xmlChar *notationName,
										const xmlChar *publicId,
										const xmlChar *systemId);

	xmlParserInputPtr static callbackExternalEntityRef(	void *ctx,
					    					const xmlChar *publicId,
											const xmlChar *systemId);

/*
	int static callbackUnknownEncoding(void *encodingHandlerData,
					  							const xmlChar *name,
					  							XML_Encoding *info);
*/

	void static callbackDefault( void *userData,  const xmlChar *s,  int len);

	void static callbackStartCDATA( void *userData );
	void static callbackEndCDATA( void *userData );
	void static callbackComment( void *userData , const xmlChar *s );
	void static callErrorHandler( SaxLibXML2Parser_Impl *pImpl , const SAXParseException &e );

public:
	void parse();
};

//---------------------------------------------
// LocatorImpl
//---------------------------------------------
class LocatorImpl :
	public WeakImplHelper1< XLocator > 
{
public:
	LocatorImpl( SaxLibXML2Parser_Impl *p )
	{
		m_pParser 	 = p;
	}
	
public: //XLocator
    virtual sal_Int32 SAL_CALL getColumnNumber(void) throw ()
    {
    	return 0; /* todo XML_GetCurrentColumnNumber( m_pParser->getEntity().pParser ); */
    }
    virtual sal_Int32 SAL_CALL getLineNumber(void) throw ()
    {
    	return 0; /* XML_GetCurrentLineNumber( m_pParser->getEntity().pParser ); */
    }
    virtual OUString SAL_CALL getPublicId(void) throw ()
    {
    	return m_pParser->getEntity().structSource.sPublicId;
    }
    virtual OUString SAL_CALL getSystemId(void) throw ()
    {
    	return m_pParser->getEntity().structSource.sSystemId;
    }

private:

	SaxLibXML2Parser_Impl *m_pParser;
};		

class LibXMLInit : public vcl::SolarThreadExecutor
{
	virtual long doIt();
};

long LibXMLInit::doIt()
{
	xmlInitParser();
	return 0;
}


SaxLibXML2Parser::SaxLibXML2Parser(  )
{
	m_pImpl = new SaxLibXML2Parser_Impl;

	LocatorImpl *pLoc = new LocatorImpl( m_pImpl );
	m_pImpl->rDocumentLocator = Reference< XLocator > ( pLoc );
	 
	// performance-Improvment. Reference is needed when calling the startTag callback.
	// Handing out the same object with every call is allowed (see sax-specification)
	m_pImpl->pAttrList = new AttributeListImpl;
	m_pImpl->rAttrList = Reference< XAttributeList > ( m_pImpl->pAttrList );
	
	m_pImpl->bExceptionWasThrown = sal_False;

	LibXMLInit aInit;
	aInit.execute();
}

SaxLibXML2Parser::~SaxLibXML2Parser()
{
	delete m_pImpl;	
	xmlCleanupParser();
}


/***************
*
* parseStream does Parser-startup initializations. The SaxLibXML2Parser_Impl::parse() method does
* the file-specific initialization work. (During a parser run, external files may be opened)
* 
****************/
void SaxLibXML2Parser::parseStream(	const InputSource& structSource)
	throw (SAXException, 
		   IOException, 
		   RuntimeException)
{
	// Only one text at one time
	MutexGuard guard( m_pImpl->aMutex );
	
	struct Entity entity;
	entity.structSource = structSource;

	if( ! entity.structSource.aInputStream.is() )
	{
		throw SAXException( OUString::createFromAscii( "No input source" ) ,
							Reference< XInterface > () , Any() );
	}
	entity.pParser = 0;

	m_pImpl->exception = SAXParseException();
	m_pImpl->pushEntity( entity );
	try
	{
		// start the document
		if( m_pImpl->rDocumentHandler.is() ) {
			m_pImpl->rDocumentHandler->setDocumentLocator( m_pImpl->rDocumentLocator );
			m_pImpl->rDocumentHandler->startDocument();
		}

		m_pImpl->parse();

		// finish document
		if( m_pImpl->rDocumentHandler.is() ) {
			m_pImpl->rDocumentHandler->endDocument();	
		}
	}
//  	catch( SAXParseException &e ) 
// 	{
// 		m_pImpl->popEntity();
//  		XML_ParserFree( entity.pParser );
//        Any aAny;
//        aAny <<= e;
//  		throw SAXException( e.Message, e.Context, aAny );
//  	}
	catch( SAXException & )
	{
		m_pImpl->popEntity();
		if( entity.pParser )
			xmlFreeParserCtxt(entity.pParser);
  		throw;
	}
	catch( IOException & )
	{
		m_pImpl->popEntity();
		if( entity.pParser )
			xmlFreeParserCtxt(entity.pParser);
		throw;
	}
	catch( RuntimeException & )
	{
		m_pImpl->popEntity();
		if( entity.pParser )
			xmlFreeParserCtxt(entity.pParser);
		throw;
	}

	if( entity.pParser )
		xmlFreeParserCtxt(entity.pParser);
}
    																			
void SaxLibXML2Parser::setDocumentHandler(const Reference< XDocumentHandler > & xHandler) 
	throw (RuntimeException)
{
	m_pImpl->rDocumentHandler = xHandler;
	m_pImpl->rExtendedDocumentHandler =
		Reference< XExtendedDocumentHandler >( xHandler , UNO_QUERY );
}
    																
void SaxLibXML2Parser::setErrorHandler(const Reference< XErrorHandler > & xHandler)
	throw (RuntimeException)
{
	m_pImpl->rErrorHandler = xHandler;
}

void SaxLibXML2Parser::setDTDHandler(const Reference< XDTDHandler > & xHandler)
	throw (RuntimeException)
{
	m_pImpl->rDTDHandler = xHandler;
}

void SaxLibXML2Parser::setEntityResolver(const Reference < XEntityResolver > & xResolver)
	throw (RuntimeException)
{
	m_pImpl->rEntityResolver = xResolver;
}


void SaxLibXML2Parser::setLocale( const Locale & locale )	throw (RuntimeException)
{
	m_pImpl->locale = locale;	
}

OUString 	SaxLibXML2Parser::getImplementationName_Static() throw ()
{
	return OUString::createFromAscii( IMPLEMENTATION_NAME );
}

// XServiceInfo
OUString SaxLibXML2Parser::getImplementationName() throw ()
{
    return OUString::createFromAscii( IMPLEMENTATION_NAME );
}

// XServiceInfo
sal_Bool SaxLibXML2Parser::supportsService(const OUString& ServiceName) throw ()
{
    Sequence< OUString > aSNL = getSupportedServiceNames();
    const OUString * pArray = aSNL.getConstArray();

    for( sal_Int32 i = 0; i < aSNL.getLength(); i++ )
        if( pArray[i] == ServiceName )
            return sal_True;

    return sal_False;
}

// XServiceInfo
Sequence< OUString > SaxLibXML2Parser::getSupportedServiceNames(void) throw ()
{
    
    Sequence<OUString> seq(1);
    seq.getArray()[0] = OUString::createFromAscii( SERVICE_NAME );
    return seq;
}

// XInitialization
void SAL_CALL SaxLibXML2Parser::initialize( const Sequence< Any >& aArguments ) throw (Exception, RuntimeException)
{
}

/*---------------------------------------
*
* Helper functions and classes
*
*
*-------------------------------------------*/

#define XE(e) case e: Message = OUString::createFromAscii("e")

OUString getErrorMessage( xmlParserErrors xmlE, OUString sSystemId , sal_Int32 nLine )
{
	const sal_Char* errmsg;

	switch( xmlE )
	{
        case XML_ERR_INVALID_HEX_CHARREF:
            errmsg = "CharRef: invalid hexadecimal value\n";
            break;
        case XML_ERR_INVALID_DEC_CHARREF:
            errmsg = "CharRef: invalid decimal value\n";
            break;
        case XML_ERR_INVALID_CHARREF:
            errmsg = "CharRef: invalid value\n";
            break;
        case XML_ERR_INTERNAL_ERROR:
            errmsg = "internal error";
            break;
        case XML_ERR_PEREF_AT_EOF:
            errmsg = "PEReference at end of document\n";
            break;
        case XML_ERR_PEREF_IN_PROLOG:
            errmsg = "PEReference in prolog\n";
            break;
        case XML_ERR_PEREF_IN_EPILOG:
            errmsg = "PEReference in epilog\n";
            break;
        case XML_ERR_PEREF_NO_NAME:
            errmsg = "PEReference: no name\n";
            break;
        case XML_ERR_PEREF_SEMICOL_MISSING:
            errmsg = "PEReference: expecting ';'\n";
            break;
        case XML_ERR_ENTITY_LOOP:
            errmsg = "Detected an entity reference loop\n";
            break;
        case XML_ERR_ENTITY_NOT_STARTED:
            errmsg = "EntityValue: \" or ' expected\n";
            break;
        case XML_ERR_ENTITY_PE_INTERNAL:
            errmsg = "PEReferences forbidden in internal subset\n";
            break;
        case XML_ERR_ENTITY_NOT_FINISHED:
            errmsg = "EntityValue: \" or ' expected\n";
            break;
        case XML_ERR_ATTRIBUTE_NOT_STARTED:
            errmsg = "AttValue: \" or ' expected\n";
            break;
        case XML_ERR_LT_IN_ATTRIBUTE:
            errmsg = "Unescaped '<' not allowed in attributes values\n";
            break;
        case XML_ERR_LITERAL_NOT_STARTED:
            errmsg = "SystemLiteral \" or ' expected\n";
            break;
        case XML_ERR_LITERAL_NOT_FINISHED:
            errmsg = "Unfinished System or Public ID \" or ' expected\n";
            break;
        case XML_ERR_MISPLACED_CDATA_END:
            errmsg = "Sequence ']]>' not allowed in content\n";
            break;
        case XML_ERR_URI_REQUIRED:
            errmsg = "SYSTEM or PUBLIC, the URI is missing\n";
            break;
        case XML_ERR_PUBID_REQUIRED:
            errmsg = "PUBLIC, the Public Identifier is missing\n";
            break;
        case XML_ERR_HYPHEN_IN_COMMENT:
            errmsg = "Comment must not contain '--' (double-hyphen)\n";
            break;
        case XML_ERR_PI_NOT_STARTED:
            errmsg = "xmlParsePI : no target name\n";
            break;
        case XML_ERR_RESERVED_XML_NAME:
            errmsg = "Invalid PI name\n";
            break;
        case XML_ERR_NOTATION_NOT_STARTED:
            errmsg = "NOTATION: Name expected here\n";
            break;
        case XML_ERR_NOTATION_NOT_FINISHED:
            errmsg = "'>' required to close NOTATION declaration\n";
            break;
        case XML_ERR_VALUE_REQUIRED:
            errmsg = "Entity value required\n";
            break;
        case XML_ERR_URI_FRAGMENT:
            errmsg = "Fragment not allowed";
            break;
        case XML_ERR_ATTLIST_NOT_STARTED:
            errmsg = "'(' required to start ATTLIST enumeration\n";
            break;
        case XML_ERR_NMTOKEN_REQUIRED:
            errmsg = "NmToken expected in ATTLIST enumeration\n";
            break;
        case XML_ERR_ATTLIST_NOT_FINISHED:
            errmsg = "')' required to finish ATTLIST enumeration\n";
            break;
        case XML_ERR_MIXED_NOT_STARTED:
            errmsg = "MixedContentDecl : '|' or ')*' expected\n";
            break;
        case XML_ERR_PCDATA_REQUIRED:
            errmsg = "MixedContentDecl : '#PCDATA' expected\n";
            break;
        case XML_ERR_ELEMCONTENT_NOT_STARTED:
            errmsg = "ContentDecl : Name or '(' expected\n";
            break;
        case XML_ERR_ELEMCONTENT_NOT_FINISHED:
            errmsg = "ContentDecl : ',' '|' or ')' expected\n";
            break;
        case XML_ERR_PEREF_IN_INT_SUBSET:
            errmsg =
                "PEReference: forbidden within markup decl in internal subset\n";
            break;
        case XML_ERR_GT_REQUIRED:
            errmsg = "expected '>'\n";
            break;
        case XML_ERR_CONDSEC_INVALID:
            errmsg = "XML conditional section '[' expected\n";
            break;
        case XML_ERR_EXT_SUBSET_NOT_FINISHED:
            errmsg = "Content error in the external subset\n";
            break;
        case XML_ERR_CONDSEC_INVALID_KEYWORD:
            errmsg =
                "conditional section INCLUDE or IGNORE keyword expected\n";
            break;
        case XML_ERR_CONDSEC_NOT_FINISHED:
            errmsg = "XML conditional section not closed\n";
            break;
        case XML_ERR_XMLDECL_NOT_STARTED:
            errmsg = "Text declaration '<?xml' required\n";
            break;
        case XML_ERR_XMLDECL_NOT_FINISHED:
            errmsg = "parsing XML declaration: '?>' expected\n";
            break;
        case XML_ERR_EXT_ENTITY_STANDALONE:
            errmsg = "external parsed entities cannot be standalone\n";
            break;
        case XML_ERR_ENTITYREF_SEMICOL_MISSING:
            errmsg = "EntityRef: expecting ';'\n";
            break;
        case XML_ERR_DOCTYPE_NOT_FINISHED:
            errmsg = "DOCTYPE improperly terminated\n";
            break;
        case XML_ERR_LTSLASH_REQUIRED:
            errmsg = "EndTag: '</' not found\n";
            break;
        case XML_ERR_EQUAL_REQUIRED:
            errmsg = "expected '='\n";
            break;
        case XML_ERR_STRING_NOT_CLOSED:
            errmsg = "String not closed expecting \" or '\n";
            break;
        case XML_ERR_STRING_NOT_STARTED:
            errmsg = "String not started expecting ' or \"\n";
            break;
        case XML_ERR_ENCODING_NAME:
            errmsg = "Invalid XML encoding name\n";
            break;
        case XML_ERR_STANDALONE_VALUE:
            errmsg = "standalone accepts only 'yes' or 'no'\n";
            break;
        case XML_ERR_DOCUMENT_EMPTY:
            errmsg = "Document is empty\n";
            break;
        case XML_ERR_DOCUMENT_END:
            errmsg = "Extra content at the end of the document\n";
            break;
        case XML_ERR_NOT_WELL_BALANCED:
            errmsg = "chunk is not well balanced\n";
            break;
        case XML_ERR_EXTRA_CONTENT:
            errmsg = "extra content at the end of well balanced chunk\n";
            break;
        case XML_ERR_VERSION_MISSING:
            errmsg = "Malformed declaration expecting version\n";
            break;
        default:
            errmsg = "Unregistered error message\n";
    }

	OUString str = OUString::createFromAscii( "[" );
	str += sSystemId;
	str += OUString::createFromAscii( " line " );
	str += OUString::valueOf( nLine );
	str += OUString::createFromAscii( "]: " );
	str += OUString::createFromAscii( errmsg );
	str += OUString::createFromAscii( "error" );

	return str;
}

SaxLibXML2Parser_Impl::SaxLibXML2Parser_Impl()
{
}

// starts parsing with actual parser !
void SaxLibXML2Parser_Impl::parse( )
{
	const int nBufSize = 16*1024;
	Sequence< sal_Int8 > aBuffer(nBufSize);

	int nRead   = nBufSize;

	xmlParserErrors eError = XML_ERR_OK;

	while( nRead )
	{
		nRead = getEntity().structSource.aInputStream->readSomeBytes( aBuffer, nBufSize );
		const char* pBuffer = (const char * )aBuffer.getConstArray();

		if( !getEntity().pParser )
		{
			xmlSAXHandler sax;
			memset( &sax, 0, sizeof(sax) );
			sax.startElement = SaxLibXML2Parser_Impl::callbackStartElement;
			sax.endElement = SaxLibXML2Parser_Impl::callbackEndElement;
			sax.characters = SaxLibXML2Parser_Impl::callbackCharacters;
			sax.processingInstruction = SaxLibXML2Parser_Impl::callbackProcessingInstruction;
			sax.unparsedEntityDecl = SaxLibXML2Parser_Impl::callbackUnparsedEntityDecl;
			sax.notationDecl = SaxLibXML2Parser_Impl::callbackNotationDecl;
			sax.resolveEntity = SaxLibXML2Parser_Impl::callbackExternalEntityRef;
//			sax.initialized = XML_SAX2_MAGIC;

/* todo
//	XML_SetUnknownEncodingHandler( entity.pParser, 	SaxLibXML2Parser_Impl::callbackUnknownEncoding ,0);
	
	if( m_pImpl->rExtendedDocumentHandler.is() ) {

		// These handlers just delegate calls to the ExtendedHandler. If no extended handler is
		// given, these callbacks can be ignored
		XML_SetDefaultHandlerExpand( entity.pParser, SaxLibXML2Parser_Impl::callbackDefault );
		XML_SetCommentHandler( entity.pParser, SaxLibXML2Parser_Impl::callbackComment );
		XML_SetCdataSectionHandler( 	entity.pParser , 
										SaxLibXML2Parser_Impl::callbackStartCDATA ,
									 	SaxLibXML2Parser_Impl::callbackEndCDATA );
	}
*/

			getEntity().pParser = xmlCreatePushParserCtxt ( &sax, this, pBuffer, nRead, NULL);
			// todo: how to get parser error for first chunk?

			if( ! getEntity().pParser )
			{
				throw SAXException( OUString::createFromAscii( "Couldn't create parser" ) ,
									Reference< XInterface > (), Any() );
			}
		}
		else if( nRead )
		{
			eError = (xmlParserErrors)xmlParseChunk( getEntity().pParser, pBuffer, nRead, 0);
		}
		else
		{	
			xmlParseChunk( getEntity().pParser, (const char * )aBuffer.getConstArray(), 0, 1);
			break;
		}		

		/* todo: parse error handling? */
		if( (eError != XML_ERR_OK) || this->bExceptionWasThrown )
		{		
			// Error during parsing !
			OUString sSystemId = rDocumentLocator->getSystemId();
			sal_Int32 nLine = rDocumentLocator->getLineNumber();

			SAXParseException aExcept( 	
				getErrorMessage(eError , sSystemId, nLine) , 
				Reference< XInterface >(), 
				Any( &exception , getCppuType( &exception) ),
				rDocumentLocator->getPublicId(),
				rDocumentLocator->getSystemId(),
				rDocumentLocator->getLineNumber(),
							rDocumentLocator->getColumnNumber()
				);
			
			if( rErrorHandler.is() )
			{

				// error handler is set, so the handler may throw the exception
				rErrorHandler->fatalError( makeAny( aExcept ) );
			}

			// Error handler has not thrown an exception, but parsing cannot go on,
			// so an exception MUST be thrown.
			throw aExcept;
		} // if( ! bContinue )
	} // while
}

//------------------------------------------
//
// The C-Callbacks
//
//-----------------------------------------
void SaxLibXML2Parser_Impl::callbackStartElement( void *pvThis, const xmlChar *name, const xmlChar **awAttributes )
{
    // in case of two concurrent threads, there is only the danger of an leak,
    // which is neglectable for one string
    static OUString g_CDATA( RTL_CONSTASCII_USTRINGPARAM( "CDATA" ) );
    
	SaxLibXML2Parser_Impl *pImpl = ((SaxLibXML2Parser_Impl*)pvThis);
	
	if( pImpl->rDocumentHandler.is() ) {

		int i = 0;
		pImpl->pAttrList->clear(); 
		
		if( awAttributes )
		{
			while( awAttributes[i] ) {
				OSL_ASSERT( awAttributes[i+1] );
				pImpl->pAttrList->addAttribute(
					X2S( awAttributes[i] ) , 
					g_CDATA ,  // expat doesn't know types
					X2S( awAttributes[i+1] ) );
				i +=2;	
			}
		}

		CALL_ELEMENT_HANDLER_AND_CARE_FOR_EXCEPTIONS(
			pImpl , 
			rDocumentHandler->startElement( X2S( name ) , 
											pImpl->rAttrList ) );
	}
}

void SaxLibXML2Parser_Impl::callbackEndElement( void *pvThis , const xmlChar *pwName  )
{
	SaxLibXML2Parser_Impl  *pImpl = ((SaxLibXML2Parser_Impl*)pvThis);
	
	if( pImpl->rDocumentHandler.is() ) {
		CALL_ELEMENT_HANDLER_AND_CARE_FOR_EXCEPTIONS( pImpl,
				rDocumentHandler->endElement( X2S( pwName ) ) );
	}
}


void SaxLibXML2Parser_Impl::callbackCharacters( void *pvThis , const xmlChar *ch , int nLen )
{
	SaxLibXML2Parser_Impl *pImpl = ((SaxLibXML2Parser_Impl*)pvThis);

	if( pImpl->rDocumentHandler.is() ) {
		CALL_ELEMENT_HANDLER_AND_CARE_FOR_EXCEPTIONS( pImpl , 
				rDocumentHandler->characters( XN2S(ch , nLen) ) );
	}
}

void SaxLibXML2Parser_Impl::callbackProcessingInstruction(	void *pvThis,
													const xmlChar *sTarget , 
													const xmlChar *sData )
{
	SaxLibXML2Parser_Impl *pImpl = ((SaxLibXML2Parser_Impl*)pvThis);
	if( pImpl->rDocumentHandler.is() ) {
		CALL_ELEMENT_HANDLER_AND_CARE_FOR_EXCEPTIONS( pImpl ,
				rDocumentHandler->processingInstruction( X2S( sTarget ), X2S( sData ) ) );
	}	
}


void SaxLibXML2Parser_Impl::callbackUnparsedEntityDecl(void *pvThis , 
						  						const xmlChar *entityName,
					      						const xmlChar *publicId,
					      						const xmlChar *systemId,
					      						const xmlChar *notationName)
{
	SaxLibXML2Parser_Impl *pImpl = ((SaxLibXML2Parser_Impl*)pvThis);
	if( pImpl->rDTDHandler.is() ) {
		CALL_ELEMENT_HANDLER_AND_CARE_FOR_EXCEPTIONS(
			pImpl , 
			rDTDHandler->unparsedEntityDecl(
				X2S( entityName ), 
				X2S( publicId ),
				X2S( systemId ),
				X2S( notationName ) ) );
	}
}
					      					
void SaxLibXML2Parser_Impl::callbackNotationDecl(	void *pvThis,
												const xmlChar *notationName,
												const xmlChar *publicId,
												const xmlChar *systemId)
{
	SaxLibXML2Parser_Impl *pImpl = ((SaxLibXML2Parser_Impl*)pvThis);
	if( pImpl->rDTDHandler.is() ) {		
		CALL_ELEMENT_HANDLER_AND_CARE_FOR_EXCEPTIONS( pImpl,
			    rDTDHandler->notationDecl( 	X2S( notationName ),
											X2S( publicId ) ,
											X2S( systemId ) ) );
	}

}										



xmlParserInputPtr SaxLibXML2Parser_Impl::callbackExternalEntityRef(	void *ctx,
													const xmlChar *publicId,
													const xmlChar *systemId)
{
	InputSource source;
	SaxLibXML2Parser_Impl *pImpl = (SaxLibXML2Parser_Impl*)ctx;

	struct Entity entity;
	
	if( pImpl->rEntityResolver.is() ) {
		try
		{
	    	entity.structSource = pImpl->rEntityResolver->resolveEntity(
				X2S( publicId ),
				X2S( systemId ) );
	    }
	    catch( SAXParseException & e )
		{
	    	pImpl->exception = e;
	    }
	    catch( SAXException & e )
		{
			Reference< XInterface > Context;
	    	pImpl->exception = SAXParseException(
				e.Message , Context , e.WrappedException ,
				pImpl->rDocumentLocator->getPublicId(),
				pImpl->rDocumentLocator->getSystemId(),
				pImpl->rDocumentLocator->getLineNumber(),
				pImpl->rDocumentLocator->getColumnNumber() );
	    }
	}

	if( entity.structSource.aInputStream.is() )
	{
		entity.pParser = 0;
		pImpl->pushEntity( entity );
		try
		{
			pImpl->parse();
		}
		catch( SAXParseException & e )
		{
			pImpl->exception = e;
		}
		catch( IOException &e )
		{
			pImpl->exception.WrappedException <<= e;
		}
		catch( RuntimeException &e )
		{
			pImpl->exception.WrappedException <<=e;
		}

		pImpl->popEntity();

		if( entity.pParser )
			xmlFreeParserCtxt(entity.pParser);
	}

	return 0;
}

/*
int SaxLibXML2Parser_Impl::callbackUnknownEncoding(void *encodingHandlerData,
					  						const xmlChar *name,
					  						XML_Encoding *info)
{
	return 0;
}					  							
*/

void SaxLibXML2Parser_Impl::callbackDefault( void *pvThis,  const xmlChar *s,  int len)
{
	SaxLibXML2Parser_Impl *pImpl = ((SaxLibXML2Parser_Impl*)pvThis);

	CALL_ELEMENT_HANDLER_AND_CARE_FOR_EXCEPTIONS(  pImpl,
				rExtendedDocumentHandler->unknown( X2S( s ) ) );
}

void SaxLibXML2Parser_Impl::callbackComment( void *pvThis , const xmlChar *s )
{
	SaxLibXML2Parser_Impl *pImpl = ((SaxLibXML2Parser_Impl*)pvThis);
	CALL_ELEMENT_HANDLER_AND_CARE_FOR_EXCEPTIONS( pImpl,
				rExtendedDocumentHandler->comment( X2S(s) ) );
}

void SaxLibXML2Parser_Impl::callbackStartCDATA( void *pvThis )
{
	SaxLibXML2Parser_Impl *pImpl = ((SaxLibXML2Parser_Impl*)pvThis);

	CALL_ELEMENT_HANDLER_AND_CARE_FOR_EXCEPTIONS( pImpl, rExtendedDocumentHandler->startCDATA() );
}


void SaxLibXML2Parser_Impl::callErrorHandler( SaxLibXML2Parser_Impl *pImpl ,
											const SAXParseException & e )
{
	try
	{
		if( pImpl->rErrorHandler.is() ) {
			Any a;
			a <<= e;
			pImpl->rErrorHandler->error( a );
		}
		else {
			pImpl->exception = e;
			pImpl->bExceptionWasThrown = sal_True;
		}
	}
	catch( SAXParseException & ex ) {
		pImpl->exception = ex;
		pImpl->bExceptionWasThrown = sal_True;
	}
	catch( SAXException & ex ) {
		pImpl->exception = SAXParseException( 
									ex.Message, 
									ex.Context, 
									ex.WrappedException,
									pImpl->rDocumentLocator->getPublicId(),
									pImpl->rDocumentLocator->getSystemId(),
									pImpl->rDocumentLocator->getLineNumber(),
									pImpl->rDocumentLocator->getColumnNumber()
							 );
		pImpl->bExceptionWasThrown = sal_True;
	}		
}

void SaxLibXML2Parser_Impl::callbackEndCDATA( void *pvThis )
{
	SaxLibXML2Parser_Impl *pImpl = ((SaxLibXML2Parser_Impl*)pvThis);

	CALL_ELEMENT_HANDLER_AND_CARE_FOR_EXCEPTIONS(pImpl,rExtendedDocumentHandler->endCDATA() );
}

}
using namespace sax_libxmlwrap;

extern "C" 
{

void SAL_CALL component_getImplementationEnvironment(
	const sal_Char ** ppEnvTypeName, uno_Environment ** ppEnv )
{
	*ppEnvTypeName = CPPU_CURRENT_LANGUAGE_BINDING_NAME;
}


sal_Bool SAL_CALL component_writeInfo(
	void * pServiceManager, void * pRegistryKey )
{
	if (pRegistryKey)
	{
		try
		{
			Reference< XRegistryKey > xKey(
				reinterpret_cast< XRegistryKey * >( pRegistryKey ) );
			
			Reference< XRegistryKey > xNewKey = xKey->createKey(
				OUString::createFromAscii( "/" IMPLEMENTATION_NAME "/UNO/SERVICES" ) );
			xNewKey->createKey( OUString::createFromAscii( SERVICE_NAME ) );
			
			return sal_True;
		}
		catch (InvalidRegistryException &)
		{
			OSL_ENSURE( sal_False, "### InvalidRegistryException!" );
		}
	}
	return sal_False;
}


void * SAL_CALL component_getFactory(
	const sal_Char * pImplName, void * pServiceManager, void * pRegistryKey )
{
	void * pRet = 0;
	
	if (pServiceManager )
	{
		Reference< XSingleServiceFactory > xRet;
		Reference< XMultiServiceFactory > xSMgr =
			reinterpret_cast< XMultiServiceFactory * > ( pServiceManager );
		
		OUString aImplementationName = OUString::createFromAscii( pImplName );
		
		if (aImplementationName ==
			OUString( RTL_CONSTASCII_USTRINGPARAM( IMPLEMENTATION_NAME  ) ) )
		{
			xRet = createSingleFactory( xSMgr, aImplementationName,
										SaxLibXML2Parser_CreateInstance,
										SaxLibXML2Parser::getSupportedServiceNames_Static() );
		}

		if (xRet.is())
		{
			xRet->acquire();
			pRet = xRet.get();
		}
	}
	
	return pRet;
}
		

}

