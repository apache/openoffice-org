/*************************************************************************
 *
 *  $RCSfile: OOoDTDResolver.java,v $
 *
 *  $Revision: 1.2 $
 *
 *  last change: $Author: sus $ $Date: 2003/11/06 15:46:25 $
 *
 *  The Contents of this file are made available subject to
 *  the terms of GNU Lesser General Public License Version 2.1.


 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2005 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 ************************************************************************/

package org.openoffice.xslt;

import org.xml.sax.ContentHandler;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.*;
import java.io.*;
import java.net.*;


public class OOoDTDResolver extends DefaultHandler implements EntityResolver, DTDHandler, ContentHandler, ErrorHandler{


    /**
     * Resolve an external entity.
     *
     * <p>Resolves JAR URLs, otherwise return null, so that the parser will use the system
     * identifier provided in the XML document.  This method implements
     * the SAX default behaviour: application writers can override it
     * in a subclass to do special translations such as catalog lookups
     * or URI redirection.</p>
     *
     * @param publicId The public identifer, or null if none is
     *                 available.                // this deactivates the open office DTD
     * @param systemId The system identifier provided in the XML
     *                 document.
     * @return The new input source, or null to require the
     *         default behaviour.
     * @exception java.io.IOException If there is an error setting
     *            up the new input source.
     * @exception org.xml.sax.SAXException Any SAX exception, possibly
     *            wrapping another exception.
     * @see org.xml.sax.EntityResolver#resolveEntity
     *
     *	For further documentation and updates visit http://xml.openoffice.org/sx2ml
     */
    public InputSource resolveEntity (String publicId, String systemId)
	throws SAXException
    {
        try{
            // this deactivates the open office DTD
            if (publicId.equals("-//OpenOffice.org//DTD OfficeDocument 1.0//EN"))
                return new InputSource(new ByteArrayInputStream("<?xml version='1.0' encoding='UTF-8'?>".getBytes()));

            if(systemId.startsWith("jar")) {
                URL url = new URL(systemId);
                JarURLConnection jarConn = (JarURLConnection) url.openConnection();
                return new InputSource(jarConn.getInputStream());
            }
        }catch(MalformedURLException me){
            System.out.println("Incorrect URL format used"+ me.getMessage());
        }catch(IOException ie){
            System.out.println("IO Problem" + ie.getMessage());
        }
        // Otherwise return null, so that the parser will use the system
        // identifier provided in the XML document.
        return null;
    }
}

