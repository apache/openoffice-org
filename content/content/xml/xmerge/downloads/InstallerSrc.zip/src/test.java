import javax.swing.*;

public class test{
	public static void main(String [] args)
	{
		JFrame f = new JFrame();
		f.getContentPane().add(new Banner());
		f.pack();
		f.show();
	}
}
