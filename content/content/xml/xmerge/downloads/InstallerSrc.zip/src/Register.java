import java.lang.String;
import java.io.*;
import javax.swing.*;

public class Register{
    
	private static JProgressBar progressBar;

     private static void unx(String url,String path, javax.swing.JLabel statusLabel){
	 System.out.println("\nFound a Unix path:"+path);
	 System.out.println("\nThis Script does not support Unix");
	
     }

    private static void windows(String url,String path, javax.swing.JLabel statusLabel){
	try{
		//System.out.println("In windows:register");
	    String s=null;
	    String classpath="";
	    int exitcode=0;
	    boolean passed=true;
	    String env[] = new String[1]; 
	    Runtime rt= Runtime.getRuntime();
	    String progpath=path.concat(File.separator+"program"+File.separator);
	    BufferedReader stdInput;
	    Process p;
		statusLabel.setText("Registering XImportFilter...");
		progressBar.setString("Registering XImportFilter ");
		progressBar.setValue(7);
	    String opSys =System.getProperty("os.name");
	     //System.out.println("cmd /c \""+progpath+"regmerge\" \""+progpath+"applicat.rdb\" /UCR \""+progpath+"XImportFilter.urd\" \""+progpath+"XExportFilter.urd\"");
		statusLabel.setText("Registering XExportFilter...");
		
	     if (opSys.indexOf("Windows")==-1){
			env[0]="LD_LIBRARY_PATH="+progpath;
		     p=rt.exec("chmod a+x "+progpath+"reg*");
		     p=rt.exec(progpath+"regmerge "+progpath+"applicat.rdb /UCR "+progpath+"XImportFilter.urd "+progpath+"XExportFilter.urd",env,new File(progpath));
	   
		}
	     else{
	   		 p=rt.exec("\""+progpath+"regmerge\" \""+progpath+"applicat.rdb\" /UCR \""+progpath+"XImportFilter.urd\" \""+progpath+"XExportFilter.urd\"");
	     }
		exitcode=p.waitFor();   
		 if (exitcode !=0){
		System.out.println("\n RegMerge Failed!");
		passed=false;
	     }
		else{
			//System.out.println("\nRegMerged required interfaces");
		}

	

	//dll registration
			statusLabel.setText("Registering Filter Library");
			progressBar.setString("Registering Filter Library");
		if (opSys.indexOf("Windows")!=-1){
			p=rt.exec("\""+progpath+"regcomp\" -register -br \""+path+File.separator+"program"+File.separator+"applicat.rdb\" -r \""+path+File.separator+"program"+File.separator+"applicat.rdb\" -c \""+url+"program/xmlfa642mi.dll\"");
		}
		else if (opSys.indexOf("Linux")!=-1){
			env[0]="LD_LIBRARY_PATH="+progpath;	
			p=rt.exec("\""+progpath+"regcomp\" -register -br \""+path+File.separator+"program"+File.separator+"applicat.rdb\" -r \""+path+File.separator+"program"+File.separator+"applicat.rdb\" -c \""+url+"program/libxmlfa642li.so\"",env);
		}
		else if (opSys.indexOf("SunOS")!=-1){
			env[0]="LD_LIBRARY_PATH="+progpath;
			p=rt.exec(progpath+"regcomp -register -br "+path+File.separator+"program"+File.separator+"applicat.rdb -r "+path+File.separator+"program"+File.separator+"applicat.rdb -c "+url+"program/libxmlfa643ss.so",env);
		}
		exitcode=p.waitFor();
  	   	if (exitcode !=0){
			System.out.println("\n Registration Failed!");
			stdInput=new BufferedReader(new InputStreamReader(p.getErrorStream()));
		     while((s=stdInput.readLine())!=null){
				System.out.println(s);
	     		}
			passed=false;
	     	}
	 	else{
			//System.out.println("\nRegistered XmlFilterAdaptor");
		}

	//jar registration	

	     //System.out.println("\n\""+progpath+"regcomp\" -register -br \""+path+File.separator+"program"+File.separator+"applicat.rdb\" -r \""+path+"\\program\\applicat.rdb\" -c \""+url+"/program/classes/XMergeBridge.jar\"");
			statusLabel.setText("Registering XMerge Bridge");
		progressBar.setString("Registering XMerge Bridge");
		progressBar.setValue(8);
		progressBar.setString("Registering XMerge Bridge");
		
		if (opSys.indexOf("Windows")!=-1){
			p=rt.exec("\""+progpath+"regcomp.exe\" -register -br \""+path+File.separator+"program"+File.separator+"applicat.rdb\" -r \""+path+File.separator+"program"+File.separator+"applicat.rdb\" -c \""+url+"program/classes/XMergeBridge.jar\"");
		}
		else{
			env[0]="LD_LIBRARY_PATH="+progpath;
			p=rt.exec(progpath+"regcomp -register -br "+path+File.separator+"program"+File.separator+"applicat.rdb -r "+path+File.separator+"program"+File.separator+"applicat.rdb -c "+url+"program/classes/XMergeBridge.jar -l com.sun.star.loader.Java2",env);
		}
	     exitcode=p.waitFor();
	     if (exitcode !=0){
			System.out.println("\n Registration Failed!");
			stdInput=new BufferedReader(new InputStreamReader(p.getErrorStream()));
		      while((s=stdInput.readLine())!=null){
				System.out.println(s);
	     		}
		      passed=false;
	     }
		else{
			//System.out.println("\nRegistered XMergeBridge.jar");
		}
	     //System.out.println("\n\""+progpath+"regcomp\" -register -br \""+path+File.separator+"program"+File.separator+"applicat.rdb\" -r \""+path+File.separator+"program"+File.separator+"applicat.rdb\" -c \""+url+"/program/classes/XFlatXml.jar\"");
			statusLabel.setText("Registering Flat XML Filter");
		progressBar.setString("Registering Flat XML Filter");
		progressBar.setValue(9);
	     if (opSys.indexOf("Windows")!=-1){
	    	 p=rt.exec("\""+progpath+"regcomp\" -register -br \""+path+File.separator+"program"+File.separator+"applicat.rdb\" -r \""+path+File.separator+"program"+File.separator+"applicat.rdb\" -c \""+url+"/program/classes/XFlatXml.jar\"");
	     }
	     else{
		env[0]="LD_LIBRARY_PATH="+progpath;
	     	 p=rt.exec(progpath+"regcomp -register -br "+path+File.separator+"program"+File.separator+"applicat.rdb -r "+path+File.separator+"program"+File.separator+"applicat.rdb -c "+url+"/program/classes/XFlatXml.jar -l com.sun.star.loader.Java2",env);
		}    
	     exitcode=p.waitFor();
	     if (exitcode !=0){
	 		System.out.println("\n Registration Failed!");
			stdInput=new BufferedReader(new InputStreamReader(p.getErrorStream()));
		      while((s=stdInput.readLine())!=null){
				System.out.println(s);
	     		}
			passed=false;
	     }
	     else{
			//System.out.println("\nRegistered XFlatXml.jar");
		}
	}
	catch(Exception e){
	    System.out.println("Error:"+e);
	}
    }

  
    
 

    public static void register(String path, javax.swing.JLabel statusLabel,JProgressBar pBar){
      progressBar=pBar;
	boolean win =false;
	String newString= "file://";
	if (path.indexOf(":")==1){
	    newString=newString.concat("/");
	    win=true;
	}
	String tmpStr1="";
	String tmpStr2="";
	newString=newString.concat(path.replace('\\','/'));
	int i=0;
	if (newString.indexOf(" ")>0){
	    tmpStr1=tmpStr1.concat(newString.substring(i,newString.indexOf(" ")));
	    tmpStr1=tmpStr1.concat("\\ ");
	    newString=newString.substring(newString.indexOf(" ")+1,newString.length()); 
	    
	    }
	tmpStr1=tmpStr1.concat(newString);
	//System.out.println(""+tmpStr1);
	char url[]=path.toCharArray();
	char test[]=new char[path.length()*2];
	int j=0;
	
	path = path.substring (0,path.length()-1);
	windows(tmpStr1,path, statusLabel);
	
    }


}


