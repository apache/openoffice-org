public class SysProp
{
	public static void main(String args[])
	{
		System.out.println("os.name : " + System.getProperty("os.name"));
		System.out.println("os.arch : " + System.getProperty("os.arch"));
		System.out.println("user.home : " + System.getProperty("user.home"));
	}
}
