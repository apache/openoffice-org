/************************************************************************
 *
 *  The Contents of this file are made available subject to the terms of
 *  either of the following licenses
 *
 *         - GNU Lesser General Public License Version 2.1
 *         - Sun Industry Standards Source License Version 1.1
 *
 *  Sun Microsystems Inc., October, 2000
 *
 *  GNU Lesser General Public License Version 2.1
 *  =============================================
 *  Copyright 2000 by Sun Microsystems, Inc.
 *  901 San Antonio Road, Palo Alto, CA 94303, USA
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *
 *  Sun Industry Standards Source License Version 1.1
 *  =================================================
 *  The contents of this file are subject to the Sun Industry Standards
 *  Source License Version 1.1 (the "License"); You may not use this file
 *  except in compliance with the License. You may obtain a copy of the
 *  License at http://www.openoffice.org/license.html.
 *
 *  Software provided under this License is provided on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
 *  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
 *  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
 *  See the License for the specific provisions governing your rights and
 *  obligations concerning the Software.
 *
 *  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
 *
 *  Copyright: 2000 by Sun Microsystems, Inc.
 *
 *  All Rights Reserved.
 *
 *  Contributor(s): _______________________________________
 *
 *
 ************************************************************************/

import java.io.*;
import java.util.*;
import java.util.jar.*;
import org.xml.sax.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.net.URL;
import java.net.JarURLConnection;
import javax.xml.parsers.*;
import javax.swing.*;

/**
 *  The <code>XmlUpdater</code> pulls a META-INF/converter.xml
 *  file out of a jar file and parses it, providing access to this
 *  information in a <code>Vector</code> of <code>ConverterInfo</code>
 *  objects.
 *
 *  @author  Aidan Butler
 */
public class XmlUpdater extends Thread {
    
    private final static String TAG_TYPES         = "Types";
    private final static String TAG_TYPEDETECTION = "TypeDetection";
    private final static String TAG_TYPE          = "Type";
    private final static String TAG_DATA          = "Data";
    private final static String TAG_FILTERS       = "Filters";
    private final static String TAG_FILTER        = "Filter";
    private final static String TAG_CLASSPATH     = "UserClassPath";
	
    private String classesPath = null;
    private String jarfilename;
    private String installPath;
    private Document document;
    
    private Element filterNode;
    private Element installedNode;
    private Element uinameNode;
    private Element cfgvalueNode;
    private Element dataNode;
    private Element typeNode;
    private JLabel statusLabel;
	private Vector listeners;
	private Thread internalThread;
	private boolean threadSuspended;
	private JProgressBar progressBar;
    
    
    public XmlUpdater(String installPath, JLabel statusLabel,JProgressBar pBar) {
        this.installPath = installPath;
        this.statusLabel = statusLabel;
		listeners = new Vector();
		threadSuspended = false;
	progressBar=pBar;
	progressBar.setStringPainted(true);
    }

	public boolean checkStop()
	{
		if (internalThread == Thread.currentThread())
			return false;
		return true;
	}

	public void checkSuspend()
	{
		if (threadSuspended)
		{
			synchronized(this)
			{
				while (threadSuspended)
				{
					try	{
						wait();
					} catch (InterruptedException eInt) {
						//...
					}
				}
			}
		}
	}
    
	public void setSuspend()
	{
		threadSuspended = true;
	}

	public void setResume()
	{
		threadSuspended = false;
		notify();
	}
	
	public void setStop()
	{
		internalThread = null;
	}
	
    public void run() {

        InputStream            istream;
        InputSource            isource;
        DocumentBuilderFactory builderFactory;
        DocumentBuilder        builder = null;
        URL                    url;
        String				   fileName = null;

		internalThread = Thread.currentThread();
		
        //System.out.println("\n\n\n\nFileName: "+installPath);
        classesPath= installPath.concat(File.separator+"program"+File.separator+"classes"+File.separator);
        String opSys =System.getProperty("os.name");
		//System.out.println("\n System "+opSys);
        String progpath=installPath;
        progpath= progpath.concat(File.separator+"program"+File.separator);
        //System.out.println("\nModifying Installation "+installPath);	
	progressBar.setString("Unzipping Required Files");
        ZipData zd = new ZipData("XMergeInstall.jar");
     
        if (!zd.extractEntry("jars/XMergeBridge.jar",classesPath, statusLabel))
		{
			onInstallComplete();
			return;
		}
        if (!zd.extractEntry("jars/xmerge.jar",classesPath, statusLabel))
		{
			onInstallComplete();
			return;
		}
        if (!zd.extractEntry("jars/XFlatXml.jar",classesPath, statusLabel))
		{
			onInstallComplete();
			return;
		}
        if (!zd.extractEntry("jars/pocketword.jar",classesPath, statusLabel))
		{
			onInstallComplete();
			return;
		}
	/*if (!zd.extractEntry("jars/wordsmith.jar",classesPath, statusLabel))
			return;*/
        if (!zd.extractEntry("jars/pexcel.jar",classesPath, statusLabel))
		{
			onInstallComplete();
			return;
		}
        if (!zd.extractEntry("jars/aportisdoc.jar",classesPath, statusLabel))
		{
			onInstallComplete();
			return;
		}
        if (!zd.extractEntry("jars/htmlsoff.jar",classesPath, statusLabel))
		{
			onInstallComplete();
			return;
		}
	if (!zd.extractEntry("jars/docbook.jar",classesPath, statusLabel))
		{
			onInstallComplete();
			return;
		}
        if (!zd.extractEntry("jars/iface.jar",classesPath, statusLabel))
		{
			onInstallComplete();
			return;
		}
        if (!zd.extractEntry("dlls/juh.dll",progpath, statusLabel))
		{
			onInstallComplete();
			return;
		}
        if (!zd.extractEntry("urd/XImportFilter.urd",progpath, statusLabel))
		{
			onInstallComplete();
			return;
		}
        if (!zd.extractEntry("urd/XExportFilter.urd",progpath, statusLabel))
		{
			onInstallComplete();
			return;
		}
	if (opSys.indexOf("Windows")!=-1){
		if (!zd.extractEntry("dlls/xmlfa642mi.dll",progpath, statusLabel))
		{
			onInstallComplete();
			;
		}
		if (!zd.extractEntry("exe/regcomp.exe",progpath, statusLabel))
		{
			onInstallComplete();
			return;
		}
        	if (!zd.extractEntry("exe/regmerge.exe",progpath, statusLabel))
			{
				onInstallComplete();
			return;
			}
	}
        else if (opSys.indexOf("SunOS")!=-1){
		if (!zd.extractEntry("solaris/libxmlfa643ss.so",progpath, statusLabel))
		{
			onInstallComplete();
			;
		}
		if (!zd.extractEntry("solaris/regcomp",progpath, statusLabel))
		{
			onInstallComplete();
			return;
		}
		
        	if (!zd.extractEntry("solaris/regmerge",progpath, statusLabel))
			{
				onInstallComplete();
			return;
			}
	 	
	}
	else if (opSys.indexOf("Linux")!=-1){
		if (!zd.extractEntry("linux/libxmlfa643li.so",progpath, statusLabel))
		{
			onInstallComplete();
			;
		}
		if (!zd.extractEntry("linux/regcomp",progpath, statusLabel))
		{
			onInstallComplete();
			return;
		}
        	if (!zd.extractEntry("linux/regmerge",progpath, statusLabel))
			{
				onInstallComplete();
			return;
			}
	 
	}
	else{
		return;
	}
        // Build the InputSource
        //
        FileInputStream fistream=null;
        FileOutputStream fostream=null;
        progressBar.setValue(1);
        
        // Get the DOM builder and build the document.
        //
        

		if (InstUtil.getTmpDir() == null)
		{
			InstUtil.createTmpDir();
		}


        fileName = installPath.concat(File.separator+"share"+File.separator+"config"+File.separator+"registry"+File.separator+"instance"+File.separator+"org"+File.separator+"openoffice"+File.separator+"Office"+File.separator+"TypeDetection.xml");
		
		//Backup the file
		statusLabel.setText("Backing up type information");
		progressBar.setString("Backing up type information");
		InstallWizard.setTypesPath(fileName);
		File typesBackup = new File(InstUtil.getTmpDir(), "TypeDetection.xml");
		File typesOrig   = new File(fileName);
		progressBar.setValue(2);

		if (!InstUtil.copy(typesOrig, typesBackup))
		{
			System.err.println("!!!!! Failed to backup");
		}
		
        byte [] contentBytes = null;
		statusLabel.setText("Registering types for Small Device Filters");
        try {
            builderFactory    = DocumentBuilderFactory.newInstance();
            //System.out.println("\n\n\nFileName: "+fileName);
            fistream           =new FileInputStream(fileName);
            
            isource           = new InputSource(fistream);
            builder           = builderFactory.newDocumentBuilder();
            document          = builder.parse(isource);
	   
            parseTypeDetectionDoc();
	    progressBar.setValue(6);	
            contentBytes = docToBytes(document);
            //fistream.close();
            fostream = new FileOutputStream(fileName);
            fostream.write(contentBytes);
            fostream.close();
        }
        catch (IOException eIO) {
            System.out.println(eIO.getMessage());
        }
        catch (ParserConfigurationException ePC) {
            System.out.println(ePC.getMessage());
        }
        catch (org.xml.sax.SAXException eSE) {
            System.out.println(eSE.getMessage());
        }

		InstallWizard.setPatchedTypes(true);
        
        //System.out.println("\n\n\n\nFinished TypeDetection");
        
        
        // Parse the document.
        //
		statusLabel.setText("Backing up CLASSPATH information");
	progressBar.setString("Backing up CLASSPATH information");
        fileName = installPath.concat(File.separator+"user"+File.separator+"config"+File.separator+"registry"+File.separator+"instance"+File.separator+"org"+File.separator+"openoffice"+File.separator+"Office"+File.separator+"Java.xml");
		InstallWizard.setJavaPath(fileName);
        checkexists(fileName);

		//Backup the file
		File javaBackup = new File(InstUtil.getTmpDir(), "Java.xml");
		File javaOrig   = new File(fileName);
		
		if (!InstUtil.copy(javaOrig, javaBackup))
		{
			System.err.println("!!!!! Failed to backup");
		}
		//System.out.println("\n\n\n\nFileName: "+fileName);
		statusLabel.setText("Updating the CLASSPATH settings");
        try {
            fistream           =new FileInputStream(fileName);
            
            isource           = new InputSource(fistream);
            document          = builder.parse(isource);
            parseJavaDoc();
            //fistream.close();
            fostream = new FileOutputStream(fileName);
            contentBytes = docToBytes(document);
            fostream.write(contentBytes);
            fostream.close();
        }
        catch (IOException eIO2) {
            System.out.println(eIO2.getMessage());
        }
        catch (org.xml.sax.SAXException eSE2) {
            System.out.println(eSE2.getMessage());
        }
		InstallWizard.setPatchedJava(true);
        //System.out.println("\nFinished Java.xml");
		statusLabel.setText("Backing up application settings. Please wait...");
                progressBar.setString("Backing up application settings");
		File rdbBackup = new File(InstUtil.getTmpDir(), "applicat.rdb");
		File rdbOrig   = new File(installPath, "program" + File.separator + "applicat.rdb");
		
		if (!InstUtil.copy(rdbOrig, rdbBackup))
		{
			System.err.println("!!!!! Failed to backup applicat.rdb");
		}
		//System.out.println("About to call register");
		Register.register(installPath+File.separator, statusLabel, progressBar);
		statusLabel.setText("Installation Complete");
		progressBar.setString("Installation Complete");
		progressBar.setValue(10);
		onInstallComplete();
    }
    
    private void checkexists(String path){
        File checkFile = new File(path);
        String justPath= path.substring(0,path.lastIndexOf(File.separator)+1);
        //System.out.println("\n"+justPath);
        if(!checkFile.exists()){
            ZipData zd = new ZipData("XMergeInstall.jar");
            if (!zd.extractEntry("xml/Java.xml",justPath, statusLabel))
			{
				System.out.println("Fail");
			}
        }
    }
    
    
    private void parseJavaDoc() {
        Node     converterNode;
        Element converterElement = null;
        NodeList converterNodes = document.getElementsByTagName(TAG_CLASSPATH);
        converterNode = converterNodes.item(0);
        addClasspath(converterNode);
    }
    
    private void addClasspath(Node n){
        //n.appendChild( document.createTextNode(File.pathSeparator+classesPath+"aidan.jar"));
        n.appendChild( document.createTextNode(File.pathSeparator+classesPath+"XMergeBridge.jar"));
        n.appendChild( document.createTextNode(File.pathSeparator+classesPath+"xmerge.jar"));
        n.appendChild( document.createTextNode(File.pathSeparator+classesPath+"aportisdoc.jar"));
        n.appendChild( document.createTextNode(File.pathSeparator+classesPath+"pocketword.jar"));
        n.appendChild( document.createTextNode(File.pathSeparator+classesPath+"pexcel.jar"));
        n.appendChild( document.createTextNode(File.pathSeparator+classesPath+"htmlsoff.jar"));
        n.appendChild( document.createTextNode(File.pathSeparator+classesPath+"XFlatXml.jar"));
        n.appendChild( document.createTextNode(File.pathSeparator+classesPath+"iface.jar"));
	n.appendChild( document.createTextNode(File.pathSeparator+classesPath+"docbook.jar"));
	//n.appendChild( document.createTextNode(File.pathSeparator+classesPath+"wordsmith.jar"));

        
    }
    
    
    private void parseTypeDetectionDoc() {
        
        Node     converterNode;
        NodeList converterNodes = document.getElementsByTagName(TAG_TYPES);
        Element converterElement = null;
        converterNode = converterNodes.item(0);
        addTypes( converterNode);
        
        //System.out.println("\n"+converterNode.getChildNodes());
        converterNodes = document.getElementsByTagName(TAG_FILTERS);
        converterNode = converterNodes.item(0);
        addFilters( converterNode);
        //System.out.println("\n"+converterNode.getChildNodes());
        
    }
    
    private void createFilter(){
        filterNode = document.createElement("Filter");
        installedNode=  document.createElement("Installed");
        uinameNode=  document.createElement("UIName");
        dataNode=  document.createElement("Data");
        cfgvalueNode=  document.createElement("cfg:Value");
        uinameNode.setAttribute("cfg:type","string");
        uinameNode.setAttribute("cfg:localized","true");
        installedNode.appendChild( document.createTextNode("true"));
        installedNode.setAttribute("cfg:type","boolean");
        uinameNode.appendChild(cfgvalueNode);
        dataNode.setAttribute("cfg:type","string");
        
    }
    
    private void createType(){
        typeNode = document.createElement("Type");
        
        dataNode = document.createElement("Data");
        uinameNode = document.createElement("UIName");
        cfgvalueNode = document.createElement("cfg:value");
        uinameNode.setAttribute("cfg:type","string");
        cfgvalueNode.setAttribute("xml:lang","en-US");
        dataNode.setAttribute("cfg:type","string");
    }
    
    private void addFilters(Node n){
        //AportisDoc Filter
        createFilter();
        filterNode.setAttribute("cfg:name","AportisDoc Palm DB");
        cfgvalueNode.appendChild( document.createTextNode("AportisDoc Palm DB"));
        cfgvalueNode.setAttribute("xml:lang","en-US");
        dataNode.appendChild( document.createTextNode("0,writer_AportisDoc_PalmDB_File,com.sun.star.text.TextDocument,com.sun.star.comp.Writer.XmlFilterAdaptor,524355,com.sun.star.documentconversion.XMergeBridge;classes/aportisdoc.jar;com.sun.star.comp.Writer.XMLImporter;com.sun.star.comp.Writer.XMLExporter;staroffice/sxw;application/x-aportisdoc,0,,"));
        
        filterNode.appendChild(installedNode);
        filterNode.appendChild(uinameNode);
        filterNode.appendChild(dataNode);
        n.appendChild(filterNode);
        
        // Flat Xml Filter
        createFilter();
        filterNode.setAttribute("cfg:name","Flat Xml File");
        cfgvalueNode.appendChild( document.createTextNode("Flat Xml File"));
        cfgvalueNode.setAttribute("xml:lang","en-US");
        dataNode.appendChild( document.createTextNode("0,writer_Flat_XML_File,com.sun.star.text.TextDocument,com.sun.star.comp.Writer.XmlFilterAdaptor,524355,com.sun.star.documentconversion.XFlatXml; ;com.sun.star.comp.Writer.XMLImporter;com.sun.star.comp.Writer.XMLExporter,0,,"));
        
        filterNode.appendChild(installedNode);
        filterNode.appendChild(uinameNode);
        filterNode.appendChild(dataNode);
        n.appendChild(filterNode);
        
        // PocketWord Filter
        createFilter();
        filterNode.setAttribute("cfg:name","PocketWord File ");
        cfgvalueNode.appendChild( document.createTextNode("PocketWord File"));
        cfgvalueNode.setAttribute("xml:lang","en-US");
        dataNode.appendChild( document.createTextNode("0,writer_PocketWord_File,com.sun.star.text.TextDocument,com.sun.star.comp.Writer.XmlFilterAdaptor,524355,com.sun.star.documentconversion.XMergeBridge;classes/pocketword.jar;com.sun.star.comp.Writer.XMLImporter;com.sun.star.comp.Writer.XMLExporter;staroffice/sxw;application/x-pocket-word,0,,"));
        
        filterNode.appendChild(installedNode);
        filterNode.appendChild(uinameNode);
        filterNode.appendChild(dataNode);
        n.appendChild(filterNode);

	/*
	// WordSmith Filter
        createFilter();
        filterNode.setAttribute("cfg:name","WordSmith PalmDB File");
        cfgvalueNode.appendChild( document.createTextNode("WordSmith PalmDB File"));
        cfgvalueNode.setAttribute("xml:lang","en-US");
        dataNode.appendChild( document.createTextNode("0,writer_WordSmith_PalmDB_File,com.sun.star.text.TextDocument,com.sun.star.comp.Writer.XmlFilterAdaptor,524355,com.sun.star.documentconversion.XMergeBridge;classes/wordsmith.jar;com.sun.star.comp.Writer.XMLImporter;com.sun.star.comp.Writer.XMLExporter;staroffice/sxw;application/x-wordsmith,0,,"));
        
        filterNode.appendChild(installedNode);
        filterNode.appendChild(uinameNode);
        filterNode.appendChild(dataNode);
        n.appendChild(filterNode);
        */
        // PocketExcel Filter
        createFilter();
        filterNode.setAttribute("cfg:name"," Pocket Excel");
        cfgvalueNode.appendChild( document.createTextNode("Pocket Excel"));
        cfgvalueNode.setAttribute("xml:lang","en-US");
        dataNode.appendChild( document.createTextNode("0,calc_Pocket_Excel_File,com.sun.star.sheet.SpreadsheetDocument,com.sun.star.comp.Writer.XmlFilterAdaptor,524355,com.sun.star.documentconversion.XMergeBridge;classes/pexcel.jar;com.sun.star.comp.Calc.XMLImporter;com.sun.star.comp.Calc.XMLExporter;staroffice/sxc;application/x-pocket-excel,1,,"));
        
        filterNode.appendChild(installedNode);
        filterNode.appendChild(uinameNode);
        filterNode.appendChild(dataNode);
        n.appendChild(filterNode);

	
	// Minicalc
	createFilter();
        filterNode.setAttribute("cfg:name","MiniCalc");
        cfgvalueNode.appendChild( document.createTextNode("MiniCalc"));
        cfgvalueNode.setAttribute("xml:lang","en-US");
        dataNode.appendChild( document.createTextNode("0,calc_MiniCalc_PalmDB_File,com.sun.star.sheet.SpreadsheetDocument,com.sun.star.comp.Writer.XmlFilterAdaptor,524355,com.sun.star.documentconversion.XMergeBridge;classes/minicalc.jar;com.sun.star.comp.Calc.XMLImporter;com.sun.star.comp.Calc.XMLExporter;staroffice/sxc;application/x-minicalc,1,,"));
        
        filterNode.appendChild(installedNode);
        filterNode.appendChild(uinameNode);
        filterNode.appendChild(dataNode);
        n.appendChild(filterNode);


	
        
        // XHTML  Filter
        createFilter();
        filterNode.setAttribute("cfg:name","XHTML File");
        cfgvalueNode.appendChild( document.createTextNode("XHTML File"));
        cfgvalueNode.setAttribute("xml:lang","en-US");
        dataNode.appendChild( document.createTextNode("0,writer_XHTML_File,com.sun.star.text.TextDocument,com.sun.star.comp.Writer.XmlFilterAdaptor,524355,com.sun.star.documentconversion.XMergeBridge;classes/htmlsoff.jar;com.sun.star.comp.Writer.XMLImporter;com.sun.star.comp.Writer.XMLExporter;staroffice/sxw;text/html,0,,"));
        
        filterNode.appendChild(installedNode);
        filterNode.appendChild(uinameNode);
        filterNode.appendChild(dataNode);
        n.appendChild(filterNode);

	 // docbook  Filter
        createFilter();
        filterNode.setAttribute("cfg:name","DocBook File");
        cfgvalueNode.appendChild( document.createTextNode("DocBook File"));
        cfgvalueNode.setAttribute("xml:lang","en-US");
        dataNode.appendChild( document.createTextNode("0,writer_DocBook_File,com.sun.star.text.TextDocument,com.sun.star.comp.Writer.XmlFilterAdaptor,524355,com.sun.star.documentconversion.XMergeBridge;classes/docbook.jar;com.sun.star.comp.Writer.XMLImporter;com.sun.star.comp.Writer.XMLExporter;staroffice/sxw;application/x-docbook,0,,"));
        
        filterNode.appendChild(installedNode);
        filterNode.appendChild(uinameNode);
        filterNode.appendChild(dataNode);
        n.appendChild(filterNode);
        
        
        // calc Flat Xml Filter
        createFilter();
        filterNode.setAttribute("cfg:name","Calc Flat Xml File");
        cfgvalueNode.appendChild( document.createTextNode("Calc Flat Xml File"));
        cfgvalueNode.setAttribute("xml:lang","en-US");
        dataNode.appendChild( document.createTextNode("0,calc_Flat_XML_File,com.sun.star.sheet.SpreadsheetDocument,com.sun.star.comp.Writer.XmlFilterAdaptor,524355,com.sun.star.documentconversion.XFlatXml; ;com.sun.star.comp.Calc.XMLImporter;com.sun.star.comp.Calc.XMLExporter,0,,"));
        
        filterNode.appendChild(installedNode);
        filterNode.appendChild(uinameNode);
        filterNode.appendChild(dataNode);
        n.appendChild(filterNode);
        
        
        
        // impress Flat Xml Filter
        createFilter();
        filterNode.setAttribute("cfg:name","Impress Flat Xml File");
        cfgvalueNode.appendChild( document.createTextNode("Impress Flat Xml File"));
        cfgvalueNode.setAttribute("xml:lang","en-US");
        dataNode.appendChild( document.createTextNode("0,impress_Flat_XML_File,com.sun.star.presentation.PresentationDocument,com.sun.star.comp.Writer.XmlFilterAdaptor,524355,com.sun.star.documentconversion.XFlatXml; ;com.sun.star.comp.Impress.XMLImporter;com.sun.star.comp.Impress.XMLExporter,0,,"));
        
        filterNode.appendChild(installedNode);
        filterNode.appendChild(uinameNode);
        filterNode.appendChild(dataNode);
        n.appendChild(filterNode);
    }
    
    
    private void addTypes(Node n) {
        //AportisDoc Filter
        createType();
        typeNode.setAttribute("cfg:name","writer_AportisDoc_PalmDB_File");
        dataNode.appendChild( document.createTextNode("1,,,,pdb,20002,"));
        cfgvalueNode.appendChild( document.createTextNode("AportisDoc Palm DB"));
        typeNode.appendChild(uinameNode);
        typeNode.appendChild(dataNode);
        
        uinameNode.appendChild(cfgvalueNode);
        n.appendChild(typeNode);
        document.importNode(n,true);
/*
	//WordSmith Filter
        createType();
        typeNode.setAttribute("cfg:name","writer_WordSmith_PalmDB_File");
        dataNode.appendChild( document.createTextNode("1,,,,pdb,20002,"));
        cfgvalueNode.appendChild( document.createTextNode("WordSmith Palm DB"));
        typeNode.appendChild(uinameNode);
        typeNode.appendChild(dataNode);
        
        uinameNode.appendChild(cfgvalueNode);
        n.appendChild(typeNode);
        document.importNode(n,true);
*/	
        
        // XHTML File
        createType();
        typeNode.setAttribute("cfg:name","writer_XHTML_File");
        dataNode.appendChild( document.createTextNode("0,,,,xhtml,20002,"));
        cfgvalueNode.appendChild( document.createTextNode("XHTML File"));
        typeNode.appendChild(uinameNode);
        typeNode.appendChild(dataNode);
        uinameNode.appendChild(cfgvalueNode);
        n.appendChild(typeNode);
        
	//DocBook File
	 createType();
        typeNode.setAttribute("cfg:name","writer_DocBook_File");
        dataNode.appendChild( document.createTextNode("1,,,,xml,20002,"));
        cfgvalueNode.appendChild( document.createTextNode("DocBook File"));
        typeNode.appendChild(uinameNode);
        typeNode.appendChild(dataNode);
        uinameNode.appendChild(cfgvalueNode);
        n.appendChild(typeNode);
        	

        // Pcoketword File
        createType();
        typeNode.setAttribute("cfg:name","writer_PocketWord_File");
        dataNode.appendChild( document.createTextNode("0,,,,psw,20002,"));
        cfgvalueNode.appendChild( document.createTextNode("PocketWord File"));
        typeNode.appendChild(uinameNode);
        typeNode.appendChild(dataNode);
        uinameNode.appendChild(cfgvalueNode);
        n.appendChild(typeNode);
        
        // Pocket Excel File
        createType();
        typeNode.setAttribute("cfg:name","calc_Pocket_Excel_File");
        dataNode.appendChild( document.createTextNode("0,,,,pxl,20002,"));
        cfgvalueNode.appendChild( document.createTextNode("Pocket Excel"));
        typeNode.appendChild(uinameNode);
        typeNode.appendChild(dataNode);
        uinameNode.appendChild(cfgvalueNode);
        n.appendChild(typeNode);

        
        // Flat xml writer File
        createType();
        typeNode.setAttribute("cfg:name","writer_Flat_XML_File");
        dataNode.appendChild( document.createTextNode("0,,,,wxml,20002,"));
        cfgvalueNode.appendChild( document.createTextNode("Writer Flat Xml"));
        typeNode.appendChild(uinameNode);
        typeNode.appendChild(dataNode);
        uinameNode.appendChild(cfgvalueNode);
        n.appendChild(typeNode);
        // Flat xml calc File
        createType();
        typeNode.setAttribute("cfg:name","calc_Flat_XML_File");
        dataNode.appendChild( document.createTextNode("0,,,,cxml,20002,"));
        cfgvalueNode.appendChild( document.createTextNode("Calc Flat Xml"));
        typeNode.appendChild(uinameNode);
        typeNode.appendChild(dataNode);
        uinameNode.appendChild(cfgvalueNode);
        n.appendChild(typeNode);
        // Flat xml calc File
        createType();
        typeNode.setAttribute("cfg:name","impress_Flat_XML_File");
        dataNode.appendChild( document.createTextNode("0,,,,ixml,20002,"));
        cfgvalueNode.appendChild( document.createTextNode("Impress Flat Xml"));
        typeNode.appendChild(uinameNode);
        typeNode.appendChild(dataNode);
        uinameNode.appendChild(cfgvalueNode);
        n.appendChild(typeNode);
    }
    
    private byte[] docToBytes(Document doc) throws IOException {
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        
        java.lang.reflect.Constructor con;
        java.lang.reflect.Method meth;
        
        String domImpl = doc.getClass().getName();
        
        /*
         * We may have multiple XML parsers in the Classpath.
         * Depending on which one is first, the actual type of
         * doc may vary.  Need a way to find out which API is being
         * used and use an appropriate serialization method.
         */
        try {
            // First of all try for JAXP 1.0
            if (domImpl.equals("com.sun.xml.tree.XmlDocument")) {
                //System.out.println("Using JAXP");
                Class jaxpDoc = Class.forName("com.sun.xml.tree.XmlDocument");
                
                // The method is in the XMLDocument class itself, not a helper
                meth = jaxpDoc.getMethod("write",
                new Class[] { Class.forName("java.io.OutputStream") } );
                
                meth.invoke(doc, new Object [] { baos } );
            } else if (domImpl.equals("org.apache.crimson.tree.XmlDocument")) {
                //System.out.println("Using Crimson");
                Class crimsonDoc = Class.forName("org.apache.crimson.tree.XmlDocument");
                // The method is in the XMLDocument class itself, not a helper
                meth = crimsonDoc.getMethod("write",
                new Class[] { Class.forName("java.io.OutputStream") } );
                
                meth.invoke(doc, new Object [] { baos } );
            } else if (domImpl.equals("org.apache.xerces.dom.DocumentImpl")
                    || domImpl.equals("org.apache.xerces.dom.DeferredDocumentImpl")) {
                //System.out.println("Using Xerces");
                // Try for Xerces
                Class xercesSer =
                Class.forName("org.apache.xml.serialize.XMLSerializer");
                
                // Get the OutputStream constructor
                // May want to use the OutputFormat parameter at some stage too
                con = xercesSer.getConstructor(new Class [] {
                    Class.forName("java.io.OutputStream"),
                    Class.forName("org.apache.xml.serialize.OutputFormat") } );
                    
                    
                    // Get the serialize method
                    meth = xercesSer.getMethod("serialize",
                    new Class [] { Class.forName("org.w3c.dom.Document") } );
                    
                    
                    // Get an instance
                    Object serializer = con.newInstance(new Object [] { baos, null } );
                    
                    
                    // Now call serialize to write the document
                    meth.invoke(serializer, new Object [] { doc } );
            }
            else {
                // We don't have another parser
                throw new IOException("No appropriate API (JAXP/Xerces) to serialize XML document: " + domImpl);
                
            }
        } catch (ClassNotFoundException cnfe) {
            throw new IOException(cnfe.toString());
        } catch (Exception e) {
            // We may get some other errors, but the bottom line is that
            // the steps being executed no longer work
            throw new IOException(e.toString());
        }
        
        byte bytes[] = baos.toByteArray();
        
        return bytes;
    }

	public void addInstallListener(InstallListener listener)
	{
		listeners.addElement(listener);
	}

	private void onInstallComplete()
	{
		Enumeration e = listeners.elements();
		while (e.hasMoreElements())
		{
			InstallListener listener = (InstallListener)e.nextElement();
			listener.installationComplete(null);
		}
	}    
}

