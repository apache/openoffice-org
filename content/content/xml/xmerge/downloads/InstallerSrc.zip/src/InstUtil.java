import java.io.*;
import java.util.*;
import java.util.zip.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.*;

public class InstUtil {
    public static boolean createTmpDir() {
        String sysTemp = System.getProperty("java.io.tmpdir");
        if (tmpDir == null) {
            tmpDir = new File(sysTemp + File.separator + "xmergeinst");
            if (tmpDir.exists())
                return true;
        }
        
        return tmpDir.mkdir();
    }
    
    public static File getTmpDir() {
        return tmpDir;
    }
    
    public static void removeTmpDir() {
        if ((tmpDir != null) && (tmpDir.exists())) {
            File types = new File(tmpDir, "TypeDetection.xml");
            if (types.exists()) 
			{
				if (types.delete())
				{
					//System.out.println("Success:type");;
				}
			}
            File java = new File(tmpDir, "Java.xml");
            if (java.exists()) java.delete();
            File rdb = new File(tmpDir, "applicat.rdb");
            if (rdb.exists()) rdb.delete();
            tmpDir.delete();
            tmpDir = null;
        }
    }
    
    public static boolean copy(File inputFile, File outputFile) {
        try {
            FileInputStream in = new FileInputStream(inputFile);
            FileOutputStream out = new FileOutputStream(outputFile);
			byte buffer[] = new byte[4096];
            int c;
            
            while ((c = in.read(buffer)) != -1) {
                //out.write(buffer, 0, c);
				out.write(buffer, 0, c);
			}
            
            in.close();
            out.close();
        } catch (IOException eIO) {
            return false;
        }
        
        return true;
    }
    
    public static File buildSversionLocation() throws IOException {
		File theFile = null;
        StringBuffer str = new StringBuffer();
        String sep = System.getProperty("file.separator");
        str.append(System.getProperty("user.home"));
        str.append(sep);
		StringBuffer thePath = new StringBuffer(str.toString());
        
        String os = System.getProperty("os.name");
        
		if (os.indexOf("Windows") != -1) {
			/*String appData = winGetAppData;
			if (os.equals("Windows 2000")) {
				thePath.append("Application Data");
				thePath.append(sep);
				theFile = new File(thePath.toString());
			} else if (os.indexOf("Windows") != -1) {
				thePath.append(sep);
				thePath.append("sversion.ini");
				theFile = new File(thePath.toString());
				if (!theFile.exists())
				{
					thePath.delete(0, thePath.length());
					thePath.append(str);
					thePath.append("Application Data");
					thePath.append(sep);
					thePath.append("sversion.ini");
					theFile = new File(thePath.toString());
				}
			}*/
			theFile = findVersionFile(new File(str.toString()));
        } else if (os.indexOf("SunOS") != -1) {
            thePath.append(".sversionrc");
			theFile = new File(thePath.toString());
        } else if (os.indexOf("Linux") != -1) {
            thePath.append(".sversionrc");
			theFile = new File(thePath.toString());
		}
        
		if (theFile == null) 
		{
			throw new IOException("Could not locate the OpenOffice settings file.\nAre you sure StarOffice is installed on your system?");
		}
		if  (!theFile.exists()) 
		{
			throw new IOException("Could not locate the OpenOffice settings file.\nAre you sure StarOffice is installed on your system?");
		}
        return theFile;
    }

	public static File findVersionFile(File start)
	{
		File versionFile = null;

		File files[] = start.listFiles(new VersionFilter());
		if (files.length == 0)
		{
			File dirs[] = start.listFiles(new DirFilter());
			for (int i=0; i< dirs.length; i++)
			{
				versionFile = findVersionFile(dirs[i]);
				if (versionFile != null)
				{
					break;
				}
			}
		}
		else
		{
			versionFile = files[0];
		}

		return versionFile;
	}	
    
    public static boolean verifySversionExists(File sversionFile) {
        if (!sversionFile.exists())
            return false;
        return true;
    }
    
    public static Properties getOfficeVersions(File sversionFile) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(sversionFile));
        Vector values;
        String sectionName = null;
        Properties results = new Properties();
        
        for (String s = reader.readLine(); s != null; s = reader.readLine()) {
            s.trim();
            //System.out.println(s);
            if (s.length() == 0)
                continue;
            if (s.charAt(0) == '[') {
                sectionName = s.substring(1, s.length() - 1);
                //System.out.println(sectionName);
                continue;
            }
            if ((sectionName != null) && sectionName.equalsIgnoreCase("Versions")) {
                String [] parts = s.split("=");
                if (parts.length == 2) {
                    //ver.version = parts[0].trim();
                    try {
                        URI uri = new URI(parts[1].trim());
                        File f = new File(uri);
                        results.put(parts[0].trim(), f.getPath());
                        //System.out.println("Putting " + parts[0] + " : " + f.getPath());
                    }
                    catch (URISyntaxException eSyntax) {
                        //throw new IOException("Error while reading version information");
						results.put(parts[0].trim(), parts[1].trim());
						//System.out.println(parts[0].trim() + " : " + parts[1].trim());
                    }
                    catch (IllegalArgumentException eArg) {
						results.put(parts[0].trim(), parts[1].trim());
						//System.out.println(parts[0].trim() + ": " + parts[1].trim());
					}
                }
                else {
                    //System.out.println("not splitting on equals");
                }
            }
        }
        
        return results;
    }
    
    public static String getJavaVersion() {
        return System.getProperty("java.version");
    }
    
    public static boolean isCorrectJavaVersion() {
        if (System.getProperty("java.version").startsWith("1.4"))
            return true;
        return false;
    }
    
    public static void main(String args[]) {
        InstUtil inst = new InstUtil();
		File f = null;
        try
		{
			f = inst.buildSversionLocation();
		}
		catch (IOException e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
        if (!inst.verifySversionExists(f)) {
            System.err.println("Problem with sversion.ini");
        }
        try {
            Properties vers = inst.getOfficeVersions(f);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println(e);
        }
        System.out.println(inst.getJavaVersion());
        if (!inst.isCorrectJavaVersion()) {
            System.err.println("Not correct Java Version");
        }
    }
    
    private static File tmpDir = null;
}



class DirFilter implements java.io.FileFilter
{
	public boolean accept(File aFile)
	{
		return aFile.isDirectory();
	}
}
class VersionFilter implements java.io.FileFilter
{
	public boolean accept(File aFile)
	{
		if (aFile.getName().compareToIgnoreCase("sversion.ini") == 0)
		{
			return true;
		}

		return false;
	}
}
