import java.lang.String;
import java.io.*;


public class install{
    

     private static void unx(String url,String path){
	 System.out.println("\nFound a Unix path:"+path);
	 System.out.println("\nThis Script does not support Unix");
	
     }

    private static void windows(String url,String path){
	try{
	    String s=null;
	    String classpath="";
	    int exitcode=0;
	    boolean passed=true;
	    Process p=Runtime.getRuntime().exec("cmd /c dir/b \""+path+"\\program\\classes\\*.jar\"");
	     
	     BufferedReader stdInput=new BufferedReader(new InputStreamReader(p.getInputStream()));
	     while((s=stdInput.readLine())!=null){
		 classpath=classpath.concat("\""+path+"\\program\\classes\\"+s+"\";");
	     }
	     System.out.println("Classpath = "+ classpath);
	    
	     p=Runtime.getRuntime().exec("cmd /c regmerge applicat.rdb /UCR XImportFilter.urd XExportFilter.urd ImportFilter.urd ExportFilter.urd");

	     exitcode=p.waitFor();   

	     System.out.println("\n\ncmd /c regcomp -register -br \""+path+"\\program\\applicat.rdb\" -r \""+path+"\\program\\applicat.rdb\" -c \""+url+"/program/classes/XMergeBridge.jar\"");
	     p=Runtime.getRuntime().exec("cmd /c regcomp -register -br \""+path+"\\program\\applicat.rdb\" -r \""+path+"\\program\\applicat.rdb\" -c \""+url+"/program/classes/XMergeBridge.jar\"");

	     exitcode=p.waitFor();
	     if (exitcode !=0){
		System.out.println("\n Registration Failed!");
		passed=false;
	     }
	     System.out.println("\n\ncmd /c regcomp -register -br \""+path+"\\program\\applicat.rdb\" -r \""+path+"\\program\\applicat.rdb\" -c \""+url+"/program/classes/XFlatXml.jar\"");
	     p=Runtime.getRuntime().exec("cmd /c regcomp -register -br \""+path+"\\program\\applicat.rdb\" -r \""+path+"\\program\\applicat.rdb\" -c \""+url+"/program/classes/XFlatXml.jar\"");
	       
	     exitcode=p.waitFor();
	     if (exitcode !=0){
		System.out.println("\n Registration Failed!");
		passed=false;
	     }
	           System.out.println("\n\ncmd /c regcomp -register -br \""+path+"\\program\\applicat.rdb\" -r \""+path+"\\program\\applicat.rdb\" -c \""+url+"/program/xmlfa642mi.dll\"");
	      p=Runtime.getRuntime().exec("cmd /c regcomp -register -br \""+path+"\\program\\applicat.rdb\" -r \""+path+"\\program\\applicat.rdb\" -c \""+url+"/program/xmlfa642mi.dll\"");
	      exitcode=p.waitFor();
	     if (exitcode !=0){
		System.out.println("\n Registration Failed!");
		passed=false;
	     }
	     
	     System.out.println("\nRemoving temporary files\n");
	      p=Runtime.getRuntime().exec("cmd /c rmdir /q /s org ");
	      exitcode=p.waitFor();
	     p=Runtime.getRuntime().exec("cmd /c rmdir /q /s com ");
	     exitcode=p.waitFor();
	     p=Runtime.getRuntime().exec("cmd /c del /q *.urd ");
	     exitcode=p.waitFor();
	     p=Runtime.getRuntime().exec("cmd /c del /q juh.dll ");
	     exitcode=p.waitFor();
	     p=Runtime.getRuntime().exec("cmd /c del /q reg*.exe ");
	     exitcode=p.waitFor();
	     if (!passed){
		 System.out.println("\nTemporary files Removed\n");
		 
		 System.out.println("\n cmd /c copy \""+path+"\\share\\config\\registry\\instance\\org\\openoffice\\Office\\TypeDetection.xml\" \""+path+"\\share\\config\\registry\\instance\\org\\openoffice\\Office\\TypeDetection.bck\"");
		 p=Runtime.getRuntime().exec("cmd /c copy \""+path+"\\share\\config\\registry\\instance\\org\\openoffice\\Office\\TypeDetection.xml\" \""+path+"\\share\\config\\registry\\instance\\org\\openoffice\\Office\\TypeDetection.bck\"");
		 exitcode=p.waitFor();
		 p=Runtime.getRuntime().exec("cmd /c type \""+path+"\\share\\config\\registry\\instance\\org\\openoffice\\Office\\TypeDetection.bck\" > \""+path+"\\share\\config\\registry\\instance\\org\\openoffice\\Office\\TypeDetection.xml\"");
		 exitcode=p.waitFor();
		 if (exitcode !=0){
		     System.out.println("\n TimeStamp update Failed!");
		 }
	     }
	   
	
	     }
	catch(Exception e){
	    System.out.println("Error:"+e);
	}
    }

    
 

    public static void main(String args[]){
	boolean win =false;
	if (args.length==0){
	    System.out.println("Usage:\n\t java -classpath . \"c:\\<install-dir>\\\"\n");
	}
	else{    
	    String path=args[0];
	    String newString= "file://";
	    if (args[0].indexOf(":")==1){
		newString=newString.concat("/");
		win=true;
	    }
	    String tmpStr1="";
	    String tmpStr2="";
	    newString=newString.concat(args[0].replace('\\','/'));
	    int i=0;
	    if (newString.indexOf(" ")>0){
		tmpStr1=tmpStr1.concat(newString.substring(i,newString.indexOf(" ")));
		tmpStr1=tmpStr1.concat("\\ ");
		newString=newString.substring(newString.indexOf(" ")+1,newString.length()); 
	       
	    }
	    tmpStr1=tmpStr1.concat(newString);
            System.out.println(""+tmpStr1);
	    char url[]=args[0].toCharArray();
	    char test[]=new char[args[0].length()*2];
	    int j=0;
	    if (win){
		 path = path.substring (0,path.length()-1);
		windows(tmpStr1,path);
	    }
	    else{
		unx(tmpStr1,path);
	    }
	}
    }

}


