#!/bin/ksh
if (($# == 0)) then
	print "\nUsage:\n \t./setup.sh -path <Path to Office installation directory>\n"

	print "\nEg:\n \t./setup.sh -path /export/home/staroffice6.1/\n"
    exit 1
fi

if [[ $1 != "-path" || $2 == "" ]]
then
    print "You must supply -path"
    exit 1
else
    OFFICE_PATH=$2
fi


print "\n## Copying Library Files to $OFFICE_PATH/program  ##\n"
echo cp ./libFlatXml.so $OFFICE_PATH/program
cp ./libFlatXml.so $OFFICE_PATH/program
echo cp ./libxmlfa643ss.so $OFFICE_PATH/program
cp ./libxmlfa643ss.so $OFFICE_PATH/program

print "\n## Copying Jar Files to $OFFICE_PATH/program/classes  ##\n"
echo cp ./XMergeBridge.jar $OFFICE_PATH/program/classes
cp ./XMergeBridge.jar $OFFICE_PATH/program/classes
echo cp ./aportisdoc.jar $OFFICE_PATH/program/classes    
cp ./aportisdoc.jar $OFFICE_PATH/program/classes  
echo cp ./pexcel.jar     $OFFICE_PATH/program/classes 
cp ./pexcel.jar     $OFFICE_PATH/program/classes   
echo cp ./htmlsoff.jar   $OFFICE_PATH/program/classes  
cp ./htmlsoff.jar   $OFFICE_PATH/program/classes
echo cp ./pocketword.jar $OFFICE_PATH/program/classes   
cp ./pocketword.jar $OFFICE_PATH/program/classes 
echo cp ./xmerge.jar $OFFICE_PATH/program/classes
cp ./xmerge.jar $OFFICE_PATH/program/classes
echo cp ./XFlatXml.jar $OFFICE_PATH/program/classes  
cp ./XFlatXml.jar $OFFICE_PATH/program/classes      
    

for file in $(ls $OFFICE_PATH/program/classes/*.jar)
do
    print "\n Adding $file to classpath"
    export CLASSPATH=$file:$CLASSPATH
done

echo $CLASSPATH
java -version

print "\n## Registering Components ##\n"
export LD_LIBRARY_PATH=$OFFICE_PATH/program/:$LD_LIBRARY_PATH
print "\n## Merging InterFace Definitions ##\n"
    regmerge $OFFICE_PATH/program/applicat.rdb /UCR XImportFilter.urd XExportFilter.urd ImportFilter.urd ExportFilter.urd

print "\n## Registering Components ##\n"
 print "\n regcomp -register -br $OFFICE_PATH/program/applicat.rdb -r $OFFICE_PATH/program/applicat.rdb -c \"file://$OFFICE_PATH/program/libFlatXml.so;file://$OFFICE_PATH/program/libxmlfa643ss.so\" \n"

    regcomp -register -br $OFFICE_PATH/program/applicat.rdb -r $OFFICE_PATH/program/applicat.rdb -c "file://$OFFICE_PATH/program/libFlatXml.so;file://$OFFICE_PATH/program/libxmlfa643ss.so"
   print "\n regcomp -register -br $OFFICE_PATH/program/applicat.rdb -r $OFFICE_PATH/program/applicat.rdb -c \"file://$OFFICE_PATH/program/classes/XMergeBridge.jar\" \n"
    #regcomp -register -br $OFFICE_PATH/program/applicat.rdb -r $OFFICE_PATH/program/applicat.rdb -c "file://$OFFICE_PATH/program/libFlatXml.so;file://$OFFICE_PATH/program/classes/XMergeBridge.jar" -l com.sun.star.loader.Java2 
    
    print " java com.sun.star.tools.uno.RegComp \"file://$OFFICE_PATH/program//applicat.rdb\" register \"file://$OFFICE_PATH/program//classes/XMergeBridge.jar\" com.sun.star.loader.Java2"

    java com.sun.star.tools.uno.RegComp "file://$OFFICE_PATH/program//applicat.rdb" register "file://$OFFICE_PATH/program//classes/XMergeBridge.jar" com.sun.star.loader.Java2


print "\n##Updating applicat.rdb time stamp##\n"

echo touch  $OFFICE_PATH/program/applicat.rdb
touch  $OFFICE_PATH/program/applicat.rdb


print "\n##Replacing TypeDetection.xml File ##\n"
echo cp $OFFICE_PATH/share/config/registry/instance/org/openoffice/Office/TypeDetection.xml $OFFICE_PATH/share/config/registry/instance/org/openoffice/Office/TypeDetection.xml.$(date '+%H%M%S')
cp $OFFICE_PATH/share/config/registry/instance/org/openoffice/Office/TypeDetection.xml $OFFICE_PATH/share/config/registry/instance/org/openoffice/Office/TypeDetection.xml.$(date '+%H%M%S')
echo ./TypeDetection.xml $OFFICE_PATH/share/config/registry/instance/org/openoffice/Office/TypeDetection.xml
cp ./TypeDetection.xml $OFFICE_PATH/share/config/registry/instance/org/openoffice/Office/TypeDetection.xml

print "##Updating User Classpaths##"
mv $OFFICE_PATH/user/config/registry/instance/org/openoffice/Office/Java.xml $OFFICE_PATH/user/config/registry/instance/org/openoffice/Office/Java.xml.$(date '+%H%M%S')
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<Java state=\"modified\" cfg:package=\"org.openoffice.Office\" xmlns=\"http://openoffice.org/2000/registry/components/Java\" xmlns:cfg=\"http://openoffice.org/2000/registry/instance\" xmlns:xsi=\"http://www.w3.org/1999/XMLSchema-instance\">
 <VirtualMachine>
  <NetAccess cfg:type=\"int\">0</NetAccess>
  <UserClassPath cfg:type=\"string\">$OFFICE_PATH/program/classes/aportisdoc.jar:$OFFICE_PATH/program/classes/htmlsoff.jar:$OFFICE_PATH/program/classes/pexcel.jar:$OFFICE_PATH/program/classes/pocketword.jar:$OFFICE_PATH/program/classes/XFlatXml.jar:$OFFICE_PATH/program/classes/XMergeBridge.jar:$OFFICE_PATH/program/classes/xmerge.jar</UserClassPath>
 </VirtualMachine>
</Java>" > $OFFICE_PATH/user/config/registry/instance/org/openoffice/Office/Java.xml




print "\n## Update Complete ##\n"


