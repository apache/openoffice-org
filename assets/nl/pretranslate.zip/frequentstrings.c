//----------------------------------------------------------------------
// frequentstrings.c
//
// this program takes the file "onlystrings.txt", which contains all the
// translatable strings from t9n.txt, and determines the frequency of 
// words and word sequences in it. If a word sequence occurs as a substring
// of a single larger word sequence only, only the larger word sequence
// is listed. 
//
// The output from this program may be used to pre-translate the most 
// frequent words and word sequences, which could much speed up 
// translation of OpenOffice.org/Star Office help files into another 
// language. 
//
// (c) 2002 S. Brouwer (simonbr@openoffice.org)
// You are welcome to use, distribute, modify etc. this software
// provided that this copyright message is preserved in it and you 
// give due credit to its author. 
//----------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include <process.h>
#include <stdlib.h>
#include <ctype.h>

unsigned char iswordchartab[]={		// all isgraphic() characters, except
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,	// the characters !,.:;?
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, 
0,0,1,1,1,1,1,1,1,1,1,1,0,1,0,1,
1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,0,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
};

#define iswordchar(c) (iswordchartab[c])


#define MAXNUMBEROFSTRINGS 69871	// this is the actual number of translatable strings in t9n.txt
#define BUFSIZE 0x10000	// 


typedef struct 
{
	char *string;			// pointer to "translatable" string from t9n.txt
	unsigned int word_count;// number of words in it
} instring_t;


typedef struct
{
	char *string;			// pointer to word sequence
	unsigned int count;		// number of times it occurs in the input file
	void *next;
	void *next_in_order;
} wordseq_t;


void frequentstrings (unsigned int n);
int justasubstring(char *string, unsigned int count);
void outputstrings (unsigned int n); 
void calcnumberofwords (void);
int hash (const char *word);
void *myalloc (unsigned int size);
void cleanup (void);
void clonelist (wordseq_t *sourcep, wordseq_t **targetpp);
void hashsubstrings(void);


FILE *infile, *infile2, *outfile;

int line, pos; 

char buf[BUFSIZE];
char infilepath[1024]; 
char outfilepath[1024]; 


wordseq_t *hashtable[256];

wordseq_t *ordered_start;		// list of the word sequences in order of new word found
wordseq_t *prev_ordered_start_heads;	// list of substrings with n words of the n+1 words word sequences
wordseq_t *prev_ordered_start_tails;	// list of substrings with n words of the n+1 words word sequences


instring_t allstrings[MAXNUMBEROFSTRINGS];	// all translatable strings

unsigned int numentries;	// stat variable to keep track of unique words/sequences

unsigned int heapused;	// stat variable to keep track of memory use

unsigned int maxwordsinstring;	// maximum number of words in any string

unsigned int numberofstrings;


void
main (int argc, char *argv[])
{
	unsigned int i, x;

	numberofstrings=0;

	heapused=0;
	numentries=0;

	if ((infile = fopen("onlystrings.out", "rt"))== NULL)
	{
		printf("Error: Cannot open input file onlystrings.out\n");
		exit (1);
	} // the file onlystrings.out contains only the translatable strings
	  // from t9n.txt

	if ((outfile = fopen("frequentstrings.out", "wt"))== NULL)
	{
		printf("Error: Cannot open output file frequentstrings.out\n");
		exit (1);
	}
	
	puts ("reading input file");

	x=0;
	for (;;)	// read in all the t9n strings
	{
		if (fgets (buf, BUFSIZE, infile)==NULL)
			break;
		numberofstrings++;
		if (numberofstrings>MAXNUMBEROFSTRINGS)
		{
			puts ("ERROR: more strings in input file than expected");
			exit (1);
		}
		allstrings[x].string=myalloc (strlen (buf)+1);
		heapused+=strlen (buf)+1;
		strcpy (allstrings[x++].string, buf);
	}

	puts ("calculating number of words in input strings");
	calcnumberofwords();
	
	for (i=83; i>0; i--) // the non-unique string with most words has 83 of them.
	{
		fprintf (outfile, "\n\n#### strings with %i words: \n", i);
		printf ("\n\nchecking sequences of %i words", i);
		frequentstrings (i);
		hashsubstrings();
		outputstrings (i);
			printf ("\nheap used %i kB; cleaning up", heapused>>10);		
		cleanup();
		printf (": heap used %i kB\n", heapused>>10);		
		prev_ordered_start_heads=ordered_start;
		ordered_start=NULL;
		clonelist (prev_ordered_start_heads, &prev_ordered_start_tails);
	}
	fclose(infile);
	fclose(outfile);
	exit (0);
}

// this function calculates the number of words in all the strings from input file
void
calcnumberofwords (void)
{
	unsigned char *cp;
	unsigned int i;
	
	maxwordsinstring=0;

	for (i=0;i<numberofstrings;i++)
	{
		allstrings[i].word_count=0;
		cp=allstrings[i].string;
		for (;;)
		{	
			if (*cp=='\0')
				break;
			if (!iswordchar(*cp))
			{
				cp++;
				continue;
			}
			while (iswordchar(*cp))
			{
				cp++;
			}
			allstrings[i].word_count++;
		}
		if (maxwordsinstring<allstrings[i].word_count)
			maxwordsinstring=allstrings[i].word_count;
	}
	printf ("maximum number of words in any string= %i\n", maxwordsinstring);
}


// this function gets all the sequences of n words from the input file strings, 
// stores them into a dictionary and and counts how many times they occur. 
void
frequentstrings (unsigned int n)
{
	unsigned char *cp, *cp2;
	unsigned char *next_start;
	unsigned int i, j, k;
	unsigned int hashvalue;
	unsigned int progress;

	wordseq_t **spp;		// keeps track of pointers in hash lists
	wordseq_t **ospp;		// keeps track of pointers in ordered lists

	ordered_start=NULL;
	ospp=&ordered_start;

	for (i=0; i<256; i++)
		hashtable[i]=NULL;



	for (i=0;i<numberofstrings;i++)	// each input file string
	{
		if (allstrings[i].word_count<n)
			continue;

		if (progress++>50)
		{
			printf(".");
			progress=0;
		}

		next_start=allstrings[i].string;

		for (j=0;j<(allstrings[i].word_count-n+1);j++)
		{
			cp=next_start;
			while (!iswordchar(*cp))
			{
				if (*cp++=='\0')
				{
					puts ("ERROR: unexpected end of string");
					exit (1);
				}
			}
			cp2=buf;
			while (iswordchar(*cp))	// get the first word of new sequence
			{
				*cp2++=*cp++;
			}
			next_start=cp;			// point next_start to the end of it

			for (k=0;k<n-1;k++)		// get the rest of the sequence
			{
				while (!iswordchar(*cp))
				{
					if (*cp=='\0')
					{
						puts ("ERROR: unexpected end of string");
						exit (1);
					}
					*cp2++=*cp++;
				}
				while (iswordchar(*cp))
				{
					*cp2++=*cp++;
				}
			}
			*cp2='\0';

			hashvalue=hash (buf);
			
			spp=&(hashtable [hashvalue]);

			for (;;)
			{
				if (*spp==NULL)
				{
					*spp=*ospp=(wordseq_t *)myalloc(sizeof (wordseq_t));
					(*spp)->next=NULL;
					(*spp)->next_in_order=NULL;
					(void **)ospp=&((*spp)->next_in_order);
					(*spp)->count=1;
					(*spp)->string=myalloc (strlen(buf)+1);
					strcpy ((*spp)->string, buf);
					break;
				}
				if (strcmp ((*spp)->string, buf)==0)
				{
					(*spp)->count++;
					break;
				}
				(void **)spp=&((*spp)->next);
			}			
		}
	}
}

// this function puts the members of the "prev" lists into 
// hashed lists according to their substrings of length n-1
void
hashsubstrings ()
{
	int i;
	unsigned char hashvalue;
	wordseq_t *wp;			// points to current wordseq in ordered list
	wordseq_t **spp;		// keeps track of next pointer in hash list

	for (i=0; i<256; i++)
		hashtable[i]=NULL;

	puts ("\nhashing substrings...");

	wp=prev_ordered_start_heads;

	while (wp!=NULL)
	{
		strcpy(buf, wp->string);
		i=strlen(buf)-1;
		while (iswordchar(buf[i]))
			i--;
		while (!iswordchar(buf[i]))
			i--;
		buf [i+1]='\0';
		hashvalue=hash (buf);
			
		spp=&(hashtable [hashvalue]);

		for (;;)
		{
			if (*spp==NULL)
			{
				*spp=wp;
				wp->next=NULL;
				break;
			}
			(void **)spp=&((*spp)->next);
		}
		wp=wp->next_in_order;
	}

	wp=prev_ordered_start_tails;

	while (wp!=NULL)
	{
		strcpy(buf, wp->string);
		i=0;
		while (iswordchar(buf[i]))
			i++;
		while (!iswordchar(buf[i]))
			i++;
		hashvalue=hash(buf+i);
			
		spp=&(hashtable [hashvalue]);

		for (;;)
		{
			if (*spp==NULL)
			{
				*spp=wp;
				wp->next=NULL;
				break;
			}
			(void **)spp=&((*spp)->next);
		}			
		wp=wp->next_in_order;
	}
}


void
outputstrings (unsigned int n)
{
	unsigned int freq, maxfreq;
	wordseq_t *sp;

	maxfreq=0;

	sp=ordered_start;
	for (;;)
	{
		if (sp==NULL)
			break;
		if (sp->count>maxfreq)
			maxfreq=sp->count;
		sp=sp->next_in_order;
	}

	printf ("max number of occurrences of any string of %i words: %i\n", n, maxfreq );

	printf ("writing results to file");

	for (freq=maxfreq; freq>4; freq--)	// do not emit any less frequent substrings than 5
	{
		printf(".");

		sp=ordered_start;

		for (;;)
		{
			if (sp==NULL)
				break;
			if (sp->count==freq)
			{
				if (!justasubstring(sp->string, sp->count))
					fprintf(outfile, "[%5i] %s\n", sp->count, sp->string);
			}
			sp=sp->next_in_order;
		}
	}
}

// this function checks if the given string occurs in a string with n+1 
// words that has the same occurrence count. 
int justasubstring(char *string, unsigned int count)
{
	wordseq_t *wp;

	wp=hashtable[hash(string)];

	for (;;)
	{
		if (wp==NULL)
			return (0);	// not found
		if (strstr(wp->string, string)!=NULL) // found
		{
			if (count==wp->count)
				return (1);
			else
				return (0); // string is a substring of more than one string
		}
		wp=wp->next;
	}
}

// this function clones an ordered list of wordsequences.
// note that the strings they refer to are not copied.
void clonelist (wordseq_t *sourcep, wordseq_t **targetpp)
{
	while (sourcep!=NULL)
	{
		*targetpp=(wordseq_t *)myalloc(sizeof (wordseq_t));
		(*targetpp)->next_in_order=NULL;
		(*targetpp)->string=sourcep->string;
		(*targetpp)->count=sourcep->count;
		(void **)targetpp=&((*targetpp)->next_in_order);
		sourcep=sourcep->next_in_order;
	}
}

// this function cleans up the "prev" lists
void cleanup()
{
	wordseq_t *curp, *nextp;

	curp=prev_ordered_start_heads;
	for (;;)
	{
		if (curp==NULL)	
			break;
		nextp=curp->next_in_order;
		heapused-=(strlen(curp->string)+1+sizeof(wordseq_t)+16);
		free (curp->string);
		free (curp);
		curp=nextp;
	}
	prev_ordered_start_heads=NULL;

	curp=prev_ordered_start_tails;
	for (;;)
	{
		if (curp==NULL)	
			break;
		nextp=curp->next_in_order;
		heapused-=(sizeof(wordseq_t)+16);
		free (curp);
		curp=nextp;
	}
	prev_ordered_start_tails=NULL;

}


#define ROTATE(v,q) \
   (v) = ((v) << (q)) | (((v) >> (32 - q)) & ((1 << (q))-1));

#define ROTATE_LEN 5

int hash(const char * word)
{
    int i;
    long  hv = 0;
    for (i=0; i < 4  &&  *word != 0; i++)
	hv = (hv << 8) | (*word++);
    while (*word != 0) {
      ROTATE(hv,ROTATE_LEN);
      hv ^= (*word++);
    }
    return (hv&0xff);
}



// a wrapper for malloc with error check and tracking of heap size used
void *myalloc (unsigned int size)
{
	void *result;

	if ((result=malloc(size))==NULL)
	{
		puts ("ERROR: malloc returned NULL");
		exit (1);
	}
	heapused+=size+16; // estimated overhead of malloc: 16 bytes
	return (result);
}

