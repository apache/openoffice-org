//----------------------------------------------------------------------
// onlystrings.c
// (c) 2002 S. Brouwer (simonbr@openoffice.org)
// This software is free to distribute, modify etc. 
// provided that this copyright message is preserved in it.
//----------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include <process.h>

#define BUFSIZE 0x10000

void
onlystrings (void); 

FILE *infile, *infile2, *outfile;

int line, pos; 

char buf[BUFSIZE];
char infilepath[1024]; 
char outfilepath[1024]; 

void
main (int argc, char *argv[])
{
	if (argc!=3)
	{
		puts("usage: ONLYSTRINGS infile outfile\n");
		exit(1);
	}

	if ((infile = fopen(argv[1], "rt"))== NULL)
	{
		printf("Error: Cannot open input file %s\n", argv[1]);
		exit (1);
	}

	if ((outfile = fopen(argv[2], "wt"))== NULL)
	{
		printf("Error: Cannot open output file %s\n", argv[2]);
		exit (1);
	}

	onlystrings ();

	fclose(infile);
	fclose(outfile);
	exit (0);
}


void
onlystrings (void)
{
	for (;;)
	{
		fgets(buf, BUFSIZE-2, infile);
		if (feof (infile))
			return;

		if (strncmp("****", buf, 4)==0)
		{
			fgets(buf, BUFSIZE-2, infile);
			if (feof (infile))
				return;

			fputs (buf, outfile);
		}
	}
}