/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM k:/localcws/src/moz/wntmsci10.pro/misc/build/mozilla/js/src/xpconnect/idl/nsIJSRuntimeService.idl
 */

#ifndef __gen_nsIJSRuntimeService_h__
#define __gen_nsIJSRuntimeService_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIJSRuntimeService */
#define NS_IJSRUNTIMESERVICE_IID_STR "dcfbb49c-1dd1-11b2-9f39-935aef484817"

#define NS_IJSRUNTIMESERVICE_IID \
  {0xdcfbb49c, 0x1dd1, 0x11b2, \
    { 0x9f, 0x39, 0x93, 0x5a, 0xef, 0x48, 0x48, 0x17 }}

class NS_NO_VTABLE nsIJSRuntimeService : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IJSRUNTIMESERVICE_IID)

  /* readonly attribute JSRuntime runtime; */
  NS_IMETHOD GetRuntime(JSRuntime * *aRuntime) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIJSRUNTIMESERVICE \
  NS_IMETHOD GetRuntime(JSRuntime * *aRuntime); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIJSRUNTIMESERVICE(_to) \
  NS_IMETHOD GetRuntime(JSRuntime * *aRuntime) { return _to GetRuntime(aRuntime); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIJSRUNTIMESERVICE(_to) \
  NS_IMETHOD GetRuntime(JSRuntime * *aRuntime) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetRuntime(aRuntime); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsJSRuntimeService : public nsIJSRuntimeService
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIJSRUNTIMESERVICE

  nsJSRuntimeService();

private:
  ~nsJSRuntimeService();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsJSRuntimeService, nsIJSRuntimeService)

nsJSRuntimeService::nsJSRuntimeService()
{
  /* member initializers and constructor code */
}

nsJSRuntimeService::~nsJSRuntimeService()
{
  /* destructor code */
}

/* readonly attribute JSRuntime runtime; */
NS_IMETHODIMP nsJSRuntimeService::GetRuntime(JSRuntime * *aRuntime)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIJSRuntimeService_h__ */
