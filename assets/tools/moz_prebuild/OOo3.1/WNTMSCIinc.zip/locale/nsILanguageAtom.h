/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM k:/localcws/src/moz/wntmsci10.pro/misc/build/mozilla/intl/locale/idl/nsILanguageAtom.idl
 */

#ifndef __gen_nsILanguageAtom_h__
#define __gen_nsILanguageAtom_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_nsIAtom_h__
#include "nsIAtom.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsILanguageAtom */
#define NS_ILANGUAGEATOM_IID_STR "a6cf911e-15b3-11d2-932e-00805f8add32"

#define NS_ILANGUAGEATOM_IID \
  {0xa6cf911e, 0x15b3, 0x11d2, \
    { 0x93, 0x2e, 0x00, 0x80, 0x5f, 0x8a, 0xdd, 0x32 }}

class NS_NO_VTABLE nsILanguageAtom : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_ILANGUAGEATOM_IID)

  /* readonly attribute wstring language; */
  NS_IMETHOD GetLanguage(PRUnichar * *aLanguage) = 0;

  /* readonly attribute nsIAtom languageGroup; */
  NS_IMETHOD GetLanguageGroup(nsIAtom * *aLanguageGroup) = 0;

  /* boolean LanguageIs (in wstring aLanguage); */
  NS_IMETHOD LanguageIs(const PRUnichar *aLanguage, PRBool *_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSILANGUAGEATOM \
  NS_IMETHOD GetLanguage(PRUnichar * *aLanguage); \
  NS_IMETHOD GetLanguageGroup(nsIAtom * *aLanguageGroup); \
  NS_IMETHOD LanguageIs(const PRUnichar *aLanguage, PRBool *_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSILANGUAGEATOM(_to) \
  NS_IMETHOD GetLanguage(PRUnichar * *aLanguage) { return _to GetLanguage(aLanguage); } \
  NS_IMETHOD GetLanguageGroup(nsIAtom * *aLanguageGroup) { return _to GetLanguageGroup(aLanguageGroup); } \
  NS_IMETHOD LanguageIs(const PRUnichar *aLanguage, PRBool *_retval) { return _to LanguageIs(aLanguage, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSILANGUAGEATOM(_to) \
  NS_IMETHOD GetLanguage(PRUnichar * *aLanguage) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLanguage(aLanguage); } \
  NS_IMETHOD GetLanguageGroup(nsIAtom * *aLanguageGroup) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetLanguageGroup(aLanguageGroup); } \
  NS_IMETHOD LanguageIs(const PRUnichar *aLanguage, PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->LanguageIs(aLanguage, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsLanguageAtom : public nsILanguageAtom
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSILANGUAGEATOM

  nsLanguageAtom();

private:
  ~nsLanguageAtom();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsLanguageAtom, nsILanguageAtom)

nsLanguageAtom::nsLanguageAtom()
{
  /* member initializers and constructor code */
}

nsLanguageAtom::~nsLanguageAtom()
{
  /* destructor code */
}

/* readonly attribute wstring language; */
NS_IMETHODIMP nsLanguageAtom::GetLanguage(PRUnichar * *aLanguage)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsIAtom languageGroup; */
NS_IMETHODIMP nsLanguageAtom::GetLanguageGroup(nsIAtom * *aLanguageGroup)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean LanguageIs (in wstring aLanguage); */
NS_IMETHODIMP nsLanguageAtom::LanguageIs(const PRUnichar *aLanguage, PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsILanguageAtom_h__ */
