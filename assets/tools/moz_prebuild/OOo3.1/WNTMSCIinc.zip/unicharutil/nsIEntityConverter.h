/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM k:/localcws/src/moz/wntmsci10.pro/misc/build/mozilla/intl/unicharutil/idl/nsIEntityConverter.idl
 */

#ifndef __gen_nsIEntityConverter_h__
#define __gen_nsIEntityConverter_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
// {8C4506A1-55E6-11d3-91D9-00105AA3F7DC}
#define NS_ENTITYCONVERTER_CID { 0x8c4506a1, 0x55e6, 0x11d3, {0x91, 0xd9, 0x0, 0x10, 0x5a, 0xa3, 0xf7, 0xdc}}
#define NS_ENTITYCONVERTER_CONTRACTID "@mozilla.org/intl/entityconverter;1"

/* starting interface:    nsIEntityConverter */
#define NS_IENTITYCONVERTER_IID_STR "d14c7111-55e0-11d3-91d9-00105aa3f7dc"

#define NS_IENTITYCONVERTER_IID \
  {0xd14c7111, 0x55e0, 0x11d3, \
    { 0x91, 0xd9, 0x00, 0x10, 0x5a, 0xa3, 0xf7, 0xdc }}

class NS_NO_VTABLE nsIEntityConverter : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IENTITYCONVERTER_IID)

  enum { entityNone = 0U };

  enum { html40Latin1 = 1U };

  enum { html40Symbols = 2U };

  enum { html40Special = 4U };

  enum { transliterate = 8U };

  enum { mathml20 = 16U };

  enum { html32 = 1U };

  enum { html40 = 7U };

  enum { entityW3C = 23U };

  /* string ConvertToEntity (in wchar character, in unsigned long entityVersion); */
  NS_IMETHOD ConvertToEntity(PRUnichar character, PRUint32 entityVersion, char **_retval) = 0;

  /* wstring ConvertToEntities (in wstring inString, in unsigned long entityVersion); */
  NS_IMETHOD ConvertToEntities(const PRUnichar *inString, PRUint32 entityVersion, PRUnichar **_retval) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIENTITYCONVERTER \
  NS_IMETHOD ConvertToEntity(PRUnichar character, PRUint32 entityVersion, char **_retval); \
  NS_IMETHOD ConvertToEntities(const PRUnichar *inString, PRUint32 entityVersion, PRUnichar **_retval); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIENTITYCONVERTER(_to) \
  NS_IMETHOD ConvertToEntity(PRUnichar character, PRUint32 entityVersion, char **_retval) { return _to ConvertToEntity(character, entityVersion, _retval); } \
  NS_IMETHOD ConvertToEntities(const PRUnichar *inString, PRUint32 entityVersion, PRUnichar **_retval) { return _to ConvertToEntities(inString, entityVersion, _retval); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIENTITYCONVERTER(_to) \
  NS_IMETHOD ConvertToEntity(PRUnichar character, PRUint32 entityVersion, char **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ConvertToEntity(character, entityVersion, _retval); } \
  NS_IMETHOD ConvertToEntities(const PRUnichar *inString, PRUint32 entityVersion, PRUnichar **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ConvertToEntities(inString, entityVersion, _retval); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsEntityConverter : public nsIEntityConverter
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIENTITYCONVERTER

  nsEntityConverter();

private:
  ~nsEntityConverter();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsEntityConverter, nsIEntityConverter)

nsEntityConverter::nsEntityConverter()
{
  /* member initializers and constructor code */
}

nsEntityConverter::~nsEntityConverter()
{
  /* destructor code */
}

/* string ConvertToEntity (in wchar character, in unsigned long entityVersion); */
NS_IMETHODIMP nsEntityConverter::ConvertToEntity(PRUnichar character, PRUint32 entityVersion, char **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* wstring ConvertToEntities (in wstring inString, in unsigned long entityVersion); */
NS_IMETHODIMP nsEntityConverter::ConvertToEntities(const PRUnichar *inString, PRUint32 entityVersion, PRUnichar **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIEntityConverter_h__ */
